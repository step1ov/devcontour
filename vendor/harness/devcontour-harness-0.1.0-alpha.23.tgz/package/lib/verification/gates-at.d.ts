import { type EvidenceRecord, type ExecutionPolicy } from '../contracts/index.ts';
import { type Boundary } from './gates.ts';
type Repo = ExecutionPolicy['repositories'][number];
/** Что нужно проверке на SHA от controller (как у эксперимента выполнимости). */
export interface GatesAtContext {
    policy: ExecutionPolicy;
    /** Каталог состояния: здесь логи, а при прежнем размещении — и рабочее дерево со снимками. */
    stateDir: string;
    /**
     * Корень рабочего дерева и снимков зависимостей проверки
     * (`<checkoutRoot>/<repositoryId>/gates-at/<id>`). Без него —
     * `chooseCheckoutRoot` по каталогу состояния и репозиториям политики.
     */
    checkoutRoot?: string;
    repoPath(repo: Repo): string;
    /** Закрытое проверке и открытое внутри него — та же граница, что у gates попыток. */
    boundary(): Boundary;
    environment?: NodeJS.ProcessEnv;
    resourceDatabase?: string;
}
export interface GatesAtInput {
    /** Идентификатор проверки: `runId` её evidence и `DEVCONTOUR_RUN_ID` gates. */
    id?: string;
    repositoryId: string;
    /** Проверяемый коммит; evidence привязано к нему. */
    sha: string;
    /** Gates профиля; их предпосылки (`dependsOn`) добавляются и идут первыми. */
    gates: string[];
    /**
     * Запись evidence под fencing хоста. Бросок прерывает проверку: хост,
     * утративший право записи, результата не получает.
     */
    record(evidence: EvidenceRecord): void;
    signal?: AbortSignal;
}
export interface GatesAtResult {
    id: string;
    sha: string;
    /** Исполненные gates в порядке исполнения (с предпосылками). */
    gates: string[];
    evidence: EvidenceRecord[];
    /** Первый непрошедший gate и причина (то же, что `failures[0]`). */
    failure?: {
        gate: string;
        message: string;
    };
    /**
     * Все непрошедшие gates. Провал не останавливает проверку: исполняются все
     * названные gates, кроме тех, чья предпосылка не прошла (они названы здесь
     * с этой причиной и evidence не получают).
     */
    failures: {
        gate: string;
        message: string;
    }[];
}
/**
 * Gates компонента на закреплённом SHA вне попытки — тем же исполнением, что
 * integration поручения: отдельное рабочее дерево на SHA, снимки зависимостей
 * компонента, ресурсы gates, lifecycle и prepare компонента, окружение фазы
 * `integration`, песочница проверок и `runGate`. Каждое evidence (вида `test`,
 * фазы `integration`, на этом SHA) записывается через `record` хоста до
 * следующего gate. После gates дерево обязано остаться на SHA без изменений.
 * Рабочее дерево и снимки убираются при любом исходе.
 *
 * Нужна приёмке набора поручений, когда часть gates профиля не исполнило ни
 * одно поручение: суженные области задач — законная декомпозиция, а полный
 * профиль проверяется один раз на итоговом SHA.
 */
export declare function runGatesAt(ctx: GatesAtContext, input: GatesAtInput): Promise<GatesAtResult>;
export {};
