import { type ExecutionPolicy, type ExecutionView, type Spike } from '../contracts/index.ts';
import type { Engine } from '../engine/engine.ts';
import { type Boundary } from './gates.ts';
/** Что нужно эксперименту от controller. */
export interface SpikeContext {
    engine: Engine;
    policy: ExecutionPolicy;
    stateDir: string;
    repoPath(repo: ExecutionPolicy['repositories'][number]): string;
    /** Закрытое проверке и открытое внутри него. */
    boundary(): Boundary;
    /**
     * Каталог рабочего дерева вида `kind` (корень вне дерева, `checkout-root.ts`);
     * без него — прежнее место в каталоге состояния.
     */
    checkout?(repositoryId: string, kind: string, id: string): string;
    environment?: NodeJS.ProcessEnv;
}
/** Эксперимент репозитория по ID или undefined. */
export declare function spikeOf(view: ExecutionView, repositoryId: string, id: string): {
    id: string;
    repositoryId: string;
    sha: string;
    command: string[];
    seed: number;
    sizes: number[];
    timeoutMs: number;
    question: string;
    results: {
        size: number;
        ms: number;
        outcome: "error" | "ok" | "timeout";
        exitCode: number;
    }[];
    outcome: "failed" | "feasible" | "inconclusive";
    limits: string;
    environment: {
        platform: string;
        arch: string;
        node: string;
        cpus: number;
        isolation: string;
    };
    at: string;
    digest: string;
} | undefined;
/** Эксперименты репозитория. */
export declare function spikesOf(view: ExecutionView, repositoryId?: string): {
    id: string;
    repositoryId: string;
    sha: string;
    command: string[];
    seed: number;
    sizes: number[];
    timeoutMs: number;
    question: string;
    results: {
        size: number;
        ms: number;
        outcome: "error" | "ok" | "timeout";
        exitCode: number;
    }[];
    outcome: "failed" | "feasible" | "inconclusive";
    limits: string;
    environment: {
        platform: string;
        arch: string;
        node: string;
        cpus: number;
        isolation: string;
    };
    at: string;
    digest: string;
}[];
/**
 * Ограниченный эксперимент выполнимости: команда на закреплённом SHA в
 * отдельном worktree, для каждого размера — под той же изоляцией, что gates,
 * с пределом времени. После таймаута большие размеры не запускаются: они
 * ничего не добавят к выводу. Результат с версиями среды и пределами вывода
 * сохраняется под digest; ссылка тяжёлого обязательства закрепляет этот digest.
 */
export declare function runSpike(ctx: SpikeContext, raw: unknown): Promise<Spike>;
