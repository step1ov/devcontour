import { z } from 'zod';
import { type ContractArtifact, type ExecutionPolicy } from '../contracts/index.ts';
import { type CorpusStore } from './corpus.ts';
import { type Boundary } from './gates.ts';
/**
 * Быстрый маршрут: подтверждённый пример становится обязательным случаем.
 *
 * Пример reviewer или ведущего — гипотеза. Controller сам запускает
 * закреплённый эталон на этом входе (режим одного случая того же checker,
 * что исполняет gate), повторяет проверку реализации на исходном дефектном
 * SHA и требует воспроизводимого расхождения. Ответ эталона, а не слова
 * reviewer, становится ожиданием. Команда из воспроизведения не исполняется
 * никогда; данные входа не интерпретируются как shell.
 *
 * Маршрут только добавляет данные под тем же checker/oracle, той же областью
 * и правилами ответа. Удаление случая, замена ожидания, допуск, покрытие,
 * новый checker или команда — обычное изменение договора проверки.
 */
export declare const fastPathChanges: readonly ["add", "remove", "replace-expected", "tolerance", "coverage", "checker", "command"];
export declare const caseInputSchema: z.ZodObject<{
    workId: z.ZodString;
    property: z.ZodString;
    input: z.ZodString;
    expected: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    actual: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    reproductionId: z.ZodOptional<z.ZodString>;
    sourceSha: z.ZodOptional<z.ZodString>;
    sourceRunId: z.ZodOptional<z.ZodString>;
    adopt: z.ZodOptional<z.ZodArray<z.ZodString>>;
    key: z.ZodString;
    change: z.ZodDefault<z.ZodEnum<{
        command: "command";
        tolerance: "tolerance";
        coverage: "coverage";
        add: "add";
        remove: "remove";
        "replace-expected": "replace-expected";
        checker: "checker";
    }>>;
    origin: z.ZodDefault<z.ZodEnum<{
        review: "review";
        agent: "agent";
        operator: "operator";
        lead: "lead";
    }>>;
    runtime: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type CaseRequest = z.input<typeof caseInputSchema>;
/** Точка после записи версии и до принятия: тест моделирует в ней сбой. */
export declare const caseHooks: {
    afterRecord: () => void;
};
/** Что нужно подтверждению от controller. */
export interface ConfirmContext {
    corpus: CorpusStore;
    policy: ExecutionPolicy;
    stateDir: string;
    repoPath(repo: ExecutionPolicy['repositories'][number]): string;
    /** Закрытое проверке и открытое внутри него. */
    boundary(): Boundary;
    /**
     * Каталог рабочего дерева вида `kind` (корень вне дерева, `checkout-root.ts`);
     * без него — прежнее место в каталоге состояния.
     */
    checkout?(repositoryId: string, kind: string, id: string): string;
    /** Источник переменных окружения (по умолчанию — процесс). */
    environment?: NodeJS.ProcessEnv;
}
/** Изменённые закреплённые файлы на SHA: checker должен быть утверждённой редакцией. */
export declare function staleArtifacts(repoPath: string, sha: string, artifacts: ContractArtifact[]): Promise<string[]>;
export declare function submitCase(ctx: ConfirmContext, raw: unknown): Promise<{
    suite: string;
    repeated: boolean;
    decision: {
        id: string;
        property: string;
        input: string;
        inputHash: string;
        outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
        reason: string;
        source: {
            sha: string;
            runId?: string | undefined;
            taskId?: string | undefined;
        };
        origin: {
            kind: "review" | "agent" | "operator" | "lead";
            runtime?: string | undefined;
        };
        at: string;
        key?: string | undefined;
        claimed?: {
            expected: string | null;
            actual: string | null;
            reproduction?: string | undefined;
        } | undefined;
        observed?: {
            repeats: number;
            durationsMs: number[];
            expected?: string | undefined;
            actual?: string | undefined;
            equal?: boolean | undefined;
        } | undefined;
        method?: {
            gate: string;
            artifacts: {
                path: string;
                blob: string;
            }[];
            contract: string;
            basis: string;
            command?: string[] | undefined;
        } | undefined;
        caseId?: string | undefined;
        version?: number | undefined;
    };
    version: {
        number: number;
        digest: string;
        cases: number;
    } | null;
    adoption: {
        awaitingOperator?: true | undefined;
        id: string;
        status: "completed" | "waiting";
        results: Record<string, string>;
    }[];
}>;
