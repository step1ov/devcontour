/**
 * Где harness создаёт рабочие деревья попыток, снимки зависимостей, деревья
 * переноса базы, проверки на SHA и проверки потребителей.
 *
 * Прежде они лежали в каталоге состояния. При встроенном размещении каталог
 * состояния находится внутри репозитория человека (`<W>/.devcontour-local`),
 * и тогда checkout кандидата оказывался вложен в его рабочее дерево. Песочница
 * закрывает `<W>` целиком и открывает только сам checkout, а инструменты,
 * которые ищут конфигурацию вверх по дереву (browserslist, Metro, postcss,
 * tsconfig, prettier), доходили до `<W>/package.json` и получали EPERM вместо
 * ENOENT. Без песочницы они бы прочитали конфигурацию рабочего дерева
 * человека — кандидат проверялся бы не сам по себе.
 *
 * Поэтому корень рабочих деревьев выбирается так:
 * - корень, заданный хостом (`checkoutRoot`), — как есть;
 * - каталог состояния внутри репозитория политики или внутри закрытого
 *   песочницей пути — каталог кэша пользователя вне дерева: macOS
 *   `~/Library/Caches/devcontour-harness/<hash>`, Linux
 *   `$XDG_CACHE_HOME/devcontour-harness/<hash>` или
 *   `~/.cache/devcontour-harness/<hash>`; `<hash>` — устойчивый хэш
 *   настоящего пути каталога состояния;
 * - иначе — прежнее место (отдельное размещение не меняется).
 *
 * Кэш на другом томе, чем репозиторий, ломает жёсткие ссылки и reflink
 * менеджеров пакетов (pnpm store): тогда корень остаётся прежним, а причина
 * видна в `note` (doctor хоста её показывает).
 */
export type CheckoutPlacement = 'configured' | 'in-place' | 'cache' | 'cross-volume';
export interface CheckoutRoot {
    /** Корень вне каталога состояния; без него — прежнее место. */
    root?: string;
    placement: CheckoutPlacement;
    /** Пояснение для диагностики: почему корень такой. */
    note?: string;
}
export interface CheckoutRootInput {
    /** Каталоги состояния (общий и каталоги попыток репозиториев); первый задаёт хэш. */
    stateDirs: string[];
    /** Пути репозиториев политики. */
    repositories: string[];
    /** Что ещё закрыто песочницей (учётные данные, каталоги хоста). */
    hidden?: string[];
    /** Корень, заданный хостом. */
    configured?: string;
    platform?: NodeJS.Platform;
    env?: NodeJS.ProcessEnv;
    home?: string;
    /** Номер тома пути (`stat.dev`); тест подменяет его. */
    device?: (path: string) => number | undefined;
}
/** Настоящий путь и для ещё не созданного каталога: от ближайшего существующего предка. */
export declare function realish(path: string): string;
/** Каталог кэша пользователя для рабочих деревьев (без хэша). */
export declare function checkoutCacheBase(platform?: NodeJS.Platform, env?: NodeJS.ProcessEnv, home?: string): string;
/** Устойчивый хэш каталога состояния: тот же путь — тот же корень. */
export declare const stateHash: (stateDir: string) => string;
export declare function chooseCheckoutRoot(input: CheckoutRootInput): CheckoutRoot;
/**
 * Каталог рабочего дерева вида `kind` (`worktrees`, `dependencies`,
 * `gates-at`…). Корень вне дерева: `<root>/<repositoryId>/<kind>/…`; иначе —
 * прежний путь `legacy`.
 */
export declare function checkoutPath(choice: CheckoutRoot, legacy: string, repositoryId: string, kind: string, ...rest: string[]): string;
/**
 * Закрыть рабочие деревья под корнями `roots` поэлементно: открытые пути
 * (`open`: свой checkout, снимки зависимостей) и их предки остаются открыты,
 * всё остальное под корнем (чужие попытки) закрыто. Закрыть корень целиком
 * нельзя: инструмент, ищущий конфигурацию вверх от checkout, получил бы EPERM
 * на `stat` несуществующего файла в предке. Элемент, появившийся после
 * построения политики (параллельная попытка), не закрыт — граница подхода,
 * как у codex; каталоги состояния и репозитории закрыты целиком.
 */
export declare function closedCheckouts(roots: string[], open: string[]): string[];
