import { z } from 'zod';
export declare const promiseKinds: readonly ["functional", "accuracy", "optimality", "completeness", "performance", "invariant", "other"];
/** Вычислительные обещания: без независимого способа проверки их не утверждают. */
export declare const strongPromises: ReadonlySet<string>;
/**
 * Проверка по закреплённым эталонным наборам (`verification: 'reference'`).
 *
 * Ответы независимого эталона (решатель, полный перебор, таблица DP)
 * получены заранее, сверены с другим способом на семействах входов и
 * закреплены артефактами контракта. Gate сверяет реализацию с наборами и
 * отчитывается тем же отчётом свойств: число проверенных входов по свойству
 * и по семействам. Каждый набор принадлежит одному gate: его минимум и
 * минимумы семейств — доля этого gate в покрытии обязательства. Обобщения за
 * пределы наборов такой способ не доказывает — это называет `gaps`.
 */
export declare const referenceSchema: z.ZodObject<{
    oracle: z.ZodObject<{
        description: z.ZodString;
        limits: z.ZodString;
    }, z.core.$strict>;
    crossChecks: z.ZodArray<z.ZodObject<{
        family: z.ZodString;
        against: z.ZodString;
        matches: z.ZodNumber;
        total: z.ZodNumber;
        artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    sets: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        artifacts: z.ZodArray<z.ZodString>;
        minCases: z.ZodNumber;
        families: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            minCases: z.ZodNumber;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    gaps: z.ZodString;
}, z.core.$strict>;
export type ReferenceVerification = z.infer<typeof referenceSchema>;
export declare const obligationSchema: z.ZodObject<{
    property: z.ZodString;
    requirements: z.ZodArray<z.ZodString>;
    promise: z.ZodEnum<{
        functional: "functional";
        accuracy: "accuracy";
        optimality: "optimality";
        completeness: "completeness";
        performance: "performance";
        invariant: "invariant";
        other: "other";
    }>;
    explanation: z.ZodOptional<z.ZodString>;
    domain: z.ZodObject<{
        inputs: z.ZodString;
        bounds: z.ZodString;
        units: z.ZodOptional<z.ZodString>;
        invalid: z.ZodString;
    }, z.core.$strict>;
    answer: z.ZodObject<{
        rules: z.ZodString;
        ties: z.ZodOptional<z.ZodString>;
        rounding: z.ZodOptional<z.ZodString>;
        tolerance: z.ZodOptional<z.ZodString>;
        refusals: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    method: z.ZodObject<{
        kind: z.ZodEnum<{
            scenario: "scenario";
            invariant: "invariant";
            other: "other";
            oracle: "oracle";
            certificate: "certificate";
            analytic: "analytic";
        }>;
        description: z.ZodString;
        applicability: z.ZodString;
        artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>;
    coverage: z.ZodObject<{
        families: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                typical: "typical";
                boundary: "boundary";
                adversarial: "adversarial";
            }>;
            description: z.ZodString;
            minCases: z.ZodNumber;
        }, z.core.$strict>>;
        minCases: z.ZodNumber;
        corpus: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>;
    resources: z.ZodObject<{
        subject: z.ZodString;
        oracle: z.ZodString;
        benchmark: z.ZodOptional<z.ZodObject<{
            method: z.ZodString;
            environment: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
    verification: z.ZodOptional<z.ZodEnum<{
        property: "property";
        reference: "reference";
    }>>;
    reference: z.ZodOptional<z.ZodObject<{
        oracle: z.ZodObject<{
            description: z.ZodString;
            limits: z.ZodString;
        }, z.core.$strict>;
        crossChecks: z.ZodArray<z.ZodObject<{
            family: z.ZodString;
            against: z.ZodString;
            matches: z.ZodNumber;
            total: z.ZodNumber;
            artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        sets: z.ZodArray<z.ZodObject<{
            gate: z.ZodString;
            artifacts: z.ZodArray<z.ZodString>;
            minCases: z.ZodNumber;
            families: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                minCases: z.ZodNumber;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
        gaps: z.ZodString;
    }, z.core.$strict>>;
    hard: z.ZodDefault<z.ZodBoolean>;
    feasibility: z.ZodOptional<z.ZodObject<{
        spike: z.ZodString;
        digest: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type Obligation = z.infer<typeof obligationSchema>;
export declare const checkDeclarationSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    gate: z.ZodString;
    obligations: z.ZodArray<z.ZodObject<{
        property: z.ZodString;
        requirements: z.ZodArray<z.ZodString>;
        promise: z.ZodEnum<{
            functional: "functional";
            accuracy: "accuracy";
            optimality: "optimality";
            completeness: "completeness";
            performance: "performance";
            invariant: "invariant";
            other: "other";
        }>;
        explanation: z.ZodOptional<z.ZodString>;
        domain: z.ZodObject<{
            inputs: z.ZodString;
            bounds: z.ZodString;
            units: z.ZodOptional<z.ZodString>;
            invalid: z.ZodString;
        }, z.core.$strict>;
        answer: z.ZodObject<{
            rules: z.ZodString;
            ties: z.ZodOptional<z.ZodString>;
            rounding: z.ZodOptional<z.ZodString>;
            tolerance: z.ZodOptional<z.ZodString>;
            refusals: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        method: z.ZodObject<{
            kind: z.ZodEnum<{
                scenario: "scenario";
                invariant: "invariant";
                other: "other";
                oracle: "oracle";
                certificate: "certificate";
                analytic: "analytic";
            }>;
            description: z.ZodString;
            applicability: z.ZodString;
            artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>;
        coverage: z.ZodObject<{
            families: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    typical: "typical";
                    boundary: "boundary";
                    adversarial: "adversarial";
                }>;
                description: z.ZodString;
                minCases: z.ZodNumber;
            }, z.core.$strict>>;
            minCases: z.ZodNumber;
            corpus: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>;
        resources: z.ZodObject<{
            subject: z.ZodString;
            oracle: z.ZodString;
            benchmark: z.ZodOptional<z.ZodObject<{
                method: z.ZodString;
                environment: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        verification: z.ZodOptional<z.ZodEnum<{
            property: "property";
            reference: "reference";
        }>>;
        reference: z.ZodOptional<z.ZodObject<{
            oracle: z.ZodObject<{
                description: z.ZodString;
                limits: z.ZodString;
            }, z.core.$strict>;
            crossChecks: z.ZodArray<z.ZodObject<{
                family: z.ZodString;
                against: z.ZodString;
                matches: z.ZodNumber;
                total: z.ZodNumber;
                artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            sets: z.ZodArray<z.ZodObject<{
                gate: z.ZodString;
                artifacts: z.ZodArray<z.ZodString>;
                minCases: z.ZodNumber;
                families: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    minCases: z.ZodNumber;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
            gaps: z.ZodString;
        }, z.core.$strict>>;
        hard: z.ZodDefault<z.ZodBoolean>;
        feasibility: z.ZodOptional<z.ZodObject<{
            spike: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    corpus: z.ZodOptional<z.ZodObject<{
        format: z.ZodString;
        extensible: z.ZodBoolean;
        maxCases: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CheckDeclaration = z.infer<typeof checkDeclarationSchema>;
/** Закреплённый файл контракта: путь в репозитории и Git blob его содержимого. */
export declare const contractArtifactSchema: z.ZodObject<{
    path: z.ZodString;
    blob: z.ZodString;
}, z.core.$strict>;
export type ContractArtifact = z.infer<typeof contractArtifactSchema>;
/**
 * Документ контракта. `checks` — договор проверки; `artifacts` — его
 * закреплённые checker/oracle/generator в репозитории `repositoryId`. Ревью
 * контракта относится к digest всего документа: смена договора проверки или
 * закреплённого файла — новый digest и новое ревью.
 */
export declare const contractDocumentSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    repositoryId: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    content: z.ZodString;
    artifacts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        blob: z.ZodString;
    }, z.core.$strict>>>;
    checks: z.ZodOptional<z.ZodObject<{
        version: z.ZodLiteral<1>;
        gate: z.ZodString;
        obligations: z.ZodArray<z.ZodObject<{
            property: z.ZodString;
            requirements: z.ZodArray<z.ZodString>;
            promise: z.ZodEnum<{
                functional: "functional";
                accuracy: "accuracy";
                optimality: "optimality";
                completeness: "completeness";
                performance: "performance";
                invariant: "invariant";
                other: "other";
            }>;
            explanation: z.ZodOptional<z.ZodString>;
            domain: z.ZodObject<{
                inputs: z.ZodString;
                bounds: z.ZodString;
                units: z.ZodOptional<z.ZodString>;
                invalid: z.ZodString;
            }, z.core.$strict>;
            answer: z.ZodObject<{
                rules: z.ZodString;
                ties: z.ZodOptional<z.ZodString>;
                rounding: z.ZodOptional<z.ZodString>;
                tolerance: z.ZodOptional<z.ZodString>;
                refusals: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            method: z.ZodObject<{
                kind: z.ZodEnum<{
                    scenario: "scenario";
                    invariant: "invariant";
                    other: "other";
                    oracle: "oracle";
                    certificate: "certificate";
                    analytic: "analytic";
                }>;
                description: z.ZodString;
                applicability: z.ZodString;
                artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>;
            coverage: z.ZodObject<{
                families: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        typical: "typical";
                        boundary: "boundary";
                        adversarial: "adversarial";
                    }>;
                    description: z.ZodString;
                    minCases: z.ZodNumber;
                }, z.core.$strict>>;
                minCases: z.ZodNumber;
                corpus: z.ZodDefault<z.ZodBoolean>;
            }, z.core.$strict>;
            resources: z.ZodObject<{
                subject: z.ZodString;
                oracle: z.ZodString;
                benchmark: z.ZodOptional<z.ZodObject<{
                    method: z.ZodString;
                    environment: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            verification: z.ZodOptional<z.ZodEnum<{
                property: "property";
                reference: "reference";
            }>>;
            reference: z.ZodOptional<z.ZodObject<{
                oracle: z.ZodObject<{
                    description: z.ZodString;
                    limits: z.ZodString;
                }, z.core.$strict>;
                crossChecks: z.ZodArray<z.ZodObject<{
                    family: z.ZodString;
                    against: z.ZodString;
                    matches: z.ZodNumber;
                    total: z.ZodNumber;
                    artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                sets: z.ZodArray<z.ZodObject<{
                    gate: z.ZodString;
                    artifacts: z.ZodArray<z.ZodString>;
                    minCases: z.ZodNumber;
                    families: z.ZodDefault<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        minCases: z.ZodNumber;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
                gaps: z.ZodString;
            }, z.core.$strict>>;
            hard: z.ZodDefault<z.ZodBoolean>;
            feasibility: z.ZodOptional<z.ZodObject<{
                spike: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        corpus: z.ZodOptional<z.ZodObject<{
            format: z.ZodString;
            extensible: z.ZodBoolean;
            maxCases: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ContractDocument = z.infer<typeof contractDocumentSchema>;
/**
 * Ограниченный эксперимент выполнимости (spike).
 *
 * Невыполнимые или неизмеримые обязательства обнаруживались после серии
 * попыток реализации. Для тяжёлого точного алгоритма или жёсткого времени до
 * реализации запускается короткий эксперимент: команда эталона или прототипа
 * на закреплённом SHA, seed и размеры входов, предел времени. Результат
 * сохраняется с версиями и пределами вывода. Таймаут — `inconclusive` для
 * выбранного способа и бюджета: он не доказывает трудность или
 * невозможность и не даёт права менять требование. Успех на выборке не
 * доказывает верхней границы на любом входе.
 */
export declare const spikeInputSchema: z.ZodObject<{
    repositoryId: z.ZodOptional<z.ZodString>;
    sha: z.ZodOptional<z.ZodString>;
    command: z.ZodArray<z.ZodString>;
    sizes: z.ZodArray<z.ZodNumber>;
    seed: z.ZodDefault<z.ZodNumber>;
    timeoutMs: z.ZodNumber;
    question: z.ZodString;
}, z.core.$strict>;
export type SpikeInput = z.input<typeof spikeInputSchema>;
export declare const spikeSchema: z.ZodObject<{
    id: z.ZodString;
    repositoryId: z.ZodString;
    sha: z.ZodString;
    command: z.ZodArray<z.ZodString>;
    seed: z.ZodNumber;
    sizes: z.ZodArray<z.ZodNumber>;
    timeoutMs: z.ZodNumber;
    question: z.ZodString;
    results: z.ZodArray<z.ZodObject<{
        size: z.ZodNumber;
        ms: z.ZodNumber;
        outcome: z.ZodEnum<{
            error: "error";
            ok: "ok";
            timeout: "timeout";
        }>;
        exitCode: z.ZodNumber;
    }, z.core.$strict>>;
    outcome: z.ZodEnum<{
        failed: "failed";
        feasible: "feasible";
        inconclusive: "inconclusive";
    }>;
    limits: z.ZodString;
    environment: z.ZodObject<{
        platform: z.ZodString;
        arch: z.ZodString;
        node: z.ZodString;
        cpus: z.ZodNumber;
        isolation: z.ZodString;
    }, z.core.$strict>;
    at: z.ZodString;
    digest: z.ZodString;
}, z.core.$strict>;
export type Spike = z.infer<typeof spikeSchema>;
