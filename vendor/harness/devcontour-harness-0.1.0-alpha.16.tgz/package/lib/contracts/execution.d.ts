import { z } from 'zod';
/**
 * Нейтральная модель исполнения — то, что ExecutionStore обязан хранить
 * транзакционно. Формы совпадают с записями задач и попыток DevContour
 * (`Task`/`Run`/`Evidence`): адаптер DevContour отображает их без
 * переименования сохранённых данных (docs/compatibility.md), standalone
 * SQLite хранит ровно эту модель. Схемы нестрогие к *отсутствию*
 * необязательных полей (прежние записи их не содержат), но строгие к их
 * форме и к лишним полям.
 *
 * Продуктовых сущностей (доски, релизы, INTENT, продуктовые согласования)
 * здесь нет: движок их не читает.
 */
export declare const workStatuses: readonly ["draft", "ready", "running", "verifying", "reviewing", "integrating", "done", "failed", "cancelled"];
export declare const workStatusSchema: z.ZodEnum<{
    ready: "ready";
    failed: "failed";
    cancelled: "cancelled";
    draft: "draft";
    running: "running";
    verifying: "verifying";
    reviewing: "reviewing";
    integrating: "integrating";
    done: "done";
}>;
export type WorkStatus = (typeof workStatuses)[number];
export declare const failureKinds: readonly ["provider-auth", "environment", "timeout", "stale-base", "empty-result", "scope-violation", "gate", "review", "review-protocol", "merge", "cancelled", "budget", "unknown"];
export declare const failureKindSchema: z.ZodEnum<{
    gate: "gate";
    unknown: "unknown";
    review: "review";
    environment: "environment";
    cancelled: "cancelled";
    timeout: "timeout";
    "provider-auth": "provider-auth";
    "stale-base": "stale-base";
    "empty-result": "empty-result";
    "scope-violation": "scope-violation";
    "review-protocol": "review-protocol";
    merge: "merge";
    budget: "budget";
}>;
export type FailureKind = (typeof failureKinds)[number];
/** Техническое согласование, привязанное к digest проверенного предложения. */
export declare const technicalApprovalSchema: z.ZodObject<{
    actor: z.ZodEnum<{
        agent: "agent";
        operator: "operator";
    }>;
    authorRuntime: z.ZodOptional<z.ZodEnum<{
        codex: "codex";
        claude: "claude";
        fixture: "fixture";
    }>>;
    reviewerRuntime: z.ZodOptional<z.ZodEnum<{
        codex: "codex";
        claude: "claude";
        fixture: "fixture";
    }>>;
    artifact: z.ZodOptional<z.ZodString>;
    digest: z.ZodOptional<z.ZodString>;
    context: z.ZodOptional<z.ZodObject<{
        digest: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type TechnicalApproval = z.infer<typeof technicalApprovalSchema>;
/** Отчёт генеративной проверки (`version: 1`), форма — как у DevContour. */
export declare const propertyReportSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    seed: z.ZodOptional<z.ZodNumber>;
    properties: z.ZodArray<z.ZodObject<{
        testId: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
            running: "running";
        }>;
        cases: z.ZodNumber;
        families: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodNumber>>;
        error: z.ZodOptional<z.ZodString>;
        current: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
        counterexample: z.ZodOptional<z.ZodObject<{
            original: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            reduced: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
            expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
            actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
            reductionTimedOut: z.ZodOptional<z.ZodBoolean>;
            case: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    corpus: z.ZodOptional<z.ZodObject<{
        digest: z.ZodString;
        executed: z.ZodNumber;
        passed: z.ZodNumber;
        witness: z.ZodString;
        failed: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            property: z.ZodString;
            expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
            actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type PropertyReport = z.infer<typeof propertyReportSchema>;
/** Доказательство генеративной проверки: seed, отчёт, версии договора и уровень. */
export declare const propertyEvidenceSchema: z.ZodObject<{
    seed: z.ZodNumber;
    reproduce: z.ZodString;
    report: z.ZodOptional<z.ZodObject<{
        version: z.ZodLiteral<1>;
        seed: z.ZodOptional<z.ZodNumber>;
        properties: z.ZodArray<z.ZodObject<{
            testId: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
                running: "running";
            }>;
            cases: z.ZodNumber;
            families: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodNumber>>;
            error: z.ZodOptional<z.ZodString>;
            current: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
            counterexample: z.ZodOptional<z.ZodObject<{
                original: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
                reduced: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                reductionTimedOut: z.ZodOptional<z.ZodBoolean>;
                case: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        corpus: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            executed: z.ZodNumber;
            passed: z.ZodNumber;
            witness: z.ZodString;
            failed: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                property: z.ZodString;
                expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    problem: z.ZodOptional<z.ZodString>;
    contracts: z.ZodRecord<z.ZodString, z.ZodString>;
    artifacts: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        blob: z.ZodString;
    }, z.core.$strict>>;
    level: z.ZodOptional<z.ZodEnum<{
        manifest: "manifest";
        legacy: "legacy";
    }>>;
    manifest: z.ZodOptional<z.ZodObject<{
        digest: z.ZodString;
        properties: z.ZodArray<z.ZodString>;
        corpus: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            cases: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    coverage: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
/** Происхождение подтверждённой команды: событие runtime или запуск probe controller. */
export declare const inspectionOriginSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"runtime">;
    runtime: z.ZodString;
    item: z.ZodNullable<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"controller">;
    runId: z.ZodString;
}, z.core.$strict>], "type">;
/**
 * Что reviewer действительно выполнил — по событиям runtime и журналу
 * проверок controller одного вызова reviewer, не по словам модели
 * (docs/review-probes.md). Поля после `reason` появились в alpha.7 и
 * необязательны: записи прежних версий читаются как есть.
 */
export declare const reviewInspectionSchema: z.ZodObject<{
    mode: z.ZodEnum<{
        commands: "commands";
        "diff-only": "diff-only";
    }>;
    source: z.ZodEnum<{
        "codex-events": "codex-events";
        unavailable: "unavailable";
        "controller-probes": "controller-probes";
        "runtime-and-controller": "runtime-and-controller";
    }>;
    commands: z.ZodArray<z.ZodObject<{
        command: z.ZodString;
        exitCode: z.ZodNullable<z.ZodNumber>;
        output: z.ZodString;
        origins: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"runtime">;
            runtime: z.ZodString;
            item: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"controller">;
            runId: z.ZodString;
        }, z.core.$strict>], "type">>>;
        status: z.ZodOptional<z.ZodEnum<{
            error: "error";
            passed: "passed";
            failed: "failed";
            cancelled: "cancelled";
            completed: "completed";
            timeout: "timeout";
        }>>;
        failure: z.ZodOptional<z.ZodEnum<{
            report: "report";
            environment: "environment";
        }>>;
        gate: z.ZodOptional<z.ZodString>;
        note: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    reason: z.ZodNullable<z.ZodString>;
    context: z.ZodOptional<z.ZodObject<{
        attempt: z.ZodString;
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        sha: z.ZodString;
        call: z.ZodNumber;
    }, z.core.$strict>>;
    total: z.ZodOptional<z.ZodNumber>;
    excluded: z.ZodOptional<z.ZodArray<z.ZodObject<{
        runId: z.ZodString;
        status: z.ZodNullable<z.ZodString>;
        reason: z.ZodEnum<{
            "not-started": "not-started";
            "legacy-unconfirmed": "legacy-unconfirmed";
            "foreign-scope": "foreign-scope";
            "unknown-status": "unknown-status";
            unfinished: "unfinished";
            abandoned: "abandoned";
        }>;
    }, z.core.$strict>>>;
    excludedTotal: z.ZodOptional<z.ZodNumber>;
    invalid: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const evidenceFindingSchema: z.ZodObject<{
    severity: z.ZodString;
    message: z.ZodString;
    path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    id: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodEnum<{
        open: "open";
        closed: "closed";
        withdrawn: "withdrawn";
    }>>;
}, z.core.$strict>;
export declare const evidenceRecordSchema: z.ZodObject<{
    id: z.ZodString;
    runId: z.ZodString;
    kind: z.ZodEnum<{
        test: "test";
        review: "review";
    }>;
    phase: z.ZodEnum<{
        candidate: "candidate";
        integration: "integration";
    }>;
    sha: z.ZodString;
    gate: z.ZodString;
    passed: z.ZodBoolean;
    createdAt: z.ZodISODateTime;
    command: z.ZodArray<z.ZodString>;
    exitCode: z.ZodNumber;
    log: z.ZodString;
    digest: z.ZodString;
    summary: z.ZodString;
    consumer: z.ZodOptional<z.ZodString>;
    inspection: z.ZodOptional<z.ZodObject<{
        mode: z.ZodEnum<{
            commands: "commands";
            "diff-only": "diff-only";
        }>;
        source: z.ZodEnum<{
            "codex-events": "codex-events";
            unavailable: "unavailable";
            "controller-probes": "controller-probes";
            "runtime-and-controller": "runtime-and-controller";
        }>;
        commands: z.ZodArray<z.ZodObject<{
            command: z.ZodString;
            exitCode: z.ZodNullable<z.ZodNumber>;
            output: z.ZodString;
            origins: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"runtime">;
                runtime: z.ZodString;
                item: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"controller">;
                runId: z.ZodString;
            }, z.core.$strict>], "type">>>;
            status: z.ZodOptional<z.ZodEnum<{
                error: "error";
                passed: "passed";
                failed: "failed";
                cancelled: "cancelled";
                completed: "completed";
                timeout: "timeout";
            }>>;
            failure: z.ZodOptional<z.ZodEnum<{
                report: "report";
                environment: "environment";
            }>>;
            gate: z.ZodOptional<z.ZodString>;
            note: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        reason: z.ZodNullable<z.ZodString>;
        context: z.ZodOptional<z.ZodObject<{
            attempt: z.ZodString;
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            sha: z.ZodString;
            call: z.ZodNumber;
        }, z.core.$strict>>;
        total: z.ZodOptional<z.ZodNumber>;
        excluded: z.ZodOptional<z.ZodArray<z.ZodObject<{
            runId: z.ZodString;
            status: z.ZodNullable<z.ZodString>;
            reason: z.ZodEnum<{
                "not-started": "not-started";
                "legacy-unconfirmed": "legacy-unconfirmed";
                "foreign-scope": "foreign-scope";
                "unknown-status": "unknown-status";
                unfinished: "unfinished";
                abandoned: "abandoned";
            }>;
        }, z.core.$strict>>>;
        excludedTotal: z.ZodOptional<z.ZodNumber>;
        invalid: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    findings: z.ZodOptional<z.ZodArray<z.ZodObject<{
        severity: z.ZodString;
        message: z.ZodString;
        path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        id: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<{
            open: "open";
            closed: "closed";
            withdrawn: "withdrawn";
        }>>;
    }, z.core.$strict>>>;
    reviewRound: z.ZodOptional<z.ZodObject<{
        version: z.ZodLiteral<1>;
        scope: z.ZodString;
        round: z.ZodNumber;
        call: z.ZodNumber;
        calls: z.ZodNumber;
        protocol: z.ZodEnum<{
            valid: "valid";
            invalid: "invalid";
            unsafe: "unsafe";
        }>;
        expected: z.ZodArray<z.ZodString>;
        issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            reason: z.ZodEnum<{
                unknown: "unknown";
                missing: "missing";
                schema: "schema";
                duplicate: "duplicate";
                "not-open": "not-open";
                "approved-with-blocking": "approved-with-blocking";
            }>;
            message: z.ZodString;
        }, z.core.$strict>>>;
        transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            from: z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>;
            to: z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>;
            basis: z.ZodString;
        }, z.core.$strict>>>;
        spec: z.ZodOptional<z.ZodString>;
        mode: z.ZodOptional<z.ZodEnum<{
            legacy: "legacy";
            strict: "strict";
        }>>;
    }, z.core.$strict>>;
    tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
            skipped: "skipped";
        }>;
        opaque: z.ZodOptional<z.ZodLiteral<true>>;
    }, z.core.$strict>>>;
    testsTruncated: z.ZodOptional<z.ZodBoolean>;
    property: z.ZodOptional<z.ZodObject<{
        seed: z.ZodNumber;
        reproduce: z.ZodString;
        report: z.ZodOptional<z.ZodObject<{
            version: z.ZodLiteral<1>;
            seed: z.ZodOptional<z.ZodNumber>;
            properties: z.ZodArray<z.ZodObject<{
                testId: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                    running: "running";
                }>;
                cases: z.ZodNumber;
                families: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodNumber>>;
                error: z.ZodOptional<z.ZodString>;
                current: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                counterexample: z.ZodOptional<z.ZodObject<{
                    original: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
                    reduced: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                    expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                    actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                    reductionTimedOut: z.ZodOptional<z.ZodBoolean>;
                    case: z.ZodOptional<z.ZodString>;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
            corpus: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                executed: z.ZodNumber;
                passed: z.ZodNumber;
                witness: z.ZodString;
                failed: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    property: z.ZodString;
                    expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                    actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        problem: z.ZodOptional<z.ZodString>;
        contracts: z.ZodRecord<z.ZodString, z.ZodString>;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            blob: z.ZodString;
        }, z.core.$strict>>;
        level: z.ZodOptional<z.ZodEnum<{
            manifest: "manifest";
            legacy: "legacy";
        }>>;
        manifest: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            properties: z.ZodArray<z.ZodString>;
            corpus: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                cases: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        coverage: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    checks: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type EvidenceRecord = z.infer<typeof evidenceRecordSchema>;
/** Снимок зависимости, против которого шла попытка. */
export declare const dependencySnapshotSchema: z.ZodObject<{
    repositoryId: z.ZodString;
    sha: z.ZodString;
    tree: z.ZodString;
    path: z.ZodString;
    artifacts: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        digest: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** Свежесть входа на момент окончания проверки: снимок против головы ветки. */
export declare const freshnessSchema: z.ZodObject<{
    repositoryId: z.ZodString;
    snapshot: z.ZodString;
    head: z.ZodString;
    fresh: z.ZodBoolean;
}, z.core.$strict>;
/** Что проверено у потребителя: его голова и снимок всех его зависимостей. */
export declare const consumerCheckedSchema: z.ZodObject<{
    sha: z.ZodString;
    tree: z.ZodString;
    dependencies: z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        sha: z.ZodString;
        tree: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    freshness: z.ZodOptional<z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        snapshot: z.ZodString;
        head: z.ZodString;
        fresh: z.ZodBoolean;
    }, z.core.$strict>>>;
    observedAt: z.ZodOptional<z.ZodISODateTime>;
}, z.core.$strict>;
export declare const attemptConsumerSchema: z.ZodObject<{
    repositoryId: z.ZodString;
    gates: z.ZodArray<z.ZodString>;
    checked: z.ZodOptional<z.ZodObject<{
        sha: z.ZodString;
        tree: z.ZodString;
        dependencies: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            sha: z.ZodString;
            tree: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        freshness: z.ZodOptional<z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            snapshot: z.ZodString;
            head: z.ZodString;
            fresh: z.ZodBoolean;
        }, z.core.$strict>>>;
        observedAt: z.ZodOptional<z.ZodISODateTime>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** Незавершённая реализация, оборванная по времени: черновик, не кандидат. */
export declare const partialDraftSchema: z.ZodObject<{
    patch: z.ZodString;
    digest: z.ZodString;
    files: z.ZodArray<z.ZodString>;
    spec: z.ZodString;
    contracts: z.ZodRecord<z.ZodString, z.ZodString>;
}, z.core.$strict>;
export declare const continuationSchema: z.ZodObject<{
    runId: z.ZodString;
    kind: z.ZodEnum<{
        candidate: "candidate";
        unfinished: "unfinished";
    }>;
    reason: z.ZodOptional<z.ZodEnum<{
        gate: "gate";
        unknown: "unknown";
        review: "review";
        environment: "environment";
        cancelled: "cancelled";
        timeout: "timeout";
        "provider-auth": "provider-auth";
        "stale-base": "stale-base";
        "empty-result": "empty-result";
        "scope-violation": "scope-violation";
        "review-protocol": "review-protocol";
        merge: "merge";
        budget: "budget";
    }>>;
    respecified: z.ZodOptional<z.ZodBoolean>;
    applied: z.ZodBoolean;
    files: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const resourceSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        device: "device";
        port: "port";
        account: "account";
        service: "service";
    }>;
    value: z.ZodString;
}, z.core.$strict>;
/**
 * Попытка. Поля и смысл — как у `Run` DevContour; `workId` соответствует
 * `taskId`. `token` — fencing-токен владения: он хранится только здесь и
 * никогда не попадает в события, результат и логи.
 */
export declare const attemptStateSchema: z.ZodObject<{
    id: z.ZodString;
    workId: z.ZodString;
    repositoryId: z.ZodString;
    attempt: z.ZodNumber;
    token: z.ZodString;
    owner: z.ZodString;
    runtime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
        fixture: "fixture";
    }>;
    reviewer: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
        fixture: "fixture";
    }>;
    model: z.ZodOptional<z.ZodString>;
    reviewerModel: z.ZodOptional<z.ZodString>;
    effort: z.ZodOptional<z.ZodString>;
    reviewerEffort: z.ZodOptional<z.ZodString>;
    policyDigest: z.ZodString;
    status: z.ZodEnum<{
        failed: "failed";
        cancelled: "cancelled";
        active: "active";
        expired: "expired";
        succeeded: "succeeded";
    }>;
    phase: z.ZodEnum<{
        ready: "ready";
        failed: "failed";
        cancelled: "cancelled";
        draft: "draft";
        running: "running";
        verifying: "verifying";
        reviewing: "reviewing";
        integrating: "integrating";
        done: "done";
    }>;
    startedAt: z.ZodISODateTime;
    finishedAt: z.ZodOptional<z.ZodISODateTime>;
    leaseUntil: z.ZodNumber;
    worktree: z.ZodOptional<z.ZodString>;
    baseSha: z.ZodOptional<z.ZodString>;
    candidateSha: z.ZodOptional<z.ZodString>;
    integrationSha: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    blocked: z.ZodOptional<z.ZodBoolean>;
    failureKind: z.ZodOptional<z.ZodEnum<{
        gate: "gate";
        unknown: "unknown";
        review: "review";
        environment: "environment";
        cancelled: "cancelled";
        timeout: "timeout";
        "provider-auth": "provider-auth";
        "stale-base": "stale-base";
        "empty-result": "empty-result";
        "scope-violation": "scope-violation";
        "review-protocol": "review-protocol";
        merge: "merge";
        budget: "budget";
    }>>;
    failureFingerprint: z.ZodOptional<z.ZodString>;
    requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
    consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        gates: z.ZodArray<z.ZodString>;
        checked: z.ZodOptional<z.ZodObject<{
            sha: z.ZodString;
            tree: z.ZodString;
            dependencies: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                sha: z.ZodString;
                tree: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            freshness: z.ZodOptional<z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                snapshot: z.ZodString;
                head: z.ZodString;
                fresh: z.ZodBoolean;
            }, z.core.$strict>>>;
            observedAt: z.ZodOptional<z.ZodISODateTime>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    checks: z.ZodOptional<z.ZodObject<{
        effective: z.ZodString;
        corpus: z.ZodOptional<z.ZodObject<{
            suite: z.ZodString;
            number: z.ZodNumber;
            digest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    context: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        repositoryId: z.ZodString;
        revision: z.ZodString;
        digest: z.ZodString;
    }, z.core.$strict>>>;
    contextSnapshot: z.ZodOptional<z.ZodString>;
    resources: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            device: "device";
            port: "port";
            account: "account";
            service: "service";
        }>;
        value: z.ZodString;
    }, z.core.$strict>>>;
    dependencies: z.ZodOptional<z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        sha: z.ZodString;
        tree: z.ZodString;
        path: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    dependencyFreshness: z.ZodOptional<z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        snapshot: z.ZodString;
        head: z.ZodString;
        fresh: z.ZodBoolean;
    }, z.core.$strict>>>;
    properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
    unboundProperties: z.ZodOptional<z.ZodArray<z.ZodString>>;
    episodeBasis: z.ZodOptional<z.ZodString>;
    implementationBasis: z.ZodOptional<z.ZodString>;
    reusedFrom: z.ZodOptional<z.ZodObject<{
        runId: z.ZodString;
        candidateSha: z.ZodString;
    }, z.core.$strict>>;
    partial: z.ZodOptional<z.ZodObject<{
        patch: z.ZodString;
        digest: z.ZodString;
        files: z.ZodArray<z.ZodString>;
        spec: z.ZodString;
        contracts: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strict>>;
    continuedFrom: z.ZodOptional<z.ZodObject<{
        runId: z.ZodString;
        kind: z.ZodEnum<{
            candidate: "candidate";
            unfinished: "unfinished";
        }>;
        reason: z.ZodOptional<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            environment: "environment";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
        }>>;
        respecified: z.ZodOptional<z.ZodBoolean>;
        applied: z.ZodBoolean;
        files: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    callsRecorded: z.ZodOptional<z.ZodLiteral<true>>;
    dispatch: z.ZodOptional<z.ZodObject<{
        policy: z.ZodLiteral<"fifo-ready-v1">;
        at: z.ZodISODateTime;
        eligible: z.ZodArray<z.ZodObject<{
            taskId: z.ZodString;
            repositoryId: z.ZodOptional<z.ZodString>;
            attempt: z.ZodNumber;
        }, z.core.$strict>>;
        activeCount: z.ZodNumber;
        concurrency: z.ZodNumber;
        inputDigest: z.ZodString;
    }, z.core.$strict>>;
    wait: z.ZodOptional<z.ZodObject<{
        approvedAt: z.ZodOptional<z.ZodISODateTime>;
        readyAt: z.ZodOptional<z.ZodISODateTime>;
    }, z.core.$strict>>;
    timings: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        stage: z.ZodString;
        startedAt: z.ZodISODateTime;
        finishedAt: z.ZodOptional<z.ZodISODateTime>;
        outcome: z.ZodOptional<z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>>;
    }, z.core.$strict>>>;
    pinned: z.ZodOptional<z.ZodObject<{
        graphId: z.ZodString;
        graphDigest: z.ZodString;
        orderDigest: z.ZodString;
        targetRef: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    engineVersion: z.ZodOptional<z.ZodString>;
    consumerVersion: z.ZodOptional<z.ZodString>;
    evidence: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        runId: z.ZodString;
        kind: z.ZodEnum<{
            test: "test";
            review: "review";
        }>;
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        sha: z.ZodString;
        gate: z.ZodString;
        passed: z.ZodBoolean;
        createdAt: z.ZodISODateTime;
        command: z.ZodArray<z.ZodString>;
        exitCode: z.ZodNumber;
        log: z.ZodString;
        digest: z.ZodString;
        summary: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
        inspection: z.ZodOptional<z.ZodObject<{
            mode: z.ZodEnum<{
                commands: "commands";
                "diff-only": "diff-only";
            }>;
            source: z.ZodEnum<{
                "codex-events": "codex-events";
                unavailable: "unavailable";
                "controller-probes": "controller-probes";
                "runtime-and-controller": "runtime-and-controller";
            }>;
            commands: z.ZodArray<z.ZodObject<{
                command: z.ZodString;
                exitCode: z.ZodNullable<z.ZodNumber>;
                output: z.ZodString;
                origins: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"runtime">;
                    runtime: z.ZodString;
                    item: z.ZodNullable<z.ZodString>;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"controller">;
                    runId: z.ZodString;
                }, z.core.$strict>], "type">>>;
                status: z.ZodOptional<z.ZodEnum<{
                    error: "error";
                    passed: "passed";
                    failed: "failed";
                    cancelled: "cancelled";
                    completed: "completed";
                    timeout: "timeout";
                }>>;
                failure: z.ZodOptional<z.ZodEnum<{
                    report: "report";
                    environment: "environment";
                }>>;
                gate: z.ZodOptional<z.ZodString>;
                note: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            reason: z.ZodNullable<z.ZodString>;
            context: z.ZodOptional<z.ZodObject<{
                attempt: z.ZodString;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                sha: z.ZodString;
                call: z.ZodNumber;
            }, z.core.$strict>>;
            total: z.ZodOptional<z.ZodNumber>;
            excluded: z.ZodOptional<z.ZodArray<z.ZodObject<{
                runId: z.ZodString;
                status: z.ZodNullable<z.ZodString>;
                reason: z.ZodEnum<{
                    "not-started": "not-started";
                    "legacy-unconfirmed": "legacy-unconfirmed";
                    "foreign-scope": "foreign-scope";
                    "unknown-status": "unknown-status";
                    unfinished: "unfinished";
                    abandoned: "abandoned";
                }>;
            }, z.core.$strict>>>;
            excludedTotal: z.ZodOptional<z.ZodNumber>;
            invalid: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        findings: z.ZodOptional<z.ZodArray<z.ZodObject<{
            severity: z.ZodString;
            message: z.ZodString;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            id: z.ZodOptional<z.ZodString>;
            status: z.ZodOptional<z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>>;
        }, z.core.$strict>>>;
        reviewRound: z.ZodOptional<z.ZodObject<{
            version: z.ZodLiteral<1>;
            scope: z.ZodString;
            round: z.ZodNumber;
            call: z.ZodNumber;
            calls: z.ZodNumber;
            protocol: z.ZodEnum<{
                valid: "valid";
                invalid: "invalid";
                unsafe: "unsafe";
            }>;
            expected: z.ZodArray<z.ZodString>;
            issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                reason: z.ZodEnum<{
                    unknown: "unknown";
                    missing: "missing";
                    schema: "schema";
                    duplicate: "duplicate";
                    "not-open": "not-open";
                    "approved-with-blocking": "approved-with-blocking";
                }>;
                message: z.ZodString;
            }, z.core.$strict>>>;
            transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                from: z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>;
                to: z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>;
                basis: z.ZodString;
            }, z.core.$strict>>>;
            spec: z.ZodOptional<z.ZodString>;
            mode: z.ZodOptional<z.ZodEnum<{
                legacy: "legacy";
                strict: "strict";
            }>>;
        }, z.core.$strict>>;
        tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
                skipped: "skipped";
            }>;
            opaque: z.ZodOptional<z.ZodLiteral<true>>;
        }, z.core.$strict>>>;
        testsTruncated: z.ZodOptional<z.ZodBoolean>;
        property: z.ZodOptional<z.ZodObject<{
            seed: z.ZodNumber;
            reproduce: z.ZodString;
            report: z.ZodOptional<z.ZodObject<{
                version: z.ZodLiteral<1>;
                seed: z.ZodOptional<z.ZodNumber>;
                properties: z.ZodArray<z.ZodObject<{
                    testId: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        running: "running";
                    }>;
                    cases: z.ZodNumber;
                    families: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodNumber>>;
                    error: z.ZodOptional<z.ZodString>;
                    current: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                    counterexample: z.ZodOptional<z.ZodObject<{
                        original: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
                        reduced: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                        expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                        actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                        reductionTimedOut: z.ZodOptional<z.ZodBoolean>;
                        case: z.ZodOptional<z.ZodString>;
                    }, z.core.$strip>>;
                }, z.core.$strip>>;
                corpus: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodString;
                    executed: z.ZodNumber;
                    passed: z.ZodNumber;
                    witness: z.ZodString;
                    failed: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        property: z.ZodString;
                        expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                        actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                    }, z.core.$strip>>;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
            problem: z.ZodOptional<z.ZodString>;
            contracts: z.ZodRecord<z.ZodString, z.ZodString>;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                blob: z.ZodString;
            }, z.core.$strict>>;
            level: z.ZodOptional<z.ZodEnum<{
                manifest: "manifest";
                legacy: "legacy";
            }>>;
            manifest: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                properties: z.ZodArray<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodString;
                    cases: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            coverage: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        checks: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type AttemptState = z.infer<typeof attemptStateSchema>;
export declare const recoveryActions: readonly ["add-cases", "new-approach", "strengthen-checker", "split-task", "clarify-obligation", "environment"];
export declare const recoveryDecisionSchema: z.ZodObject<{
    action: z.ZodEnum<{
        environment: "environment";
        "add-cases": "add-cases";
        "new-approach": "new-approach";
        "strengthen-checker": "strengthen-checker";
        "split-task": "split-task";
        "clarify-obligation": "clarify-obligation";
    }>;
    reason: z.ZodString;
    evidence: z.ZodArray<z.ZodString>;
    hypothesis: z.ZodOptional<z.ZodString>;
    plan: z.ZodOptional<z.ZodString>;
    cases: z.ZodOptional<z.ZodArray<z.ZodObject<{
        input: z.ZodString;
        expected: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>>>;
    proposal: z.ZodOptional<z.ZodString>;
    conflict: z.ZodOptional<z.ZodString>;
    source: z.ZodObject<{
        kind: z.ZodEnum<{
            operator: "operator";
            lead: "lead";
        }>;
        runtime: z.ZodOptional<z.ZodString>;
        model: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    decidedAt: z.ZodISODateTime;
}, z.core.$strict>;
/** Эпизод повторяющихся отказов по свойству (`version` — CAS ручного решения). */
export declare const propertyRecoverySchema: z.ZodObject<{
    id: z.ZodString;
    property: z.ZodString;
    basis: z.ZodString;
    runs: z.ZodArray<z.ZodString>;
    openedAt: z.ZodISODateTime;
    status: z.ZodEnum<{
        closed: "closed";
        stopped: "stopped";
        "awaiting-lead": "awaiting-lead";
        analyzing: "analyzing";
        applying: "applying";
        retry: "retry";
        retrying: "retrying";
        "awaiting-user": "awaiting-user";
    }>;
    calls: z.ZodNumber;
    decision: z.ZodOptional<z.ZodObject<{
        action: z.ZodEnum<{
            environment: "environment";
            "add-cases": "add-cases";
            "new-approach": "new-approach";
            "strengthen-checker": "strengthen-checker";
            "split-task": "split-task";
            "clarify-obligation": "clarify-obligation";
        }>;
        reason: z.ZodString;
        evidence: z.ZodArray<z.ZodString>;
        hypothesis: z.ZodOptional<z.ZodString>;
        plan: z.ZodOptional<z.ZodString>;
        cases: z.ZodOptional<z.ZodArray<z.ZodObject<{
            input: z.ZodString;
            expected: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strict>>>;
        proposal: z.ZodOptional<z.ZodString>;
        conflict: z.ZodOptional<z.ZodString>;
        source: z.ZodObject<{
            kind: z.ZodEnum<{
                operator: "operator";
                lead: "lead";
            }>;
            runtime: z.ZodOptional<z.ZodString>;
            model: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        decidedAt: z.ZodISODateTime;
    }, z.core.$strict>>;
    retryRun: z.ZodOptional<z.ZodString>;
    reason: z.ZodOptional<z.ZodString>;
    history: z.ZodArray<z.ZodObject<{
        at: z.ZodISODateTime;
        event: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    version: z.ZodNumber;
}, z.core.$strict>;
export type PropertyRecovery = z.infer<typeof propertyRecoverySchema>;
export declare const workStateSchema: z.ZodObject<{
    id: z.ZodString;
    graphId: z.ZodString;
    order: z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        title: z.ZodString;
        goal: z.ZodString;
        acceptance: z.ZodArray<z.ZodString>;
        role: z.ZodString;
        repositoryId: z.ZodString;
        relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
        writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
        dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
        gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            gates: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>>;
        properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            source: z.ZodString;
            digest: z.ZodString;
            text: z.ZodString;
            gate: z.ZodString;
            scenario: z.ZodString;
            testId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>>;
        context: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>;
    status: z.ZodEnum<{
        ready: "ready";
        failed: "failed";
        cancelled: "cancelled";
        draft: "draft";
        running: "running";
        verifying: "verifying";
        reviewing: "reviewing";
        integrating: "integrating";
        done: "done";
    }>;
    attempt: z.ZodNumber;
    activeRunId: z.ZodOptional<z.ZodString>;
    resultSha: z.ZodOptional<z.ZodString>;
    failure: z.ZodOptional<z.ZodString>;
    failureKind: z.ZodOptional<z.ZodEnum<{
        gate: "gate";
        unknown: "unknown";
        review: "review";
        environment: "environment";
        cancelled: "cancelled";
        timeout: "timeout";
        "provider-auth": "provider-auth";
        "stale-base": "stale-base";
        "empty-result": "empty-result";
        "scope-violation": "scope-violation";
        "review-protocol": "review-protocol";
        merge: "merge";
        budget: "budget";
    }>>;
    failureFingerprint: z.ZodOptional<z.ZodString>;
    approvedAt: z.ZodOptional<z.ZodISODateTime>;
    approvedDigest: z.ZodOptional<z.ZodString>;
    approvedScope: z.ZodOptional<z.ZodString>;
    approval: z.ZodOptional<z.ZodObject<{
        actor: z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>;
        authorRuntime: z.ZodOptional<z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>>;
        reviewerRuntime: z.ZodOptional<z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>>;
        artifact: z.ZodOptional<z.ZodString>;
        digest: z.ZodOptional<z.ZodString>;
        context: z.ZodOptional<z.ZodObject<{
            digest: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    hold: z.ZodOptional<z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
    }, z.core.$strict>>;
    budgetBlock: z.ZodOptional<z.ZodObject<{
        reason: z.ZodString;
        at: z.ZodISODateTime;
    }, z.core.$strict>>;
    checkVersion: z.ZodOptional<z.ZodObject<{
        suite: z.ZodString;
        number: z.ZodNumber;
        digest: z.ZodString;
    }, z.core.$strict>>;
    recovery: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        property: z.ZodString;
        basis: z.ZodString;
        runs: z.ZodArray<z.ZodString>;
        openedAt: z.ZodISODateTime;
        status: z.ZodEnum<{
            closed: "closed";
            stopped: "stopped";
            "awaiting-lead": "awaiting-lead";
            analyzing: "analyzing";
            applying: "applying";
            retry: "retry";
            retrying: "retrying";
            "awaiting-user": "awaiting-user";
        }>;
        calls: z.ZodNumber;
        decision: z.ZodOptional<z.ZodObject<{
            action: z.ZodEnum<{
                environment: "environment";
                "add-cases": "add-cases";
                "new-approach": "new-approach";
                "strengthen-checker": "strengthen-checker";
                "split-task": "split-task";
                "clarify-obligation": "clarify-obligation";
            }>;
            reason: z.ZodString;
            evidence: z.ZodArray<z.ZodString>;
            hypothesis: z.ZodOptional<z.ZodString>;
            plan: z.ZodOptional<z.ZodString>;
            cases: z.ZodOptional<z.ZodArray<z.ZodObject<{
                input: z.ZodString;
                expected: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            proposal: z.ZodOptional<z.ZodString>;
            conflict: z.ZodOptional<z.ZodString>;
            source: z.ZodObject<{
                kind: z.ZodEnum<{
                    operator: "operator";
                    lead: "lead";
                }>;
                runtime: z.ZodOptional<z.ZodString>;
                model: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            decidedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
        retryRun: z.ZodOptional<z.ZodString>;
        reason: z.ZodOptional<z.ZodString>;
        history: z.ZodArray<z.ZodObject<{
            at: z.ZodISODateTime;
            event: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        version: z.ZodNumber;
    }, z.core.$strict>>;
    recoveryHistory: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        property: z.ZodString;
        basis: z.ZodString;
        runs: z.ZodArray<z.ZodString>;
        openedAt: z.ZodISODateTime;
        status: z.ZodEnum<{
            closed: "closed";
            stopped: "stopped";
            "awaiting-lead": "awaiting-lead";
            analyzing: "analyzing";
            applying: "applying";
            retry: "retry";
            retrying: "retrying";
            "awaiting-user": "awaiting-user";
        }>;
        calls: z.ZodNumber;
        decision: z.ZodOptional<z.ZodObject<{
            action: z.ZodEnum<{
                environment: "environment";
                "add-cases": "add-cases";
                "new-approach": "new-approach";
                "strengthen-checker": "strengthen-checker";
                "split-task": "split-task";
                "clarify-obligation": "clarify-obligation";
            }>;
            reason: z.ZodString;
            evidence: z.ZodArray<z.ZodString>;
            hypothesis: z.ZodOptional<z.ZodString>;
            plan: z.ZodOptional<z.ZodString>;
            cases: z.ZodOptional<z.ZodArray<z.ZodObject<{
                input: z.ZodString;
                expected: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strict>>>;
            proposal: z.ZodOptional<z.ZodString>;
            conflict: z.ZodOptional<z.ZodString>;
            source: z.ZodObject<{
                kind: z.ZodEnum<{
                    operator: "operator";
                    lead: "lead";
                }>;
                runtime: z.ZodOptional<z.ZodString>;
                model: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            decidedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
        retryRun: z.ZodOptional<z.ZodString>;
        reason: z.ZodOptional<z.ZodString>;
        history: z.ZodArray<z.ZodObject<{
            at: z.ZodISODateTime;
            event: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        version: z.ZodNumber;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type WorkState = z.infer<typeof workStateSchema>;
export declare const graphStateSchema: z.ZodObject<{
    id: z.ZodString;
    digest: z.ZodString;
    graph: z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        orders: z.ZodArray<z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            id: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            title: z.ZodString;
            goal: z.ZodString;
            acceptance: z.ZodArray<z.ZodString>;
            role: z.ZodString;
            repositoryId: z.ZodString;
            relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
            writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
            dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
            gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>>;
            properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                source: z.ZodString;
                digest: z.ZodString;
                text: z.ZodString;
                gate: z.ZodString;
                scenario: z.ZodString;
                testId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>>;
            context: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        prerequisites: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            repositoryId: z.ZodString;
            resultSha: z.ZodString;
            receipt: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"engine">;
                runId: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"trusted">;
                issuer: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>], "kind">;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    policyDigest: z.ZodString;
    approval: z.ZodOptional<z.ZodObject<{
        actor: z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>;
        authorRuntime: z.ZodOptional<z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>>;
        reviewerRuntime: z.ZodOptional<z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>>;
        artifact: z.ZodOptional<z.ZodString>;
        digest: z.ZodOptional<z.ZodString>;
        context: z.ZodOptional<z.ZodObject<{
            digest: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
        at: z.ZodISODateTime;
    }, z.core.$strict>>;
    registeredAt: z.ZodISODateTime;
}, z.core.$strict>;
export type GraphState = z.infer<typeof graphStateSchema>;
/**
 * Причины паузы. `operator` и `shutdown` — решения человека и штатной
 * остановки; `runtime` — отказ провайдера (`pauseFailures` называет классы);
 * `reconfigure` — операция применения политики, снимает её только она;
 * `base-check` — техническое ожидание проверки перенесённой базы.
 */
export declare const pauseReasons: readonly ["operator", "shutdown", "runtime", "base-check", "reconfigure"];
export type PauseReason = (typeof pauseReasons)[number];
export declare const controlStateSchema: z.ZodObject<{
    paused: z.ZodBoolean;
    pauseReason: z.ZodOptional<z.ZodEnum<{
        runtime: "runtime";
        operator: "operator";
        shutdown: "shutdown";
        "base-check": "base-check";
        reconfigure: "reconfigure";
    }>>;
    pausedAt: z.ZodOptional<z.ZodISODateTime>;
    pauseOperation: z.ZodOptional<z.ZodString>;
    pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        gate: "gate";
        unknown: "unknown";
        review: "review";
        environment: "environment";
        cancelled: "cancelled";
        timeout: "timeout";
        "provider-auth": "provider-auth";
        "stale-base": "stale-base";
        "empty-result": "empty-result";
        "scope-violation": "scope-violation";
        "review-protocol": "review-protocol";
        merge: "merge";
        budget: "budget";
    }>>>;
    waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            "base-check": "base-check";
            "context-lock": "context-lock";
        }>;
        detail: z.ZodString;
        at: z.ZodISODateTime;
        operation: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    appliedPolicy: z.ZodOptional<z.ZodObject<{
        digest: z.ZodString;
        generation: z.ZodOptional<z.ZodNumber>;
        at: z.ZodISODateTime;
        by: z.ZodString;
    }, z.core.$strict>>;
    reconfigure: z.ZodOptional<z.ZodObject<{
        operation: z.ZodString;
        digest: z.ZodString;
        requestedAt: z.ZodISODateTime;
        appliedAt: z.ZodOptional<z.ZodISODateTime>;
        appliedBy: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ControlState = z.infer<typeof controlStateSchema>;
/** Единственный действующий controller очереди. */
export declare const controllerLeaseSchema: z.ZodObject<{
    owner: z.ZodString;
    leaseUntil: z.ZodNumber;
    engineVersion: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ControllerLease = z.infer<typeof controllerLeaseSchema>;
/**
 * Диагностика процесса runtime — форма `RuntimeDiagnostics` DevContour:
 * время, последний вывод, код и сигнал, таймаут/отмена, хвосты потоков
 * (уже замаскированные), дерево процессов.
 */
export declare const runtimeDiagnosticsSchema: z.ZodObject<{
    startedAt: z.ZodISODateTime;
    finishedAt: z.ZodISODateTime;
    lastOutputAt: z.ZodNullable<z.ZodISODateTime>;
    exitCode: z.ZodNullable<z.ZodNumber>;
    signal: z.ZodNullable<z.ZodString>;
    timedOut: z.ZodBoolean;
    aborted: z.ZodBoolean;
    stdoutTail: z.ZodString;
    stderrTail: z.ZodString;
    processTree: z.ZodOptional<z.ZodObject<{
        available: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
        processes: z.ZodArray<z.ZodObject<{
            pid: z.ZodNumber;
            parentPid: z.ZodNumber;
            groupPid: z.ZodNumber;
            name: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type RuntimeDiagnostics = z.infer<typeof runtimeDiagnosticsSchema>;
export declare const usageSchema: z.ZodObject<{
    inputTokens: z.ZodNullable<z.ZodNumber>;
    outputTokens: z.ZodNullable<z.ZodNumber>;
    cacheReadTokens: z.ZodNullable<z.ZodNumber>;
    cacheWriteTokens: z.ZodNullable<z.ZodNumber>;
    reportedUsd: z.ZodNullable<z.ZodNumber>;
    complete: z.ZodBoolean;
    source: z.ZodEnum<{
        fixture: "fixture";
        unavailable: "unavailable";
        "codex-turn-events": "codex-turn-events";
        "claude-result": "claude-result";
    }>;
}, z.core.$strict>;
export type Usage = z.infer<typeof usageSchema>;
/**
 * Запись вызова модели. Атрибуция закрепляется **при вызове**: поручение,
 * группа (у DevContour — доска со всеми ревизиями) и поручения группы на
 * момент вызова. Перенос поручения между группами расход не переносит;
 * записи без закреплённой атрибуции получают её от хоста
 * (`BudgetScopes.legacy`) один раз и больше не пересчитываются.
 */
export declare const callRecordSchema: z.ZodObject<{
    id: z.ZodString;
    repositoryId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    subjectId: z.ZodOptional<z.ZodString>;
    subjectKind: z.ZodOptional<z.ZodEnum<{
        work: "work";
        group: "group";
        other: "other";
    }>>;
    stage: z.ZodString;
    runtime: z.ZodString;
    model: z.ZodNullable<z.ZodString>;
    runtimeVersion: z.ZodNullable<z.ZodString>;
    startedAt: z.ZodISODateTime;
    finishedAt: z.ZodOptional<z.ZodISODateTime>;
    outcome: z.ZodEnum<{
        error: "error";
        active: "active";
        abandoned: "abandoned";
        returned: "returned";
    }>;
    process: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        pid: z.ZodNumber;
        startedAt: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    abandonedAt: z.ZodOptional<z.ZodISODateTime>;
    durationMs: z.ZodOptional<z.ZodNumber>;
    elapsedMs: z.ZodOptional<z.ZodNumber>;
    startedHr: z.ZodOptional<z.ZodString>;
    durationUnknown: z.ZodOptional<z.ZodLiteral<true>>;
    bootId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    groupId: z.ZodOptional<z.ZodString>;
    workIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    promptBytes: z.ZodNumber;
    promptDigest: z.ZodString;
    usage: z.ZodObject<{
        inputTokens: z.ZodNullable<z.ZodNumber>;
        outputTokens: z.ZodNullable<z.ZodNumber>;
        cacheReadTokens: z.ZodNullable<z.ZodNumber>;
        cacheWriteTokens: z.ZodNullable<z.ZodNumber>;
        reportedUsd: z.ZodNullable<z.ZodNumber>;
        complete: z.ZodBoolean;
        source: z.ZodEnum<{
            fixture: "fixture";
            unavailable: "unavailable";
            "codex-turn-events": "codex-turn-events";
            "claude-result": "claude-result";
        }>;
    }, z.core.$strict>;
    costUsd: z.ZodNullable<z.ZodNumber>;
    costSource: z.ZodEnum<{
        unknown: "unknown";
        "provider-reported": "provider-reported";
        "tariff-estimate": "tariff-estimate";
    }>;
    price: z.ZodOptional<z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
        model: z.ZodString;
        effectiveAt: z.ZodISODateTime;
        input: z.ZodNumber;
        output: z.ZodNumber;
        cacheRead: z.ZodNumber;
        cacheWrite: z.ZodNumber;
    }, z.core.$strict>>;
    diagnostics: z.ZodOptional<z.ZodObject<{
        startedAt: z.ZodISODateTime;
        finishedAt: z.ZodISODateTime;
        lastOutputAt: z.ZodNullable<z.ZodISODateTime>;
        exitCode: z.ZodNullable<z.ZodNumber>;
        signal: z.ZodNullable<z.ZodString>;
        timedOut: z.ZodBoolean;
        aborted: z.ZodBoolean;
        stdoutTail: z.ZodString;
        stderrTail: z.ZodString;
        processTree: z.ZodOptional<z.ZodObject<{
            available: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                groupPid: z.ZodNumber;
                name: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CallRecord = z.infer<typeof callRecordSchema>;
export declare const checkSuiteSchema: z.ZodObject<{
    id: z.ZodString;
    repositoryId: z.ZodString;
    contractId: z.ZodString;
    contractDigest: z.ZodString;
    gate: z.ZodString;
    basis: z.ZodString;
    cases: z.ZodRecord<z.ZodString, z.ZodObject<{
        id: z.ZodString;
        property: z.ZodString;
        input: z.ZodString;
        expected: z.ZodString;
        source: z.ZodObject<{
            kind: z.ZodLiteral<"oracle">;
            decision: z.ZodString;
            sha: z.ZodString;
            runId: z.ZodOptional<z.ZodString>;
            taskId: z.ZodOptional<z.ZodString>;
            reproduction: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        addedAt: z.ZodISODateTime;
    }, z.core.$strict>>;
    versions: z.ZodArray<z.ZodObject<{
        number: z.ZodNumber;
        digest: z.ZodString;
        previous: z.ZodNullable<z.ZodString>;
        cases: z.ZodArray<z.ZodString>;
        blob: z.ZodString;
        createdAt: z.ZodISODateTime;
        reason: z.ZodString;
        decisions: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    decisions: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        key: z.ZodOptional<z.ZodString>;
        property: z.ZodString;
        input: z.ZodString;
        inputHash: z.ZodString;
        outcome: z.ZodEnum<{
            rejected: "rejected";
            inconclusive: "inconclusive";
            confirmed: "confirmed";
            refuted: "refuted";
        }>;
        reason: z.ZodString;
        claimed: z.ZodOptional<z.ZodObject<{
            expected: z.ZodNullable<z.ZodString>;
            actual: z.ZodNullable<z.ZodString>;
            reproduction: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        source: z.ZodObject<{
            sha: z.ZodString;
            runId: z.ZodOptional<z.ZodString>;
            taskId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        observed: z.ZodOptional<z.ZodObject<{
            expected: z.ZodOptional<z.ZodString>;
            actual: z.ZodOptional<z.ZodString>;
            equal: z.ZodOptional<z.ZodBoolean>;
            repeats: z.ZodNumber;
            durationsMs: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>>;
        method: z.ZodOptional<z.ZodObject<{
            gate: z.ZodString;
            command: z.ZodOptional<z.ZodArray<z.ZodString>>;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                blob: z.ZodString;
            }, z.core.$strict>>;
            contract: z.ZodString;
            basis: z.ZodString;
        }, z.core.$strict>>;
        caseId: z.ZodOptional<z.ZodString>;
        version: z.ZodOptional<z.ZodNumber>;
        origin: z.ZodObject<{
            kind: z.ZodEnum<{
                review: "review";
                agent: "agent";
                operator: "operator";
                lead: "lead";
            }>;
            runtime: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        at: z.ZodISODateTime;
    }, z.core.$strict>>;
    adoptions: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        taskId: z.ZodString;
        from: z.ZodNullable<z.ZodObject<{
            number: z.ZodNumber;
            digest: z.ZodString;
        }, z.core.$strict>>;
        to: z.ZodObject<{
            number: z.ZodNumber;
            digest: z.ZodString;
        }, z.core.$strict>;
        actor: z.ZodString;
        reason: z.ZodString;
        operation: z.ZodString;
        at: z.ZodISODateTime;
    }, z.core.$strict>>;
    pending: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodNumber;
        digest: z.ZodOptional<z.ZodString>;
        awaitingOperator: z.ZodOptional<z.ZodBoolean>;
        tasks: z.ZodArray<z.ZodString>;
        status: z.ZodEnum<{
            completed: "completed";
            waiting: "waiting";
        }>;
        results: z.ZodRecord<z.ZodString, z.ZodString>;
        actor: z.ZodString;
        reason: z.ZodString;
        requestedAt: z.ZodISODateTime;
        completedAt: z.ZodOptional<z.ZodISODateTime>;
    }, z.core.$strict>>;
    operations: z.ZodRecord<z.ZodString, z.ZodObject<{
        key: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            running: "running";
        }>;
        token: z.ZodOptional<z.ZodString>;
        leaseUntil: z.ZodOptional<z.ZodNumber>;
        decision: z.ZodOptional<z.ZodString>;
        startedAt: z.ZodISODateTime;
    }, z.core.$strict>>;
    revision: z.ZodNumber;
}, z.core.$strict>;
export type CheckSuite = z.infer<typeof checkSuiteSchema>;
/**
 * Задание технической очереди — форма `WorkflowJob` DevContour: предмет
 * (вид и ID группы, у DevContour — доска или ChangeSet), закреплённый runtime
 * автора, digest входа (смена входа делает задание `stale`), этап, попытки,
 * число ремонтов, владение (token/lease) и история. Постановка идемпотентна
 * по ключу; повтор с другим автором отклоняется.
 */
export declare const workflowJobSchema: z.ZodObject<{
    kind: z.ZodString;
    id: z.ZodString;
    authorRuntime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
    }>;
    maxAttempts: z.ZodNumber;
    key: z.ZodString;
    owner: z.ZodOptional<z.ZodString>;
    inputDigest: z.ZodString;
    stage: z.ZodNumber;
    attempts: z.ZodNumber;
    status: z.ZodEnum<{
        failed: "failed";
        completed: "completed";
        running: "running";
        queued: "queued";
        stale: "stale";
    }>;
    repairs: z.ZodOptional<z.ZodNumber>;
    token: z.ZodOptional<z.ZodString>;
    leaseUntil: z.ZodOptional<z.ZodNumber>;
    startedAt: z.ZodISODateTime;
    finishedAt: z.ZodOptional<z.ZodISODateTime>;
    error: z.ZodOptional<z.ZodString>;
    history: z.ZodArray<z.ZodObject<{
        at: z.ZodISODateTime;
        stage: z.ZodNumber;
        event: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type WorkflowJob = z.infer<typeof workflowJobSchema>;
/**
 * Пространства локальных записей и их схемы. Запись адресуется
 * `(namespace, owner, key)`: `owner` — репозиторий, за которым запись
 * закреплена, или `@workspace` для общих. У DevContour с хранением по
 * компонентам запись владельца-компонента живёт в его базе. Неизвестное
 * пространство движок не пишет и не читает.
 */
export declare const WORKSPACE_OWNER = "@workspace";
/**
 * Воспроизведение из находки ревью: вход, на котором поручение ломалось.
 * Один и тот же вход одного свойства — одна запись, повтор добавляет прогон.
 * `observed` — запуск подтверждён журналом controller (probe); иначе это
 * гипотеза reviewer. Диагностика: gate не расширяет, корпусом не становится
 * без подтверждения эталоном.
 */
export declare const reproductionRecordSchema: z.ZodObject<{
    key: z.ZodString;
    property: z.ZodNullable<z.ZodString>;
    inputHash: z.ZodString;
    input: z.ZodString;
    expected: z.ZodNullable<z.ZodString>;
    actual: z.ZodNullable<z.ZodString>;
    command: z.ZodNullable<z.ZodArray<z.ZodString>>;
    message: z.ZodString;
    claimed: z.ZodBoolean;
    observed: z.ZodBoolean;
    run: z.ZodNullable<z.ZodString>;
    runs: z.ZodArray<z.ZodObject<{
        runId: z.ZodString;
        sha: z.ZodString;
        at: z.ZodISODateTime;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ReproductionRecord = z.infer<typeof reproductionRecordSchema>;
/** Реестр воспроизведений поручения; ограничен — старые записи вытесняются. */
export declare const reproductionRegistrySchema: z.ZodObject<{
    workId: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        property: z.ZodNullable<z.ZodString>;
        inputHash: z.ZodString;
        input: z.ZodString;
        expected: z.ZodNullable<z.ZodString>;
        actual: z.ZodNullable<z.ZodString>;
        command: z.ZodNullable<z.ZodArray<z.ZodString>>;
        message: z.ZodString;
        claimed: z.ZodBoolean;
        observed: z.ZodBoolean;
        run: z.ZodNullable<z.ZodString>;
        runs: z.ZodArray<z.ZodObject<{
            runId: z.ZodString;
            sha: z.ZodString;
            at: z.ZodISODateTime;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const MAX_REPRODUCTIONS = 500;
export declare const localSchemas: {
    /** Учёт вызовов моделей. */
    readonly usage: z.ZodObject<{
        id: z.ZodString;
        repositoryId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        subjectId: z.ZodOptional<z.ZodString>;
        subjectKind: z.ZodOptional<z.ZodEnum<{
            work: "work";
            group: "group";
            other: "other";
        }>>;
        stage: z.ZodString;
        runtime: z.ZodString;
        model: z.ZodNullable<z.ZodString>;
        runtimeVersion: z.ZodNullable<z.ZodString>;
        startedAt: z.ZodISODateTime;
        finishedAt: z.ZodOptional<z.ZodISODateTime>;
        outcome: z.ZodEnum<{
            error: "error";
            active: "active";
            abandoned: "abandoned";
            returned: "returned";
        }>;
        process: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            pid: z.ZodNumber;
            startedAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        abandonedAt: z.ZodOptional<z.ZodISODateTime>;
        durationMs: z.ZodOptional<z.ZodNumber>;
        elapsedMs: z.ZodOptional<z.ZodNumber>;
        startedHr: z.ZodOptional<z.ZodString>;
        durationUnknown: z.ZodOptional<z.ZodLiteral<true>>;
        bootId: z.ZodOptional<z.ZodString>;
        workId: z.ZodOptional<z.ZodString>;
        groupId: z.ZodOptional<z.ZodString>;
        workIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        promptBytes: z.ZodNumber;
        promptDigest: z.ZodString;
        usage: z.ZodObject<{
            inputTokens: z.ZodNullable<z.ZodNumber>;
            outputTokens: z.ZodNullable<z.ZodNumber>;
            cacheReadTokens: z.ZodNullable<z.ZodNumber>;
            cacheWriteTokens: z.ZodNullable<z.ZodNumber>;
            reportedUsd: z.ZodNullable<z.ZodNumber>;
            complete: z.ZodBoolean;
            source: z.ZodEnum<{
                fixture: "fixture";
                unavailable: "unavailable";
                "codex-turn-events": "codex-turn-events";
                "claude-result": "claude-result";
            }>;
        }, z.core.$strict>;
        costUsd: z.ZodNullable<z.ZodNumber>;
        costSource: z.ZodEnum<{
            unknown: "unknown";
            "provider-reported": "provider-reported";
            "tariff-estimate": "tariff-estimate";
        }>;
        price: z.ZodOptional<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            model: z.ZodString;
            effectiveAt: z.ZodISODateTime;
            input: z.ZodNumber;
            output: z.ZodNumber;
            cacheRead: z.ZodNumber;
            cacheWrite: z.ZodNumber;
        }, z.core.$strict>>;
        diagnostics: z.ZodOptional<z.ZodObject<{
            startedAt: z.ZodISODateTime;
            finishedAt: z.ZodISODateTime;
            lastOutputAt: z.ZodNullable<z.ZodISODateTime>;
            exitCode: z.ZodNullable<z.ZodNumber>;
            signal: z.ZodNullable<z.ZodString>;
            timedOut: z.ZodBoolean;
            aborted: z.ZodBoolean;
            stdoutTail: z.ZodString;
            stderrTail: z.ZodString;
            processTree: z.ZodOptional<z.ZodObject<{
                available: z.ZodBoolean;
                reason: z.ZodOptional<z.ZodString>;
                processes: z.ZodArray<z.ZodObject<{
                    pid: z.ZodNumber;
                    parentPid: z.ZodNumber;
                    groupPid: z.ZodNumber;
                    name: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    /** Снимки контекста попыток по digest: повторное использование после рестарта. */
    readonly 'context-snapshots': z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        sources: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodString;
            version: z.ZodString;
            repositoryId: z.ZodOptional<z.ZodString>;
            revision: z.ZodOptional<z.ZodString>;
            required: z.ZodBoolean;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
                bytes: z.ZodNumber;
                content: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    encoding: z.ZodLiteral<"utf8">;
                    data: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    encoding: z.ZodLiteral<"base64">;
                    data: z.ZodString;
                }, z.core.$strict>], "encoding">;
            }, z.core.$strict>>;
            references: z.ZodDefault<z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
                bytes: z.ZodNumber;
                content: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    encoding: z.ZodLiteral<"utf8">;
                    data: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    encoding: z.ZodLiteral<"base64">;
                    data: z.ZodString;
                }, z.core.$strict>], "encoding">;
            }, z.core.$strict>>>;
            digest: z.ZodString;
            hostDigest: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        missing: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            reason: z.ZodString;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    /** Ключи идемпотентности запуска: (connector, ref, revision, digest) → graphId. */
    readonly 'run-keys': z.ZodObject<{
        graphId: z.ZodString;
        digest: z.ZodString;
        at: z.ZodISODateTime;
    }, z.core.$strict>;
    /** Состояние доставки результата по ключу. */
    readonly delivery: z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            pending: "pending";
            delivered: "delivered";
            conflict: "conflict";
            uncertain: "uncertain";
        }>;
        attempts: z.ZodNumber;
        lastError: z.ZodOptional<z.ZodString>;
        operation: z.ZodOptional<z.ZodString>;
        currentRevision: z.ZodOptional<z.ZodString>;
        receipt: z.ZodOptional<z.ZodString>;
        updatedAt: z.ZodISODateTime;
    }, z.core.$strict>;
    /** История технического ревью плана и контрактов. */
    readonly reviews: z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        at: z.ZodISODateTime;
        approved: z.ZodBoolean;
        summary: z.ZodString;
        authorRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
            external: "external";
        }>;
        reviewerRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewerModel: z.ZodOptional<z.ZodString>;
        sameVendor: z.ZodBoolean;
        reviewerBinding: z.ZodOptional<z.ZodString>;
        contextDigest: z.ZodOptional<z.ZodString>;
        findings: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            severity: z.ZodEnum<{
                blocking: "blocking";
                note: "note";
            }>;
            message: z.ZodString;
            rule: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            status: z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>;
            openedIn: z.ZodNumber;
            changedIn: z.ZodNumber;
            basis: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        artifact: z.ZodString;
    }, z.core.$strict>;
    /** Наборы корпуса подтверждённых случаев (у DevContour — `check-suites`). */
    readonly 'check-suites': z.ZodObject<{
        id: z.ZodString;
        repositoryId: z.ZodString;
        contractId: z.ZodString;
        contractDigest: z.ZodString;
        gate: z.ZodString;
        basis: z.ZodString;
        cases: z.ZodRecord<z.ZodString, z.ZodObject<{
            id: z.ZodString;
            property: z.ZodString;
            input: z.ZodString;
            expected: z.ZodString;
            source: z.ZodObject<{
                kind: z.ZodLiteral<"oracle">;
                decision: z.ZodString;
                sha: z.ZodString;
                runId: z.ZodOptional<z.ZodString>;
                taskId: z.ZodOptional<z.ZodString>;
                reproduction: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            addedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
        versions: z.ZodArray<z.ZodObject<{
            number: z.ZodNumber;
            digest: z.ZodString;
            previous: z.ZodNullable<z.ZodString>;
            cases: z.ZodArray<z.ZodString>;
            blob: z.ZodString;
            createdAt: z.ZodISODateTime;
            reason: z.ZodString;
            decisions: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        decisions: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            key: z.ZodOptional<z.ZodString>;
            property: z.ZodString;
            input: z.ZodString;
            inputHash: z.ZodString;
            outcome: z.ZodEnum<{
                rejected: "rejected";
                inconclusive: "inconclusive";
                confirmed: "confirmed";
                refuted: "refuted";
            }>;
            reason: z.ZodString;
            claimed: z.ZodOptional<z.ZodObject<{
                expected: z.ZodNullable<z.ZodString>;
                actual: z.ZodNullable<z.ZodString>;
                reproduction: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            source: z.ZodObject<{
                sha: z.ZodString;
                runId: z.ZodOptional<z.ZodString>;
                taskId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            observed: z.ZodOptional<z.ZodObject<{
                expected: z.ZodOptional<z.ZodString>;
                actual: z.ZodOptional<z.ZodString>;
                equal: z.ZodOptional<z.ZodBoolean>;
                repeats: z.ZodNumber;
                durationsMs: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>>;
            method: z.ZodOptional<z.ZodObject<{
                gate: z.ZodString;
                command: z.ZodOptional<z.ZodArray<z.ZodString>>;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    blob: z.ZodString;
                }, z.core.$strict>>;
                contract: z.ZodString;
                basis: z.ZodString;
            }, z.core.$strict>>;
            caseId: z.ZodOptional<z.ZodString>;
            version: z.ZodOptional<z.ZodNumber>;
            origin: z.ZodObject<{
                kind: z.ZodEnum<{
                    review: "review";
                    agent: "agent";
                    operator: "operator";
                    lead: "lead";
                }>;
                runtime: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            at: z.ZodISODateTime;
        }, z.core.$strict>>;
        adoptions: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            taskId: z.ZodString;
            from: z.ZodNullable<z.ZodObject<{
                number: z.ZodNumber;
                digest: z.ZodString;
            }, z.core.$strict>>;
            to: z.ZodObject<{
                number: z.ZodNumber;
                digest: z.ZodString;
            }, z.core.$strict>;
            actor: z.ZodString;
            reason: z.ZodString;
            operation: z.ZodString;
            at: z.ZodISODateTime;
        }, z.core.$strict>>;
        pending: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            version: z.ZodNumber;
            digest: z.ZodOptional<z.ZodString>;
            awaitingOperator: z.ZodOptional<z.ZodBoolean>;
            tasks: z.ZodArray<z.ZodString>;
            status: z.ZodEnum<{
                completed: "completed";
                waiting: "waiting";
            }>;
            results: z.ZodRecord<z.ZodString, z.ZodString>;
            actor: z.ZodString;
            reason: z.ZodString;
            requestedAt: z.ZodISODateTime;
            completedAt: z.ZodOptional<z.ZodISODateTime>;
        }, z.core.$strict>>;
        operations: z.ZodRecord<z.ZodString, z.ZodObject<{
            key: z.ZodString;
            status: z.ZodEnum<{
                completed: "completed";
                running: "running";
            }>;
            token: z.ZodOptional<z.ZodString>;
            leaseUntil: z.ZodOptional<z.ZodNumber>;
            decision: z.ZodOptional<z.ZodString>;
            startedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
        revision: z.ZodNumber;
    }, z.core.$strict>;
    /** Техническая очередь ведущего (у DevContour — `lead`). */
    readonly 'workflow-jobs': z.ZodObject<{
        kind: z.ZodString;
        id: z.ZodString;
        authorRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
        maxAttempts: z.ZodNumber;
        key: z.ZodString;
        owner: z.ZodOptional<z.ZodString>;
        inputDigest: z.ZodString;
        stage: z.ZodNumber;
        attempts: z.ZodNumber;
        status: z.ZodEnum<{
            failed: "failed";
            completed: "completed";
            running: "running";
            queued: "queued";
            stale: "stale";
        }>;
        repairs: z.ZodOptional<z.ZodNumber>;
        token: z.ZodOptional<z.ZodString>;
        leaseUntil: z.ZodOptional<z.ZodNumber>;
        startedAt: z.ZodISODateTime;
        finishedAt: z.ZodOptional<z.ZodISODateTime>;
        error: z.ZodOptional<z.ZodString>;
        history: z.ZodArray<z.ZodObject<{
            at: z.ZodISODateTime;
            stage: z.ZodNumber;
            event: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    /**
     * Документы контрактов, прошедшие ревью, по digest: из них движок берёт
     * договор проверки и закреплённые артефакты поручения (у DevContour —
     * `contracts` состояния).
     */
    readonly 'contract-documents': z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        repositoryId: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        content: z.ZodString;
        artifacts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            blob: z.ZodString;
        }, z.core.$strict>>>;
        checks: z.ZodOptional<z.ZodObject<{
            version: z.ZodLiteral<1>;
            gate: z.ZodString;
            obligations: z.ZodArray<z.ZodObject<{
                property: z.ZodString;
                requirements: z.ZodArray<z.ZodString>;
                promise: z.ZodEnum<{
                    functional: "functional";
                    accuracy: "accuracy";
                    optimality: "optimality";
                    completeness: "completeness";
                    performance: "performance";
                    invariant: "invariant";
                    other: "other";
                }>;
                explanation: z.ZodOptional<z.ZodString>;
                domain: z.ZodObject<{
                    inputs: z.ZodString;
                    bounds: z.ZodString;
                    units: z.ZodOptional<z.ZodString>;
                    invalid: z.ZodString;
                }, z.core.$strict>;
                answer: z.ZodObject<{
                    rules: z.ZodString;
                    ties: z.ZodOptional<z.ZodString>;
                    rounding: z.ZodOptional<z.ZodString>;
                    tolerance: z.ZodOptional<z.ZodString>;
                    refusals: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                method: z.ZodObject<{
                    kind: z.ZodEnum<{
                        scenario: "scenario";
                        invariant: "invariant";
                        other: "other";
                        oracle: "oracle";
                        certificate: "certificate";
                        analytic: "analytic";
                    }>;
                    description: z.ZodString;
                    applicability: z.ZodString;
                    artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                coverage: z.ZodObject<{
                    families: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            typical: "typical";
                            boundary: "boundary";
                            adversarial: "adversarial";
                        }>;
                        description: z.ZodString;
                        minCases: z.ZodNumber;
                    }, z.core.$strict>>;
                    minCases: z.ZodNumber;
                    corpus: z.ZodDefault<z.ZodBoolean>;
                }, z.core.$strict>;
                resources: z.ZodObject<{
                    subject: z.ZodString;
                    oracle: z.ZodString;
                    benchmark: z.ZodOptional<z.ZodObject<{
                        method: z.ZodString;
                        environment: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                verification: z.ZodOptional<z.ZodEnum<{
                    property: "property";
                    reference: "reference";
                }>>;
                reference: z.ZodOptional<z.ZodObject<{
                    oracle: z.ZodObject<{
                        description: z.ZodString;
                        limits: z.ZodString;
                    }, z.core.$strict>;
                    crossChecks: z.ZodArray<z.ZodObject<{
                        family: z.ZodString;
                        against: z.ZodString;
                        matches: z.ZodNumber;
                        total: z.ZodNumber;
                        artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    sets: z.ZodArray<z.ZodObject<{
                        gate: z.ZodString;
                        artifacts: z.ZodArray<z.ZodString>;
                        minCases: z.ZodNumber;
                        families: z.ZodDefault<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            minCases: z.ZodNumber;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                    gaps: z.ZodString;
                }, z.core.$strict>>;
                hard: z.ZodDefault<z.ZodBoolean>;
                feasibility: z.ZodOptional<z.ZodObject<{
                    spike: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            corpus: z.ZodOptional<z.ZodObject<{
                format: z.ZodString;
                extensible: z.ZodBoolean;
                maxCases: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    /**
     * Ограниченные эксперименты выполнимости по репозиториям: на них ссылаются
     * тяжёлые обязательства договора проверки (у DevContour — `spikes`).
     */
    readonly spikes: z.ZodObject<{
        id: z.ZodString;
        repositoryId: z.ZodString;
        sha: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        seed: z.ZodNumber;
        sizes: z.ZodArray<z.ZodNumber>;
        timeoutMs: z.ZodNumber;
        question: z.ZodString;
        results: z.ZodArray<z.ZodObject<{
            size: z.ZodNumber;
            ms: z.ZodNumber;
            outcome: z.ZodEnum<{
                error: "error";
                ok: "ok";
                timeout: "timeout";
            }>;
            exitCode: z.ZodNumber;
        }, z.core.$strict>>;
        outcome: z.ZodEnum<{
            failed: "failed";
            feasible: "feasible";
            inconclusive: "inconclusive";
        }>;
        limits: z.ZodString;
        environment: z.ZodObject<{
            platform: z.ZodString;
            arch: z.ZodString;
            node: z.ZodString;
            cpus: z.ZodNumber;
            isolation: z.ZodString;
        }, z.core.$strict>;
        at: z.ZodString;
        digest: z.ZodString;
    }, z.core.$strict>;
    /**
     * Реестр воспроизведений из находок ревью по поручениям (у DevContour —
     * `reproductions` состояния): входы, на которых поручение ломалось,
     * передаются следующей попытке.
     */
    readonly reproductions: z.ZodObject<{
        workId: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            property: z.ZodNullable<z.ZodString>;
            inputHash: z.ZodString;
            input: z.ZodString;
            expected: z.ZodNullable<z.ZodString>;
            actual: z.ZodNullable<z.ZodString>;
            command: z.ZodNullable<z.ZodArray<z.ZodString>>;
            message: z.ZodString;
            claimed: z.ZodBoolean;
            observed: z.ZodBoolean;
            run: z.ZodNullable<z.ZodString>;
            runs: z.ZodArray<z.ZodObject<{
                runId: z.ZodString;
                sha: z.ZodString;
                at: z.ZodISODateTime;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
};
export type LocalNamespace = keyof typeof localSchemas;
export type LocalValue<N extends LocalNamespace> = z.infer<(typeof localSchemas)[N]>;
export declare const jointVerificationStateSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    status: z.ZodLiteral<"active">;
    manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        sha: z.ZodString;
        tree: z.ZodString;
    }, z.core.$strict>>>;
    manifestDigest: z.ZodOptional<z.ZodString>;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    startedAt: z.ZodISODateTime;
    policyDigest: z.ZodString;
    specDigest: z.ZodString;
    workIds: z.ZodArray<z.ZodString>;
    impact: z.ZodOptional<z.ZodObject<{
        changed: z.ZodArray<z.ZodString>;
        affected: z.ZodArray<z.ZodString>;
        gateIds: z.ZodArray<z.ZodString>;
        mode: z.ZodEnum<{
            all: "all";
            affected: "affected";
        }>;
        reason: z.ZodString;
        baseline: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    evidence: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        passed: z.ZodBoolean;
        command: z.ZodArray<z.ZodString>;
        exitCode: z.ZodNumber;
        log: z.ZodString;
        digest: z.ZodString;
        summary: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    token: z.ZodString;
    leaseUntil: z.ZodNumber;
    engineVersion: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"failed">;
    finishedAt: z.ZodISODateTime;
    manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        sha: z.ZodString;
        tree: z.ZodString;
    }, z.core.$strict>>>;
    manifestDigest: z.ZodOptional<z.ZodString>;
    error: z.ZodString;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    startedAt: z.ZodISODateTime;
    policyDigest: z.ZodString;
    specDigest: z.ZodString;
    workIds: z.ZodArray<z.ZodString>;
    impact: z.ZodOptional<z.ZodObject<{
        changed: z.ZodArray<z.ZodString>;
        affected: z.ZodArray<z.ZodString>;
        gateIds: z.ZodArray<z.ZodString>;
        mode: z.ZodEnum<{
            all: "all";
            affected: "affected";
        }>;
        reason: z.ZodString;
        baseline: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    evidence: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        passed: z.ZodBoolean;
        command: z.ZodArray<z.ZodString>;
        exitCode: z.ZodNumber;
        log: z.ZodString;
        digest: z.ZodString;
        summary: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    token: z.ZodString;
    leaseUntil: z.ZodNumber;
    engineVersion: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"passed">;
    finishedAt: z.ZodISODateTime;
    manifest: z.ZodRecord<z.ZodString, z.ZodObject<{
        sha: z.ZodString;
        tree: z.ZodString;
    }, z.core.$strict>>;
    manifestDigest: z.ZodString;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    startedAt: z.ZodISODateTime;
    policyDigest: z.ZodString;
    specDigest: z.ZodString;
    workIds: z.ZodArray<z.ZodString>;
    impact: z.ZodOptional<z.ZodObject<{
        changed: z.ZodArray<z.ZodString>;
        affected: z.ZodArray<z.ZodString>;
        gateIds: z.ZodArray<z.ZodString>;
        mode: z.ZodEnum<{
            all: "all";
            affected: "affected";
        }>;
        reason: z.ZodString;
        baseline: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    evidence: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        passed: z.ZodBoolean;
        command: z.ZodArray<z.ZodString>;
        exitCode: z.ZodNumber;
        log: z.ZodString;
        digest: z.ZodString;
        summary: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    token: z.ZodString;
    leaseUntil: z.ZodNumber;
    engineVersion: z.ZodOptional<z.ZodString>;
}, z.core.$strict>], "status">;
export type JointVerificationState = z.infer<typeof jointVerificationStateSchema>;
/** Документ состояния standalone SQLite. DevContour хранит свой документ, а не этот. */
export declare const executionDocumentSchema: z.ZodObject<{
    stateVersion: z.ZodLiteral<1>;
    graphs: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        digest: z.ZodString;
        graph: z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            id: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            orders: z.ZodArray<z.ZodObject<{
                apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
                id: z.ZodString;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
                title: z.ZodString;
                goal: z.ZodString;
                acceptance: z.ZodArray<z.ZodString>;
                role: z.ZodString;
                repositoryId: z.ZodString;
                relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
                writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
                dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
                gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>>;
                properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
                requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    source: z.ZodString;
                    digest: z.ZodString;
                    text: z.ZodString;
                    gate: z.ZodString;
                    scenario: z.ZodString;
                    testId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>>;
                context: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            prerequisites: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                repositoryId: z.ZodString;
                resultSha: z.ZodString;
                receipt: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"engine">;
                    runId: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"trusted">;
                    issuer: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>], "kind">;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        policyDigest: z.ZodString;
        approval: z.ZodOptional<z.ZodObject<{
            actor: z.ZodEnum<{
                agent: "agent";
                operator: "operator";
            }>;
            authorRuntime: z.ZodOptional<z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>>;
            reviewerRuntime: z.ZodOptional<z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>>;
            artifact: z.ZodOptional<z.ZodString>;
            digest: z.ZodOptional<z.ZodString>;
            context: z.ZodOptional<z.ZodObject<{
                digest: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>>;
            at: z.ZodISODateTime;
        }, z.core.$strict>>;
        registeredAt: z.ZodISODateTime;
    }, z.core.$strict>>;
    works: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        graphId: z.ZodString;
        order: z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            id: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            title: z.ZodString;
            goal: z.ZodString;
            acceptance: z.ZodArray<z.ZodString>;
            role: z.ZodString;
            repositoryId: z.ZodString;
            relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
            writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
            dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
            gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>>;
            properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                source: z.ZodString;
                digest: z.ZodString;
                text: z.ZodString;
                gate: z.ZodString;
                scenario: z.ZodString;
                testId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>>;
            context: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        activeRunId: z.ZodOptional<z.ZodString>;
        resultSha: z.ZodOptional<z.ZodString>;
        failure: z.ZodOptional<z.ZodString>;
        failureKind: z.ZodOptional<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            environment: "environment";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
        }>>;
        failureFingerprint: z.ZodOptional<z.ZodString>;
        approvedAt: z.ZodOptional<z.ZodISODateTime>;
        approvedDigest: z.ZodOptional<z.ZodString>;
        approvedScope: z.ZodOptional<z.ZodString>;
        approval: z.ZodOptional<z.ZodObject<{
            actor: z.ZodEnum<{
                agent: "agent";
                operator: "operator";
            }>;
            authorRuntime: z.ZodOptional<z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>>;
            reviewerRuntime: z.ZodOptional<z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>>;
            artifact: z.ZodOptional<z.ZodString>;
            digest: z.ZodOptional<z.ZodString>;
            context: z.ZodOptional<z.ZodObject<{
                digest: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        hold: z.ZodOptional<z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
        }, z.core.$strict>>;
        budgetBlock: z.ZodOptional<z.ZodObject<{
            reason: z.ZodString;
            at: z.ZodISODateTime;
        }, z.core.$strict>>;
        checkVersion: z.ZodOptional<z.ZodObject<{
            suite: z.ZodString;
            number: z.ZodNumber;
            digest: z.ZodString;
        }, z.core.$strict>>;
        recovery: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            property: z.ZodString;
            basis: z.ZodString;
            runs: z.ZodArray<z.ZodString>;
            openedAt: z.ZodISODateTime;
            status: z.ZodEnum<{
                closed: "closed";
                stopped: "stopped";
                "awaiting-lead": "awaiting-lead";
                analyzing: "analyzing";
                applying: "applying";
                retry: "retry";
                retrying: "retrying";
                "awaiting-user": "awaiting-user";
            }>;
            calls: z.ZodNumber;
            decision: z.ZodOptional<z.ZodObject<{
                action: z.ZodEnum<{
                    environment: "environment";
                    "add-cases": "add-cases";
                    "new-approach": "new-approach";
                    "strengthen-checker": "strengthen-checker";
                    "split-task": "split-task";
                    "clarify-obligation": "clarify-obligation";
                }>;
                reason: z.ZodString;
                evidence: z.ZodArray<z.ZodString>;
                hypothesis: z.ZodOptional<z.ZodString>;
                plan: z.ZodOptional<z.ZodString>;
                cases: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    input: z.ZodString;
                    expected: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                proposal: z.ZodOptional<z.ZodString>;
                conflict: z.ZodOptional<z.ZodString>;
                source: z.ZodObject<{
                    kind: z.ZodEnum<{
                        operator: "operator";
                        lead: "lead";
                    }>;
                    runtime: z.ZodOptional<z.ZodString>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                decidedAt: z.ZodISODateTime;
            }, z.core.$strict>>;
            retryRun: z.ZodOptional<z.ZodString>;
            reason: z.ZodOptional<z.ZodString>;
            history: z.ZodArray<z.ZodObject<{
                at: z.ZodISODateTime;
                event: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            version: z.ZodNumber;
        }, z.core.$strict>>;
        recoveryHistory: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            property: z.ZodString;
            basis: z.ZodString;
            runs: z.ZodArray<z.ZodString>;
            openedAt: z.ZodISODateTime;
            status: z.ZodEnum<{
                closed: "closed";
                stopped: "stopped";
                "awaiting-lead": "awaiting-lead";
                analyzing: "analyzing";
                applying: "applying";
                retry: "retry";
                retrying: "retrying";
                "awaiting-user": "awaiting-user";
            }>;
            calls: z.ZodNumber;
            decision: z.ZodOptional<z.ZodObject<{
                action: z.ZodEnum<{
                    environment: "environment";
                    "add-cases": "add-cases";
                    "new-approach": "new-approach";
                    "strengthen-checker": "strengthen-checker";
                    "split-task": "split-task";
                    "clarify-obligation": "clarify-obligation";
                }>;
                reason: z.ZodString;
                evidence: z.ZodArray<z.ZodString>;
                hypothesis: z.ZodOptional<z.ZodString>;
                plan: z.ZodOptional<z.ZodString>;
                cases: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    input: z.ZodString;
                    expected: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strict>>>;
                proposal: z.ZodOptional<z.ZodString>;
                conflict: z.ZodOptional<z.ZodString>;
                source: z.ZodObject<{
                    kind: z.ZodEnum<{
                        operator: "operator";
                        lead: "lead";
                    }>;
                    runtime: z.ZodOptional<z.ZodString>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                decidedAt: z.ZodISODateTime;
            }, z.core.$strict>>;
            retryRun: z.ZodOptional<z.ZodString>;
            reason: z.ZodOptional<z.ZodString>;
            history: z.ZodArray<z.ZodObject<{
                at: z.ZodISODateTime;
                event: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            version: z.ZodNumber;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    attempts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        workId: z.ZodString;
        repositoryId: z.ZodString;
        attempt: z.ZodNumber;
        token: z.ZodString;
        owner: z.ZodString;
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        model: z.ZodOptional<z.ZodString>;
        reviewerModel: z.ZodOptional<z.ZodString>;
        effort: z.ZodOptional<z.ZodString>;
        reviewerEffort: z.ZodOptional<z.ZodString>;
        policyDigest: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            cancelled: "cancelled";
            active: "active";
            expired: "expired";
            succeeded: "succeeded";
        }>;
        phase: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        startedAt: z.ZodISODateTime;
        finishedAt: z.ZodOptional<z.ZodISODateTime>;
        leaseUntil: z.ZodNumber;
        worktree: z.ZodOptional<z.ZodString>;
        baseSha: z.ZodOptional<z.ZodString>;
        candidateSha: z.ZodOptional<z.ZodString>;
        integrationSha: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
        blocked: z.ZodOptional<z.ZodBoolean>;
        failureKind: z.ZodOptional<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            environment: "environment";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
        }>>;
        failureFingerprint: z.ZodOptional<z.ZodString>;
        requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            gates: z.ZodArray<z.ZodString>;
            checked: z.ZodOptional<z.ZodObject<{
                sha: z.ZodString;
                tree: z.ZodString;
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>>;
                observedAt: z.ZodOptional<z.ZodISODateTime>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        checks: z.ZodOptional<z.ZodObject<{
            effective: z.ZodString;
            corpus: z.ZodOptional<z.ZodObject<{
                suite: z.ZodString;
                number: z.ZodNumber;
                digest: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        context: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            repositoryId: z.ZodString;
            revision: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>>;
        contextSnapshot: z.ZodOptional<z.ZodString>;
        resources: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                device: "device";
                port: "port";
                account: "account";
                service: "service";
            }>;
            value: z.ZodString;
        }, z.core.$strict>>>;
        dependencies: z.ZodOptional<z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            sha: z.ZodString;
            tree: z.ZodString;
            path: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        dependencyFreshness: z.ZodOptional<z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            snapshot: z.ZodString;
            head: z.ZodString;
            fresh: z.ZodBoolean;
        }, z.core.$strict>>>;
        properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
        unboundProperties: z.ZodOptional<z.ZodArray<z.ZodString>>;
        episodeBasis: z.ZodOptional<z.ZodString>;
        implementationBasis: z.ZodOptional<z.ZodString>;
        reusedFrom: z.ZodOptional<z.ZodObject<{
            runId: z.ZodString;
            candidateSha: z.ZodString;
        }, z.core.$strict>>;
        partial: z.ZodOptional<z.ZodObject<{
            patch: z.ZodString;
            digest: z.ZodString;
            files: z.ZodArray<z.ZodString>;
            spec: z.ZodString;
            contracts: z.ZodRecord<z.ZodString, z.ZodString>;
        }, z.core.$strict>>;
        continuedFrom: z.ZodOptional<z.ZodObject<{
            runId: z.ZodString;
            kind: z.ZodEnum<{
                candidate: "candidate";
                unfinished: "unfinished";
            }>;
            reason: z.ZodOptional<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
            }>>;
            respecified: z.ZodOptional<z.ZodBoolean>;
            applied: z.ZodBoolean;
            files: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        callsRecorded: z.ZodOptional<z.ZodLiteral<true>>;
        dispatch: z.ZodOptional<z.ZodObject<{
            policy: z.ZodLiteral<"fifo-ready-v1">;
            at: z.ZodISODateTime;
            eligible: z.ZodArray<z.ZodObject<{
                taskId: z.ZodString;
                repositoryId: z.ZodOptional<z.ZodString>;
                attempt: z.ZodNumber;
            }, z.core.$strict>>;
            activeCount: z.ZodNumber;
            concurrency: z.ZodNumber;
            inputDigest: z.ZodString;
        }, z.core.$strict>>;
        wait: z.ZodOptional<z.ZodObject<{
            approvedAt: z.ZodOptional<z.ZodISODateTime>;
            readyAt: z.ZodOptional<z.ZodISODateTime>;
        }, z.core.$strict>>;
        timings: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            stage: z.ZodString;
            startedAt: z.ZodISODateTime;
            finishedAt: z.ZodOptional<z.ZodISODateTime>;
            outcome: z.ZodOptional<z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>>;
        }, z.core.$strict>>>;
        pinned: z.ZodOptional<z.ZodObject<{
            graphId: z.ZodString;
            graphDigest: z.ZodString;
            orderDigest: z.ZodString;
            targetRef: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        engineVersion: z.ZodOptional<z.ZodString>;
        consumerVersion: z.ZodOptional<z.ZodString>;
        evidence: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            runId: z.ZodString;
            kind: z.ZodEnum<{
                test: "test";
                review: "review";
            }>;
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            sha: z.ZodString;
            gate: z.ZodString;
            passed: z.ZodBoolean;
            createdAt: z.ZodISODateTime;
            command: z.ZodArray<z.ZodString>;
            exitCode: z.ZodNumber;
            log: z.ZodString;
            digest: z.ZodString;
            summary: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
            inspection: z.ZodOptional<z.ZodObject<{
                mode: z.ZodEnum<{
                    commands: "commands";
                    "diff-only": "diff-only";
                }>;
                source: z.ZodEnum<{
                    "codex-events": "codex-events";
                    unavailable: "unavailable";
                    "controller-probes": "controller-probes";
                    "runtime-and-controller": "runtime-and-controller";
                }>;
                commands: z.ZodArray<z.ZodObject<{
                    command: z.ZodString;
                    exitCode: z.ZodNullable<z.ZodNumber>;
                    output: z.ZodString;
                    origins: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                        type: z.ZodLiteral<"runtime">;
                        runtime: z.ZodString;
                        item: z.ZodNullable<z.ZodString>;
                    }, z.core.$strict>, z.ZodObject<{
                        type: z.ZodLiteral<"controller">;
                        runId: z.ZodString;
                    }, z.core.$strict>], "type">>>;
                    status: z.ZodOptional<z.ZodEnum<{
                        error: "error";
                        passed: "passed";
                        failed: "failed";
                        cancelled: "cancelled";
                        completed: "completed";
                        timeout: "timeout";
                    }>>;
                    failure: z.ZodOptional<z.ZodEnum<{
                        report: "report";
                        environment: "environment";
                    }>>;
                    gate: z.ZodOptional<z.ZodString>;
                    note: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                reason: z.ZodNullable<z.ZodString>;
                context: z.ZodOptional<z.ZodObject<{
                    attempt: z.ZodString;
                    phase: z.ZodEnum<{
                        candidate: "candidate";
                        integration: "integration";
                    }>;
                    sha: z.ZodString;
                    call: z.ZodNumber;
                }, z.core.$strict>>;
                total: z.ZodOptional<z.ZodNumber>;
                excluded: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    runId: z.ZodString;
                    status: z.ZodNullable<z.ZodString>;
                    reason: z.ZodEnum<{
                        "not-started": "not-started";
                        "legacy-unconfirmed": "legacy-unconfirmed";
                        "foreign-scope": "foreign-scope";
                        "unknown-status": "unknown-status";
                        unfinished: "unfinished";
                        abandoned: "abandoned";
                    }>;
                }, z.core.$strict>>>;
                excludedTotal: z.ZodOptional<z.ZodNumber>;
                invalid: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            findings: z.ZodOptional<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            reviewRound: z.ZodOptional<z.ZodObject<{
                version: z.ZodLiteral<1>;
                scope: z.ZodString;
                round: z.ZodNumber;
                call: z.ZodNumber;
                calls: z.ZodNumber;
                protocol: z.ZodEnum<{
                    valid: "valid";
                    invalid: "invalid";
                    unsafe: "unsafe";
                }>;
                expected: z.ZodArray<z.ZodString>;
                issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    reason: z.ZodEnum<{
                        unknown: "unknown";
                        missing: "missing";
                        schema: "schema";
                        duplicate: "duplicate";
                        "not-open": "not-open";
                        "approved-with-blocking": "approved-with-blocking";
                    }>;
                    message: z.ZodString;
                }, z.core.$strict>>>;
                transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    from: z.ZodEnum<{
                        open: "open";
                        closed: "closed";
                        withdrawn: "withdrawn";
                    }>;
                    to: z.ZodEnum<{
                        open: "open";
                        closed: "closed";
                        withdrawn: "withdrawn";
                    }>;
                    basis: z.ZodString;
                }, z.core.$strict>>>;
                spec: z.ZodOptional<z.ZodString>;
                mode: z.ZodOptional<z.ZodEnum<{
                    legacy: "legacy";
                    strict: "strict";
                }>>;
            }, z.core.$strict>>;
            tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                    skipped: "skipped";
                }>;
                opaque: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>>;
            testsTruncated: z.ZodOptional<z.ZodBoolean>;
            property: z.ZodOptional<z.ZodObject<{
                seed: z.ZodNumber;
                reproduce: z.ZodString;
                report: z.ZodOptional<z.ZodObject<{
                    version: z.ZodLiteral<1>;
                    seed: z.ZodOptional<z.ZodNumber>;
                    properties: z.ZodArray<z.ZodObject<{
                        testId: z.ZodString;
                        status: z.ZodEnum<{
                            passed: "passed";
                            failed: "failed";
                            running: "running";
                        }>;
                        cases: z.ZodNumber;
                        families: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodNumber>>;
                        error: z.ZodOptional<z.ZodString>;
                        current: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                        counterexample: z.ZodOptional<z.ZodObject<{
                            original: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
                            reduced: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                            expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                            actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                            reductionTimedOut: z.ZodOptional<z.ZodBoolean>;
                            case: z.ZodOptional<z.ZodString>;
                        }, z.core.$strip>>;
                    }, z.core.$strip>>;
                    corpus: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        executed: z.ZodNumber;
                        passed: z.ZodNumber;
                        witness: z.ZodString;
                        failed: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            property: z.ZodString;
                            expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                            actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                        }, z.core.$strip>>;
                    }, z.core.$strip>>;
                }, z.core.$strip>>;
                problem: z.ZodOptional<z.ZodString>;
                contracts: z.ZodRecord<z.ZodString, z.ZodString>;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    blob: z.ZodString;
                }, z.core.$strict>>;
                level: z.ZodOptional<z.ZodEnum<{
                    manifest: "manifest";
                    legacy: "legacy";
                }>>;
                manifest: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodString;
                    properties: z.ZodArray<z.ZodString>;
                    corpus: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        cases: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                coverage: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            checks: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    verifications: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        status: z.ZodLiteral<"active">;
        manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            sha: z.ZodString;
            tree: z.ZodString;
        }, z.core.$strict>>>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        startedAt: z.ZodISODateTime;
        policyDigest: z.ZodString;
        specDigest: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        impact: z.ZodOptional<z.ZodObject<{
            changed: z.ZodArray<z.ZodString>;
            affected: z.ZodArray<z.ZodString>;
            gateIds: z.ZodArray<z.ZodString>;
            mode: z.ZodEnum<{
                all: "all";
                affected: "affected";
            }>;
            reason: z.ZodString;
            baseline: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        evidence: z.ZodArray<z.ZodObject<{
            gate: z.ZodString;
            passed: z.ZodBoolean;
            command: z.ZodArray<z.ZodString>;
            exitCode: z.ZodNumber;
            log: z.ZodString;
            digest: z.ZodString;
            summary: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        token: z.ZodString;
        leaseUntil: z.ZodNumber;
        engineVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodLiteral<"failed">;
        finishedAt: z.ZodISODateTime;
        manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            sha: z.ZodString;
            tree: z.ZodString;
        }, z.core.$strict>>>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        error: z.ZodString;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        startedAt: z.ZodISODateTime;
        policyDigest: z.ZodString;
        specDigest: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        impact: z.ZodOptional<z.ZodObject<{
            changed: z.ZodArray<z.ZodString>;
            affected: z.ZodArray<z.ZodString>;
            gateIds: z.ZodArray<z.ZodString>;
            mode: z.ZodEnum<{
                all: "all";
                affected: "affected";
            }>;
            reason: z.ZodString;
            baseline: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        evidence: z.ZodArray<z.ZodObject<{
            gate: z.ZodString;
            passed: z.ZodBoolean;
            command: z.ZodArray<z.ZodString>;
            exitCode: z.ZodNumber;
            log: z.ZodString;
            digest: z.ZodString;
            summary: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        token: z.ZodString;
        leaseUntil: z.ZodNumber;
        engineVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodLiteral<"passed">;
        finishedAt: z.ZodISODateTime;
        manifest: z.ZodRecord<z.ZodString, z.ZodObject<{
            sha: z.ZodString;
            tree: z.ZodString;
        }, z.core.$strict>>;
        manifestDigest: z.ZodString;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        startedAt: z.ZodISODateTime;
        policyDigest: z.ZodString;
        specDigest: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        impact: z.ZodOptional<z.ZodObject<{
            changed: z.ZodArray<z.ZodString>;
            affected: z.ZodArray<z.ZodString>;
            gateIds: z.ZodArray<z.ZodString>;
            mode: z.ZodEnum<{
                all: "all";
                affected: "affected";
            }>;
            reason: z.ZodString;
            baseline: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        evidence: z.ZodArray<z.ZodObject<{
            gate: z.ZodString;
            passed: z.ZodBoolean;
            command: z.ZodArray<z.ZodString>;
            exitCode: z.ZodNumber;
            log: z.ZodString;
            digest: z.ZodString;
            summary: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        token: z.ZodString;
        leaseUntil: z.ZodNumber;
        engineVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>], "status">>>;
    control: z.ZodObject<{
        paused: z.ZodBoolean;
        pauseReason: z.ZodOptional<z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>>;
        pausedAt: z.ZodOptional<z.ZodISODateTime>;
        pauseOperation: z.ZodOptional<z.ZodString>;
        pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            environment: "environment";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
        }>>>;
        waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                "base-check": "base-check";
                "context-lock": "context-lock";
            }>;
            detail: z.ZodString;
            at: z.ZodISODateTime;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        appliedPolicy: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodOptional<z.ZodNumber>;
            at: z.ZodISODateTime;
            by: z.ZodString;
        }, z.core.$strict>>;
        reconfigure: z.ZodOptional<z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            requestedAt: z.ZodISODateTime;
            appliedAt: z.ZodOptional<z.ZodISODateTime>;
            appliedBy: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    controller: z.ZodOptional<z.ZodObject<{
        owner: z.ZodString;
        leaseUntil: z.ZodNumber;
        engineVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    sequence: z.ZodNumber;
}, z.core.$strict>;
export type ExecutionDocument = z.infer<typeof executionDocumentSchema>;
/** Текст, который хранит fencing-токен, — проверка утечки в тестах и адаптерах. */
export declare const containsToken: (value: unknown, token: string) => boolean;
