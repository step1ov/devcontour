import { z } from 'zod';
import { type Author, type ExecutionPolicy, type ExecutionView, type PropertyRecovery, type RuntimeAdapter, type RuntimeBinding, type WorkState } from '../contracts/index.ts';
import type { Engine } from '../engine/engine.ts';
import type { Runner } from '../engine/runner.ts';
/**
 * Разбор ведущего по повторяющемуся свойству.
 *
 * Ответ — структурированное предложение с причиной и evidence, а не
 * произвольная программа или правка состояния. Controller проверяет
 * допустимость и исполняет только разрешённое: добавление подтверждённых
 * случаев под существующим эталоном и один повтор с новой гипотезой —
 * автономно; усиление checker и декомпозиция — подготовленным предложением
 * для обычного ревью; уточнение обязательства — решением человека; причина в
 * среде — остановкой с диагностикой.
 */
export declare const recoveryResultSchema: z.ZodObject<{
    action: z.ZodEnum<{
        environment: "environment";
        "add-cases": "add-cases";
        "new-approach": "new-approach";
        "strengthen-checker": "strengthen-checker";
        "split-task": "split-task";
        "clarify-obligation": "clarify-obligation";
    }>;
    reason: z.ZodString;
    evidence: z.ZodArray<z.ZodString>;
    hypothesis: z.ZodNullable<z.ZodString>;
    plan: z.ZodNullable<z.ZodString>;
    cases: z.ZodNullable<z.ZodArray<z.ZodObject<{
        input: z.ZodString;
        expected: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>>;
    proposal: z.ZodNullable<z.ZodString>;
    conflict: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/** JSON Schema ответа разбора для structured output runtime. */
export declare const recoveryOutputSchema: {
    type: string;
    additionalProperties: boolean;
    properties: {
        action: {
            type: string;
            enum: ("environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation")[];
        };
        reason: {
            type: string;
        };
        evidence: {
            type: string;
            items: {
                type: string;
            };
        };
        hypothesis: {
            type: string[];
        };
        plan: {
            type: string[];
        };
        cases: {
            anyOf: ({
                type: string;
                items?: undefined;
            } | {
                type: string;
                items: {
                    type: string;
                    additionalProperties: boolean;
                    properties: {
                        input: {
                            type: string;
                        };
                        expected: {
                            type: string[];
                        };
                    };
                    required: string[];
                };
            })[];
        };
        proposal: {
            type: string[];
        };
        conflict: {
            type: string[];
        };
    };
    required: string[];
};
/** Что ведущий получает для разбора: свойство, версии, примеры, попытки, время, действия. */
export declare function recoveryBrief(view: ExecutionView, work: WorkState, policy: ExecutionPolicy): {
    work: {
        id: string;
        title: string;
        goal: string;
        attempt: number;
    };
    property: string;
    obligation: {
        property: string;
        requirements: string[];
        promise: "functional" | "accuracy" | "optimality" | "completeness" | "performance" | "invariant" | "other";
        domain: {
            inputs: string;
            bounds: string;
            invalid: string;
            units?: string | undefined;
        };
        answer: {
            rules: string;
            ties?: string | undefined;
            rounding?: string | undefined;
            tolerance?: string | undefined;
            refusals?: string | undefined;
        };
        method: {
            kind: "scenario" | "invariant" | "other" | "oracle" | "certificate" | "analytic";
            description: string;
            applicability: string;
            artifacts: string[];
        };
        coverage: {
            families: {
                id: string;
                kind: "typical" | "boundary" | "adversarial";
                description: string;
                minCases: number;
            }[];
            minCases: number;
            corpus: boolean;
        };
        resources: {
            subject: string;
            oracle: string;
            benchmark?: {
                method: string;
                environment: string;
            } | undefined;
        };
        hard: boolean;
        explanation?: string | undefined;
        gates?: string[] | undefined;
        verification?: "property" | "reference" | undefined;
        reference?: {
            oracle: {
                description: string;
                limits: string;
            };
            crossChecks: {
                family: string;
                against: string;
                matches: number;
                total: number;
                artifacts?: string[] | undefined;
            }[];
            sets: {
                gate: string;
                artifacts: string[];
                minCases: number;
                families: {
                    id: string;
                    minCases: number;
                }[];
            }[];
            gaps: string;
        } | undefined;
        feasibility?: {
            spike: string;
            digest: string;
        } | undefined;
    } | undefined;
    versions: {
        spec: string | undefined;
        contracts: {
            [k: string]: string;
        };
        corpus: {
            suite: string;
            number: number;
            digest: string;
        } | null;
    };
    examples: {
        run: string;
        phase: "candidate" | "integration";
        seed: number;
        counterexample: {
            original: unknown;
            reduced?: unknown;
            expected?: unknown;
            actual?: unknown;
            reductionTimedOut?: boolean | undefined;
            case?: string | undefined;
        } | null;
        current: {} | null;
    }[];
    corpus: {
        suite: string;
        cases: {
            id: string;
            input: string;
            expected: string;
        }[];
    } | null;
    attempts: {
        run: string;
        attempt: number;
        failureKind: "gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | undefined;
        error: string | undefined;
        findings: {
            severity: string;
            message: string;
            path?: string | null | undefined;
            line?: number | null | undefined;
            id?: string | undefined;
            status?: "open" | "closed" | "withdrawn" | undefined;
        }[];
        durationMs: number | null;
    }[];
    spentMs: number;
    budgets: {
        attemptsLeft: number;
        repairBudget: number;
    };
    actions: {
        'add-cases': string;
        'new-approach': string;
        'strengthen-checker': string;
        'split-task': string;
        'clarify-obligation': string;
        environment: string;
    };
};
/** Разбор ведущим (runtime автора) — под учётом вызова, без права правки. */
export declare function analyzeRecovery(ctx: {
    engine: Engine;
    policy: ExecutionPolicy;
    adapters: Partial<Record<Author, RuntimeAdapter>>;
    stateDir: string;
    cwd: string;
    environment?: NodeJS.ProcessEnv;
    /**
     * Назначение вызова сверх runtime автора (модель, профиль инструментов) —
     * у хоста с собственным выбором модели и профиля ведущего. Окружение
     * вызова получает окружение профиля.
     */
    binding?: Omit<RuntimeBinding, 'runtime'>;
    /** Дополнительно закрытое и открытое на чтение вызову. */
    boundary?: {
        hidden: string[];
        readable: string[];
    };
}, work: WorkState, author: 'codex' | 'claude', signal: AbortSignal): Promise<NonNullable<PropertyRecovery['decision']>>;
/**
 * Исполнить разрешённое добавление случаев: каждый подтверждается эталоном
 * на дефектном SHA. Ключи выводятся из эпизода — повтор после сбоя не
 * создаёт второго подтверждения.
 */
export declare function applyCases(runner: Runner, work: WorkState): Promise<{
    outcome: string;
    reason: string;
}[]>;
