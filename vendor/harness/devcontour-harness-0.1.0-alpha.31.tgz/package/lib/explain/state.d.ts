import type { ExecutionView } from '../contracts/index.ts';
import type { Harness } from '../control/harness.ts';
import type { StopInput } from '../projections/stop.ts';
export interface StopInputOptions {
    maxAttempts: number;
    repairBudget: number;
    workId?: string;
}
/**
 * Control таким, каким его увидит следующий run этого процесса: run снимает
 * паузу «не запускали» (без причины) и штатную остановку, а применимый запрос
 * политики применяет до выдачи стадии (с ним снимается и его пауза). Общий
 * для `explain` и `status --detail`. `lifted` — пауза есть, но её снимет run.
 * Документ не меняется: `control` — прежний объект или его копия.
 */
export declare function nextRunControl(h: Harness, v: ExecutionView): {
    control: {
        paused: boolean;
        pauseReason?: "runtime" | "operator" | "shutdown" | "base-check" | "reconfigure" | undefined;
        pausedAt?: string | undefined;
        pauseOperation?: string | undefined;
        pauseFailures?: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead")[] | undefined;
        waits?: {
            kind: "base-check" | "context-lock";
            detail: string;
            at: string;
            operation?: string | undefined;
        }[] | undefined;
        appliedPolicy?: {
            digest: string;
            at: string;
            by: string;
            generation?: number | undefined;
        } | undefined;
        reconfigure?: {
            operation: string;
            digest: string;
            requestedAt: string;
            appliedAt?: string | undefined;
            appliedBy?: string | undefined;
            error?: string | undefined;
        } | undefined;
    };
    lifted: boolean;
};
/**
 * Входы explainStop из сохранённого состояния; ничего не пишет.
 *
 * Класс отказа — сохранённый `failureKind` (его поставил классификатор в
 * точке отказа); текст ошибки здесь не разбирается. Счётчики восстановления
 * подставляются так, как их видит `repairDecision` (h1-spec K4): без
 * отпечатка повторять нечего, без задания графа движок сам не чинит.
 * Первым идёт вход действующей роли controller, затем поручения (кроме
 * принятых) в порядке состояния.
 */
export declare function stopInputsOf(h: Harness, options: StopInputOptions): StopInput[];
