import { type ErrorCode } from '../contracts/errors.ts';
import type { Actor, FailureKind, NextAction, PauseReason, WorkStatus } from './enums.ts';
/**
 * Код остановки по классу отказа. Это та же таблица, которой RunResult
 * называет stopReason: сетевой класс приходит из сохранённого failureKind
 * (его ставит classifyFailure в точке отказа), текст здесь не разбирается.
 */
export declare function stopCodeOf(kind: FailureKind | undefined): ErrorCode;
export interface QueuePause {
    code: ErrorCode;
    cause: StopCause;
    actor: Actor;
    action: NextAction;
}
/**
 * Кто и что снимает паузу выдачи — то же рассуждение, которым `explainStop`
 * объясняет остановку на claim: пауза оператора и штатной остановки снимается
 * `resume`; пауза отказа runtime — исправлением первого класса отказа
 * (`pauseFailures`, без него — окружение); паузу reconfigure и base-check
 * снимает сама операция. Без паузы — `undefined`. Пауза без причины —
 * прежние записи паузы рантайма (как в `queueStop`).
 */
export declare function queuePause(control: {
    paused: boolean;
    pauseReason?: PauseReason;
    pauseFailures?: readonly FailureKind[];
}): QueuePause | undefined;
export declare const stopCauses: readonly ["provider-auth", "environment", "timeout", "stalled", "stale-base", "empty-result", "unfinished", "scope-violation", "gate", "review", "review-protocol", "merge", "cancelled", "budget", "needs-lead", "unknown", "runtime-missing", "controller-busy", "operator-pause", "approval-required", "not-ready"];
export type StopCause = (typeof stopCauses)[number];
export declare const stopPhases: readonly ["preflight", "claim", "implementation", "gates", "review", "integration", "delivery"];
export type StopPhase = (typeof stopPhases)[number];
export interface EvidenceLink {
    kind: 'attempt' | 'evidence' | 'event' | 'doctor';
    id: string;
    sha?: string;
}
export type StopInput = {
    kind: 'work';
    work: {
        id: string;
        status: WorkStatus;
        attempt: number;
        failureKind?: FailureKind;
        failure?: string;
        hold?: {
            operation: string;
            reason: string;
        };
        budgetBlock?: {
            reason: string;
        };
        /**
         * Эпизод восстановления свойства: работу ведёт его разбор, а не штатный
         * repair. Статус — как в `PropertyRecovery.status`.
         */
        recovery?: {
            status: string;
        };
        /** Незавершённые предпосылки, на которых движок остановит задание. */
        waitingOn?: string[];
        /** Согласование графа устарело для этой политики (режим operator). */
        approvalStale?: string;
        /**
         * Активная попытка без движения по обходу controller: что не
         * двигалось, сколько и что controller сделает (`action` у stalled).
         */
        liveness?: {
            state: 'quiet' | 'stalled';
            lastMovementAt: string;
            activity?: string;
            action?: 'stop' | 'report';
        };
    };
    maxAttempts: number;
    repair: {
        sameFailureRepairs: number;
        groupRepairsUsed: number;
        groupRepairBudget: number;
        /**
         * Что движок сделает с этой работой, когда продолжит задание графа
         * (вычисляется тем же порядком решений, что `advance`): `retry` —
         * назначит повтор, `wait` — сначала занят другим (разбор свойства,
         * другое поручение группы), `stop` — автоматического действия нет.
         * Не задано — решение выводится из счётчиков.
         */
        outlook?: 'retry' | 'wait' | 'stop';
    };
    control: {
        paused: boolean;
        pauseReason?: PauseReason;
        pauseFailures?: FailureKind[];
    };
    phase?: StopPhase;
    runId?: string;
    evidence?: EvidenceLink[];
} | {
    kind: 'error';
    error: {
        code: ErrorCode;
        message: string;
    };
} | {
    kind: 'runtime';
    runtime: {
        runtime: string;
        available: boolean;
        reason?: string;
    };
};
export interface StopDiagnosis {
    code: ErrorCode;
    cause: StopCause;
    phase: StopPhase;
    actor: Actor;
    action: NextAction;
    retryPlanned: boolean;
    message: string;
    evidence: EvidenceLink[];
    workId?: string;
    runId?: string;
}
/**
 * Объяснение остановки (OP-DIAG-05): только чтение, ничего не планирует.
 * Класс отказа берётся из сохранённого `failureKind` — текст ошибки здесь не
 * разбирается и не переклассифицируется (исторический `unknown` остаётся им).
 */
export declare function explainStop(input: StopInput): StopDiagnosis;
