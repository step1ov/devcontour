import { z } from 'zod';
/** Предел имени стадии в событии `attempt.stage`. */
export declare const STAGE_NAME_LIMIT = 300;
/**
 * Нагрузка каждого типа события — закрытая схема: лишних полей нет, и
 * поэтому в событие нельзя положить fencing-токен, секрет или произвольный
 * объект попытки. Событие читают внешние получатели и CLI.
 */
export declare const eventPayloads: {
    readonly 'graph.registered': z.ZodObject<{
        digest: z.ZodString;
        orders: z.ZodNumber;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>;
    readonly 'graph.reviewed': z.ZodObject<{
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        approved: z.ZodBoolean;
        open: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'graph.approved': z.ZodObject<{
        digest: z.ZodString;
        actor: z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>;
    }, z.core.$strict>;
    readonly 'work.ready': z.ZodObject<{
        orderDigest: z.ZodString;
    }, z.core.$strict>;
    readonly 'work.held': z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        released: z.ZodBoolean;
    }, z.core.$strict>;
    readonly 'attempt.claimed': z.ZodObject<{
        owner: z.ZodString;
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        policyDigest: z.ZodString;
        engineVersion: z.ZodString;
    }, z.core.$strict>;
    readonly 'attempt.phase': z.ZodObject<{
        phase: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        sha: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    readonly 'attempt.gate': z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        gate: z.ZodString;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
        recheck: z.ZodOptional<z.ZodObject<{
            of: z.ZodString;
            outcome: z.ZodEnum<{
                flaky: "flaky";
                confirmed: "confirmed";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'attempt.review': z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        sameVendor: z.ZodBoolean;
        blocking: z.ZodNumber;
    }, z.core.$strict>;
    /**
     * Граница стадии попытки (замер `AttemptState.timings`): одно `started` и
     * не больше одного `finished` на стадию, в той же транзакции под fencing,
     * что и замер. Стадия попытки, утратившей владение или упавшей, остаётся
     * открытой: её конец — событие конца попытки. `at` и `durationMs` — по
     * часам движка, те же, что в замере.
     */
    readonly 'attempt.stage': z.ZodObject<{
        timingId: z.ZodString;
        stage: z.ZodString;
        phase: z.ZodEnum<{
            started: "started";
            finished: "finished";
        }>;
        at: z.ZodISODateTime;
        durationMs: z.ZodOptional<z.ZodNumber>;
        outcome: z.ZodOptional<z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>>;
    }, z.core.$strict>;
    /**
     * Обход controller сменил живость исполняющейся попытки (только переходы).
     * У `stalled` — снимок: процессы исполняющихся команд и хвост их вывода
     * (замаскированные), и что controller сделал (`action`).
     */
    readonly 'attempt.liveness': z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        previous: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodNumber;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
        snapshot: z.ZodOptional<z.ZodObject<{
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                cpuMs: z.ZodOptional<z.ZodNumber>;
                command: z.ZodString;
            }, z.core.$strict>>;
            processesUnavailable: z.ZodOptional<z.ZodBoolean>;
            tail: z.ZodString;
            artifact: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'attempt.failed': z.ZodObject<{
        failureKind: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>;
        message: z.ZodString;
        blocked: z.ZodBoolean;
    }, z.core.$strict>;
    readonly 'attempt.expired': z.ZodObject<{
        leaseUntil: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'attempt.cancelled': z.ZodObject<{
        reason: z.ZodString;
    }, z.core.$strict>;
    readonly 'attempt.recovered': z.ZodObject<{
        integrationSha: z.ZodString;
        accepted: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    readonly 'work.accepted': z.ZodObject<{
        resultSha: z.ZodString;
        integrationSha: z.ZodString;
    }, z.core.$strict>;
    readonly 'work.blocked': z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict>;
    readonly 'control.paused': z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
        failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>>>;
    }, z.core.$strict>;
    readonly 'control.resumed': z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
    }, z.core.$strict>;
    readonly 'controller.acquired': z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict>;
    readonly 'controller.released': z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict>;
    readonly 'budget.blocked': z.ZodObject<{
        scope: z.ZodEnum<{
            work: "work";
            group: "group";
            total: "total";
        }>;
        scopeId: z.ZodOptional<z.ZodString>;
        state: z.ZodEnum<{
            exceeded: "exceeded";
            undetermined: "undetermined";
        }>;
        reason: z.ZodString;
    }, z.core.$strict>;
    /** Задачи приняли версию корпуса; тела случаев в журнал не попадают. */
    readonly 'corpus.adopted': z.ZodObject<{
        suite: z.ZodString;
        pending: z.ZodString;
        version: z.ZodNumber;
        digest: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            waiting: "waiting";
        }>;
        accepted: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    /** Эпизод повторяющихся отказов по свойству сменил состояние. */
    readonly 'work.recovery': z.ZodObject<{
        recoveryId: z.ZodString;
        property: z.ZodString;
        status: z.ZodEnum<{
            closed: "closed";
            stopped: "stopped";
            "awaiting-lead": "awaiting-lead";
            analyzing: "analyzing";
            applying: "applying";
            retry: "retry";
            retrying: "retrying";
            "awaiting-user": "awaiting-user";
        }>;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    /** Совместная проверка комбинации репозиториев началась (без manifest). */
    readonly 'joint.started': z.ZodObject<{
        verificationId: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        policyDigest: z.ZodString;
    }, z.core.$strict>;
    /**
     * Обход зависших совместной проверки сменил её живость (только переходы);
     * нагрузка — как у `attempt.liveness`. При `report` это единственный след
     * зависания: записи попытки у проверки нет.
     */
    readonly 'joint.liveness': z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        previous: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodNumber;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
        snapshot: z.ZodOptional<z.ZodObject<{
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                cpuMs: z.ZodOptional<z.ZodNumber>;
                command: z.ZodString;
            }, z.core.$strict>>;
            processesUnavailable: z.ZodOptional<z.ZodBoolean>;
            tail: z.ZodString;
            artifact: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        verificationId: z.ZodString;
    }, z.core.$strict>;
    /** Совместная проверка закончилась: `passed` — только с manifest. */
    readonly 'joint.finished': z.ZodObject<{
        verificationId: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    /** Политика стала применённой: запуском процесса или операцией reconfigure. */
    readonly 'policy.applied': z.ZodObject<{
        digest: z.ZodString;
        generation: z.ZodNumber;
        by: z.ZodString;
        operation: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    /** Запрос операции применить политику с ожидаемым digest или его отказ. */
    readonly 'policy.reconfigure': z.ZodObject<{
        operation: z.ZodString;
        digest: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            requested: "requested";
            cleared: "cleared";
        }>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    readonly 'delivery.pending': z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'delivery.delivered': z.ZodObject<{
        receipt: z.ZodOptional<z.ZodString>;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'delivery.failed': z.ZodObject<{
        error: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'delivery.conflict': z.ZodObject<{
        currentRevision: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
    /**
     * Исход мутации получателя не доказан (только получатели, сообщающие это
     * явно): повтор не отправляет мутацию до разбора (reconcile).
     */
    readonly 'delivery.uncertain': z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
};
export type EventType = keyof typeof eventPayloads;
/** Нагрузка события своего типа. */
export type RunEventPayload<T extends EventType> = z.infer<(typeof eventPayloads)[T]>;
export declare const eventTypes: EventType[];
declare const envelopeSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    seq: z.ZodNumber;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    attempt: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
type Envelope = z.infer<typeof envelopeSchema>;
/** Событие: общий конверт и нагрузка своего типа (дискриминатор `type`). */
export declare const runEventSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    seq: z.ZodNumber;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    attempt: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.stage" | "attempt.liveness" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.liveness" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
    payload: z.ZodObject<{
        digest: z.ZodString;
        orders: z.ZodNumber;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict> | z.ZodObject<{
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        approved: z.ZodBoolean;
        open: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        actor: z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        orderDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        released: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        policyDigest: z.ZodString;
        engineVersion: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        sha: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        gate: z.ZodString;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
        recheck: z.ZodOptional<z.ZodObject<{
            of: z.ZodString;
            outcome: z.ZodEnum<{
                flaky: "flaky";
                confirmed: "confirmed";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        sameVendor: z.ZodBoolean;
        blocking: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        timingId: z.ZodString;
        stage: z.ZodString;
        phase: z.ZodEnum<{
            started: "started";
            finished: "finished";
        }>;
        at: z.ZodISODateTime;
        durationMs: z.ZodOptional<z.ZodNumber>;
        outcome: z.ZodOptional<z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>>;
    }, z.core.$strict> | z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        previous: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodNumber;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
        snapshot: z.ZodOptional<z.ZodObject<{
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                cpuMs: z.ZodOptional<z.ZodNumber>;
                command: z.ZodString;
            }, z.core.$strict>>;
            processesUnavailable: z.ZodOptional<z.ZodBoolean>;
            tail: z.ZodString;
            artifact: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        failureKind: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>;
        message: z.ZodString;
        blocked: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        leaseUntil: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        integrationSha: z.ZodString;
        accepted: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        resultSha: z.ZodString;
        integrationSha: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
        failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>>>;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        scope: z.ZodEnum<{
            work: "work";
            group: "group";
            total: "total";
        }>;
        scopeId: z.ZodOptional<z.ZodString>;
        state: z.ZodEnum<{
            exceeded: "exceeded";
            undetermined: "undetermined";
        }>;
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        suite: z.ZodString;
        pending: z.ZodString;
        version: z.ZodNumber;
        digest: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            waiting: "waiting";
        }>;
        accepted: z.ZodArray<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        recoveryId: z.ZodString;
        property: z.ZodString;
        status: z.ZodEnum<{
            closed: "closed";
            stopped: "stopped";
            "awaiting-lead": "awaiting-lead";
            analyzing: "analyzing";
            applying: "applying";
            retry: "retry";
            retrying: "retrying";
            "awaiting-user": "awaiting-user";
        }>;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        policyDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        previous: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodNumber;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
        snapshot: z.ZodOptional<z.ZodObject<{
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                cpuMs: z.ZodOptional<z.ZodNumber>;
                command: z.ZodString;
            }, z.core.$strict>>;
            processesUnavailable: z.ZodOptional<z.ZodBoolean>;
            tail: z.ZodString;
            artifact: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        verificationId: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        generation: z.ZodNumber;
        by: z.ZodString;
        operation: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        digest: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            requested: "requested";
            cleared: "cleared";
        }>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        receipt: z.ZodOptional<z.ZodString>;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        error: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        currentRevision: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>, ...z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    seq: z.ZodNumber;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    attempt: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.stage" | "attempt.liveness" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.liveness" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
    payload: z.ZodObject<{
        digest: z.ZodString;
        orders: z.ZodNumber;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict> | z.ZodObject<{
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        approved: z.ZodBoolean;
        open: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        actor: z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        orderDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        released: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        policyDigest: z.ZodString;
        engineVersion: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        sha: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        gate: z.ZodString;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
        recheck: z.ZodOptional<z.ZodObject<{
            of: z.ZodString;
            outcome: z.ZodEnum<{
                flaky: "flaky";
                confirmed: "confirmed";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        sameVendor: z.ZodBoolean;
        blocking: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        timingId: z.ZodString;
        stage: z.ZodString;
        phase: z.ZodEnum<{
            started: "started";
            finished: "finished";
        }>;
        at: z.ZodISODateTime;
        durationMs: z.ZodOptional<z.ZodNumber>;
        outcome: z.ZodOptional<z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>>;
    }, z.core.$strict> | z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        previous: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodNumber;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
        snapshot: z.ZodOptional<z.ZodObject<{
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                cpuMs: z.ZodOptional<z.ZodNumber>;
                command: z.ZodString;
            }, z.core.$strict>>;
            processesUnavailable: z.ZodOptional<z.ZodBoolean>;
            tail: z.ZodString;
            artifact: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        failureKind: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>;
        message: z.ZodString;
        blocked: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        leaseUntil: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        integrationSha: z.ZodString;
        accepted: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        resultSha: z.ZodString;
        integrationSha: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
        failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>>>;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        scope: z.ZodEnum<{
            work: "work";
            group: "group";
            total: "total";
        }>;
        scopeId: z.ZodOptional<z.ZodString>;
        state: z.ZodEnum<{
            exceeded: "exceeded";
            undetermined: "undetermined";
        }>;
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        suite: z.ZodString;
        pending: z.ZodString;
        version: z.ZodNumber;
        digest: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            waiting: "waiting";
        }>;
        accepted: z.ZodArray<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        recoveryId: z.ZodString;
        property: z.ZodString;
        status: z.ZodEnum<{
            closed: "closed";
            stopped: "stopped";
            "awaiting-lead": "awaiting-lead";
            analyzing: "analyzing";
            applying: "applying";
            retry: "retry";
            retrying: "retrying";
            "awaiting-user": "awaiting-user";
        }>;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        policyDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        previous: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodNumber;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
        snapshot: z.ZodOptional<z.ZodObject<{
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                cpuMs: z.ZodOptional<z.ZodNumber>;
                command: z.ZodString;
            }, z.core.$strict>>;
            processesUnavailable: z.ZodOptional<z.ZodBoolean>;
            tail: z.ZodString;
            artifact: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        verificationId: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        generation: z.ZodNumber;
        by: z.ZodString;
        operation: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        digest: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            requested: "requested";
            cleared: "cleared";
        }>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        receipt: z.ZodOptional<z.ZodString>;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        error: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        currentRevision: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>[]], "type">;
/** Событие известного этой версии типа: так оно записывается. */
export type KnownRunEvent = {
    [T in EventType]: Envelope & {
        type: T;
        payload: z.infer<(typeof eventPayloads)[T]>;
    };
}[EventType];
/**
 * Событие типа, которого эта версия не знает (его записала более новая
 * версия): при чтении журнала оно не обрывает список, а возвращается
 * непрозрачным — конверт, `type: 'unknown'` и исходный тип в `original`;
 * нагрузка не возвращается. Записать такое событие нельзя: писатель строгий
 * (`runEventSchema`). Известный тип с нарушенной нагрузкой — по-прежнему отказ.
 */
export declare const unknownRunEventSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    seq: z.ZodNumber;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    attempt: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"unknown">;
    original: z.ZodString;
}, z.core.$strict>;
export type UnknownRunEvent = z.infer<typeof unknownRunEventSchema>;
/** Событие журнала при чтении: известного типа или непрозрачное неизвестное. */
export type RunEvent = KnownRunEvent | UnknownRunEvent;
/** Схема прочитанного события (`events`): `runEventSchema` и `unknownRunEventSchema`. */
export declare const readRunEventSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    seq: z.ZodNumber;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    attempt: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.stage" | "attempt.liveness" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.liveness" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
    payload: z.ZodObject<{
        digest: z.ZodString;
        orders: z.ZodNumber;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict> | z.ZodObject<{
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        approved: z.ZodBoolean;
        open: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        actor: z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        orderDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        released: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        policyDigest: z.ZodString;
        engineVersion: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        sha: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        gate: z.ZodString;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
        recheck: z.ZodOptional<z.ZodObject<{
            of: z.ZodString;
            outcome: z.ZodEnum<{
                flaky: "flaky";
                confirmed: "confirmed";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        sameVendor: z.ZodBoolean;
        blocking: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        timingId: z.ZodString;
        stage: z.ZodString;
        phase: z.ZodEnum<{
            started: "started";
            finished: "finished";
        }>;
        at: z.ZodISODateTime;
        durationMs: z.ZodOptional<z.ZodNumber>;
        outcome: z.ZodOptional<z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>>;
    }, z.core.$strict> | z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        previous: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodNumber;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
        snapshot: z.ZodOptional<z.ZodObject<{
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                cpuMs: z.ZodOptional<z.ZodNumber>;
                command: z.ZodString;
            }, z.core.$strict>>;
            processesUnavailable: z.ZodOptional<z.ZodBoolean>;
            tail: z.ZodString;
            artifact: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        failureKind: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>;
        message: z.ZodString;
        blocked: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        leaseUntil: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        integrationSha: z.ZodString;
        accepted: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        resultSha: z.ZodString;
        integrationSha: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
        failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>>>;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        scope: z.ZodEnum<{
            work: "work";
            group: "group";
            total: "total";
        }>;
        scopeId: z.ZodOptional<z.ZodString>;
        state: z.ZodEnum<{
            exceeded: "exceeded";
            undetermined: "undetermined";
        }>;
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        suite: z.ZodString;
        pending: z.ZodString;
        version: z.ZodNumber;
        digest: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            waiting: "waiting";
        }>;
        accepted: z.ZodArray<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        recoveryId: z.ZodString;
        property: z.ZodString;
        status: z.ZodEnum<{
            closed: "closed";
            stopped: "stopped";
            "awaiting-lead": "awaiting-lead";
            analyzing: "analyzing";
            applying: "applying";
            retry: "retry";
            retrying: "retrying";
            "awaiting-user": "awaiting-user";
        }>;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        policyDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        previous: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodNumber;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
        snapshot: z.ZodOptional<z.ZodObject<{
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                cpuMs: z.ZodOptional<z.ZodNumber>;
                command: z.ZodString;
            }, z.core.$strict>>;
            processesUnavailable: z.ZodOptional<z.ZodBoolean>;
            tail: z.ZodString;
            artifact: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        verificationId: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        generation: z.ZodNumber;
        by: z.ZodString;
        operation: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        digest: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            requested: "requested";
            cleared: "cleared";
        }>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        receipt: z.ZodOptional<z.ZodString>;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        error: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        currentRevision: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>, ...z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    seq: z.ZodNumber;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    attempt: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.stage" | "attempt.liveness" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.liveness" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
    payload: z.ZodObject<{
        digest: z.ZodString;
        orders: z.ZodNumber;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict> | z.ZodObject<{
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        approved: z.ZodBoolean;
        open: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        actor: z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        orderDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        released: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        policyDigest: z.ZodString;
        engineVersion: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        sha: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        gate: z.ZodString;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
        recheck: z.ZodOptional<z.ZodObject<{
            of: z.ZodString;
            outcome: z.ZodEnum<{
                flaky: "flaky";
                confirmed: "confirmed";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        sameVendor: z.ZodBoolean;
        blocking: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        timingId: z.ZodString;
        stage: z.ZodString;
        phase: z.ZodEnum<{
            started: "started";
            finished: "finished";
        }>;
        at: z.ZodISODateTime;
        durationMs: z.ZodOptional<z.ZodNumber>;
        outcome: z.ZodOptional<z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>>;
    }, z.core.$strict> | z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        previous: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodNumber;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
        snapshot: z.ZodOptional<z.ZodObject<{
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                cpuMs: z.ZodOptional<z.ZodNumber>;
                command: z.ZodString;
            }, z.core.$strict>>;
            processesUnavailable: z.ZodOptional<z.ZodBoolean>;
            tail: z.ZodString;
            artifact: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        failureKind: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>;
        message: z.ZodString;
        blocked: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        leaseUntil: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        integrationSha: z.ZodString;
        accepted: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        resultSha: z.ZodString;
        integrationSha: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
        failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>>>;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        scope: z.ZodEnum<{
            work: "work";
            group: "group";
            total: "total";
        }>;
        scopeId: z.ZodOptional<z.ZodString>;
        state: z.ZodEnum<{
            exceeded: "exceeded";
            undetermined: "undetermined";
        }>;
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        suite: z.ZodString;
        pending: z.ZodString;
        version: z.ZodNumber;
        digest: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            waiting: "waiting";
        }>;
        accepted: z.ZodArray<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        recoveryId: z.ZodString;
        property: z.ZodString;
        status: z.ZodEnum<{
            closed: "closed";
            stopped: "stopped";
            "awaiting-lead": "awaiting-lead";
            analyzing: "analyzing";
            applying: "applying";
            retry: "retry";
            retrying: "retrying";
            "awaiting-user": "awaiting-user";
        }>;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        policyDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        previous: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodNumber;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
        snapshot: z.ZodOptional<z.ZodObject<{
            processes: z.ZodArray<z.ZodObject<{
                pid: z.ZodNumber;
                parentPid: z.ZodNumber;
                cpuMs: z.ZodOptional<z.ZodNumber>;
                command: z.ZodString;
            }, z.core.$strict>>;
            processesUnavailable: z.ZodOptional<z.ZodBoolean>;
            tail: z.ZodString;
            artifact: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        verificationId: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        generation: z.ZodNumber;
        by: z.ZodString;
        operation: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        digest: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            requested: "requested";
            cleared: "cleared";
        }>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        receipt: z.ZodOptional<z.ZodString>;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        error: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        currentRevision: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>[], z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    seq: z.ZodNumber;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    attempt: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"unknown">;
    original: z.ZodString;
}, z.core.$strict>], "type">;
/**
 * Разобрать сохранённое событие терпимо к неизвестному типу: тип, которого
 * нет в `eventPayloads`, становится `UnknownRunEvent` (конверт проверяется
 * строго); известный тип разбирается строгой схемой, и её отказ — ошибка.
 */
export declare function readRunEvent(raw: unknown): RunEvent;
export type RunEventDraft = {
    [T in EventType]: Omit<Envelope, 'apiVersion' | 'seq' | 'at'> & {
        type: T;
        payload: z.infer<(typeof eventPayloads)[T]>;
    };
}[EventType];
/**
 * Типы транзакций исполнения. Это сохранённые строки: DevContour пишет их
 * в журнал аудита как тип события и разбирает (`scheduler.error` — причина
 * остановки очереди), поэтому harness использует те же имена, а не новые.
 * `heartbeat` продлевает сроки и события не создаёт.
 */
export declare const transactionKinds: readonly ["run.claimed", "heartbeat", "run.heartbeat-failed", "run.phase", "run.context", "run.dependencies", "run.dependency-freshness", "run.consumer-checked", "run.implementation-basis", "run.partial", "run.continuation", "run.model", "run.timing.started", "run.timing.finished", "run.liveness", "evidence.recorded", "reproduction.recorded", "findings.recorded", "task.done", "run.failed", "run.recovered", "recovery.rejected", "runs.expired", "task.retry", "task.cancelled", "task.held", "task.released", "task.hold-transferred", "wait.started", "wait.cleared", "recovery.reserved", "recovery.decided", "recovery.applied", "recovery.interrupted", "scheduler.started", "scheduler.paused", "scheduler.released", "scheduler.error", "scheduler.blockers", "config.started", "config.reconfigured", "config.reconfigure-requested", "config.reconfigure-cleared", "graph.registered", "graph.reviewed", "graph.approved", "delivery.recorded", "workspace.verification.started", "workspace.manifest", "workspace.evidence", "workspace.verified", "workspace.failed", "workspace.liveness", "base.moved", "workflow.updated", "usage.recorded", "checks.recorded", "checks.adopted", "checks.awaiting-operator", "checks.adoption-abandoned", "checks.spike"];
export type TransactionKind = (typeof transactionKinds)[number];
export {};
