import { z } from 'zod';
import { API_VERSION } from './version.ts';
import { HarnessError, type ErrorCode } from './errors.ts';
/**
 * Договор CLI `harness`.
 *
 * - Каждая команда получает явные пути; бинарник не хранит настроек проекта
 *   и не помнит «последний активный проект».
 * - `--state <каталог>` — каталог состояния исполнения (SQLite, артефакты
 *   попыток). Создаётся только командами, которые пишут (`run`,
 *   `review-*`, `approve`); читающие команды на отсутствующем каталоге
 *   отвечают `NOT_FOUND` и ничего не создают.
 * - stdout — ровно один JSON `CliEnvelope`; диагностика — stderr. Явный
 *   `--human` (init, explain) заменяет успешный ответ текстом; отказ — тот же
 *   JSON на stdout, exit code одинаков в обоих режимах.
 * - Exit: 0 — успех; 2 — неверный вход; 3 — отказ или блокировка по
 *   правилам; 4 — инфраструктура. Exit 1 не используется.
 *
 * Библиотека и CLI вызывают одни и те же доменные операции; у CLI нет
 * операции «передать PASS» или «принять без проверок».
 */
export interface CliArgument {
    name: string;
    value: 'path' | 'dir' | 'id' | 'digest' | 'number' | 'text' | 'flag' | 'sink';
    required: boolean;
    description: string;
    /** Аргумент можно повторить; значения — список. */
    multiple?: true;
}
export interface CliCommandContract {
    description: string;
    /** Пишет ли команда состояние. `false` — гарантированно без побочных эффектов. */
    writes: boolean;
    /** Что делает повтор той же команды с теми же аргументами. */
    idempotency: string;
    args: CliArgument[];
    /** Отказы по существу (exit 3), которые команда обязана различать кодом. */
    refusals: ErrorCode[];
}
export declare const cliCommands: {
    readonly validate: {
        readonly description: "Проверить граф, политику, их связь и (если задан) снимок контекста без вызова моделей и записи состояния";
        readonly writes: false;
        readonly idempotency: "Чистая функция входов";
        readonly args: [CliArgument, CliArgument, CliArgument];
        readonly refusals: [];
    };
    readonly 'review-plan': {
        readonly description: "Техническое ревью плана (графа) с конкретным digest; новый раунд сохраняет историю находок предмета";
        readonly writes: true;
        readonly idempotency: "Повтор с тем же digest и тем же автором, уже согласованный последним раундом, возвращает этот раунд без вызова модели; иначе — новый раунд в пределах maxAttempts. Автор, не допускаемый правилом вендора, — REVIEWER_SAME_VENDOR до вызова модели";
        readonly args: [CliArgument, CliArgument, CliArgument, CliArgument, CliArgument, {
            readonly name: "--source";
            readonly value: "path";
            readonly required: false;
            readonly description: "Конфигурация коннектора задач: внешние предпосылки графа допускаются по решению источника (trusts) и доступности SHA в target ref; без неё доверенных receipt нет";
        }];
        readonly refusals: ["REVIEW_REJECTED", "ATTEMPTS_EXHAUSTED", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN", "NOT_READY"];
    };
    readonly 'review-contract': {
        readonly description: "Техническое ревью контракта с конкретным digest";
        readonly writes: true;
        readonly idempotency: "Как review-plan, предмет — ID контракта";
        readonly args: [CliArgument, {
            readonly name: "--contract";
            readonly value: "path";
            readonly required: true;
            readonly description: "ContractDocument JSON";
        }, CliArgument, CliArgument];
        readonly refusals: ["REVIEW_REJECTED", "ATTEMPTS_EXHAUSTED", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN"];
    };
    readonly approve: {
        readonly description: "Согласование оператором (approvalMode: operator) конкретного digest графа или контракта, уже прошедшего ревью";
        readonly writes: true;
        readonly idempotency: "Повтор для того же digest ничего не меняет";
        readonly args: [CliArgument, {
            readonly name: "--digest";
            readonly value: "digest";
            readonly required: true;
            readonly description: "Digest из ReviewRecord последнего раунда";
        }, {
            readonly name: "--subject";
            readonly value: "id";
            readonly required: true;
            readonly description: "ID графа или контракта";
        }];
        readonly refusals: ["APPROVAL_STALE", "APPROVAL_REQUIRED", "REVIEW_REJECTED"];
    };
    readonly run: {
        readonly description: "Зарегистрировать согласованный граф (идемпотентно по connector, ref, revision, digest) и вести работу до простоя";
        readonly writes: true;
        readonly idempotency: "Тот же граф той же редакции продолжает прежнюю работу; другой digest для той же редакции источника — REVISION_CONFLICT";
        readonly args: [CliArgument, {
            readonly required: false;
            readonly description: "WorkGraph JSON; не нужен с --source";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly multiple?: true;
        }, CliArgument, CliArgument, {
            readonly name: "--source";
            readonly value: "path";
            readonly required: false;
            readonly description: "Конфигурация коннектора (relay-v1-http | relay-v2-cli): перед запуском задачи перечитываются, semantic digest сверяется с закреплённым снимком и eligibility — до любого вызова runtime; результат доставляется в исходную задачу";
        }, {
            readonly name: "--sink";
            readonly value: "sink";
            readonly required: false;
            readonly description: "Получатель результата, `file:<каталог>`";
        }, {
            readonly name: "--once";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Один шаг очереди вместо работы до простоя";
        }, {
            readonly name: "--author";
            readonly value: "id";
            readonly required: false;
            readonly description: "Автор графа для ревью плана; по умолчанию external";
        }];
        readonly refusals: ["APPROVAL_REQUIRED", "APPROVAL_STALE", "PAUSED", "CONTROLLER_BUSY", "REVISION_CONFLICT", "GATE_FAILED", "REVIEW_REJECTED", "SCOPE_VIOLATION", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN", "ATTEMPTS_EXHAUSTED"];
    };
    readonly status: {
        readonly description: "Состояние очереди, графов и поручений с причинами блокировки";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, {
            readonly name: "--graph";
            readonly value: "id";
            readonly required: false;
            readonly description: "Только этот граф";
        }, {
            readonly name: "--detail";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Добавить detail: почему стоит выдача и активные попытки (стадия, владение, gates)";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly events: {
        readonly description: "События строго после номера, по возрастанию";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, {
            readonly name: "--after";
            readonly value: "number";
            readonly required: false;
            readonly description: "Номер, по умолчанию 0";
        }, {
            readonly name: "--limit";
            readonly value: "number";
            readonly required: false;
            readonly description: "1–500, по умолчанию 100";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly pause: {
        readonly description: "Пауза оператора: новые claims запрещены, активные попытки продолжаются";
        readonly writes: true;
        readonly idempotency: "Повтор ничего не меняет";
        readonly args: [CliArgument];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly resume: {
        readonly description: "Снять паузу — решение человека: паузу оператора, штатной остановки и отказа runtime (с её классами отказов); паузу операции reconfigure не снимает";
        readonly writes: true;
        readonly idempotency: "Повтор без паузы ничего не меняет";
        readonly args: [CliArgument];
        readonly refusals: ["NOT_FOUND", "PAUSED"];
    };
    readonly cancel: {
        readonly description: "Отменить поручение: активная попытка теряет владение, поручение становится cancelled; это не retry";
        readonly writes: true;
        readonly idempotency: "Повтор для отменённого ничего не меняет";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--reason";
            readonly value: "text";
            readonly required: false;
            readonly description: "Причина";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly retry: {
        readonly description: "Новая попытка неуспешного (failed) поручения в пределах maxAttempts и бюджета; --reset сбрасывает счётчик попыток с причиной, учёт расходов не сбрасывается";
        readonly writes: true;
        readonly idempotency: "Повтор для уже готового к выдаче поручения ничего не меняет";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--reset";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Сбросить счётчик попыток; требует --reason";
        }, {
            readonly name: "--reason";
            readonly value: "text";
            readonly required: false;
            readonly description: "Причина сброса";
        }];
        readonly refusals: ["NOT_FOUND", "ATTEMPTS_EXHAUSTED", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN"];
    };
    readonly result: {
        readonly description: "Машинный результат последней завершённой попытки поручения и состояние доставки";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, CliArgument];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly deliver: {
        readonly description: "Повторить доставку результата получателю с тем же ключом; модели, gates и интеграция не вызываются";
        readonly writes: true;
        readonly idempotency: "Доставленный результат повторно не доставляется";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--sink";
            readonly value: "sink";
            readonly required: true;
            readonly description: "Получатель, `file:<каталог>`";
        }];
        readonly refusals: ["NOT_FOUND", "REVISION_CONFLICT"];
    };
    readonly 'worktree-cleanup': {
        readonly description: "Убрать рабочие деревья закончившихся попыток: ветки и достижимые коммиты остаются, неподтверждённые правки сохраняются проверенным патчем в артефактах попытки, игнорируемые файлы не сохраняются и перечисляются в ответе; индекс, который патч не сохранит, — отказ; в сомнении дерево остаётся, а отказ назван; модель не вызывается";
        readonly writes: true;
        readonly idempotency: "Повтор не находит уже убранных деревьев и ничего не меняет";
        readonly args: [CliArgument, {
            readonly name: "--dry-run";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Только показать, что было бы убрано, что исчезнет (игнорируемое) и почему отказано; ничего не пишет";
        }];
        readonly refusals: ["NOT_FOUND", "NOT_READY"];
    };
    readonly cleanup: {
        readonly description: "Довести незавершённую очистку закончившейся попытки: повторить teardown по сохранённым receipt окружений и убрать её рабочие деревья; модели, gates и Git-приёмка не вызываются";
        readonly writes: true;
        readonly idempotency: "Повтор после успешной очистки отвечает nothing-pending и ничего не меняет";
        readonly args: [CliArgument, {
            readonly name: "--run";
            readonly value: "id";
            readonly required: true;
            readonly description: "ID попытки (runId)";
        }];
        readonly refusals: ["NOT_FOUND", "NOT_READY"];
    };
    readonly profile: {
        readonly description: "Разрешить профиль стека (встроенный ID или ./file.json репозитория): слои, gates, закрепление; только чтение манифестов, без команд проекта";
        readonly writes: false;
        readonly idempotency: "Чистая функция файлов профиля";
        readonly args: [{
            readonly name: "--profile";
            readonly value: "text";
            readonly required: true;
            readonly description: "Встроенный ID профиля или относительный ./file.json";
        }, {
            readonly name: "--repository";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Корень репозитория для локального профиля";
        }];
        readonly refusals: [];
    };
    readonly doctor: {
        readonly description: "Версии, наличие runtime и их capabilities, OS-sandbox, совместимость каталога состояния; без live-вызова модели";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [{
            readonly required: false;
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly description: string;
            readonly multiple?: true;
        }, {
            readonly required: false;
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly description: string;
            readonly multiple?: true;
        }];
        readonly refusals: [];
    };
    readonly init: {
        readonly description: "Подготовить существующий Git npm/pnpm-репозиторий: план или create-only запись .harness/ (политика из профиля и toolchain inspection; manifest до политики, политика последней); чужие файлы не меняются";
        readonly writes: true;
        readonly idempotency: "Повтор с теми же решениями ничего не пишет (created пуст); после прерывания дописывает недостающее; иные решения при существующем manifest — PATH_CONFLICT content-differs";
        readonly args: [{
            readonly name: "--repository";
            readonly value: "dir";
            readonly required: true;
            readonly description: "Корень Git-репозитория проекта";
        }, {
            readonly name: "--profile";
            readonly value: "text";
            readonly required: false;
            readonly description: "Встроенный профиль или ./file.json репозитория; без него — из manifest, иначе по lockfile (npm-ci | pnpm-frozen)";
        }, {
            readonly name: "--writer";
            readonly value: "id";
            readonly required: false;
            readonly description: "Runtime writer: claude (по умолчанию) или codex; reviewer — другой вендор";
        }, {
            readonly name: "--state";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Каталог состояния вне репозитория; по умолчанию <state home>/projects/<projectId>";
        }, {
            readonly name: "--plan";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Только план, без записи";
        }, {
            readonly name: "--human";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Текст для человека вместо JSON";
        }];
        readonly refusals: ["PATH_CONFLICT", "CONTROLLER_BUSY", "NOT_READY"];
    };
    readonly explain: {
        readonly description: "Объяснить остановки: код, причина, фаза, кто действует, допустимый следующий шаг и evidence; без повторов, вызовов моделей и изменений состояния";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, {
            readonly required: true;
            readonly description: "ExecutionPolicy JSON: maxAttempts, repairBudget и runtime политики";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly multiple?: true;
        }, {
            readonly name: "--work";
            readonly value: "id";
            readonly required: false;
            readonly description: "ID поручения";
        }, {
            readonly name: "--human";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Текст для человека вместо JSON";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly report: {
        readonly description: "Отчёт об эффекте по данным каталога состояния: принятые поручения, отказы проверок и ревью, автономность, скорость, расход, окружение, недели; только чтение, без вызовов моделей";
        readonly writes: false;
        readonly idempotency: "Только чтение. Тот же каталог и те же параметры дают те же байты: момент отчёта по умолчанию — последняя метка времени в данных, а не часы";
        readonly args: [CliArgument, {
            readonly name: "--since";
            readonly value: "text";
            readonly required: false;
            readonly description: "Начало окна включительно: ISO-время с поясом, дата YYYY-MM-DD или Nd/Nw до --as-of";
        }, {
            readonly name: "--until";
            readonly value: "text";
            readonly required: false;
            readonly description: "Конец окна не включительно: ISO-время с поясом или дата";
        }, {
            readonly name: "--as-of";
            readonly value: "text";
            readonly required: false;
            readonly description: "Момент отчёта; по умолчанию — последняя метка времени в данных";
        }, {
            readonly name: "--format";
            readonly value: "text";
            readonly required: false;
            readonly description: "json (по умолчанию, в конверте), md или html (текст в stdout без конверта; отказ — JSON-конверт)";
        }, {
            readonly name: "--no-titles";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Без заголовков поручений и метки проекта";
        }, {
            readonly name: "--out";
            readonly value: "path";
            readonly required: false;
            readonly description: "Записать отчёт выбранного формата в файл (не символическую ссылку и не файл состояния); в stdout — конверт с путём и размером";
        }];
        readonly refusals: ["NOT_FOUND", "PATH_CONFLICT"];
    };
    readonly handoff: {
        readonly description: "Пакет передачи контекста для новой сессии ведущего агента из хранилища: активная работа и стадия, решения и остановки, незавершённые попытки, последние провалы, бюджеты, следующий шаг; только чтение";
        readonly writes: false;
        readonly idempotency: "Только чтение; агент добавляет только намерения (--intent)";
        readonly args: [CliArgument, {
            readonly name: "--graph";
            readonly value: "id";
            readonly required: false;
            readonly description: "Только этот граф";
        }, {
            readonly name: "--intent";
            readonly value: "text";
            readonly required: false;
            readonly multiple: true;
            readonly description: "Намерение агента (до 20, каждое до 1000 знаков); единственный текст не из хранилища";
        }, {
            readonly name: "--format";
            readonly value: "text";
            readonly required: false;
            readonly description: "json (по умолчанию, конверт HandoffPack) или md (Markdown без конверта)";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly 'plan-request': {
        readonly description: "Собрать read-only запрос планирования из постановки и фактов проекта (роли, gates, репозитории, контекст, ресурсы, контракты, требования) для ведущего агента; модель не вызывается, ничего не пишется";
        readonly writes: false;
        readonly idempotency: "Чистая функция входов: те же постановка и факты дают тот же prompt и basis";
        readonly args: [{
            readonly name: "--brief";
            readonly value: "path";
            readonly required: true;
            readonly description: "Постановка пользователя, UTF-8";
        }, CliArgument, {
            readonly description: "ContextSnapshot JSON; без него — каталоги <каталог политики>/work/context/<id>";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly required: boolean;
            readonly multiple?: true;
        }, {
            readonly name: "--contracts";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Каталог ContractDocument JSON, на которые может ссылаться план";
        }, {
            readonly name: "--requirements";
            readonly value: "path";
            readonly required: false;
            readonly description: "Закоммиченный файл с разделами ## REQ-*: [<repositoryId>:]<путь от корня репозитория>; можно повторять";
            readonly multiple: true;
        }, {
            readonly name: "--human";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Только текст prompt вместо JSON";
        }];
        readonly refusals: ["NOT_READY"];
    };
    readonly 'plan-check': {
        readonly description: "Проверить draft плана против фактов проекта и собрать WorkGraph без вызова моделей, ревью и записи; согласования не выдаёт";
        readonly writes: false;
        readonly idempotency: "Чистая функция входов и HEAD источников требований";
        readonly args: [{
            readonly name: "--draft";
            readonly value: "path";
            readonly required: true;
            readonly description: "Draft JSON (schemas/plan-draft.schema.json); ID графа — имя файла без .draft.json/.json";
        }, CliArgument, CliArgument, {
            readonly name: "--contracts";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Как у plan-request";
        }, {
            readonly name: "--brief";
            readonly value: "path";
            readonly required: false;
            readonly description: "Постановка: revision графа = basis";
        }, {
            readonly name: "--basis";
            readonly value: "digest";
            readonly required: false;
            readonly description: "basis из plan-request, по которому составлен draft; расхождение — APPROVAL_STALE";
        }];
        readonly refusals: ["APPROVAL_STALE", "NOT_READY"];
    };
    readonly capabilities: {
        readonly description: "Каталог общих операций harness для агента: имя, версия, protocolVersion, пределы UTF-8 байт и для каждой операции описание, readOnly, JSON Schema входа и данных ответа; только чтение";
        readonly writes: false;
        readonly idempotency: "Чистая функция установленной версии пакета";
        readonly args: [];
        readonly refusals: [];
    };
    readonly 'source-check': {
        readonly description: "Коннектор задач: подключение, идентичность и capabilities backend, совпадение проекта, проверка mapping; без мутаций, записи истории и создания состояния";
        readonly writes: false;
        readonly idempotency: "Только чтение получателя";
        readonly args: [CliArgument, {
            readonly required: false;
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly description: string;
            readonly multiple?: true;
        }, {
            readonly required: false;
            readonly description: "ExecutionPolicy JSON для сверки gates/ролей mapping";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly multiple?: true;
        }];
        readonly refusals: ["NOT_READY"];
    };
    readonly 'source-snapshot': {
        readonly description: "Коннектор задач: согласованное чтение задач, предпросмотр и закрепление снимка (graph/context/manifest) для review-plan и approve";
        readonly writes: true;
        readonly idempotency: "Неизменная постановка — тот же semantic digest, тот же граф и контекст; новых записей у получателя нет";
        readonly args: [CliArgument, CliArgument, {
            readonly required: false;
            readonly description: "ExecutionPolicy JSON: её секреты маскируются в диагностике";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly multiple?: true;
        }, {
            readonly name: "--out";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Каталог graph.json, context.json, manifest.json";
        }];
        readonly refusals: ["NOT_READY"];
    };
    readonly 'source-status': {
        readonly description: "Коннектор задач: локально принято / доставлено / конфликт / неизвестный исход и независимое чтение получателя";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, CliArgument];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly 'source-deliver': {
        readonly description: "Коннектор задач: доставить или продолжить доставку принятых результатов с тем же ключом операции; модели, gates и Git не вызываются";
        readonly writes: true;
        readonly idempotency: "Подтверждённая доставка не повторяется; неизвестный исход не отправляется повторно до source-reconcile";
        readonly args: [CliArgument, CliArgument, {
            readonly required: false;
            readonly description: "ID поручения; без него — все с результатом";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly multiple?: true;
        }];
        readonly refusals: ["NOT_FOUND", "CONTROLLER_BUSY", "REVISION_CONFLICT"];
    };
    readonly 'source-reconcile': {
        readonly description: "Коннектор задач: разобрать неизвестный исход или конфликт операции доставки по фактам получателя; неоднозначность — только явным решением";
        readonly writes: true;
        readonly idempotency: "Разобранная операция не меняется; мутаций без решения и фактов нет";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--operation";
            readonly value: "digest";
            readonly required: true;
            readonly description: "Ключ операции из source-status";
        }, {
            readonly name: "--decision";
            readonly value: "text";
            readonly required: false;
            readonly description: "resend (записи у получателя нет), adopt:<id> (одна из нескольких записей с маркером), recheck (CAS-конфликт без изменения постановки)";
        }];
        readonly refusals: ["NOT_FOUND", "CONTROLLER_BUSY"];
    };
};
export type CliCommand = keyof typeof cliCommands;
export declare const validateDataSchema: z.ZodObject<{
    graphId: z.ZodString;
    graphDigest: z.ZodString;
    policyDigest: z.ZodString;
    contextDigest: z.ZodOptional<z.ZodString>;
    orders: z.ZodNumber;
}, z.core.$strict>;
/** Активная попытка `status --detail` (`attemptView`). */
export declare const attemptViewSchema: z.ZodObject<{
    runId: z.ZodString;
    workId: z.ZodString;
    attempt: z.ZodNumber;
    status: z.ZodString;
    phase: z.ZodEnum<{
        ready: "ready";
        failed: "failed";
        cancelled: "cancelled";
        draft: "draft";
        running: "running";
        verifying: "verifying";
        reviewing: "reviewing";
        integrating: "integrating";
        done: "done";
    }>;
    runtime: z.ZodString;
    model: z.ZodOptional<z.ZodString>;
    startedAt: z.ZodISODateTime;
    elapsedMs: z.ZodNumber;
    stage: z.ZodOptional<z.ZodObject<{
        name: z.ZodString;
        family: z.ZodString;
        startedAt: z.ZodISODateTime;
        elapsedMs: z.ZodNumber;
    }, z.core.$strict>>;
    lease: z.ZodObject<{
        owner: z.ZodString;
        leaseUntil: z.ZodNumber;
        leaseMs: z.ZodNumber;
        sinceHeartbeatMs: z.ZodOptional<z.ZodNumber>;
        stale: z.ZodBoolean;
    }, z.core.$strict>;
    gates: z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        required: z.ZodNumber;
        passed: z.ZodNumber;
        failed: z.ZodNumber;
        remaining: z.ZodNumber;
    }, z.core.$strict>;
    liveness: z.ZodOptional<z.ZodObject<{
        state: z.ZodEnum<{
            active: "active";
            stalled: "stalled";
            quiet: "quiet";
        }>;
        since: z.ZodISODateTime;
        lastMovementAt: z.ZodISODateTime;
        idleMs: z.ZodOptional<z.ZodNumber>;
        activity: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                gate: "gate";
                command: "command";
                agent: "agent";
                step: "step";
            }>;
            label: z.ZodString;
        }, z.core.$strict>>;
        action: z.ZodOptional<z.ZodEnum<{
            report: "report";
            stop: "stop";
        }>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/**
 * Почему выдача стоит (`status --detail`): причина паузы (`queueStop`), кто и
 * что её снимает (`queuePause`, то же рассуждение, что у `explain`), классы
 * отказа паузы runtime и последнее сообщение отказа этих классов.
 */
export declare const queueViewSchema: z.ZodObject<{
    paused: z.ZodBoolean;
    reason: z.ZodOptional<z.ZodEnum<{
        runtime: "runtime";
        operator: "operator";
        shutdown: "shutdown";
        "base-check": "base-check";
        reconfigure: "reconfigure";
    }>>;
    detail: z.ZodOptional<z.ZodString>;
    since: z.ZodOptional<z.ZodISODateTime>;
    operation: z.ZodOptional<z.ZodString>;
    liftedByRun: z.ZodOptional<z.ZodLiteral<true>>;
    failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        gate: "gate";
        unknown: "unknown";
        review: "review";
        cancelled: "cancelled";
        environment: "environment";
        timeout: "timeout";
        "provider-auth": "provider-auth";
        stalled: "stalled";
        "stale-base": "stale-base";
        "empty-result": "empty-result";
        unfinished: "unfinished";
        "scope-violation": "scope-violation";
        "review-protocol": "review-protocol";
        merge: "merge";
        budget: "budget";
        "needs-lead": "needs-lead";
    }>>>;
    code: z.ZodOptional<z.ZodEnum<{
        INVALID_INPUT: "INVALID_INPUT";
        UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
        UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
        GRAPH_CYCLE: "GRAPH_CYCLE";
        GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
        GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
        GATE_UNKNOWN: "GATE_UNKNOWN";
        GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
        REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
        REVIEWER_MISSING: "REVIEWER_MISSING";
        RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
        APPROVAL_STALE: "APPROVAL_STALE";
        APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
        LEASE_STALE: "LEASE_STALE";
        CONTROLLER_BUSY: "CONTROLLER_BUSY";
        PAUSED: "PAUSED";
        NOT_READY: "NOT_READY";
        SCOPE_VIOLATION: "SCOPE_VIOLATION";
        GATE_FAILED: "GATE_FAILED";
        REVIEW_REJECTED: "REVIEW_REJECTED";
        BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
        BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
        ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
        REVISION_CONFLICT: "REVISION_CONFLICT";
        CANCELLED: "CANCELLED";
        NOT_FOUND: "NOT_FOUND";
        PATH_CONFLICT: "PATH_CONFLICT";
        STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
        RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
        REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
        SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
        GIT_FAILED: "GIT_FAILED";
        STORAGE_FAILED: "STORAGE_FAILED";
        DELIVERY_FAILED: "DELIVERY_FAILED";
        INTERNAL: "INTERNAL";
    }>>;
    cause: z.ZodOptional<z.ZodEnum<{
        gate: "gate";
        unknown: "unknown";
        review: "review";
        cancelled: "cancelled";
        environment: "environment";
        timeout: "timeout";
        "provider-auth": "provider-auth";
        stalled: "stalled";
        "stale-base": "stale-base";
        "empty-result": "empty-result";
        unfinished: "unfinished";
        "scope-violation": "scope-violation";
        "review-protocol": "review-protocol";
        merge: "merge";
        budget: "budget";
        "needs-lead": "needs-lead";
        "runtime-missing": "runtime-missing";
        "controller-busy": "controller-busy";
        "operator-pause": "operator-pause";
        "approval-required": "approval-required";
        "not-ready": "not-ready";
    }>>;
    actor: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        controller: "controller";
        lead: "lead";
        user: "user";
    }>>>;
    action: z.ZodOptional<z.ZodEnum<{
        none: "none";
        wait: "wait";
        retry: "retry";
        "review-plan": "review-plan";
        "diagnose-failure": "diagnose-failure";
        "reset-attempts": "reset-attempts";
        "raise-budget": "raise-budget";
        "replan-dependents": "replan-dependents";
        "recovery-decision": "recovery-decision";
        "user-decision": "user-decision";
        "resume-queue": "resume-queue";
        "fix-environment": "fix-environment";
        "fix-access": "fix-access";
    }>>;
}, z.core.$strict>;
export declare const statusDataSchema: z.ZodObject<{
    stateVersion: z.ZodLiteral<1>;
    control: z.ZodObject<{
        paused: z.ZodBoolean;
        pauseReason: z.ZodOptional<z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>>;
        pausedAt: z.ZodOptional<z.ZodISODateTime>;
        pauseOperation: z.ZodOptional<z.ZodString>;
        pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>>>;
        waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                "base-check": "base-check";
                "context-lock": "context-lock";
            }>;
            detail: z.ZodString;
            at: z.ZodISODateTime;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        appliedPolicy: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodOptional<z.ZodNumber>;
            at: z.ZodISODateTime;
            by: z.ZodString;
        }, z.core.$strict>>;
        reconfigure: z.ZodOptional<z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            requestedAt: z.ZodISODateTime;
            appliedAt: z.ZodOptional<z.ZodISODateTime>;
            appliedBy: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    controller: z.ZodOptional<z.ZodObject<{
        owner: z.ZodString;
        leaseUntil: z.ZodNumber;
        engineVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    graphs: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        digest: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        approved: z.ZodBoolean;
    }, z.core.$strict>>;
    works: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        graphId: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        activeRunId: z.ZodOptional<z.ZodString>;
        liveness: z.ZodOptional<z.ZodEnum<{
            stalled: "stalled";
            quiet: "quiet";
        }>>;
        resultSha: z.ZodOptional<z.ZodString>;
        blockers: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            message: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    budgets: z.ZodOptional<z.ZodObject<{
        onUnknown: z.ZodEnum<{
            continue: "continue";
            stop: "stop";
        }>;
        budgets: z.ZodArray<z.ZodObject<{
            scope: z.ZodObject<{
                kind: z.ZodEnum<{
                    work: "work";
                    group: "group";
                    total: "total";
                }>;
                id: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
                within: "within";
            }>;
            limit: z.ZodObject<{
                usd: z.ZodOptional<z.ZodNumber>;
                timeMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            reportedUsd: z.ZodNumber;
            estimatedUsd: z.ZodNumber;
            unknownCalls: z.ZodNumber;
            unfinishedCalls: z.ZodNumber;
            abandonedCalls: z.ZodNumber;
            errorCalls: z.ZodNumber;
            uncoveredRuns: z.ZodNumber;
            durationMs: z.ZodNumber;
            remainingUsd: z.ZodNullable<z.ZodNumber>;
            remainingMs: z.ZodNullable<z.ZodNumber>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    detail: z.ZodOptional<z.ZodObject<{
        at: z.ZodISODateTime;
        queue: z.ZodObject<{
            paused: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            detail: z.ZodOptional<z.ZodString>;
            since: z.ZodOptional<z.ZodISODateTime>;
            operation: z.ZodOptional<z.ZodString>;
            liftedByRun: z.ZodOptional<z.ZodLiteral<true>>;
            failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>>;
            code: z.ZodOptional<z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>>;
            cause: z.ZodOptional<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
                "runtime-missing": "runtime-missing";
                "controller-busy": "controller-busy";
                "operator-pause": "operator-pause";
                "approval-required": "approval-required";
                "not-ready": "not-ready";
            }>>;
            actor: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                controller: "controller";
                lead: "lead";
                user: "user";
            }>>>;
            action: z.ZodOptional<z.ZodEnum<{
                none: "none";
                wait: "wait";
                retry: "retry";
                "review-plan": "review-plan";
                "diagnose-failure": "diagnose-failure";
                "reset-attempts": "reset-attempts";
                "raise-budget": "raise-budget";
                "replan-dependents": "replan-dependents";
                "recovery-decision": "recovery-decision";
                "user-decision": "user-decision";
                "resume-queue": "resume-queue";
                "fix-environment": "fix-environment";
                "fix-access": "fix-access";
            }>>;
        }, z.core.$strict>;
        attempts: z.ZodArray<z.ZodObject<{
            runId: z.ZodString;
            workId: z.ZodString;
            attempt: z.ZodNumber;
            status: z.ZodString;
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            runtime: z.ZodString;
            model: z.ZodOptional<z.ZodString>;
            startedAt: z.ZodISODateTime;
            elapsedMs: z.ZodNumber;
            stage: z.ZodOptional<z.ZodObject<{
                name: z.ZodString;
                family: z.ZodString;
                startedAt: z.ZodISODateTime;
                elapsedMs: z.ZodNumber;
            }, z.core.$strict>>;
            lease: z.ZodObject<{
                owner: z.ZodString;
                leaseUntil: z.ZodNumber;
                leaseMs: z.ZodNumber;
                sinceHeartbeatMs: z.ZodOptional<z.ZodNumber>;
                stale: z.ZodBoolean;
            }, z.core.$strict>;
            gates: z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                required: z.ZodNumber;
                passed: z.ZodNumber;
                failed: z.ZodNumber;
                remaining: z.ZodNumber;
            }, z.core.$strict>;
            liveness: z.ZodOptional<z.ZodObject<{
                state: z.ZodEnum<{
                    active: "active";
                    stalled: "stalled";
                    quiet: "quiet";
                }>;
                since: z.ZodISODateTime;
                lastMovementAt: z.ZodISODateTime;
                idleMs: z.ZodOptional<z.ZodNumber>;
                activity: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        gate: "gate";
                        command: "command";
                        agent: "agent";
                        step: "step";
                    }>;
                    label: z.ZodString;
                }, z.core.$strict>>;
                action: z.ZodOptional<z.ZodEnum<{
                    report: "report";
                    stop: "stop";
                }>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const eventsDataSchema: z.ZodObject<{
    events: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        seq: z.ZodNumber;
        at: z.ZodISODateTime;
        graphId: z.ZodOptional<z.ZodString>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        attempt: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.stage" | "attempt.liveness" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.liveness" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
        payload: z.ZodObject<{
            digest: z.ZodString;
            orders: z.ZodNumber;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodEnum<{
                plan: "plan";
                contract: "contract";
            }>;
            subject: z.ZodString;
            digest: z.ZodString;
            round: z.ZodNumber;
            approved: z.ZodBoolean;
            open: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            actor: z.ZodEnum<{
                agent: "agent";
                operator: "operator";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            orderDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            released: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            policyDigest: z.ZodString;
            engineVersion: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
            recheck: z.ZodOptional<z.ZodObject<{
                of: z.ZodString;
                outcome: z.ZodEnum<{
                    flaky: "flaky";
                    confirmed: "confirmed";
                }>;
            }, z.core.$strict>>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            sameVendor: z.ZodBoolean;
            blocking: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            timingId: z.ZodString;
            stage: z.ZodString;
            phase: z.ZodEnum<{
                started: "started";
                finished: "finished";
            }>;
            at: z.ZodISODateTime;
            durationMs: z.ZodOptional<z.ZodNumber>;
            outcome: z.ZodOptional<z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>>;
        }, z.core.$strict> | z.ZodObject<{
            state: z.ZodEnum<{
                active: "active";
                stalled: "stalled";
                quiet: "quiet";
            }>;
            previous: z.ZodEnum<{
                active: "active";
                stalled: "stalled";
                quiet: "quiet";
            }>;
            lastMovementAt: z.ZodISODateTime;
            idleMs: z.ZodNumber;
            activity: z.ZodOptional<z.ZodObject<{
                kind: z.ZodEnum<{
                    gate: "gate";
                    command: "command";
                    agent: "agent";
                    step: "step";
                }>;
                label: z.ZodString;
            }, z.core.$strict>>;
            cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
            action: z.ZodOptional<z.ZodEnum<{
                report: "report";
                stop: "stop";
            }>>;
            snapshot: z.ZodOptional<z.ZodObject<{
                processes: z.ZodArray<z.ZodObject<{
                    pid: z.ZodNumber;
                    parentPid: z.ZodNumber;
                    cpuMs: z.ZodOptional<z.ZodNumber>;
                    command: z.ZodString;
                }, z.core.$strict>>;
                processesUnavailable: z.ZodOptional<z.ZodBoolean>;
                tail: z.ZodString;
                artifact: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict> | z.ZodObject<{
            failureKind: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>;
            message: z.ZodString;
            blocked: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            leaseUntil: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            integrationSha: z.ZodString;
            accepted: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            resultSha: z.ZodString;
            integrationSha: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
            failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>>;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            scope: z.ZodEnum<{
                work: "work";
                group: "group";
                total: "total";
            }>;
            scopeId: z.ZodOptional<z.ZodString>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
            }>;
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            suite: z.ZodString;
            pending: z.ZodString;
            version: z.ZodNumber;
            digest: z.ZodString;
            status: z.ZodEnum<{
                completed: "completed";
                waiting: "waiting";
            }>;
            accepted: z.ZodArray<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            recoveryId: z.ZodString;
            property: z.ZodString;
            status: z.ZodEnum<{
                closed: "closed";
                stopped: "stopped";
                "awaiting-lead": "awaiting-lead";
                analyzing: "analyzing";
                applying: "applying";
                retry: "retry";
                retrying: "retrying";
                "awaiting-user": "awaiting-user";
            }>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            policyDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            state: z.ZodEnum<{
                active: "active";
                stalled: "stalled";
                quiet: "quiet";
            }>;
            previous: z.ZodEnum<{
                active: "active";
                stalled: "stalled";
                quiet: "quiet";
            }>;
            lastMovementAt: z.ZodISODateTime;
            idleMs: z.ZodNumber;
            activity: z.ZodOptional<z.ZodObject<{
                kind: z.ZodEnum<{
                    gate: "gate";
                    command: "command";
                    agent: "agent";
                    step: "step";
                }>;
                label: z.ZodString;
            }, z.core.$strict>>;
            cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
            action: z.ZodOptional<z.ZodEnum<{
                report: "report";
                stop: "stop";
            }>>;
            snapshot: z.ZodOptional<z.ZodObject<{
                processes: z.ZodArray<z.ZodObject<{
                    pid: z.ZodNumber;
                    parentPid: z.ZodNumber;
                    cpuMs: z.ZodOptional<z.ZodNumber>;
                    command: z.ZodString;
                }, z.core.$strict>>;
                processesUnavailable: z.ZodOptional<z.ZodBoolean>;
                tail: z.ZodString;
                artifact: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            verificationId: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>;
            manifestDigest: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodNumber;
            by: z.ZodString;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                requested: "requested";
                cleared: "cleared";
            }>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            receipt: z.ZodOptional<z.ZodString>;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            error: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            currentRevision: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>, ...z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        seq: z.ZodNumber;
        at: z.ZodISODateTime;
        graphId: z.ZodOptional<z.ZodString>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        attempt: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.stage" | "attempt.liveness" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.liveness" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
        payload: z.ZodObject<{
            digest: z.ZodString;
            orders: z.ZodNumber;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodEnum<{
                plan: "plan";
                contract: "contract";
            }>;
            subject: z.ZodString;
            digest: z.ZodString;
            round: z.ZodNumber;
            approved: z.ZodBoolean;
            open: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            actor: z.ZodEnum<{
                agent: "agent";
                operator: "operator";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            orderDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            released: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            policyDigest: z.ZodString;
            engineVersion: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
            recheck: z.ZodOptional<z.ZodObject<{
                of: z.ZodString;
                outcome: z.ZodEnum<{
                    flaky: "flaky";
                    confirmed: "confirmed";
                }>;
            }, z.core.$strict>>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            sameVendor: z.ZodBoolean;
            blocking: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            timingId: z.ZodString;
            stage: z.ZodString;
            phase: z.ZodEnum<{
                started: "started";
                finished: "finished";
            }>;
            at: z.ZodISODateTime;
            durationMs: z.ZodOptional<z.ZodNumber>;
            outcome: z.ZodOptional<z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>>;
        }, z.core.$strict> | z.ZodObject<{
            state: z.ZodEnum<{
                active: "active";
                stalled: "stalled";
                quiet: "quiet";
            }>;
            previous: z.ZodEnum<{
                active: "active";
                stalled: "stalled";
                quiet: "quiet";
            }>;
            lastMovementAt: z.ZodISODateTime;
            idleMs: z.ZodNumber;
            activity: z.ZodOptional<z.ZodObject<{
                kind: z.ZodEnum<{
                    gate: "gate";
                    command: "command";
                    agent: "agent";
                    step: "step";
                }>;
                label: z.ZodString;
            }, z.core.$strict>>;
            cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
            action: z.ZodOptional<z.ZodEnum<{
                report: "report";
                stop: "stop";
            }>>;
            snapshot: z.ZodOptional<z.ZodObject<{
                processes: z.ZodArray<z.ZodObject<{
                    pid: z.ZodNumber;
                    parentPid: z.ZodNumber;
                    cpuMs: z.ZodOptional<z.ZodNumber>;
                    command: z.ZodString;
                }, z.core.$strict>>;
                processesUnavailable: z.ZodOptional<z.ZodBoolean>;
                tail: z.ZodString;
                artifact: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict> | z.ZodObject<{
            failureKind: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>;
            message: z.ZodString;
            blocked: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            leaseUntil: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            integrationSha: z.ZodString;
            accepted: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            resultSha: z.ZodString;
            integrationSha: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
            failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>>;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            scope: z.ZodEnum<{
                work: "work";
                group: "group";
                total: "total";
            }>;
            scopeId: z.ZodOptional<z.ZodString>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
            }>;
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            suite: z.ZodString;
            pending: z.ZodString;
            version: z.ZodNumber;
            digest: z.ZodString;
            status: z.ZodEnum<{
                completed: "completed";
                waiting: "waiting";
            }>;
            accepted: z.ZodArray<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            recoveryId: z.ZodString;
            property: z.ZodString;
            status: z.ZodEnum<{
                closed: "closed";
                stopped: "stopped";
                "awaiting-lead": "awaiting-lead";
                analyzing: "analyzing";
                applying: "applying";
                retry: "retry";
                retrying: "retrying";
                "awaiting-user": "awaiting-user";
            }>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            policyDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            state: z.ZodEnum<{
                active: "active";
                stalled: "stalled";
                quiet: "quiet";
            }>;
            previous: z.ZodEnum<{
                active: "active";
                stalled: "stalled";
                quiet: "quiet";
            }>;
            lastMovementAt: z.ZodISODateTime;
            idleMs: z.ZodNumber;
            activity: z.ZodOptional<z.ZodObject<{
                kind: z.ZodEnum<{
                    gate: "gate";
                    command: "command";
                    agent: "agent";
                    step: "step";
                }>;
                label: z.ZodString;
            }, z.core.$strict>>;
            cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
            action: z.ZodOptional<z.ZodEnum<{
                report: "report";
                stop: "stop";
            }>>;
            snapshot: z.ZodOptional<z.ZodObject<{
                processes: z.ZodArray<z.ZodObject<{
                    pid: z.ZodNumber;
                    parentPid: z.ZodNumber;
                    cpuMs: z.ZodOptional<z.ZodNumber>;
                    command: z.ZodString;
                }, z.core.$strict>>;
                processesUnavailable: z.ZodOptional<z.ZodBoolean>;
                tail: z.ZodString;
                artifact: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            verificationId: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>;
            manifestDigest: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodNumber;
            by: z.ZodString;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                requested: "requested";
                cleared: "cleared";
            }>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            receipt: z.ZodOptional<z.ZodString>;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            error: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            currentRevision: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>[], z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        seq: z.ZodNumber;
        at: z.ZodISODateTime;
        graphId: z.ZodOptional<z.ZodString>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        attempt: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"unknown">;
        original: z.ZodString;
    }, z.core.$strict>], "type">>;
    next: z.ZodNumber;
}, z.core.$strict>;
export declare const runDataSchema: z.ZodObject<{
    graphId: z.ZodString;
    digest: z.ZodString;
    resumed: z.ZodBoolean;
    baseline: z.ZodOptional<z.ZodObject<{
        sha: z.ZodString;
        reason: z.ZodString;
        tasks: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    works: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        runId: z.ZodOptional<z.ZodString>;
        resultSha: z.ZodOptional<z.ZodString>;
        blockers: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            message: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    workflow: z.ZodOptional<z.ZodObject<{
        key: z.ZodString;
        kind: z.ZodString;
        id: z.ZodString;
        stage: z.ZodNumber;
        status: z.ZodEnum<{
            failed: "failed";
            completed: "completed";
            running: "running";
            queued: "queued";
            stale: "stale";
        }>;
        attempts: z.ZodNumber;
        repairs: z.ZodNumber;
        repairBudget: z.ZodNumber;
        error: z.ZodOptional<z.ZodString>;
        history: z.ZodArray<z.ZodObject<{
            at: z.ZodISODateTime;
            stage: z.ZodNumber;
            event: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const controlDataSchema: z.ZodObject<{
    control: z.ZodObject<{
        paused: z.ZodBoolean;
        pauseReason: z.ZodOptional<z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>>;
        pausedAt: z.ZodOptional<z.ZodISODateTime>;
        pauseOperation: z.ZodOptional<z.ZodString>;
        pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
        }>>>;
        waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                "base-check": "base-check";
                "context-lock": "context-lock";
            }>;
            detail: z.ZodString;
            at: z.ZodISODateTime;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        appliedPolicy: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodOptional<z.ZodNumber>;
            at: z.ZodISODateTime;
            by: z.ZodString;
        }, z.core.$strict>>;
        reconfigure: z.ZodOptional<z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            requestedAt: z.ZodISODateTime;
            appliedAt: z.ZodOptional<z.ZodISODateTime>;
            appliedBy: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    changed: z.ZodBoolean;
}, z.core.$strict>;
export declare const workActionDataSchema: z.ZodObject<{
    workId: z.ZodString;
    status: z.ZodEnum<{
        ready: "ready";
        failed: "failed";
        cancelled: "cancelled";
        draft: "draft";
        running: "running";
        verifying: "verifying";
        reviewing: "reviewing";
        integrating: "integrating";
        done: "done";
    }>;
    attempt: z.ZodNumber;
    changed: z.ZodBoolean;
}, z.core.$strict>;
export declare const approveDataSchema: z.ZodObject<{
    subject: z.ZodString;
    digest: z.ZodString;
    at: z.ZodISODateTime;
    changed: z.ZodBoolean;
}, z.core.$strict>;
export declare const doctorDataSchema: z.ZodObject<{
    harness: z.ZodString;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    node: z.ZodString;
    platform: z.ZodString;
    runtimes: z.ZodArray<z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        available: z.ZodBoolean;
        version: z.ZodOptional<z.ZodString>;
        structuredOutput: z.ZodBoolean;
        cancellation: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    sandbox: z.ZodObject<{
        os: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    state: z.ZodOptional<z.ZodObject<{
        stateVersion: z.ZodNumber;
        compatible: z.ZodBoolean;
        writer: z.ZodOptional<z.ZodString>;
        engineVersions: z.ZodOptional<z.ZodObject<{
            controller: z.ZodOptional<z.ZodString>;
            attempts: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    checkouts: z.ZodOptional<z.ZodObject<{
        placement: z.ZodEnum<{
            configured: "configured";
            "in-place": "in-place";
            cache: "cache";
            "cross-volume": "cross-volume";
        }>;
        root: z.ZodOptional<z.ZodString>;
        note: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    toolchains: z.ZodOptional<z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        root: z.ZodString;
        configSource: z.ZodOptional<z.ZodString>;
        plan: z.ZodArray<z.ZodObject<{
            phase: z.ZodEnum<{
                gate: "gate";
                prepare: "prepare";
                dependencyBuild: "dependencyBuild";
                preflight: "preflight";
                setup: "setup";
                ready: "ready";
                teardown: "teardown";
            }>;
            id: z.ZodString;
            kind: z.ZodOptional<z.ZodEnum<{
                check: "check";
                test: "test";
            }>>;
            cwd: z.ZodString;
            argv: z.ZodArray<z.ZodString>;
            report: z.ZodOptional<z.ZodString>;
            field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        }, z.core.$strict>>;
        tools: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            provider: z.ZodEnum<{
                path: "path";
                project: "project";
            }>;
            found: z.ZodBoolean;
            version: z.ZodOptional<z.ZodString>;
            required: z.ZodArray<z.ZodObject<{
                version: z.ZodString;
                source: z.ZodString;
            }, z.core.$strict>>;
            usedBy: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        lockfiles: z.ZodArray<z.ZodObject<{
            dir: z.ZodString;
            files: z.ZodArray<z.ZodString>;
            manager: z.ZodOptional<z.ZodString>;
            selectedBy: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        reports: z.ZodArray<z.ZodObject<{
            gate: z.ZodString;
            path: z.ZodString;
            cwd: z.ZodString;
        }, z.core.$strict>>;
        ambiguities: z.ZodArray<z.ZodObject<{
            field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            path: z.ZodOptional<z.ZodString>;
            message: z.ZodString;
            resolvedBy: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        problems: z.ZodArray<z.ZodObject<{
            code: z.ZodString;
            field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            path: z.ZodOptional<z.ZodString>;
            message: z.ZodString;
        }, z.core.$strict>>;
        warnings: z.ZodArray<z.ZodObject<{
            code: z.ZodString;
            field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            path: z.ZodOptional<z.ZodString>;
            message: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    problems: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const profileDataSchema: z.ZodObject<{
    pin: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        source: z.ZodOptional<z.ZodObject<{
            repositoryId: z.ZodString;
            path: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    profile: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        capabilities: z.ZodArray<z.ZodString>;
        gates: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"test">;
            report: z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>;
            artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"check">;
            report: z.ZodOptional<z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>>;
            artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>], "kind">>;
        prepare: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
        environment: z.ZodOptional<z.ZodObject<{
            inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
            values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        }, z.core.$strict>>;
        lifecycle: z.ZodOptional<z.ZodObject<{
            setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            teardown: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        toolchain: z.ZodOptional<z.ZodObject<{
            tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
                npm: "npm";
                pnpm: "pnpm";
            }>>>;
        }, z.core.$strict>>;
        protectedPaths: z.ZodArray<z.ZodString>;
        generatedPaths: z.ZodArray<z.ZodString>;
        concurrency: z.ZodOptional<z.ZodNumber>;
        runTimeoutMs: z.ZodOptional<z.ZodNumber>;
        roles: z.ZodRecord<z.ZodString, z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
            writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
            reviewer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            title: z.ZodOptional<z.ZodString>;
            requiresContract: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        contextPacks: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            repositoryId: z.ZodOptional<z.ZodString>;
            roles: z.ZodDefault<z.ZodArray<z.ZodString>>;
            files: z.ZodArray<z.ZodString>;
            references: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        source: z.ZodOptional<z.ZodObject<{
            repositoryId: z.ZodString;
            path: z.ZodString;
        }, z.core.$strict>>;
        closure: z.ZodArray<z.ZodObject<{
            ref: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const versionDataSchema: z.ZodObject<{
    harness: z.ZodString;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
}, z.core.$strict>;
export declare const sourceCheckDataSchema: z.ZodObject<{
    provider: z.ZodEnum<{
        "relay-v1-http": "relay-v1-http";
        "relay-v2-cli": "relay-v2-cli";
    }>;
    projectId: z.ZodString;
    connector: z.ZodString;
    connected: z.ZodBoolean;
    projectMatches: z.ZodBoolean;
    identity: z.ZodOptional<z.ZodObject<{
        capabilities: z.ZodArray<z.ZodString>;
        build: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strict>>;
    history: z.ZodObject<{
        enabled: z.ZodBoolean;
        capability: z.ZodBoolean;
    }, z.core.$strict>;
    mapping: z.ZodArray<z.ZodObject<{
        ref: z.ZodString;
        key: z.ZodOptional<z.ZodString>;
        problems: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    ownership: z.ZodObject<{
        stateDir: z.ZodString;
        store: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    problems: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
/** Закреплённый локальный пакет `tasks[].context`: то, что называет manifest снимка. */
export declare const localContextManifestSchema: z.ZodObject<{
    id: z.ZodString;
    digest: z.ZodString;
    files: z.ZodNumber;
    references: z.ZodNumber;
    bytes: z.ZodNumber;
}, z.core.$strict>;
export type LocalContextManifest = z.infer<typeof localContextManifestSchema>;
export declare const sourceSnapshotDataSchema: z.ZodObject<{
    connector: z.ZodString;
    graphId: z.ZodString;
    graphDigest: z.ZodString;
    contextDigest: z.ZodString;
    localContext: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        digest: z.ZodString;
        files: z.ZodNumber;
        references: z.ZodNumber;
        bytes: z.ZodNumber;
    }, z.core.$strict>>>;
    revision: z.ZodString;
    created: z.ZodBoolean;
    eligible: z.ZodBoolean;
    problems: z.ZodArray<z.ZodString>;
    truncated: z.ZodArray<z.ZodString>;
    baseline: z.ZodOptional<z.ZodObject<{
        sha: z.ZodString;
        reason: z.ZodString;
        tasks: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    tasks: z.ZodArray<z.ZodObject<{
        identity: z.ZodString;
        key: z.ZodString;
        orderId: z.ZodString;
        semanticDigest: z.ZodString;
        casRevision: z.ZodNumber;
        column: z.ZodString;
    }, z.core.$strict>>;
    files: z.ZodObject<{
        graph: z.ZodString;
        context: z.ZodString;
        manifest: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const sourceStatusDataSchema: z.ZodObject<{
    connector: z.ZodString;
    provider: z.ZodEnum<{
        "relay-v1-http": "relay-v1-http";
        "relay-v2-cli": "relay-v2-cli";
    }>;
    projectId: z.ZodString;
    snapshot: z.ZodOptional<z.ZodObject<{
        revision: z.ZodString;
        graphId: z.ZodString;
        baseline: z.ZodOptional<z.ZodObject<{
            sha: z.ZodString;
            reason: z.ZodString;
            tasks: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    ownership: z.ZodObject<{
        stateDir: z.ZodString;
        store: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    tasks: z.ZodArray<z.ZodObject<{
        index: z.ZodNumber;
        ref: z.ZodString;
        key: z.ZodOptional<z.ZodString>;
        identity: z.ZodOptional<z.ZodString>;
        workId: z.ZodString;
        local: z.ZodObject<{
            status: z.ZodString;
            attempt: z.ZodOptional<z.ZodNumber>;
            resultSha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        deliveries: z.ZodArray<z.ZodObject<{
            status: z.ZodString;
            key: z.ZodString;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        operations: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            runId: z.ZodString;
            outcome: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
                intent: "intent";
                "in-progress": "in-progress";
            }>;
            reason: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            steps: z.ZodArray<z.ZodObject<{
                n: z.ZodNumber;
                kind: z.ZodString;
                status: z.ZodString;
                marker: z.ZodString;
            }, z.core.$strict>>;
            lease: z.ZodOptional<z.ZodObject<{
                owner: z.ZodString;
                expiresAt: z.ZodISODateTime;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        remote: z.ZodUnion<readonly [z.ZodObject<{
            reachable: z.ZodLiteral<true>;
            column: z.ZodString;
            casRevision: z.ZodNumber;
            semanticDigest: z.ZodString;
            matchesSnapshot: z.ZodBoolean;
            criteria: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                completed: z.ZodBoolean;
            }, z.core.$strict>>;
            markers: z.ZodRecord<z.ZodString, z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            reachable: z.ZodLiteral<false>;
            error: z.ZodString;
        }, z.core.$strict>]>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const sourceDeliverDataSchema: z.ZodObject<{
    connector: z.ZodString;
    deliveries: z.ZodArray<z.ZodObject<{
        workId: z.ZodString;
        outcome: z.ZodString;
        delivery: z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            operation: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const sourceReconcileDataSchema: z.ZodObject<{
    operation: z.ZodString;
    workId: z.ZodString;
    before: z.ZodString;
    after: z.ZodString;
    resolved: z.ZodBoolean;
    facts: z.ZodArray<z.ZodString>;
    delivery: z.ZodOptional<z.ZodArray<z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            pending: "pending";
            delivered: "delivered";
            conflict: "conflict";
            uncertain: "uncertain";
        }>;
        attempts: z.ZodNumber;
        lastError: z.ZodOptional<z.ZodString>;
        operation: z.ZodOptional<z.ZodString>;
        currentRevision: z.ZodOptional<z.ZodString>;
        receipt: z.ZodOptional<z.ZodString>;
        updatedAt: z.ZodISODateTime;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const cleanupDataSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    status: z.ZodLiteral<"nothing-pending">;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"cleaned">;
    receipts: z.ZodArray<z.ZodString>;
}, z.core.$strict>], "status">;
export declare const worktreeCleanupDataSchema: z.ZodObject<{
    dryRun: z.ZodBoolean;
    removed: z.ZodNumber;
    removable: z.ZodNumber;
    refused: z.ZodNumber;
    failed: z.ZodNumber;
    reclaimedKb: z.ZodNumber;
    worktrees: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        repositoryId: z.ZodString;
        attemptId: z.ZodOptional<z.ZodString>;
        action: z.ZodEnum<{
            refused: "refused";
            failed: "failed";
            removed: "removed";
            remove: "remove";
        }>;
        reason: z.ZodOptional<z.ZodEnum<{
            "scan-limit": "scan-limit";
            active: "active";
            recoverable: "recoverable";
            "cleanup-pending": "cleanup-pending";
            "cleanup-unreadable": "cleanup-unreadable";
            "unknown-attempt": "unknown-attempt";
            untrusted: "untrusted";
            "embedded-repository": "embedded-repository";
            "scan-failed": "scan-failed";
            "read-only-path": "read-only-path";
            "undecodable-path": "undecodable-path";
            "worktree-locked": "worktree-locked";
            "clean-filter": "clean-filter";
            "tree-changed": "tree-changed";
            "ignore-rules-changed": "ignore-rules-changed";
            "hidden-changes": "hidden-changes";
            "staged-ignored": "staged-ignored";
            "staged-differs": "staged-differs";
            "unreachable-head": "unreachable-head";
            "patch-unusable": "patch-unusable";
            "removal-incomplete": "removal-incomplete";
            "not-registered": "not-registered";
        }>>;
        error: z.ZodOptional<z.ZodString>;
        head: z.ZodOptional<z.ZodString>;
        sizeKb: z.ZodOptional<z.ZodNumber>;
        uncommitted: z.ZodOptional<z.ZodNumber>;
        ignored: z.ZodOptional<z.ZodObject<{
            count: z.ZodNumber;
            paths: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        record: z.ZodOptional<z.ZodString>;
        removalStarted: z.ZodOptional<z.ZodBoolean>;
        registered: z.ZodOptional<z.ZodBoolean>;
        treePresent: z.ZodOptional<z.ZodBoolean>;
        patch: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** `init`: план или результат подготовки проекта. */
export declare const initDataSchema: z.ZodObject<{
    mode: z.ZodEnum<{
        plan: "plan";
        apply: "apply";
    }>;
    status: z.ZodEnum<{
        partial: "partial";
        complete: "complete";
        new: "new";
    }>;
    projectId: z.ZodString;
    root: z.ZodString;
    manifestPath: z.ZodString;
    manifest: z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        kind: z.ZodLiteral<"harness-project">;
        manifestVersion: z.ZodLiteral<1>;
        projectId: z.ZodString;
        root: z.ZodString;
        repository: z.ZodObject<{
            id: z.ZodString;
            targetRef: z.ZodString;
        }, z.core.$strict>;
        profile: z.ZodObject<{
            ref: z.ZodString;
            pin: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodString;
                digest: z.ZodString;
                source: z.ZodOptional<z.ZodObject<{
                    repositoryId: z.ZodString;
                    path: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        runtimes: z.ZodObject<{
            writer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
        }, z.core.$strict>;
        paths: z.ZodObject<{
            policy: z.ZodLiteral<".harness/policy.json">;
            work: z.ZodLiteral<".harness/work">;
            notes: z.ZodLiteral<".harness/work/context/notes">;
            state: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>;
    files: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        action: z.ZodEnum<{
            conflict: "conflict";
            create: "create";
            preserve: "preserve";
        }>;
        conflict: z.ZodOptional<z.ZodEnum<{
            symlink: "symlink";
            "ancestor-not-directory": "ancestor-not-directory";
            "not-regular-file": "not-regular-file";
            "content-differs": "content-differs";
            "outside-root": "outside-root";
        }>>;
        conflictPath: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    conflicts: z.ZodNumber;
    created: z.ZodArray<z.ZodString>;
    preserved: z.ZodArray<z.ZodString>;
    profile: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        source: z.ZodOptional<z.ZodObject<{
            repositoryId: z.ZodString;
            path: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    shadowed: z.ZodArray<z.ZodString>;
    facts: z.ZodObject<{
        repositoryId: z.ZodString;
        targetRef: z.ZodString;
        roles: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        gates: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                check: "check";
                test: "test";
            }>;
        }, z.core.$strict>>;
        workDir: z.ZodString;
        contextDir: z.ZodString;
        notesDir: z.ZodString;
    }, z.core.$strict>;
    toolchain: z.ZodObject<{
        ready: z.ZodBoolean;
        problems: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    next: z.ZodArray<z.ZodObject<{
        command: z.ZodString;
        args: z.ZodArray<z.ZodString>;
        why: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** `explain`: объяснения остановок. */
export declare const explainDataSchema: z.ZodObject<{
    diagnoses: z.ZodArray<z.ZodObject<{
        code: z.ZodEnum<{
            INVALID_INPUT: "INVALID_INPUT";
            UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
            UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
            GRAPH_CYCLE: "GRAPH_CYCLE";
            GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
            GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
            GATE_UNKNOWN: "GATE_UNKNOWN";
            GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
            REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
            REVIEWER_MISSING: "REVIEWER_MISSING";
            RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
            APPROVAL_STALE: "APPROVAL_STALE";
            APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
            LEASE_STALE: "LEASE_STALE";
            CONTROLLER_BUSY: "CONTROLLER_BUSY";
            PAUSED: "PAUSED";
            NOT_READY: "NOT_READY";
            SCOPE_VIOLATION: "SCOPE_VIOLATION";
            GATE_FAILED: "GATE_FAILED";
            REVIEW_REJECTED: "REVIEW_REJECTED";
            BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
            BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
            ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
            REVISION_CONFLICT: "REVISION_CONFLICT";
            CANCELLED: "CANCELLED";
            NOT_FOUND: "NOT_FOUND";
            PATH_CONFLICT: "PATH_CONFLICT";
            STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
            RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
            REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
            SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
            GIT_FAILED: "GIT_FAILED";
            STORAGE_FAILED: "STORAGE_FAILED";
            DELIVERY_FAILED: "DELIVERY_FAILED";
            INTERNAL: "INTERNAL";
        }>;
        cause: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
            "runtime-missing": "runtime-missing";
            "controller-busy": "controller-busy";
            "operator-pause": "operator-pause";
            "approval-required": "approval-required";
            "not-ready": "not-ready";
        }>;
        phase: z.ZodEnum<{
            gates: "gates";
            preflight: "preflight";
            review: "review";
            integration: "integration";
            delivery: "delivery";
            claim: "claim";
            implementation: "implementation";
        }>;
        actor: z.ZodNullable<z.ZodEnum<{
            controller: "controller";
            lead: "lead";
            user: "user";
        }>>;
        action: z.ZodEnum<{
            none: "none";
            wait: "wait";
            retry: "retry";
            "review-plan": "review-plan";
            "diagnose-failure": "diagnose-failure";
            "reset-attempts": "reset-attempts";
            "raise-budget": "raise-budget";
            "replan-dependents": "replan-dependents";
            "recovery-decision": "recovery-decision";
            "user-decision": "user-decision";
            "resume-queue": "resume-queue";
            "fix-environment": "fix-environment";
            "fix-access": "fix-access";
        }>;
        retryPlanned: z.ZodBoolean;
        message: z.ZodString;
        evidence: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                attempt: "attempt";
                evidence: "evidence";
                event: "event";
                doctor: "doctor";
            }>;
            id: z.ZodString;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** Схема `data` каждой команды. */
export declare const cliDataSchemas: {
    readonly validate: z.ZodObject<{
        graphId: z.ZodString;
        graphDigest: z.ZodString;
        policyDigest: z.ZodString;
        contextDigest: z.ZodOptional<z.ZodString>;
        orders: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'review-plan': z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        at: z.ZodISODateTime;
        approved: z.ZodBoolean;
        summary: z.ZodString;
        authorRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
            external: "external";
        }>;
        reviewerRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewerModel: z.ZodOptional<z.ZodString>;
        sameVendor: z.ZodBoolean;
        reviewerBinding: z.ZodOptional<z.ZodString>;
        contextDigest: z.ZodOptional<z.ZodString>;
        findings: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            severity: z.ZodEnum<{
                blocking: "blocking";
                note: "note";
            }>;
            message: z.ZodString;
            rule: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            status: z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>;
            openedIn: z.ZodNumber;
            changedIn: z.ZodNumber;
            basis: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        artifact: z.ZodString;
    }, z.core.$strict>;
    readonly 'review-contract': z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        at: z.ZodISODateTime;
        approved: z.ZodBoolean;
        summary: z.ZodString;
        authorRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
            external: "external";
        }>;
        reviewerRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewerModel: z.ZodOptional<z.ZodString>;
        sameVendor: z.ZodBoolean;
        reviewerBinding: z.ZodOptional<z.ZodString>;
        contextDigest: z.ZodOptional<z.ZodString>;
        findings: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            severity: z.ZodEnum<{
                blocking: "blocking";
                note: "note";
            }>;
            message: z.ZodString;
            rule: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            status: z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>;
            openedIn: z.ZodNumber;
            changedIn: z.ZodNumber;
            basis: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        artifact: z.ZodString;
    }, z.core.$strict>;
    readonly approve: z.ZodObject<{
        subject: z.ZodString;
        digest: z.ZodString;
        at: z.ZodISODateTime;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly run: z.ZodObject<{
        graphId: z.ZodString;
        digest: z.ZodString;
        resumed: z.ZodBoolean;
        baseline: z.ZodOptional<z.ZodObject<{
            sha: z.ZodString;
            reason: z.ZodString;
            tasks: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        works: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            status: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            runId: z.ZodOptional<z.ZodString>;
            resultSha: z.ZodOptional<z.ZodString>;
            blockers: z.ZodArray<z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workflow: z.ZodOptional<z.ZodObject<{
            key: z.ZodString;
            kind: z.ZodString;
            id: z.ZodString;
            stage: z.ZodNumber;
            status: z.ZodEnum<{
                failed: "failed";
                completed: "completed";
                running: "running";
                queued: "queued";
                stale: "stale";
            }>;
            attempts: z.ZodNumber;
            repairs: z.ZodNumber;
            repairBudget: z.ZodNumber;
            error: z.ZodOptional<z.ZodString>;
            history: z.ZodArray<z.ZodObject<{
                at: z.ZodISODateTime;
                stage: z.ZodNumber;
                event: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly status: z.ZodObject<{
        stateVersion: z.ZodLiteral<1>;
        control: z.ZodObject<{
            paused: z.ZodBoolean;
            pauseReason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            pausedAt: z.ZodOptional<z.ZodISODateTime>;
            pauseOperation: z.ZodOptional<z.ZodString>;
            pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>>;
            waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    "base-check": "base-check";
                    "context-lock": "context-lock";
                }>;
                detail: z.ZodString;
                at: z.ZodISODateTime;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            appliedPolicy: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodOptional<z.ZodNumber>;
                at: z.ZodISODateTime;
                by: z.ZodString;
            }, z.core.$strict>>;
            reconfigure: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                requestedAt: z.ZodISODateTime;
                appliedAt: z.ZodOptional<z.ZodISODateTime>;
                appliedBy: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        controller: z.ZodOptional<z.ZodObject<{
            owner: z.ZodString;
            leaseUntil: z.ZodNumber;
            engineVersion: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        graphs: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            digest: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            approved: z.ZodBoolean;
        }, z.core.$strict>>;
        works: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            graphId: z.ZodString;
            status: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            attempt: z.ZodNumber;
            activeRunId: z.ZodOptional<z.ZodString>;
            liveness: z.ZodOptional<z.ZodEnum<{
                stalled: "stalled";
                quiet: "quiet";
            }>>;
            resultSha: z.ZodOptional<z.ZodString>;
            blockers: z.ZodArray<z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        budgets: z.ZodOptional<z.ZodObject<{
            onUnknown: z.ZodEnum<{
                continue: "continue";
                stop: "stop";
            }>;
            budgets: z.ZodArray<z.ZodObject<{
                scope: z.ZodObject<{
                    kind: z.ZodEnum<{
                        work: "work";
                        group: "group";
                        total: "total";
                    }>;
                    id: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                state: z.ZodEnum<{
                    exceeded: "exceeded";
                    undetermined: "undetermined";
                    within: "within";
                }>;
                limit: z.ZodObject<{
                    usd: z.ZodOptional<z.ZodNumber>;
                    timeMs: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>;
                reportedUsd: z.ZodNumber;
                estimatedUsd: z.ZodNumber;
                unknownCalls: z.ZodNumber;
                unfinishedCalls: z.ZodNumber;
                abandonedCalls: z.ZodNumber;
                errorCalls: z.ZodNumber;
                uncoveredRuns: z.ZodNumber;
                durationMs: z.ZodNumber;
                remainingUsd: z.ZodNullable<z.ZodNumber>;
                remainingMs: z.ZodNullable<z.ZodNumber>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        detail: z.ZodOptional<z.ZodObject<{
            at: z.ZodISODateTime;
            queue: z.ZodObject<{
                paused: z.ZodBoolean;
                reason: z.ZodOptional<z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>>;
                detail: z.ZodOptional<z.ZodString>;
                since: z.ZodOptional<z.ZodISODateTime>;
                operation: z.ZodOptional<z.ZodString>;
                liftedByRun: z.ZodOptional<z.ZodLiteral<true>>;
                failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    cancelled: "cancelled";
                    environment: "environment";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    stalled: "stalled";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    unfinished: "unfinished";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                    "needs-lead": "needs-lead";
                }>>>;
                code: z.ZodOptional<z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>>;
                cause: z.ZodOptional<z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    cancelled: "cancelled";
                    environment: "environment";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    stalled: "stalled";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    unfinished: "unfinished";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                    "needs-lead": "needs-lead";
                    "runtime-missing": "runtime-missing";
                    "controller-busy": "controller-busy";
                    "operator-pause": "operator-pause";
                    "approval-required": "approval-required";
                    "not-ready": "not-ready";
                }>>;
                actor: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    controller: "controller";
                    lead: "lead";
                    user: "user";
                }>>>;
                action: z.ZodOptional<z.ZodEnum<{
                    none: "none";
                    wait: "wait";
                    retry: "retry";
                    "review-plan": "review-plan";
                    "diagnose-failure": "diagnose-failure";
                    "reset-attempts": "reset-attempts";
                    "raise-budget": "raise-budget";
                    "replan-dependents": "replan-dependents";
                    "recovery-decision": "recovery-decision";
                    "user-decision": "user-decision";
                    "resume-queue": "resume-queue";
                    "fix-environment": "fix-environment";
                    "fix-access": "fix-access";
                }>>;
            }, z.core.$strict>;
            attempts: z.ZodArray<z.ZodObject<{
                runId: z.ZodString;
                workId: z.ZodString;
                attempt: z.ZodNumber;
                status: z.ZodString;
                phase: z.ZodEnum<{
                    ready: "ready";
                    failed: "failed";
                    cancelled: "cancelled";
                    draft: "draft";
                    running: "running";
                    verifying: "verifying";
                    reviewing: "reviewing";
                    integrating: "integrating";
                    done: "done";
                }>;
                runtime: z.ZodString;
                model: z.ZodOptional<z.ZodString>;
                startedAt: z.ZodISODateTime;
                elapsedMs: z.ZodNumber;
                stage: z.ZodOptional<z.ZodObject<{
                    name: z.ZodString;
                    family: z.ZodString;
                    startedAt: z.ZodISODateTime;
                    elapsedMs: z.ZodNumber;
                }, z.core.$strict>>;
                lease: z.ZodObject<{
                    owner: z.ZodString;
                    leaseUntil: z.ZodNumber;
                    leaseMs: z.ZodNumber;
                    sinceHeartbeatMs: z.ZodOptional<z.ZodNumber>;
                    stale: z.ZodBoolean;
                }, z.core.$strict>;
                gates: z.ZodObject<{
                    phase: z.ZodEnum<{
                        candidate: "candidate";
                        integration: "integration";
                    }>;
                    required: z.ZodNumber;
                    passed: z.ZodNumber;
                    failed: z.ZodNumber;
                    remaining: z.ZodNumber;
                }, z.core.$strict>;
                liveness: z.ZodOptional<z.ZodObject<{
                    state: z.ZodEnum<{
                        active: "active";
                        stalled: "stalled";
                        quiet: "quiet";
                    }>;
                    since: z.ZodISODateTime;
                    lastMovementAt: z.ZodISODateTime;
                    idleMs: z.ZodOptional<z.ZodNumber>;
                    activity: z.ZodOptional<z.ZodObject<{
                        kind: z.ZodEnum<{
                            gate: "gate";
                            command: "command";
                            agent: "agent";
                            step: "step";
                        }>;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                    action: z.ZodOptional<z.ZodEnum<{
                        report: "report";
                        stop: "stop";
                    }>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly events: z.ZodObject<{
        events: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            seq: z.ZodNumber;
            at: z.ZodISODateTime;
            graphId: z.ZodOptional<z.ZodString>;
            workId: z.ZodOptional<z.ZodString>;
            runId: z.ZodOptional<z.ZodString>;
            attempt: z.ZodOptional<z.ZodNumber>;
            type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.stage" | "attempt.liveness" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.liveness" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
            payload: z.ZodObject<{
                digest: z.ZodString;
                orders: z.ZodNumber;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
            }, z.core.$strict> | z.ZodObject<{
                kind: z.ZodEnum<{
                    plan: "plan";
                    contract: "contract";
                }>;
                subject: z.ZodString;
                digest: z.ZodString;
                round: z.ZodNumber;
                approved: z.ZodBoolean;
                open: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                actor: z.ZodEnum<{
                    agent: "agent";
                    operator: "operator";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                orderDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
                released: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                policyDigest: z.ZodString;
                engineVersion: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    ready: "ready";
                    failed: "failed";
                    cancelled: "cancelled";
                    draft: "draft";
                    running: "running";
                    verifying: "verifying";
                    reviewing: "reviewing";
                    integrating: "integrating";
                    done: "done";
                }>;
                sha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                recheck: z.ZodOptional<z.ZodObject<{
                    of: z.ZodString;
                    outcome: z.ZodEnum<{
                        flaky: "flaky";
                        confirmed: "confirmed";
                    }>;
                }, z.core.$strict>>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                sameVendor: z.ZodBoolean;
                blocking: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                timingId: z.ZodString;
                stage: z.ZodString;
                phase: z.ZodEnum<{
                    started: "started";
                    finished: "finished";
                }>;
                at: z.ZodISODateTime;
                durationMs: z.ZodOptional<z.ZodNumber>;
                outcome: z.ZodOptional<z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                }>>;
            }, z.core.$strict> | z.ZodObject<{
                state: z.ZodEnum<{
                    active: "active";
                    stalled: "stalled";
                    quiet: "quiet";
                }>;
                previous: z.ZodEnum<{
                    active: "active";
                    stalled: "stalled";
                    quiet: "quiet";
                }>;
                lastMovementAt: z.ZodISODateTime;
                idleMs: z.ZodNumber;
                activity: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        gate: "gate";
                        command: "command";
                        agent: "agent";
                        step: "step";
                    }>;
                    label: z.ZodString;
                }, z.core.$strict>>;
                cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
                action: z.ZodOptional<z.ZodEnum<{
                    report: "report";
                    stop: "stop";
                }>>;
                snapshot: z.ZodOptional<z.ZodObject<{
                    processes: z.ZodArray<z.ZodObject<{
                        pid: z.ZodNumber;
                        parentPid: z.ZodNumber;
                        cpuMs: z.ZodOptional<z.ZodNumber>;
                        command: z.ZodString;
                    }, z.core.$strict>>;
                    processesUnavailable: z.ZodOptional<z.ZodBoolean>;
                    tail: z.ZodString;
                    artifact: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict> | z.ZodObject<{
                failureKind: z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    cancelled: "cancelled";
                    environment: "environment";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    stalled: "stalled";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    unfinished: "unfinished";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                    "needs-lead": "needs-lead";
                }>;
                message: z.ZodString;
                blocked: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                leaseUntil: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                integrationSha: z.ZodString;
                accepted: z.ZodBoolean;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                resultSha: z.ZodString;
                integrationSha: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                code: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
                failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    cancelled: "cancelled";
                    environment: "environment";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    stalled: "stalled";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    unfinished: "unfinished";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                    "needs-lead": "needs-lead";
                }>>>;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                scope: z.ZodEnum<{
                    work: "work";
                    group: "group";
                    total: "total";
                }>;
                scopeId: z.ZodOptional<z.ZodString>;
                state: z.ZodEnum<{
                    exceeded: "exceeded";
                    undetermined: "undetermined";
                }>;
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                suite: z.ZodString;
                pending: z.ZodString;
                version: z.ZodNumber;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    completed: "completed";
                    waiting: "waiting";
                }>;
                accepted: z.ZodArray<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                recoveryId: z.ZodString;
                property: z.ZodString;
                status: z.ZodEnum<{
                    closed: "closed";
                    stopped: "stopped";
                    "awaiting-lead": "awaiting-lead";
                    analyzing: "analyzing";
                    applying: "applying";
                    retry: "retry";
                    retrying: "retrying";
                    "awaiting-user": "awaiting-user";
                }>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                workIds: z.ZodArray<z.ZodString>;
                policyDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                state: z.ZodEnum<{
                    active: "active";
                    stalled: "stalled";
                    quiet: "quiet";
                }>;
                previous: z.ZodEnum<{
                    active: "active";
                    stalled: "stalled";
                    quiet: "quiet";
                }>;
                lastMovementAt: z.ZodISODateTime;
                idleMs: z.ZodNumber;
                activity: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        gate: "gate";
                        command: "command";
                        agent: "agent";
                        step: "step";
                    }>;
                    label: z.ZodString;
                }, z.core.$strict>>;
                cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
                action: z.ZodOptional<z.ZodEnum<{
                    report: "report";
                    stop: "stop";
                }>>;
                snapshot: z.ZodOptional<z.ZodObject<{
                    processes: z.ZodArray<z.ZodObject<{
                        pid: z.ZodNumber;
                        parentPid: z.ZodNumber;
                        cpuMs: z.ZodOptional<z.ZodNumber>;
                        command: z.ZodString;
                    }, z.core.$strict>>;
                    processesUnavailable: z.ZodOptional<z.ZodBoolean>;
                    tail: z.ZodString;
                    artifact: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                verificationId: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                }>;
                manifestDigest: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodNumber;
                by: z.ZodString;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    failed: "failed";
                    requested: "requested";
                    cleared: "cleared";
                }>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                receipt: z.ZodOptional<z.ZodString>;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                error: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                currentRevision: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict>;
        }, z.core.$strict>, ...z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            seq: z.ZodNumber;
            at: z.ZodISODateTime;
            graphId: z.ZodOptional<z.ZodString>;
            workId: z.ZodOptional<z.ZodString>;
            runId: z.ZodOptional<z.ZodString>;
            attempt: z.ZodOptional<z.ZodNumber>;
            type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.stage" | "attempt.liveness" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.liveness" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
            payload: z.ZodObject<{
                digest: z.ZodString;
                orders: z.ZodNumber;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
            }, z.core.$strict> | z.ZodObject<{
                kind: z.ZodEnum<{
                    plan: "plan";
                    contract: "contract";
                }>;
                subject: z.ZodString;
                digest: z.ZodString;
                round: z.ZodNumber;
                approved: z.ZodBoolean;
                open: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                actor: z.ZodEnum<{
                    agent: "agent";
                    operator: "operator";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                orderDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
                released: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                policyDigest: z.ZodString;
                engineVersion: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    ready: "ready";
                    failed: "failed";
                    cancelled: "cancelled";
                    draft: "draft";
                    running: "running";
                    verifying: "verifying";
                    reviewing: "reviewing";
                    integrating: "integrating";
                    done: "done";
                }>;
                sha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                recheck: z.ZodOptional<z.ZodObject<{
                    of: z.ZodString;
                    outcome: z.ZodEnum<{
                        flaky: "flaky";
                        confirmed: "confirmed";
                    }>;
                }, z.core.$strict>>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                sameVendor: z.ZodBoolean;
                blocking: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                timingId: z.ZodString;
                stage: z.ZodString;
                phase: z.ZodEnum<{
                    started: "started";
                    finished: "finished";
                }>;
                at: z.ZodISODateTime;
                durationMs: z.ZodOptional<z.ZodNumber>;
                outcome: z.ZodOptional<z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                }>>;
            }, z.core.$strict> | z.ZodObject<{
                state: z.ZodEnum<{
                    active: "active";
                    stalled: "stalled";
                    quiet: "quiet";
                }>;
                previous: z.ZodEnum<{
                    active: "active";
                    stalled: "stalled";
                    quiet: "quiet";
                }>;
                lastMovementAt: z.ZodISODateTime;
                idleMs: z.ZodNumber;
                activity: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        gate: "gate";
                        command: "command";
                        agent: "agent";
                        step: "step";
                    }>;
                    label: z.ZodString;
                }, z.core.$strict>>;
                cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
                action: z.ZodOptional<z.ZodEnum<{
                    report: "report";
                    stop: "stop";
                }>>;
                snapshot: z.ZodOptional<z.ZodObject<{
                    processes: z.ZodArray<z.ZodObject<{
                        pid: z.ZodNumber;
                        parentPid: z.ZodNumber;
                        cpuMs: z.ZodOptional<z.ZodNumber>;
                        command: z.ZodString;
                    }, z.core.$strict>>;
                    processesUnavailable: z.ZodOptional<z.ZodBoolean>;
                    tail: z.ZodString;
                    artifact: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict> | z.ZodObject<{
                failureKind: z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    cancelled: "cancelled";
                    environment: "environment";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    stalled: "stalled";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    unfinished: "unfinished";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                    "needs-lead": "needs-lead";
                }>;
                message: z.ZodString;
                blocked: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                leaseUntil: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                integrationSha: z.ZodString;
                accepted: z.ZodBoolean;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                resultSha: z.ZodString;
                integrationSha: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                code: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
                failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    cancelled: "cancelled";
                    environment: "environment";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    stalled: "stalled";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    unfinished: "unfinished";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                    "needs-lead": "needs-lead";
                }>>>;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                scope: z.ZodEnum<{
                    work: "work";
                    group: "group";
                    total: "total";
                }>;
                scopeId: z.ZodOptional<z.ZodString>;
                state: z.ZodEnum<{
                    exceeded: "exceeded";
                    undetermined: "undetermined";
                }>;
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                suite: z.ZodString;
                pending: z.ZodString;
                version: z.ZodNumber;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    completed: "completed";
                    waiting: "waiting";
                }>;
                accepted: z.ZodArray<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                recoveryId: z.ZodString;
                property: z.ZodString;
                status: z.ZodEnum<{
                    closed: "closed";
                    stopped: "stopped";
                    "awaiting-lead": "awaiting-lead";
                    analyzing: "analyzing";
                    applying: "applying";
                    retry: "retry";
                    retrying: "retrying";
                    "awaiting-user": "awaiting-user";
                }>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                workIds: z.ZodArray<z.ZodString>;
                policyDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                state: z.ZodEnum<{
                    active: "active";
                    stalled: "stalled";
                    quiet: "quiet";
                }>;
                previous: z.ZodEnum<{
                    active: "active";
                    stalled: "stalled";
                    quiet: "quiet";
                }>;
                lastMovementAt: z.ZodISODateTime;
                idleMs: z.ZodNumber;
                activity: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        gate: "gate";
                        command: "command";
                        agent: "agent";
                        step: "step";
                    }>;
                    label: z.ZodString;
                }, z.core.$strict>>;
                cpuUnavailable: z.ZodOptional<z.ZodBoolean>;
                action: z.ZodOptional<z.ZodEnum<{
                    report: "report";
                    stop: "stop";
                }>>;
                snapshot: z.ZodOptional<z.ZodObject<{
                    processes: z.ZodArray<z.ZodObject<{
                        pid: z.ZodNumber;
                        parentPid: z.ZodNumber;
                        cpuMs: z.ZodOptional<z.ZodNumber>;
                        command: z.ZodString;
                    }, z.core.$strict>>;
                    processesUnavailable: z.ZodOptional<z.ZodBoolean>;
                    tail: z.ZodString;
                    artifact: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                verificationId: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                }>;
                manifestDigest: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodNumber;
                by: z.ZodString;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    failed: "failed";
                    requested: "requested";
                    cleared: "cleared";
                }>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                receipt: z.ZodOptional<z.ZodString>;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                error: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                currentRevision: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict>;
        }, z.core.$strict>[], z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            seq: z.ZodNumber;
            at: z.ZodISODateTime;
            graphId: z.ZodOptional<z.ZodString>;
            workId: z.ZodOptional<z.ZodString>;
            runId: z.ZodOptional<z.ZodString>;
            attempt: z.ZodOptional<z.ZodNumber>;
            type: z.ZodLiteral<"unknown">;
            original: z.ZodString;
        }, z.core.$strict>], "type">>;
        next: z.ZodNumber;
    }, z.core.$strict>;
    readonly pause: z.ZodObject<{
        control: z.ZodObject<{
            paused: z.ZodBoolean;
            pauseReason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            pausedAt: z.ZodOptional<z.ZodISODateTime>;
            pauseOperation: z.ZodOptional<z.ZodString>;
            pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>>;
            waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    "base-check": "base-check";
                    "context-lock": "context-lock";
                }>;
                detail: z.ZodString;
                at: z.ZodISODateTime;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            appliedPolicy: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodOptional<z.ZodNumber>;
                at: z.ZodISODateTime;
                by: z.ZodString;
            }, z.core.$strict>>;
            reconfigure: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                requestedAt: z.ZodISODateTime;
                appliedAt: z.ZodOptional<z.ZodISODateTime>;
                appliedBy: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly resume: z.ZodObject<{
        control: z.ZodObject<{
            paused: z.ZodBoolean;
            pauseReason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            pausedAt: z.ZodOptional<z.ZodISODateTime>;
            pauseOperation: z.ZodOptional<z.ZodString>;
            pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>>;
            waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    "base-check": "base-check";
                    "context-lock": "context-lock";
                }>;
                detail: z.ZodString;
                at: z.ZodISODateTime;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            appliedPolicy: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodOptional<z.ZodNumber>;
                at: z.ZodISODateTime;
                by: z.ZodString;
            }, z.core.$strict>>;
            reconfigure: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                requestedAt: z.ZodISODateTime;
                appliedAt: z.ZodOptional<z.ZodISODateTime>;
                appliedBy: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly cancel: z.ZodObject<{
        workId: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly retry: z.ZodObject<{
        workId: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly result: z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        result: z.ZodDiscriminatedUnion<[z.ZodObject<{
            outcome: z.ZodLiteral<"accepted">;
            shas: z.ZodObject<{
                base: z.ZodString;
                candidate: z.ZodString;
                integration: z.ZodString;
                result: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    review: "review";
                    property: "property";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodString;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            outcome: z.ZodEnum<{
                rejected: "rejected";
                blocked: "blocked";
                cancelled: "cancelled";
                stopped: "stopped";
            }>;
            shas: z.ZodObject<{
                base: z.ZodOptional<z.ZodString>;
                candidate: z.ZodOptional<z.ZodString>;
                integration: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            stopReason: z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    review: "review";
                    property: "property";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodString;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>], "outcome">;
        delivery: z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            operation: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly deliver: z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        result: z.ZodDiscriminatedUnion<[z.ZodObject<{
            outcome: z.ZodLiteral<"accepted">;
            shas: z.ZodObject<{
                base: z.ZodString;
                candidate: z.ZodString;
                integration: z.ZodString;
                result: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    review: "review";
                    property: "property";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodString;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            outcome: z.ZodEnum<{
                rejected: "rejected";
                blocked: "blocked";
                cancelled: "cancelled";
                stopped: "stopped";
            }>;
            shas: z.ZodObject<{
                base: z.ZodOptional<z.ZodString>;
                candidate: z.ZodOptional<z.ZodString>;
                integration: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            stopReason: z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    review: "review";
                    property: "property";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodString;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>], "outcome">;
        delivery: z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            operation: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly cleanup: z.ZodDiscriminatedUnion<[z.ZodObject<{
        status: z.ZodLiteral<"nothing-pending">;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodLiteral<"cleaned">;
        receipts: z.ZodArray<z.ZodString>;
    }, z.core.$strict>], "status">;
    readonly 'worktree-cleanup': z.ZodObject<{
        dryRun: z.ZodBoolean;
        removed: z.ZodNumber;
        removable: z.ZodNumber;
        refused: z.ZodNumber;
        failed: z.ZodNumber;
        reclaimedKb: z.ZodNumber;
        worktrees: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            repositoryId: z.ZodString;
            attemptId: z.ZodOptional<z.ZodString>;
            action: z.ZodEnum<{
                refused: "refused";
                failed: "failed";
                removed: "removed";
                remove: "remove";
            }>;
            reason: z.ZodOptional<z.ZodEnum<{
                "scan-limit": "scan-limit";
                active: "active";
                recoverable: "recoverable";
                "cleanup-pending": "cleanup-pending";
                "cleanup-unreadable": "cleanup-unreadable";
                "unknown-attempt": "unknown-attempt";
                untrusted: "untrusted";
                "embedded-repository": "embedded-repository";
                "scan-failed": "scan-failed";
                "read-only-path": "read-only-path";
                "undecodable-path": "undecodable-path";
                "worktree-locked": "worktree-locked";
                "clean-filter": "clean-filter";
                "tree-changed": "tree-changed";
                "ignore-rules-changed": "ignore-rules-changed";
                "hidden-changes": "hidden-changes";
                "staged-ignored": "staged-ignored";
                "staged-differs": "staged-differs";
                "unreachable-head": "unreachable-head";
                "patch-unusable": "patch-unusable";
                "removal-incomplete": "removal-incomplete";
                "not-registered": "not-registered";
            }>>;
            error: z.ZodOptional<z.ZodString>;
            head: z.ZodOptional<z.ZodString>;
            sizeKb: z.ZodOptional<z.ZodNumber>;
            uncommitted: z.ZodOptional<z.ZodNumber>;
            ignored: z.ZodOptional<z.ZodObject<{
                count: z.ZodNumber;
                paths: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
            record: z.ZodOptional<z.ZodString>;
            removalStarted: z.ZodOptional<z.ZodBoolean>;
            registered: z.ZodOptional<z.ZodBoolean>;
            treePresent: z.ZodOptional<z.ZodBoolean>;
            patch: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly profile: z.ZodObject<{
        pin: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            source: z.ZodOptional<z.ZodObject<{
                repositoryId: z.ZodString;
                path: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        profile: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            capabilities: z.ZodArray<z.ZodString>;
            gates: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"test">;
                report: z.ZodObject<{
                    type: z.ZodLiteral<"junit">;
                    path: z.ZodString;
                }, z.core.$strict>;
                artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
                property: z.ZodOptional<z.ZodObject<{
                    path: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
                cwd: z.ZodOptional<z.ZodString>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"check">;
                report: z.ZodOptional<z.ZodObject<{
                    type: z.ZodLiteral<"junit">;
                    path: z.ZodString;
                }, z.core.$strict>>;
                artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
                property: z.ZodOptional<z.ZodObject<{
                    path: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
                cwd: z.ZodOptional<z.ZodString>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>], "kind">>;
            prepare: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
            environment: z.ZodOptional<z.ZodObject<{
                inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
                values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
                secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            }, z.core.$strict>>;
            lifecycle: z.ZodOptional<z.ZodObject<{
                setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>>;
                ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>>;
                teardown: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            toolchain: z.ZodOptional<z.ZodObject<{
                tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
                packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
                    npm: "npm";
                    pnpm: "pnpm";
                }>>>;
            }, z.core.$strict>>;
            protectedPaths: z.ZodArray<z.ZodString>;
            generatedPaths: z.ZodArray<z.ZodString>;
            concurrency: z.ZodOptional<z.ZodNumber>;
            runTimeoutMs: z.ZodOptional<z.ZodNumber>;
            roles: z.ZodRecord<z.ZodString, z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
                writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                title: z.ZodOptional<z.ZodString>;
                requiresContract: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strict>>;
            contextPacks: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                version: z.ZodString;
                repositoryId: z.ZodOptional<z.ZodString>;
                roles: z.ZodDefault<z.ZodArray<z.ZodString>>;
                files: z.ZodArray<z.ZodString>;
                references: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            source: z.ZodOptional<z.ZodObject<{
                repositoryId: z.ZodString;
                path: z.ZodString;
            }, z.core.$strict>>;
            closure: z.ZodArray<z.ZodObject<{
                ref: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    readonly doctor: z.ZodObject<{
        harness: z.ZodString;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        node: z.ZodString;
        platform: z.ZodString;
        runtimes: z.ZodArray<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            available: z.ZodBoolean;
            version: z.ZodOptional<z.ZodString>;
            structuredOutput: z.ZodBoolean;
            cancellation: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        sandbox: z.ZodObject<{
            os: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        state: z.ZodOptional<z.ZodObject<{
            stateVersion: z.ZodNumber;
            compatible: z.ZodBoolean;
            writer: z.ZodOptional<z.ZodString>;
            engineVersions: z.ZodOptional<z.ZodObject<{
                controller: z.ZodOptional<z.ZodString>;
                attempts: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        checkouts: z.ZodOptional<z.ZodObject<{
            placement: z.ZodEnum<{
                configured: "configured";
                "in-place": "in-place";
                cache: "cache";
                "cross-volume": "cross-volume";
            }>;
            root: z.ZodOptional<z.ZodString>;
            note: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        toolchains: z.ZodOptional<z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            root: z.ZodString;
            configSource: z.ZodOptional<z.ZodString>;
            plan: z.ZodArray<z.ZodObject<{
                phase: z.ZodEnum<{
                    gate: "gate";
                    prepare: "prepare";
                    dependencyBuild: "dependencyBuild";
                    preflight: "preflight";
                    setup: "setup";
                    ready: "ready";
                    teardown: "teardown";
                }>;
                id: z.ZodString;
                kind: z.ZodOptional<z.ZodEnum<{
                    check: "check";
                    test: "test";
                }>>;
                cwd: z.ZodString;
                argv: z.ZodArray<z.ZodString>;
                report: z.ZodOptional<z.ZodString>;
                field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            }, z.core.$strict>>;
            tools: z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                provider: z.ZodEnum<{
                    path: "path";
                    project: "project";
                }>;
                found: z.ZodBoolean;
                version: z.ZodOptional<z.ZodString>;
                required: z.ZodArray<z.ZodObject<{
                    version: z.ZodString;
                    source: z.ZodString;
                }, z.core.$strict>>;
                usedBy: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
            lockfiles: z.ZodArray<z.ZodObject<{
                dir: z.ZodString;
                files: z.ZodArray<z.ZodString>;
                manager: z.ZodOptional<z.ZodString>;
                selectedBy: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            reports: z.ZodArray<z.ZodObject<{
                gate: z.ZodString;
                path: z.ZodString;
                cwd: z.ZodString;
            }, z.core.$strict>>;
            ambiguities: z.ZodArray<z.ZodObject<{
                field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                path: z.ZodOptional<z.ZodString>;
                message: z.ZodString;
                resolvedBy: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            problems: z.ZodArray<z.ZodObject<{
                code: z.ZodString;
                field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                path: z.ZodOptional<z.ZodString>;
                message: z.ZodString;
            }, z.core.$strict>>;
            warnings: z.ZodArray<z.ZodObject<{
                code: z.ZodString;
                field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                path: z.ZodOptional<z.ZodString>;
                message: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        problems: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    readonly init: z.ZodObject<{
        mode: z.ZodEnum<{
            plan: "plan";
            apply: "apply";
        }>;
        status: z.ZodEnum<{
            partial: "partial";
            complete: "complete";
            new: "new";
        }>;
        projectId: z.ZodString;
        root: z.ZodString;
        manifestPath: z.ZodString;
        manifest: z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            kind: z.ZodLiteral<"harness-project">;
            manifestVersion: z.ZodLiteral<1>;
            projectId: z.ZodString;
            root: z.ZodString;
            repository: z.ZodObject<{
                id: z.ZodString;
                targetRef: z.ZodString;
            }, z.core.$strict>;
            profile: z.ZodObject<{
                ref: z.ZodString;
                pin: z.ZodObject<{
                    id: z.ZodString;
                    version: z.ZodString;
                    digest: z.ZodString;
                    source: z.ZodOptional<z.ZodObject<{
                        repositoryId: z.ZodString;
                        path: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            runtimes: z.ZodObject<{
                writer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
            }, z.core.$strict>;
            paths: z.ZodObject<{
                policy: z.ZodLiteral<".harness/policy.json">;
                work: z.ZodLiteral<".harness/work">;
                notes: z.ZodLiteral<".harness/work/context/notes">;
                state: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict>;
        files: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            action: z.ZodEnum<{
                conflict: "conflict";
                create: "create";
                preserve: "preserve";
            }>;
            conflict: z.ZodOptional<z.ZodEnum<{
                symlink: "symlink";
                "ancestor-not-directory": "ancestor-not-directory";
                "not-regular-file": "not-regular-file";
                "content-differs": "content-differs";
                "outside-root": "outside-root";
            }>>;
            conflictPath: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        conflicts: z.ZodNumber;
        created: z.ZodArray<z.ZodString>;
        preserved: z.ZodArray<z.ZodString>;
        profile: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            source: z.ZodOptional<z.ZodObject<{
                repositoryId: z.ZodString;
                path: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        shadowed: z.ZodArray<z.ZodString>;
        facts: z.ZodObject<{
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            roles: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            gates: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                }>;
            }, z.core.$strict>>;
            workDir: z.ZodString;
            contextDir: z.ZodString;
            notesDir: z.ZodString;
        }, z.core.$strict>;
        toolchain: z.ZodObject<{
            ready: z.ZodBoolean;
            problems: z.ZodArray<z.ZodString>;
        }, z.core.$strict>;
        next: z.ZodArray<z.ZodObject<{
            command: z.ZodString;
            args: z.ZodArray<z.ZodString>;
            why: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly explain: z.ZodObject<{
        diagnoses: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            cause: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
                "runtime-missing": "runtime-missing";
                "controller-busy": "controller-busy";
                "operator-pause": "operator-pause";
                "approval-required": "approval-required";
                "not-ready": "not-ready";
            }>;
            phase: z.ZodEnum<{
                gates: "gates";
                preflight: "preflight";
                review: "review";
                integration: "integration";
                delivery: "delivery";
                claim: "claim";
                implementation: "implementation";
            }>;
            actor: z.ZodNullable<z.ZodEnum<{
                controller: "controller";
                lead: "lead";
                user: "user";
            }>>;
            action: z.ZodEnum<{
                none: "none";
                wait: "wait";
                retry: "retry";
                "review-plan": "review-plan";
                "diagnose-failure": "diagnose-failure";
                "reset-attempts": "reset-attempts";
                "raise-budget": "raise-budget";
                "replan-dependents": "replan-dependents";
                "recovery-decision": "recovery-decision";
                "user-decision": "user-decision";
                "resume-queue": "resume-queue";
                "fix-environment": "fix-environment";
                "fix-access": "fix-access";
            }>;
            retryPlanned: z.ZodBoolean;
            message: z.ZodString;
            evidence: z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    attempt: "attempt";
                    evidence: "evidence";
                    event: "event";
                    doctor: "doctor";
                }>;
                id: z.ZodString;
                sha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            workId: z.ZodOptional<z.ZodString>;
            runId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly report: z.ZodUnion<readonly [z.ZodObject<{
        reportVersion: z.ZodLiteral<1>;
        harnessVersion: z.ZodString;
        label: z.ZodNullable<z.ZodString>;
        window: z.ZodObject<{
            since: z.ZodNullable<z.ZodISODateTime>;
            until: z.ZodNullable<z.ZodISODateTime>;
            asOf: z.ZodISODateTime;
        }, z.core.$strict>;
        enoughData: z.ZodBoolean;
        coverage: z.ZodObject<{
            works: z.ZodNumber;
            attempts: z.ZodNumber;
            failed: z.ZodNumber;
            withFailureKind: z.ZodNumber;
            withTimings: z.ZodNumber;
            withCalls: z.ZodNumber;
            doneWithoutAttempt: z.ZodNumber;
            withWait: z.ZodNumber;
            withEngineVersion: z.ZodNumber;
            engines: z.ZodArray<z.ZodString>;
            enginesTruncated: z.ZodBoolean;
            calls: z.ZodNumber;
            reviews: z.ZodNumber;
            events: z.ZodNumber;
            eventsFrom: z.ZodNullable<z.ZodISODateTime>;
        }, z.core.$strict>;
        summary: z.ZodDiscriminatedUnion<[z.ZodObject<{
            status: z.ZodLiteral<"ok">;
            headlines: z.ZodArray<z.ZodObject<{
                id: z.ZodEnum<{
                    accepted: "accepted";
                    environment: "environment";
                    "sent-back": "sent-back";
                    "lead-time": "lead-time";
                    spend: "spend";
                }>;
                value: z.ZodString;
                text: z.ZodString;
                basis: z.ZodString;
                measure: z.ZodObject<{
                    value: z.ZodNullable<z.ZodNumber>;
                    n: z.ZodNumber;
                    unknown: z.ZodNumber;
                    bound: z.ZodEnum<{
                        exact: "exact";
                        unknown: "unknown";
                        lower: "lower";
                        upper: "upper";
                    }>;
                }, z.core.$strict>;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            status: z.ZodLiteral<"not-enough-data">;
            text: z.ZodString;
            accepted: z.ZodNumber;
            attempts: z.ZodNumber;
            failedAttempts: z.ZodNumber;
            works: z.ZodNumber;
        }, z.core.$strict>], "status">;
        defects: z.ZodObject<{
            rejected: z.ZodNumber;
            byKind: z.ZodObject<{
                gate: z.ZodNumber;
                review: z.ZodNumber;
                'scope-violation': z.ZodNumber;
            }, z.core.$strict>;
            byPhase: z.ZodObject<{
                candidate: z.ZodNumber;
                integration: z.ZodNumber;
                unknown: z.ZodNumber;
            }, z.core.$strict>;
            sentBack: z.ZodObject<{
                value: z.ZodNullable<z.ZodNumber>;
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                bound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
            }, z.core.$strict>;
            sentBackSetupOnly: z.ZodNumber;
            sentBackRange: z.ZodObject<{
                min: z.ZodNumber;
                max: z.ZodNumber;
            }, z.core.$strict>;
            byGate: z.ZodArray<z.ZodObject<{
                gate: z.ZodString;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                failed: z.ZodNumber;
                setup: z.ZodBoolean;
            }, z.core.$strict>>;
            byGateTruncated: z.ZodBoolean;
            reviews: z.ZodObject<{
                rejected: z.ZodNumber;
                candidate: z.ZodNumber;
                integration: z.ZodNumber;
                blockingFindings: z.ZodNumber;
                withoutFindings: z.ZodNumber;
            }, z.core.$strict>;
            afterGreenGates: z.ZodObject<{
                value: z.ZodNullable<z.ZodNumber>;
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                bound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
            }, z.core.$strict>;
            integration: z.ZodNumber;
            planContract: z.ZodObject<{
                rounds: z.ZodNumber;
                rejected: z.ZodNumber;
                plans: z.ZodObject<{
                    rounds: z.ZodNumber;
                    rejected: z.ZodNumber;
                }, z.core.$strict>;
                contracts: z.ZodObject<{
                    rounds: z.ZodNumber;
                    rejected: z.ZodNumber;
                }, z.core.$strict>;
                blockingClosed: z.ZodNumber;
                blockingOpen: z.ZodNumber;
                blockingWithdrawn: z.ZodNumber;
            }, z.core.$strict>;
            withdrawn: z.ZodObject<{
                value: z.ZodNullable<z.ZodNumber>;
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                bound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
            }, z.core.$strict>;
            items: z.ZodArray<z.ZodObject<{
                workId: z.ZodString;
                runId: z.ZodString;
                attempt: z.ZodNumber;
                kind: z.ZodEnum<{
                    test: "test";
                    review: "review";
                    scope: "scope";
                }>;
                phase: z.ZodNullable<z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>>;
                gate: z.ZodNullable<z.ZodString>;
                at: z.ZodISODateTime;
                sha: z.ZodNullable<z.ZodString>;
                log: z.ZodNullable<z.ZodString>;
                blocking: z.ZodNullable<z.ZodNumber>;
            }, z.core.$strict>>;
            itemsTotal: z.ZodNumber;
            itemsTruncated: z.ZodBoolean;
        }, z.core.$strict>;
        autonomy: z.ZodObject<{
            withAction: z.ZodObject<{
                value: z.ZodNullable<z.ZodNumber>;
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                bound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
            }, z.core.$strict>;
            withoutAction: z.ZodObject<{
                value: z.ZodNullable<z.ZodNumber>;
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                bound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
            }, z.core.$strict>;
            actions: z.ZodObject<{
                operatorDecisions: z.ZodNumber;
                holds: z.ZodNumber;
                cancelledAttempts: z.ZodNumber;
                retries: z.ZodNullable<z.ZodNumber>;
                resets: z.ZodNullable<z.ZodNumber>;
                baseMoves: z.ZodNullable<z.ZodNumber>;
            }, z.core.$strict>;
            approvals: z.ZodObject<{
                operator: z.ZodNumber;
                agent: z.ZodNumber;
                source: z.ZodEnum<{
                    none: "none";
                    state: "state";
                    events: "events";
                    mixed: "mixed";
                }>;
            }, z.core.$strict>;
            pauses: z.ZodArray<z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
                count: z.ZodNumber;
                pausedMs: z.ZodNumber;
                open: z.ZodNumber;
                failures: z.ZodArray<z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    cancelled: "cancelled";
                    environment: "environment";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    stalled: "stalled";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    unfinished: "unfinished";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                    "needs-lead": "needs-lead";
                }>>;
            }, z.core.$strict>>;
            escalations: z.ZodNumber;
        }, z.core.$strict>;
        speed: z.ZodObject<{
            leadTime: z.ZodObject<{
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                median: z.ZodNullable<z.ZodNumber>;
                p75: z.ZodNullable<z.ZodNumber>;
                max: z.ZodNullable<z.ZodNumber>;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            leadTimeFallback: z.ZodNumber;
            dependencyWait: z.ZodObject<{
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                median: z.ZodNullable<z.ZodNumber>;
                p75: z.ZodNullable<z.ZodNumber>;
                max: z.ZodNullable<z.ZodNumber>;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            queueWait: z.ZodObject<{
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                median: z.ZodNullable<z.ZodNumber>;
                p75: z.ZodNullable<z.ZodNumber>;
                max: z.ZodNullable<z.ZodNumber>;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            stages: z.ZodArray<z.ZodObject<{
                family: z.ZodString;
                spans: z.ZodNumber;
                totalMs: z.ZodNumber;
                medianMs: z.ZodNullable<z.ZodNumber>;
                acceptedMs: z.ZodNumber;
                rejectedMs: z.ZodNumber;
                incomplete: z.ZodNumber;
            }, z.core.$strict>>;
            stagesTruncated: z.ZodBoolean;
            firstPass: z.ZodObject<{
                value: z.ZodNullable<z.ZodNumber>;
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                bound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
            }, z.core.$strict>;
            firstPassRaw: z.ZodObject<{
                value: z.ZodNullable<z.ZodNumber>;
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                bound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
            }, z.core.$strict>;
            finished: z.ZodObject<{
                accepted: z.ZodNumber;
                failed: z.ZodNumber;
                cancelled: z.ZodNumber;
            }, z.core.$strict>;
            attemptsPerAccepted: z.ZodObject<{
                n: z.ZodNumber;
                buckets: z.ZodObject<{
                    '1': z.ZodNumber;
                    '2': z.ZodNumber;
                    '3': z.ZodNumber;
                    '4-6': z.ZodNumber;
                    '7+': z.ZodNumber;
                }, z.core.$strict>;
                median: z.ZodNullable<z.ZodNumber>;
                mean: z.ZodNullable<z.ZodNumber>;
            }, z.core.$strict>;
            attemptsOnOther: z.ZodNumber;
            machineTime: z.ZodObject<{
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                median: z.ZodNullable<z.ZodNumber>;
                p75: z.ZodNullable<z.ZodNumber>;
                max: z.ZodNullable<z.ZodNumber>;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        cost: z.ZodObject<{
            calls: z.ZodNumber;
            knownCalls: z.ZodNumber;
            knownUsd: z.ZodNumber;
            reportedUsd: z.ZodNumber;
            estimatedUsd: z.ZodNumber;
            unknown: z.ZodObject<{
                total: z.ZodNumber;
                noPrice: z.ZodNumber;
                incomplete: z.ZodNumber;
                active: z.ZodNumber;
                abandoned: z.ZodNumber;
                byRuntime: z.ZodArray<z.ZodObject<{
                    runtime: z.ZodString;
                    calls: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            attemptsWithoutCalls: z.ZodNumber;
            attemptsPartialCalls: z.ZodNumber;
            perAccepted: z.ZodObject<{
                value: z.ZodNullable<z.ZodNumber>;
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                bound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
            }, z.core.$strict>;
            perAttempt: z.ZodObject<{
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                median: z.ZodNullable<z.ZodNumber>;
                p75: z.ZodNullable<z.ZodNumber>;
                max: z.ZodNullable<z.ZodNumber>;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            rejected: z.ZodObject<{
                bound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
                usd: z.ZodNumber;
                totalUsd: z.ZodNumber;
                attempts: z.ZodNumber;
                byBucket: z.ZodArray<z.ZodObject<{
                    bucket: z.ZodEnum<{
                        unknown: "unknown";
                        integration: "integration";
                        environment: "environment";
                        operator: "operator";
                        budget: "budget";
                        defect: "defect";
                        incomplete: "incomplete";
                        "time-limit": "time-limit";
                        tool: "tool";
                        unclassified: "unclassified";
                    }>;
                    usd: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            byStage: z.ZodArray<z.ZodObject<{
                stage: z.ZodString;
                calls: z.ZodNumber;
                knownUsd: z.ZodNumber;
                unknownCalls: z.ZodNumber;
            }, z.core.$strict>>;
            tokens: z.ZodObject<{
                input: z.ZodNumber;
                output: z.ZodNumber;
                cacheRead: z.ZodNumber;
                cacheWrite: z.ZodNumber;
                incompleteCalls: z.ZodNumber;
            }, z.core.$strict>;
        }, z.core.$strict>;
        environment: z.ZodObject<{
            failed: z.ZodNumber;
            classified: z.ZodNumber;
            interrupted: z.ZodNumber;
            buckets: z.ZodArray<z.ZodObject<{
                bucket: z.ZodEnum<{
                    unknown: "unknown";
                    integration: "integration";
                    environment: "environment";
                    operator: "operator";
                    budget: "budget";
                    defect: "defect";
                    incomplete: "incomplete";
                    "time-limit": "time-limit";
                    tool: "tool";
                    unclassified: "unclassified";
                }>;
                count: z.ZodNumber;
            }, z.core.$strict>>;
            share: z.ZodObject<{
                value: z.ZodNullable<z.ZodNumber>;
                n: z.ZodNumber;
                unknown: z.ZodNumber;
                bound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
            }, z.core.$strict>;
            setupCheckFailures: z.ZodNumber;
            timeLimit: z.ZodNumber;
            causes: z.ZodNull;
            neutral: z.ZodObject<{
                costBound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
                attempts: z.ZodNumber;
                blocked: z.ZodNumber;
                machineMs: z.ZodNumber;
                knownUsd: z.ZodNumber;
                runtimePauses: z.ZodNumber;
            }, z.core.$strict>;
            rechecks: z.ZodObject<{
                flaky: z.ZodNumber;
                confirmed: z.ZodNumber;
            }, z.core.$strict>;
        }, z.core.$strict>;
        weeks: z.ZodObject<{
            rows: z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
                kind: z.ZodLiteral<"week">;
                week: z.ZodString;
                attempts: z.ZodNumber;
                accepted: z.ZodNumber;
                firstPass: z.ZodNumber;
                defects: z.ZodNumber;
                environment: z.ZodNumber;
                knownUsd: z.ZodNumber;
                unknownCalls: z.ZodNumber;
                leadMedianMs: z.ZodNullable<z.ZodNumber>;
                engines: z.ZodArray<z.ZodString>;
                engineChanged: z.ZodBoolean;
                enginesTruncated: z.ZodBoolean;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"gap">;
                from: z.ZodString;
                to: z.ZodString;
            }, z.core.$strict>]>>;
            earlier: z.ZodNullable<z.ZodObject<{
                kind: z.ZodLiteral<"earlier">;
                from: z.ZodString;
                to: z.ZodString;
                weeks: z.ZodNumber;
                attempts: z.ZodNumber;
                accepted: z.ZodNumber;
                firstPass: z.ZodNumber;
                defects: z.ZodNumber;
                environment: z.ZodNumber;
                knownUsd: z.ZodNumber;
                unknownCalls: z.ZodNumber;
            }, z.core.$strict>>;
            active: z.ZodNumber;
        }, z.core.$strict>;
        works: z.ZodObject<{
            rows: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                title: z.ZodOptional<z.ZodString>;
                outcome: z.ZodEnum<{
                    failed: "failed";
                    accepted: "accepted";
                    cancelled: "cancelled";
                }>;
                finishedAt: z.ZodNullable<z.ZodISODateTime>;
                attempts: z.ZodNumber;
                counted: z.ZodNumber;
                leadMs: z.ZodNullable<z.ZodNumber>;
                knownUsd: z.ZodNumber;
                unknownCalls: z.ZodNumber;
                costBound: z.ZodEnum<{
                    exact: "exact";
                    unknown: "unknown";
                    lower: "lower";
                    upper: "upper";
                }>;
                rejections: z.ZodArray<z.ZodObject<{
                    key: z.ZodEnum<{
                        unknown: "unknown";
                        integration: "integration";
                        environment: "environment";
                        operator: "operator";
                        budget: "budget";
                        defect: "defect";
                        incomplete: "incomplete";
                        "time-limit": "time-limit";
                        tool: "tool";
                        unclassified: "unclassified";
                    }>;
                    count: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            total: z.ZodNumber;
            truncated: z.ZodBoolean;
        }, z.core.$strict>;
        limitations: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            text: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        out: z.ZodString;
        format: z.ZodEnum<{
            json: "json";
            md: "md";
            html: "html";
        }>;
        bytes: z.ZodNumber;
        asOf: z.ZodISODateTime;
    }, z.core.$strict>]>;
    readonly handoff: z.ZodObject<{
        handoffVersion: z.ZodLiteral<1>;
        at: z.ZodISODateTime;
        graphId: z.ZodOptional<z.ZodString>;
        limits: z.ZodObject<{
            maxAttempts: z.ZodNumber;
            repairBudget: z.ZodNumber;
        }, z.core.$strict>;
        summary: z.ZodObject<{
            works: z.ZodNumber;
            open: z.ZodNumber;
            done: z.ZodNumber;
            cancelled: z.ZodNumber;
            byStatus: z.ZodArray<z.ZodObject<{
                status: z.ZodEnum<{
                    ready: "ready";
                    failed: "failed";
                    cancelled: "cancelled";
                    draft: "draft";
                    running: "running";
                    verifying: "verifying";
                    reviewing: "reviewing";
                    integrating: "integrating";
                    done: "done";
                }>;
                count: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        queue: z.ZodObject<{
            paused: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            detail: z.ZodOptional<z.ZodString>;
            since: z.ZodOptional<z.ZodISODateTime>;
            operation: z.ZodOptional<z.ZodString>;
            failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>>;
            liftedByRun: z.ZodOptional<z.ZodLiteral<true>>;
            code: z.ZodOptional<z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>>;
            actor: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                controller: "controller";
                lead: "lead";
                user: "user";
            }>>>;
            action: z.ZodOptional<z.ZodEnum<{
                none: "none";
                wait: "wait";
                retry: "retry";
                "review-plan": "review-plan";
                "diagnose-failure": "diagnose-failure";
                "reset-attempts": "reset-attempts";
                "raise-budget": "raise-budget";
                "replan-dependents": "replan-dependents";
                "recovery-decision": "recovery-decision";
                "user-decision": "user-decision";
                "resume-queue": "resume-queue";
                "fix-environment": "fix-environment";
                "fix-access": "fix-access";
            }>>;
        }, z.core.$strict>;
        controller: z.ZodOptional<z.ZodObject<{
            owner: z.ZodString;
            until: z.ZodISODateTime;
            live: z.ZodBoolean;
        }, z.core.$strict>>;
        active: z.ZodArray<z.ZodObject<{
            workId: z.ZodString;
            title: z.ZodString;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            runtime: z.ZodString;
            elapsedMs: z.ZodNumber;
            stage: z.ZodOptional<z.ZodObject<{
                name: z.ZodString;
                elapsedMs: z.ZodNumber;
            }, z.core.$strict>>;
            sinceHeartbeatMs: z.ZodOptional<z.ZodNumber>;
            leaseUntil: z.ZodISODateTime;
            stale: z.ZodBoolean;
            gates: z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                required: z.ZodNumber;
                passed: z.ZodNumber;
                failed: z.ZodNumber;
                remaining: z.ZodNumber;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        unfinished: z.ZodArray<z.ZodObject<{
            runId: z.ZodString;
            workId: z.ZodString;
            attempt: z.ZodNumber;
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            startedAt: z.ZodISODateTime;
            stale: z.ZodBoolean;
            current: z.ZodBoolean;
            interrupted: z.ZodOptional<z.ZodLiteral<"shutdown">>;
        }, z.core.$strict>>;
        works: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            graphId: z.ZodString;
            title: z.ZodString;
            status: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            attempt: z.ZodNumber;
            failureKind: z.ZodOptional<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>;
            failure: z.ZodOptional<z.ZodString>;
            hold: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
            }, z.core.$strict>>;
            recovery: z.ZodOptional<z.ZodObject<{
                status: z.ZodString;
                property: z.ZodString;
                reason: z.ZodOptional<z.ZodString>;
                proposal: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            blockers: z.ZodArray<z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>>;
            blockersTruncated: z.ZodOptional<z.ZodNumber>;
            next: z.ZodObject<{
                actor: z.ZodNullable<z.ZodEnum<{
                    controller: "controller";
                    lead: "lead";
                    user: "user";
                }>>;
                action: z.ZodEnum<{
                    none: "none";
                    wait: "wait";
                    retry: "retry";
                    "review-plan": "review-plan";
                    "diagnose-failure": "diagnose-failure";
                    "reset-attempts": "reset-attempts";
                    "raise-budget": "raise-budget";
                    "replan-dependents": "replan-dependents";
                    "recovery-decision": "recovery-decision";
                    "user-decision": "user-decision";
                    "resume-queue": "resume-queue";
                    "fix-environment": "fix-environment";
                    "fix-access": "fix-access";
                }>;
                step: z.ZodOptional<z.ZodEnum<{
                    accepted: "accepted";
                    cancelled: "cancelled";
                    "recovery-awaiting-lead": "recovery-awaiting-lead";
                    "recovery-analyzing": "recovery-analyzing";
                    "recovery-applying": "recovery-applying";
                    "recovery-retry-allowed": "recovery-retry-allowed";
                    "recovery-retrying": "recovery-retrying";
                    "recovery-awaiting-user": "recovery-awaiting-user";
                    "recovery-stopped": "recovery-stopped";
                    "corpus-adoption": "corpus-adoption";
                    held: "held";
                    "plan-review": "plan-review";
                    "attempt-running": "attempt-running";
                    "retry-within-budget": "retry-within-budget";
                    "attempts-exhausted": "attempts-exhausted";
                    "awaiting-claim": "awaiting-claim";
                }>>;
                property: z.ZodOptional<z.ZodString>;
                detail: z.ZodOptional<z.ZodString>;
                command: z.ZodOptional<z.ZodEnum<{
                    "harness run": "harness run";
                    "harness resume": "harness resume";
                }>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        stops: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            cause: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
                "runtime-missing": "runtime-missing";
                "controller-busy": "controller-busy";
                "operator-pause": "operator-pause";
                "approval-required": "approval-required";
                "not-ready": "not-ready";
            }>;
            phase: z.ZodEnum<{
                gates: "gates";
                preflight: "preflight";
                review: "review";
                integration: "integration";
                delivery: "delivery";
                claim: "claim";
                implementation: "implementation";
            }>;
            actor: z.ZodNullable<z.ZodEnum<{
                controller: "controller";
                lead: "lead";
                user: "user";
            }>>;
            action: z.ZodEnum<{
                none: "none";
                wait: "wait";
                retry: "retry";
                "review-plan": "review-plan";
                "diagnose-failure": "diagnose-failure";
                "reset-attempts": "reset-attempts";
                "raise-budget": "raise-budget";
                "replan-dependents": "replan-dependents";
                "recovery-decision": "recovery-decision";
                "user-decision": "user-decision";
                "resume-queue": "resume-queue";
                "fix-environment": "fix-environment";
                "fix-access": "fix-access";
            }>;
            retryPlanned: z.ZodBoolean;
            message: z.ZodString;
            evidence: z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    attempt: "attempt";
                    evidence: "evidence";
                    event: "event";
                    doctor: "doctor";
                }>;
                id: z.ZodString;
                sha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            workId: z.ZodOptional<z.ZodString>;
            runId: z.ZodOptional<z.ZodString>;
            queue: z.ZodOptional<z.ZodLiteral<true>>;
            works: z.ZodOptional<z.ZodArray<z.ZodString>>;
            worksCount: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        failures: z.ZodArray<z.ZodObject<{
            runId: z.ZodString;
            workId: z.ZodString;
            workStatus: z.ZodOptional<z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>>;
            attempt: z.ZodNumber;
            status: z.ZodEnum<{
                failed: "failed";
                expired: "expired";
            }>;
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            finishedAt: z.ZodOptional<z.ZodISODateTime>;
            failureKind: z.ZodOptional<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                cancelled: "cancelled";
                environment: "environment";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                stalled: "stalled";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>;
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        budgets: z.ZodOptional<z.ZodObject<{
            onUnknown: z.ZodEnum<{
                continue: "continue";
                stop: "stop";
            }>;
            entries: z.ZodArray<z.ZodObject<{
                scope: z.ZodEnum<{
                    work: "work";
                    group: "group";
                    total: "total";
                }>;
                id: z.ZodOptional<z.ZodString>;
                state: z.ZodEnum<{
                    exceeded: "exceeded";
                    undetermined: "undetermined";
                    within: "within";
                }>;
                limitUsd: z.ZodOptional<z.ZodNumber>;
                limitMs: z.ZodOptional<z.ZodNumber>;
                reportedUsd: z.ZodNumber;
                estimatedUsd: z.ZodNumber;
                complete: z.ZodBoolean;
                unknownCalls: z.ZodNumber;
                unfinishedCalls: z.ZodNumber;
                abandonedCalls: z.ZodNumber;
                uncoveredRuns: z.ZodNumber;
                durationMs: z.ZodNumber;
                remainingUsd: z.ZodNullable<z.ZodNumber>;
                remainingMs: z.ZodNullable<z.ZodNumber>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        repairs: z.ZodArray<z.ZodObject<{
            graphId: z.ZodString;
            status: z.ZodString;
            used: z.ZodNumber;
            budget: z.ZodNumber;
        }, z.core.$strict>>;
        next: z.ZodObject<{
            actor: z.ZodNullable<z.ZodEnum<{
                controller: "controller";
                lead: "lead";
                user: "user";
            }>>;
            action: z.ZodEnum<{
                none: "none";
                wait: "wait";
                retry: "retry";
                "review-plan": "review-plan";
                "diagnose-failure": "diagnose-failure";
                "reset-attempts": "reset-attempts";
                "raise-budget": "raise-budget";
                "replan-dependents": "replan-dependents";
                "recovery-decision": "recovery-decision";
                "user-decision": "user-decision";
                "resume-queue": "resume-queue";
                "fix-environment": "fix-environment";
                "fix-access": "fix-access";
            }>;
            step: z.ZodOptional<z.ZodEnum<{
                accepted: "accepted";
                cancelled: "cancelled";
                "recovery-awaiting-lead": "recovery-awaiting-lead";
                "recovery-analyzing": "recovery-analyzing";
                "recovery-applying": "recovery-applying";
                "recovery-retry-allowed": "recovery-retry-allowed";
                "recovery-retrying": "recovery-retrying";
                "recovery-awaiting-user": "recovery-awaiting-user";
                "recovery-stopped": "recovery-stopped";
                "corpus-adoption": "corpus-adoption";
                held: "held";
                "plan-review": "plan-review";
                "attempt-running": "attempt-running";
                "retry-within-budget": "retry-within-budget";
                "attempts-exhausted": "attempts-exhausted";
                "awaiting-claim": "awaiting-claim";
            }>>;
            property: z.ZodOptional<z.ZodString>;
            detail: z.ZodOptional<z.ZodString>;
            command: z.ZodOptional<z.ZodEnum<{
                "harness run": "harness run";
                "harness resume": "harness resume";
            }>>;
            workId: z.ZodOptional<z.ZodString>;
            code: z.ZodOptional<z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>>;
        }, z.core.$strict>;
        intentions: z.ZodArray<z.ZodString>;
        truncated: z.ZodObject<{
            works: z.ZodNumber;
            stops: z.ZodNumber;
            failures: z.ZodNumber;
            unfinished: z.ZodNumber;
            budgets: z.ZodNumber;
            budgetsWithin: z.ZodNumber;
            repairs: z.ZodNumber;
            intentions: z.ZodNumber;
            intentionsDropped: z.ZodNumber;
            bySize: z.ZodBoolean;
        }, z.core.$strict>;
    }, z.core.$strict>;
    readonly 'plan-request': z.ZodObject<{
        prompt: z.ZodString;
        readOnly: z.ZodLiteral<true>;
        recommendedTasks: z.ZodNumber;
        maxTasks: z.ZodLiteral<30>;
        basis: z.ZodString;
        facts: z.ZodObject<{
            repositories: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodOptional<z.ZodString>;
                kind: z.ZodOptional<z.ZodString>;
                path: z.ZodString;
            }, z.core.$strict>>;
            roles: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                roles: z.ZodArray<z.ZodObject<{
                    role: z.ZodString;
                    title: z.ZodOptional<z.ZodString>;
                    writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    requiresContract: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            gates: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodString;
                }, z.core.$strict>>;
                groups: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
            }, z.core.$strict>>;
            contextPacks: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                version: z.ZodOptional<z.ZodString>;
                repositoryId: z.ZodOptional<z.ZodString>;
                roles: z.ZodOptional<z.ZodArray<z.ZodString>>;
                files: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            resources: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodString;
            }, z.core.$strict>>;
            contracts: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                digest: z.ZodString;
            }, z.core.$loose>>;
        }, z.core.$strict>;
        draftSchema: z.ZodLiteral<"plan-draft">;
    }, z.core.$strict>;
    readonly 'plan-check': z.ZodObject<{
        issues: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            message: z.ZodString;
        }, z.core.$strict>>;
        checkPlan: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                "gate-undeclared": "gate-undeclared";
                "test-gate-missing": "test-gate-missing";
            }>;
            taskKey: z.ZodString;
            repositoryId: z.ZodString;
            ref: z.ZodOptional<z.ZodString>;
            testGates: z.ZodArray<z.ZodString>;
            action: z.ZodEnum<{
                "declare-gate": "declare-gate";
                "add-test-gate": "add-test-gate";
            }>;
        }, z.core.$strict>>;
        graph: z.ZodOptional<z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            id: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            orders: z.ZodArray<z.ZodObject<{
                apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
                id: z.ZodString;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
                title: z.ZodString;
                goal: z.ZodString;
                acceptance: z.ZodArray<z.ZodString>;
                role: z.ZodString;
                repositoryId: z.ZodString;
                relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
                writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
                dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
                gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>>;
                properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
                requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    source: z.ZodString;
                    digest: z.ZodString;
                    text: z.ZodString;
                    gate: z.ZodString;
                    scenario: z.ZodString;
                    testId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>>;
                context: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            prerequisites: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                repositoryId: z.ZodString;
                resultSha: z.ZodString;
                receipt: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"engine">;
                    runId: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"trusted">;
                    issuer: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>], "kind">;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
        graphDigest: z.ZodOptional<z.ZodString>;
        basis: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    readonly capabilities: z.ZodObject<{
        name: z.ZodString;
        version: z.ZodString;
        protocolVersion: z.ZodNumber;
        maxInputBytes: z.ZodNumber;
        maxResultBytes: z.ZodNumber;
        tools: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            description: z.ZodString;
            readOnly: z.ZodBoolean;
            inputSchema: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            outputSchema: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'source-check': z.ZodObject<{
        provider: z.ZodEnum<{
            "relay-v1-http": "relay-v1-http";
            "relay-v2-cli": "relay-v2-cli";
        }>;
        projectId: z.ZodString;
        connector: z.ZodString;
        connected: z.ZodBoolean;
        projectMatches: z.ZodBoolean;
        identity: z.ZodOptional<z.ZodObject<{
            capabilities: z.ZodArray<z.ZodString>;
            build: z.ZodRecord<z.ZodString, z.ZodString>;
        }, z.core.$strict>>;
        history: z.ZodObject<{
            enabled: z.ZodBoolean;
            capability: z.ZodBoolean;
        }, z.core.$strict>;
        mapping: z.ZodArray<z.ZodObject<{
            ref: z.ZodString;
            key: z.ZodOptional<z.ZodString>;
            problems: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        ownership: z.ZodObject<{
            stateDir: z.ZodString;
            store: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        problems: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    readonly 'source-snapshot': z.ZodObject<{
        connector: z.ZodString;
        graphId: z.ZodString;
        graphDigest: z.ZodString;
        contextDigest: z.ZodString;
        localContext: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            digest: z.ZodString;
            files: z.ZodNumber;
            references: z.ZodNumber;
            bytes: z.ZodNumber;
        }, z.core.$strict>>>;
        revision: z.ZodString;
        created: z.ZodBoolean;
        eligible: z.ZodBoolean;
        problems: z.ZodArray<z.ZodString>;
        truncated: z.ZodArray<z.ZodString>;
        baseline: z.ZodOptional<z.ZodObject<{
            sha: z.ZodString;
            reason: z.ZodString;
            tasks: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        tasks: z.ZodArray<z.ZodObject<{
            identity: z.ZodString;
            key: z.ZodString;
            orderId: z.ZodString;
            semanticDigest: z.ZodString;
            casRevision: z.ZodNumber;
            column: z.ZodString;
        }, z.core.$strict>>;
        files: z.ZodObject<{
            graph: z.ZodString;
            context: z.ZodString;
            manifest: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>;
    readonly 'source-status': z.ZodObject<{
        connector: z.ZodString;
        provider: z.ZodEnum<{
            "relay-v1-http": "relay-v1-http";
            "relay-v2-cli": "relay-v2-cli";
        }>;
        projectId: z.ZodString;
        snapshot: z.ZodOptional<z.ZodObject<{
            revision: z.ZodString;
            graphId: z.ZodString;
            baseline: z.ZodOptional<z.ZodObject<{
                sha: z.ZodString;
                reason: z.ZodString;
                tasks: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        ownership: z.ZodObject<{
            stateDir: z.ZodString;
            store: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        tasks: z.ZodArray<z.ZodObject<{
            index: z.ZodNumber;
            ref: z.ZodString;
            key: z.ZodOptional<z.ZodString>;
            identity: z.ZodOptional<z.ZodString>;
            workId: z.ZodString;
            local: z.ZodObject<{
                status: z.ZodString;
                attempt: z.ZodOptional<z.ZodNumber>;
                resultSha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            deliveries: z.ZodArray<z.ZodObject<{
                status: z.ZodString;
                key: z.ZodString;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            operations: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                runId: z.ZodString;
                outcome: z.ZodString;
                status: z.ZodEnum<{
                    failed: "failed";
                    delivered: "delivered";
                    conflict: "conflict";
                    uncertain: "uncertain";
                    intent: "intent";
                    "in-progress": "in-progress";
                }>;
                reason: z.ZodOptional<z.ZodString>;
                currentRevision: z.ZodOptional<z.ZodString>;
                steps: z.ZodArray<z.ZodObject<{
                    n: z.ZodNumber;
                    kind: z.ZodString;
                    status: z.ZodString;
                    marker: z.ZodString;
                }, z.core.$strict>>;
                lease: z.ZodOptional<z.ZodObject<{
                    owner: z.ZodString;
                    expiresAt: z.ZodISODateTime;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            remote: z.ZodUnion<readonly [z.ZodObject<{
                reachable: z.ZodLiteral<true>;
                column: z.ZodString;
                casRevision: z.ZodNumber;
                semanticDigest: z.ZodString;
                matchesSnapshot: z.ZodBoolean;
                criteria: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    title: z.ZodString;
                    completed: z.ZodBoolean;
                }, z.core.$strict>>;
                markers: z.ZodRecord<z.ZodString, z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                reachable: z.ZodLiteral<false>;
                error: z.ZodString;
            }, z.core.$strict>]>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'source-deliver': z.ZodObject<{
        connector: z.ZodString;
        deliveries: z.ZodArray<z.ZodObject<{
            workId: z.ZodString;
            outcome: z.ZodString;
            delivery: z.ZodArray<z.ZodObject<{
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                status: z.ZodEnum<{
                    failed: "failed";
                    pending: "pending";
                    delivered: "delivered";
                    conflict: "conflict";
                    uncertain: "uncertain";
                }>;
                attempts: z.ZodNumber;
                lastError: z.ZodOptional<z.ZodString>;
                operation: z.ZodOptional<z.ZodString>;
                currentRevision: z.ZodOptional<z.ZodString>;
                receipt: z.ZodOptional<z.ZodString>;
                updatedAt: z.ZodISODateTime;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'source-reconcile': z.ZodObject<{
        operation: z.ZodString;
        workId: z.ZodString;
        before: z.ZodString;
        after: z.ZodString;
        resolved: z.ZodBoolean;
        facts: z.ZodArray<z.ZodString>;
        delivery: z.ZodOptional<z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            operation: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    readonly version: z.ZodObject<{
        harness: z.ZodString;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    }, z.core.$strict>;
};
export declare const cliErrorSchema: z.ZodObject<{
    code: z.ZodEnum<{
        INVALID_INPUT: "INVALID_INPUT";
        UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
        UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
        GRAPH_CYCLE: "GRAPH_CYCLE";
        GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
        GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
        GATE_UNKNOWN: "GATE_UNKNOWN";
        GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
        REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
        REVIEWER_MISSING: "REVIEWER_MISSING";
        RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
        APPROVAL_STALE: "APPROVAL_STALE";
        APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
        LEASE_STALE: "LEASE_STALE";
        CONTROLLER_BUSY: "CONTROLLER_BUSY";
        PAUSED: "PAUSED";
        NOT_READY: "NOT_READY";
        SCOPE_VIOLATION: "SCOPE_VIOLATION";
        GATE_FAILED: "GATE_FAILED";
        REVIEW_REJECTED: "REVIEW_REJECTED";
        BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
        BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
        ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
        REVISION_CONFLICT: "REVISION_CONFLICT";
        CANCELLED: "CANCELLED";
        NOT_FOUND: "NOT_FOUND";
        PATH_CONFLICT: "PATH_CONFLICT";
        STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
        RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
        REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
        SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
        GIT_FAILED: "GIT_FAILED";
        STORAGE_FAILED: "STORAGE_FAILED";
        DELIVERY_FAILED: "DELIVERY_FAILED";
        INTERNAL: "INTERNAL";
    }>;
    class: z.ZodEnum<{
        input: "input";
        refused: "refused";
        infrastructure: "infrastructure";
    }>;
    message: z.ZodString;
    issues: z.ZodArray<z.ZodObject<{
        path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        message: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
/**
 * Нарушение схемы внутри harness (ответ команды вне договора, собственная
 * запись) — дефект, а не ошибка ввода: INTERNAL с путями полей вместо дампа
 * ZodError в сообщении.
 */
export declare const contractViolation: (error: z.ZodError) => HarnessError;
export type CliEnvelope<C extends CliCommand | 'version' = CliCommand | 'version'> = {
    apiVersion: typeof API_VERSION;
    command: C;
    ok: true;
    data: z.infer<(typeof cliDataSchemas)[C]>;
} | {
    apiVersion: typeof API_VERSION;
    command: C | null;
    ok: false;
    error: z.infer<typeof cliErrorSchema>;
};
/** Входной документ контракта для `review-contract` — см. `checks.ts`. */
export { contractDocumentSchema, type ContractDocument } from './checks.ts';
