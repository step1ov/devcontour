import { z } from 'zod';
import { type Author } from './primitives.ts';
import type { CodedIssue } from './errors.ts';
export declare const environmentSchema: z.ZodObject<{
    inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
    values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
}, z.core.$strict>;
export declare const stepSchema: z.ZodObject<{
    id: z.ZodString;
    command: z.ZodArray<z.ZodString>;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare const lifecycleSchema: z.ZodObject<{
    setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>>;
    ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>>;
    teardown: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/**
 * Gate. У `test` JUnit-отчёт обязателен: exit 0 без свежего непустого
 * отчёта на точном SHA не принимается. `check` — проверка без testcases.
 */
export declare const gateSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"test">;
    report: z.ZodObject<{
        type: z.ZodLiteral<"junit">;
        path: z.ZodString;
    }, z.core.$strict>;
    id: z.ZodString;
    command: z.ZodArray<z.ZodString>;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
    property: z.ZodOptional<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
    cwd: z.ZodOptional<z.ZodString>;
    resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"check">;
    report: z.ZodOptional<z.ZodObject<{
        type: z.ZodLiteral<"junit">;
        path: z.ZodString;
    }, z.core.$strict>>;
    id: z.ZodString;
    command: z.ZodArray<z.ZodString>;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
    property: z.ZodOptional<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
    cwd: z.ZodOptional<z.ZodString>;
    resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>], "kind">;
export type GatePolicy = z.infer<typeof gateSchema>;
/** Группы gates: не больше 100 групп по 100 ссылок, члены — gates или группы (`@имя`). */
export declare const gateGroupsSchema: z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>;
/** Gate совместной проверки: выполняется в дереве `repositoryId`, сохраняет `artifacts`. */
export declare const workspaceGateSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"test">;
    report: z.ZodObject<{
        type: z.ZodLiteral<"junit">;
        path: z.ZodString;
    }, z.core.$strict>;
    repositoryId: z.ZodString;
    artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
    id: z.ZodString;
    command: z.ZodArray<z.ZodString>;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
    property: z.ZodOptional<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
    cwd: z.ZodOptional<z.ZodString>;
    resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"check">;
    report: z.ZodOptional<z.ZodObject<{
        type: z.ZodLiteral<"junit">;
        path: z.ZodString;
    }, z.core.$strict>>;
    repositoryId: z.ZodString;
    artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
    id: z.ZodString;
    command: z.ZodArray<z.ZodString>;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
    property: z.ZodOptional<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
    cwd: z.ZodOptional<z.ZodString>;
    resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>], "kind">;
export declare const runtimeBindingSchema: z.ZodObject<{
    runtime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
        fixture: "fixture";
    }>;
    model: z.ZodOptional<z.ZodString>;
    effort: z.ZodOptional<z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
        xhigh: "xhigh";
    }>>;
    toolProfile: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type RuntimeBinding = z.infer<typeof runtimeBindingSchema>;
/**
 * Правило выбора reviewer для одного вида ревью. Reviewer задан явно: у
 * harness нет неявного «противоположного runtime». `different-vendor`
 * (умолчание) отклоняет reviewer того же вендора, что и writer;
 * `same-vendor-allowed` разрешает его, сохраняя отдельную роль, свежую
 * сессию и прежние условия приёмки.
 */
export declare const reviewRuleSchema: z.ZodObject<{
    reviewer: z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        model: z.ZodOptional<z.ZodString>;
        effort: z.ZodOptional<z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
            xhigh: "xhigh";
        }>>;
        toolProfile: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        model: z.ZodOptional<z.ZodString>;
        effort: z.ZodOptional<z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
            xhigh: "xhigh";
        }>>;
        toolProfile: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    vendor: z.ZodDefault<z.ZodEnum<{
        "different-vendor": "different-vendor";
        "same-vendor-allowed": "same-vendor-allowed";
    }>>;
}, z.core.$strict>;
export type ReviewRule = z.infer<typeof reviewRuleSchema>;
export declare const roleBindingSchema: z.ZodObject<{
    writer: z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        model: z.ZodOptional<z.ZodString>;
        effort: z.ZodOptional<z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
            xhigh: "xhigh";
        }>>;
        toolProfile: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
    review: z.ZodOptional<z.ZodObject<{
        reviewer: z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        vendor: z.ZodDefault<z.ZodEnum<{
            "different-vendor": "different-vendor";
            "same-vendor-allowed": "same-vendor-allowed";
        }>>;
    }, z.core.$strict>>;
    requiresContract: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export declare const repositoryPolicySchema: z.ZodObject<{
    id: z.ZodString;
    roles: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        writer: z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
        review: z.ZodOptional<z.ZodObject<{
            reviewer: z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            vendor: z.ZodDefault<z.ZodEnum<{
                "different-vendor": "different-vendor";
                "same-vendor-allowed": "same-vendor-allowed";
            }>>;
        }, z.core.$strict>>;
        requiresContract: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>>;
    review: z.ZodOptional<z.ZodObject<{
        reviewer: z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        vendor: z.ZodDefault<z.ZodEnum<{
            "different-vendor": "different-vendor";
            "same-vendor-allowed": "same-vendor-allowed";
        }>>;
    }, z.core.$strict>>;
    path: z.ZodString;
    kind: z.ZodDefault<z.ZodEnum<{
        product: "product";
        library: "library";
    }>>;
    targetRef: z.ZodString;
    dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
    gates: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"test">;
        report: z.ZodObject<{
            type: z.ZodLiteral<"junit">;
            path: z.ZodString;
        }, z.core.$strict>;
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
        property: z.ZodOptional<z.ZodObject<{
            path: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
        cwd: z.ZodOptional<z.ZodString>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"check">;
        report: z.ZodOptional<z.ZodObject<{
            type: z.ZodLiteral<"junit">;
            path: z.ZodString;
        }, z.core.$strict>>;
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
        property: z.ZodOptional<z.ZodObject<{
            path: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
        cwd: z.ZodOptional<z.ZodString>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>], "kind">>;
    gateGroups: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    protectedPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
    generatedPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
    environment: z.ZodOptional<z.ZodObject<{
        inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
        values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strict>>;
    lifecycle: z.ZodOptional<z.ZodObject<{
        setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        teardown: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    prepare: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>>;
    dependencyBuild: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>>;
    dependencyArtifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
    preflight: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>>;
    toolchain: z.ZodOptional<z.ZodObject<{
        tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
            npm: "npm";
            pnpm: "pnpm";
        }>>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/**
 * MCP-сервер профиля инструментов: stdio-команда либо http-адрес. Учётные
 * данные — только именами переменных окружения (`env`, `bearerTokenEnv`):
 * значения в политику не входят и в URL не допускаются.
 */
export declare const mcpServerSchema: z.ZodObject<{
    transport: z.ZodEnum<{
        stdio: "stdio";
        http: "http";
    }>;
    command: z.ZodOptional<z.ZodString>;
    args: z.ZodDefault<z.ZodArray<z.ZodString>>;
    env: z.ZodDefault<z.ZodArray<z.ZodString>>;
    url: z.ZodOptional<z.ZodURL>;
    bearerTokenEnv: z.ZodOptional<z.ZodString>;
    tools: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export type McpServer = z.infer<typeof mcpServerSchema>;
export declare const toolProfileSchema: z.ZodObject<{
    runtime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
    }>;
    environment: z.ZodOptional<z.ZodObject<{
        inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
        values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strict>>;
    mcp: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
        transport: z.ZodEnum<{
            stdio: "stdio";
            http: "http";
        }>;
        command: z.ZodOptional<z.ZodString>;
        args: z.ZodDefault<z.ZodArray<z.ZodString>>;
        env: z.ZodDefault<z.ZodArray<z.ZodString>>;
        url: z.ZodOptional<z.ZodURL>;
        bearerTokenEnv: z.ZodOptional<z.ZodString>;
        tools: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>>;
    claudeTools: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        Read: "Read";
        Glob: "Glob";
        Grep: "Grep";
        Edit: "Edit";
        Write: "Write";
        Bash: "Bash";
    }>>>;
    claudeAllowedTools: z.ZodDefault<z.ZodArray<z.ZodString>>;
    codexShell: z.ZodDefault<z.ZodBoolean>;
    codexNetwork: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
/** Тариф модели за миллион токенов, USD. Форма совпадает с сохранёнными тарифами DevContour. */
export declare const priceSchema: z.ZodObject<{
    runtime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
    }>;
    model: z.ZodString;
    effectiveAt: z.ZodISODateTime;
    input: z.ZodNumber;
    output: z.ZodNumber;
    cacheRead: z.ZodNumber;
    cacheWrite: z.ZodNumber;
}, z.core.$strict>;
/**
 * Политика исполнения: кто пишет и проверяет, какими gates, в какой
 * изоляции, с какими пределами. Digest политики закрепляется за попыткой;
 * попытка, выданная под другой политикой, под новой не принимается.
 */
export declare const executionPolicySchema: z.ZodObject<{
    policyVersion: z.ZodLiteral<1>;
    repositories: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        roles: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            writer: z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
            review: z.ZodOptional<z.ZodObject<{
                reviewer: z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                vendor: z.ZodDefault<z.ZodEnum<{
                    "different-vendor": "different-vendor";
                    "same-vendor-allowed": "same-vendor-allowed";
                }>>;
            }, z.core.$strict>>;
            requiresContract: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>>>;
        review: z.ZodOptional<z.ZodObject<{
            reviewer: z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            vendor: z.ZodDefault<z.ZodEnum<{
                "different-vendor": "different-vendor";
                "same-vendor-allowed": "same-vendor-allowed";
            }>>;
        }, z.core.$strict>>;
        path: z.ZodString;
        kind: z.ZodDefault<z.ZodEnum<{
            product: "product";
            library: "library";
        }>>;
        targetRef: z.ZodString;
        dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
        gates: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"test">;
            report: z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>;
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"check">;
            report: z.ZodOptional<z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>>;
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>], "kind">>;
        gateGroups: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
        protectedPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
        generatedPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
        environment: z.ZodOptional<z.ZodObject<{
            inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
            values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        }, z.core.$strict>>;
        lifecycle: z.ZodOptional<z.ZodObject<{
            setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            teardown: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        prepare: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        dependencyBuild: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        dependencyArtifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
        preflight: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        toolchain: z.ZodOptional<z.ZodObject<{
            tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
                npm: "npm";
                pnpm: "pnpm";
            }>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    roles: z.ZodRecord<z.ZodString, z.ZodObject<{
        writer: z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
        review: z.ZodOptional<z.ZodObject<{
            reviewer: z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            vendor: z.ZodDefault<z.ZodEnum<{
                "different-vendor": "different-vendor";
                "same-vendor-allowed": "same-vendor-allowed";
            }>>;
        }, z.core.$strict>>;
        requiresContract: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    review: z.ZodObject<{
        code: z.ZodObject<{
            reviewer: z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            vendor: z.ZodDefault<z.ZodEnum<{
                "different-vendor": "different-vendor";
                "same-vendor-allowed": "same-vendor-allowed";
            }>>;
        }, z.core.$strict>;
        plan: z.ZodObject<{
            reviewer: z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            vendor: z.ZodDefault<z.ZodEnum<{
                "different-vendor": "different-vendor";
                "same-vendor-allowed": "same-vendor-allowed";
            }>>;
        }, z.core.$strict>;
        contract: z.ZodObject<{
            reviewer: z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            vendor: z.ZodDefault<z.ZodEnum<{
                "different-vendor": "different-vendor";
                "same-vendor-allowed": "same-vendor-allowed";
            }>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    mode: z.ZodDefault<z.ZodEnum<{
        fixture: "fixture";
        live: "live";
    }>>;
    workspaceGates: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"test">;
        report: z.ZodObject<{
            type: z.ZodLiteral<"junit">;
            path: z.ZodString;
        }, z.core.$strict>;
        repositoryId: z.ZodString;
        artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
        property: z.ZodOptional<z.ZodObject<{
            path: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
        cwd: z.ZodOptional<z.ZodString>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"check">;
        report: z.ZodOptional<z.ZodObject<{
            type: z.ZodLiteral<"junit">;
            path: z.ZodString;
        }, z.core.$strict>>;
        repositoryId: z.ZodString;
        artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
        property: z.ZodOptional<z.ZodObject<{
            path: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
        cwd: z.ZodOptional<z.ZodString>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>], "kind">>>;
    workspaceLifecycle: z.ZodOptional<z.ZodObject<{
        setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        teardown: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    verificationMode: z.ZodDefault<z.ZodEnum<{
        all: "all";
        affected: "affected";
    }>>;
    approvalMode: z.ZodDefault<z.ZodEnum<{
        agent: "agent";
        operator: "operator";
    }>>;
    isolation: z.ZodDefault<z.ZodObject<{
        mode: z.ZodDefault<z.ZodEnum<{
            os: "os";
            none: "none";
        }>>;
        domains: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    toolProfiles: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
        environment: z.ZodOptional<z.ZodObject<{
            inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
            values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        }, z.core.$strict>>;
        mcp: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
            transport: z.ZodEnum<{
                stdio: "stdio";
                http: "http";
            }>;
            command: z.ZodOptional<z.ZodString>;
            args: z.ZodDefault<z.ZodArray<z.ZodString>>;
            env: z.ZodDefault<z.ZodArray<z.ZodString>>;
            url: z.ZodOptional<z.ZodURL>;
            bearerTokenEnv: z.ZodOptional<z.ZodString>;
            tools: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>>;
        claudeTools: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            Read: "Read";
            Glob: "Glob";
            Grep: "Grep";
            Edit: "Edit";
            Write: "Write";
            Bash: "Bash";
        }>>>;
        claudeAllowedTools: z.ZodDefault<z.ZodArray<z.ZodString>>;
        codexShell: z.ZodDefault<z.ZodBoolean>;
        codexNetwork: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>>;
    environment: z.ZodOptional<z.ZodObject<{
        inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
        values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strict>>;
    lifecycle: z.ZodOptional<z.ZodObject<{
        setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        teardown: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    resources: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            device: "device";
            port: "port";
            account: "account";
            service: "service";
        }>;
        value: z.ZodString;
    }, z.core.$strict>>>;
    concurrency: z.ZodDefault<z.ZodNumber>;
    leaseMs: z.ZodDefault<z.ZodNumber>;
    runTimeoutMs: z.ZodDefault<z.ZodNumber>;
    reviewProbes: z.ZodDefault<z.ZodObject<{
        commandTimeoutMs: z.ZodDefault<z.ZodNumber>;
        budgetMs: z.ZodDefault<z.ZodNumber>;
        reserveMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
    reviewProtocolRetries: z.ZodOptional<z.ZodNumber>;
    maxAttempts: z.ZodDefault<z.ZodNumber>;
    repairBudget: z.ZodDefault<z.ZodNumber>;
    reuseImplementation: z.ZodDefault<z.ZodBoolean>;
    budgets: z.ZodOptional<z.ZodObject<{
        work: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
            usd: z.ZodNumber;
            timeMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            usd: z.ZodOptional<z.ZodNumber>;
            timeMs: z.ZodNumber;
        }, z.core.$strict>]>>;
        group: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
            usd: z.ZodNumber;
            timeMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            usd: z.ZodOptional<z.ZodNumber>;
            timeMs: z.ZodNumber;
        }, z.core.$strict>]>>;
        total: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
            usd: z.ZodNumber;
            timeMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            usd: z.ZodOptional<z.ZodNumber>;
            timeMs: z.ZodNumber;
        }, z.core.$strict>]>>;
        onUnknown: z.ZodDefault<z.ZodEnum<{
            continue: "continue";
            stop: "stop";
        }>>;
    }, z.core.$strict>>;
    prices: z.ZodDefault<z.ZodArray<z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
        model: z.ZodString;
        effectiveAt: z.ZodISODateTime;
        input: z.ZodNumber;
        output: z.ZodNumber;
        cacheRead: z.ZodNumber;
        cacheWrite: z.ZodNumber;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type ExecutionPolicy = z.infer<typeof executionPolicySchema>;
export type ExecutionPolicyInput = z.input<typeof executionPolicySchema>;
export declare const policyDigest: (policy: ExecutionPolicy) => string;
/**
 * Digest исполнительной части политики — основание согласования графа и
 * fencing попыток. Пределы бюджетов и тарифы в него не входят: это учёт, а не
 * условия исполнения, и поднятый предел действует сразу, без нового
 * согласования (как в DevContour). `policyDigest` — digest загруженной
 * политики целиком: им сверяются применение политики (`appliedPolicy`) и
 * запрос операции reconfigure.
 */
export declare const executionDigest: (policy: ExecutionPolicy) => string;
export type ReviewKind = 'code' | 'plan' | 'contract';
type RoleBinding = z.infer<typeof roleBindingSchema>;
/**
 * Привязка роли для поручения репозитория: роль, переопределённая
 * репозиторием, целиком заменяет роль политики. Единственная точка поиска
 * роли: правила записи, writer и ревью не расходятся между собой.
 */
export declare function roleBinding(policy: Pick<ExecutionPolicy, 'roles' | 'repositories'>, role: string, repositoryId?: string): RoleBinding | undefined;
/** Правило ревью кода роли: своё у роли, иначе репозитория, иначе политики. */
export declare function codeReview(policy: Pick<ExecutionPolicy, 'roles' | 'review' | 'repositories'>, role: string, repositoryId?: string): ReviewRule;
/**
 * Единственная точка выбора reviewer. Возвращает назначение или отказ с
 * кодом; другого пути назначить reviewer у движка нет.
 */
export declare function selectReviewer(policy: Pick<ExecutionPolicy, 'roles' | 'review' | 'repositories'>, kind: ReviewKind, writer: {
    runtime: Author;
}, role?: string, repositoryId?: string): {
    ok: true;
    reviewer: RuntimeBinding;
    sameVendor: boolean;
} | {
    ok: false;
    code: 'REVIEWER_SAME_VENDOR' | 'REVIEWER_MISSING';
    message: string;
};
type Issue = CodedIssue;
/** Gates в порядке зависимостей; повтор, неизвестная зависимость и цикл — нарушения. */
export declare function gateOrderIssues(gates: {
    id: string;
    dependsOn?: string[];
}[]): Omit<CodedIssue, 'path'>[];
/**
 * Согласованность политики, которую не выразить схемой, — проверки
 * DevContour `validateWorkflow` и загрузки конфигурации, перенесённые без
 * ослабления: компоненты без циклов, gates упорядочиваемы, у репозитория
 * есть test gate, зарезервированный gate не объявлен, шаги уникальны,
 * ресурсы известны и корректны, профили инструментов совместимы с runtime,
 * `effort` только для codex, `fixture` только в режиме `fixture`, пары
 * writer/reviewer допустимы правилом вендора.
 */
export declare function policyIssues(policy: ExecutionPolicy): Issue[];
/**
 * Раскрыть область в явный список gates репозитория: ID gates и группы
 * (`@имя`), рекурсивно, без циклов, в порядке первого появления; каждый gate
 * один раз. Неизвестный член, неизвестная группа и цикл — отказ с кодом.
 * Без области — все gates репозитория. Раскрытая группа повторно не
 * обходится: общий подграф иначе стоил бы экспоненциально.
 */
export declare function expandGateRefs(repo: Pick<z.infer<typeof repositoryPolicySchema>, 'gates' | 'gateGroups' | 'id'>, refs?: string[]): string[];
/** Имена переменных, которые MCP-серверы профиля получают по имени от CLI. */
export declare const mcpEnvironment: (profile?: {
    mcp: Record<string, McpServer>;
}) => {
    inherit: string[];
    values: {};
    secrets: {};
};
export {};
