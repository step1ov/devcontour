/**
 * Git на хосте над деревом, в котором исполнялся чужой код.
 *
 * Исполнитель и проверки пишут в checkout. Git, запущенный потом на хосте,
 * читает конфигурацию того репозитория, который найдёт от рабочего каталога,
 * а она способна запускать программы (`core.fsmonitor`, hooks, драйверы
 * фильтров и diff). Подменённый файл `.git` (`gitdir: <checkout>/evil`),
 * `.git/commondir` в обычном checkout или вложенный `.git` уводили git в
 * конфигурацию, которую написал чужой код, — и она исполнялась вне песочницы.
 *
 * Поэтому каждый вызов git хоста сначала сверяет, куда git придёт: файл
 * `.git` рабочего дерева, созданного через `worktree add`, должен остаться
 * тем же; gitdir и общий каталог репозитория лежат вне дерева и согласованы
 * между собой; общий каталог — уже известный хосту репозиторий, если он
 * известен; вложенный репозиторий внутри известного дерева и перенаправление
 * обычного `.git` — отказ. Флаги `gitHardening` поверх этого снимают
 * исполняемые настройки, которые git читает сам.
 */
export declare const gitHardening: string[];
export declare class UntrustedCheckoutError extends Error {
    name: string;
}
/**
 * Сверяет репозиторий, который git найдёт от `cwd`. Возвращает его общий
 * каталог или `undefined`, если репозитория нет (git откажет сам).
 */
export declare function assertTrustedCheckout(cwd: string): string | undefined;
/** Рабочее дерево создано хостом: дальше его `.git` обязан остаться прежним. */
export declare function rememberWorktree(path: string): void;
/** Ключ дерева — настоящий путь (/var → /private/var). */
export declare const worktreeKey: (path: string) => string;
export declare function forgetWorktree(key: string): void;
/** Путь, который `git worktree add` получит как каталог дерева. */
export declare function worktreeAddPath(args: string[]): string | undefined;
/** Только для тестов: забыть, что известно процессу. */
export declare function resetGitTrust(): void;
