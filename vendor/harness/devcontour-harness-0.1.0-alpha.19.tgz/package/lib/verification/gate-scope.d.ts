import { type GatePolicy } from '../contracts/index.ts';
type Gate = Pick<GatePolicy, 'id' | 'kind' | 'dependsOn'>;
/**
 * Порядок исполнения области gates — один для попытки (candidate и
 * integration) и для проверки на SHA вне попытки (`runGatesAt`): ids в
 * порядке области, каждая предпосылка `dependsOn`, входящая в область, —
 * раньше своего gate. Неизвестный id (псевдо-gate требований) пропускается.
 */
export declare function orderedScope<T extends Pick<GatePolicy, 'id' | 'dependsOn'>>(gates: T[], ids: string[]): T[];
/** Явные предпосылки gate: замыкание по `dependsOn`, ids в порядке профиля. */
export declare function explicitPrerequisites(gates: Gate[], id: string): string[];
/**
 * Предпосылки gate при исполнении вне области задачи (проверка доски на её
 * итоговом SHA). Область задачи предпосылки называет явно, и попытка
 * исполняет ровно её. Проверке на SHA области нет, поэтому предпосылки
 * выводятся из профиля:
 *
 * - явные — замыкание по `dependsOn` (`explicitPrerequisites`); объявленный
 *   `dependsOn`, в том числе пустой, — режим графа: других предпосылок нет;
 * - неявные — у gate без поля `dependsOn` (режим порядка массива, где профиль
 *   сам задаёт последовательность) все более ранние gates вида `check`
 *   (установка, сборка, статические проверки) со своими предпосылками. Более
 *   ранние test gates не добавляются: тесты друг от друга не зависят.
 *
 * Каждый gate посещается один раз, поэтому `dependsOn` на более поздний
 * gate вместе с неявным ребром к более ранним не зацикливается. Сам gate в
 * результат не входит. Результат — ids в порядке профиля.
 */
export declare function gatePrerequisites(gates: Gate[], id: string): string[];
/**
 * Область проверки gates вне задачи: названные gates и предпосылки каждого
 * (`gatePrerequisites`), в порядке профиля. Исполняется `orderedScope`, как
 * область задачи.
 */
export declare function standaloneScope(gates: Gate[], ids: string[]): string[];
export {};
