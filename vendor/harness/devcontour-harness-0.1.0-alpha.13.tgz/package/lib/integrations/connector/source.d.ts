import { type Prerequisite, type WorkGraph, type SourceRef, type WorkSource } from '../../contracts/index.ts';
import { type ConnectorConfig } from './config.ts';
import { type BuiltSnapshot } from './snapshot.ts';
import type { ConnectorStore } from './store.ts';
import { type RelayTransport } from './transport.ts';
/**
 * Источник поручений из внешнего хранилища задач.
 *
 * - `fetch` — согласованный снимок набора задач конфигурации (eligibility и
 *   пределы проверяются до возврата графа);
 * - `revision` — текущий semantic digest задачи (или набора) для обнаружения
 *   конфликта; ошибка сети/CLI — исключение, а не «записи нет»;
 * - `trusts` — только receipt, выданный этим коннектором (`issuer` = его ID),
 *   digest которого совпадает с записью в его состоянии. Статус задачи done
 *   доверием не является.
 */
export declare class RelayWorkSource implements WorkSource {
    readonly options: {
        config: ConnectorConfig;
        transport: RelayTransport;
        store: ConnectorStore;
        /** Абсолютный каталог пакетов `tasks[].context`. */
        contextDir?: string;
    };
    readonly id: string;
    constructor(options: {
        config: ConnectorConfig;
        transport: RelayTransport;
        store: ConnectorStore;
        /** Абсолютный каталог пакетов `tasks[].context`. */
        contextDir?: string;
    });
    /** Снимок без проверки eligibility (для предпросмотра и диагностики). */
    snapshot(signal?: AbortSignal): Promise<BuiltSnapshot>;
    fetch(ref: string): Promise<{
        graph: WorkGraph;
        source: SourceRef;
    }>;
    revision(ref: string): Promise<string | undefined>;
    trusts(prerequisite: Prerequisite): Promise<boolean>;
}
