import { type ExecutionPolicy, type RuntimeAdapter, type RuntimeName } from '../contracts/index.ts';
/**
 * Проверка среды без live-вызова модели: версия пакета и Node, наличие
 * runtime (по `--version`) и их возможности, OS-sandbox, совместимость
 * каталога состояния. Каталог состояния открывается только если он есть.
 */
export declare function doctor(policy: ExecutionPolicy | undefined, adapters: Partial<Record<RuntimeName, RuntimeAdapter>>, stateDir?: string): Promise<{
    problems: string[];
    state?: {
        stateVersion: number;
        compatible: boolean;
        writer?: string;
    } | undefined;
    harness: string;
    apiVersion: "devcontour-harness/v1alpha1";
    node: string;
    platform: string;
    runtimes: {
        structuredOutput: boolean;
        cancellation: boolean;
        version?: string | undefined;
        runtime: "codex" | "claude";
        available: boolean;
    }[];
    sandbox: {
        reason?: string | undefined;
        os: boolean;
    };
}>;
