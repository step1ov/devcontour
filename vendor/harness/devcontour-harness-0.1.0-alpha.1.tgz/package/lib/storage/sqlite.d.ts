import { type ExecutionStore, type ExecutionTransaction, type ExecutionView, type NotPromise, type RunEvent, type TransactionKind } from '../contracts/index.ts';
/**
 * Standalone ExecutionStore: нейтральный документ, события и локальные
 * записи в одной SQLite. Транзакция — `BEGIN IMMEDIATE` (вложенная —
 * SAVEPOINT); документ читается один раз на внешнюю транзакцию, вложенные
 * работают с ним же и при отказе восстанавливают его снимок и свой буфер
 * событий. Документ проверяется схемой при каждой фиксации: состояние вне
 * договора не записывается.
 *
 * Версия: в `meta` записаны версия формата и версия писателя. Неизвестная
 * версия формата отклоняется при открытии, до любой записи.
 */
export declare class SqliteExecutionStore implements ExecutionStore {
    readonly file: string;
    readonly writer: string;
    readonly stateVersion: 1;
    private db;
    private frame?;
    private savepoint;
    constructor(file: string, writer: string);
    private load;
    read<T>(fn: (view: ExecutionView) => NotPromise<T>): T;
    transact<T>(kind: TransactionKind, fn: (tx: ExecutionTransaction) => NotPromise<T>): T;
    private writeEvents;
    events(after?: number, limit?: number): RunEvent[];
    close(): void;
    private view;
}
