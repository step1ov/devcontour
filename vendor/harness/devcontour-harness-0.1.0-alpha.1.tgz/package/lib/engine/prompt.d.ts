import type { AttemptState, ContextSnapshot, WorkState } from '../contracts/index.ts';
/** Предыдущие попытки поручения с находками ревью: исполнитель адресует каждую открытую. */
export declare function previousAttempts(attempts: AttemptState[], current: string): {
    attempt: number;
    error: string | undefined;
    evidence: {
        gate: string;
        phase: "candidate" | "integration";
        passed: boolean;
        summary: string;
        findings: {
            severity: string;
            message: string;
            path?: string | null | undefined;
            line?: number | null | undefined;
        }[] | undefined;
    }[];
}[];
/** Закреплённый контекст: вложенные файлы — содержимым, справки — названием. */
export declare function contextText(snapshot: ContextSnapshot | undefined): string;
/** Запрос исполнителю или reviewer: исходные критерии, область, прежние находки, контекст. */
export declare function prompt(input: {
    work: WorkState;
    attempt: AttemptState;
    history: AttemptState[];
    context?: ContextSnapshot;
    gates: {
        id: string;
        command: string[];
    }[];
    review?: {
        sha: string;
        phase: string;
        diff: string;
    };
    /** Обязательный корпус и решение разбора, под которым выдан повтор. */
    notes?: string[];
}): string;
