/**
 * Коды отказов harness. Код — договор: по нему потребитель решает, что
 * делать, а текст сообщения может меняться. Каждый код относится к одному
 * классу, и класс определяет exit code CLI.
 */
export declare const errorClasses: {
    /** Вход не прошёл проверку: исправить вход и повторить. */
    readonly input: 2;
    /** Работа отклонена или заблокирована правилами: отказ по существу. */
    readonly refused: 3;
    /** Окружение или инфраструктура не дали выполнить операцию. */
    readonly infrastructure: 4;
};
export type ErrorClass = keyof typeof errorClasses;
export declare const errorCodes: {
    readonly INVALID_INPUT: "input";
    readonly UNSUPPORTED_COMMAND: "input";
    readonly UNSUPPORTED_VERSION: "input";
    readonly GRAPH_CYCLE: "input";
    readonly GRAPH_UNKNOWN_DEPENDENCY: "input";
    readonly GRAPH_DUPLICATE_ID: "input";
    readonly GATE_UNKNOWN: "input";
    readonly GATE_GROUP_CYCLE: "input";
    readonly REVIEWER_SAME_VENDOR: "input";
    readonly REVIEWER_MISSING: "input";
    readonly APPROVAL_STALE: "refused";
    readonly APPROVAL_REQUIRED: "refused";
    readonly LEASE_STALE: "refused";
    readonly CONTROLLER_BUSY: "refused";
    readonly PAUSED: "refused";
    readonly NOT_READY: "refused";
    readonly SCOPE_VIOLATION: "refused";
    readonly GATE_FAILED: "refused";
    readonly REVIEW_REJECTED: "refused";
    readonly BUDGET_EXHAUSTED: "refused";
    readonly BUDGET_UNKNOWN: "refused";
    readonly ATTEMPTS_EXHAUSTED: "refused";
    readonly REVISION_CONFLICT: "refused";
    readonly CANCELLED: "refused";
    readonly NOT_FOUND: "refused";
    readonly STATE_VERSION_UNSUPPORTED: "infrastructure";
    readonly RUNTIME_UNAVAILABLE: "infrastructure";
    readonly SANDBOX_UNAVAILABLE: "infrastructure";
    readonly GIT_FAILED: "infrastructure";
    readonly STORAGE_FAILED: "infrastructure";
    readonly DELIVERY_FAILED: "infrastructure";
    readonly INTERNAL: "infrastructure";
};
export type ErrorCode = keyof typeof errorCodes;
export interface ErrorIssue {
    path: (string | number)[];
    message: string;
}
export declare class HarnessError extends Error {
    readonly code: ErrorCode;
    readonly issues: ErrorIssue[];
    readonly class: ErrorClass;
    constructor(code: ErrorCode, message: string, issues?: ErrorIssue[]);
    toJSON(): {
        code: "INVALID_INPUT" | "UNSUPPORTED_COMMAND" | "UNSUPPORTED_VERSION" | "GRAPH_CYCLE" | "GRAPH_UNKNOWN_DEPENDENCY" | "GRAPH_DUPLICATE_ID" | "GATE_UNKNOWN" | "GATE_GROUP_CYCLE" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "LEASE_STALE" | "CONTROLLER_BUSY" | "PAUSED" | "NOT_READY" | "SCOPE_VIOLATION" | "GATE_FAILED" | "REVIEW_REJECTED" | "BUDGET_EXHAUSTED" | "BUDGET_UNKNOWN" | "ATTEMPTS_EXHAUSTED" | "REVISION_CONFLICT" | "CANCELLED" | "NOT_FOUND" | "STATE_VERSION_UNSUPPORTED" | "RUNTIME_UNAVAILABLE" | "SANDBOX_UNAVAILABLE" | "GIT_FAILED" | "STORAGE_FAILED" | "DELIVERY_FAILED" | "INTERNAL";
        class: "input" | "refused" | "infrastructure";
        message: string;
        issues: ErrorIssue[];
    };
}
/**
 * Exit codes CLI. 0 — успех; 1 не используется намеренно: им завершается
 * Node при необработанном исключении, и его нельзя спутать с отказом.
 */
export declare const exitCodes: {
    /** Вход не прошёл проверку: исправить вход и повторить. */
    readonly input: 2;
    /** Работа отклонена или заблокирована правилами: отказ по существу. */
    readonly refused: 3;
    /** Окружение или инфраструктура не дали выполнить операцию. */
    readonly infrastructure: 4;
    readonly ok: 0;
};
export declare const exitCodeOf: (error: unknown) => 3 | 4 | 2;
