import { z } from 'zod';
/**
 * Ответы исполнителей. Runtime возвращает сырой текст/JSON (`RuntimeResponse.output`
 * — вход парсера); движок разбирает его этими схемами. Ответ вне схемы —
 * отказ ревью или реализации, а не самооценка writer.
 */
/** Находка, которую исполнитель предлагает завести отдельной работой (bug/debt). */
export declare const discoverySchema: z.ZodObject<{
    kind: z.ZodEnum<{
        bug: "bug";
        debt: "debt";
    }>;
    title: z.ZodString;
    path: z.ZodString;
    line: z.ZodNumber;
    observation: z.ZodString;
    consequence: z.ZodString;
    reproduction: z.ZodString;
}, z.core.$strict>;
export declare const implementationResultSchema: z.ZodObject<{
    completed: z.ZodBoolean;
    summary: z.ZodString;
    discoveries: z.ZodDefault<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            bug: "bug";
            debt: "debt";
        }>;
        title: z.ZodString;
        path: z.ZodString;
        line: z.ZodNumber;
        observation: z.ZodString;
        consequence: z.ZodString;
        reproduction: z.ZodString;
    }, z.core.$strict>>>;
}, z.core.$strip>;
export type ImplementationResult = z.infer<typeof implementationResultSchema>;
export declare const reproductionSchema: z.ZodObject<{
    property: z.ZodNullable<z.ZodString>;
    input: z.ZodString;
    expected: z.ZodNullable<z.ZodString>;
    actual: z.ZodNullable<z.ZodString>;
    command: z.ZodNullable<z.ZodArray<z.ZodString>>;
    executed: z.ZodBoolean;
    run: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
export declare const reviewExecutionSchema: z.ZodObject<{
    commands: z.ZodArray<z.ZodObject<{
        command: z.ZodString;
        exitCode: z.ZodNumber;
        summary: z.ZodString;
    }, z.core.$strict>>;
    noCommandsReason: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
/** Состояние прежней находки в новом раунде ревью. */
export declare const findingTransitionSchema: z.ZodObject<{
    id: z.ZodString;
    status: z.ZodEnum<{
        open: "open";
        closed: "closed";
        withdrawn: "withdrawn";
    }>;
    basis: z.ZodString;
}, z.core.$strict>;
/**
 * Ответ reviewer. Принятие (`approved: true`) при любой блокирующей находке
 * — отказ; `previous` обязан назвать состояние каждой прежней открытой
 * находки этого предмета (см. `reviewIssues`).
 */
export declare const reviewResultSchema: z.ZodObject<{
    execution: z.ZodOptional<z.ZodObject<{
        commands: z.ZodArray<z.ZodObject<{
            command: z.ZodString;
            exitCode: z.ZodNumber;
            summary: z.ZodString;
        }, z.core.$strict>>;
        noCommandsReason: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    approved: z.ZodBoolean;
    summary: z.ZodString;
    discoveries: z.ZodDefault<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            bug: "bug";
            debt: "debt";
        }>;
        title: z.ZodString;
        path: z.ZodString;
        line: z.ZodNumber;
        observation: z.ZodString;
        consequence: z.ZodString;
        reproduction: z.ZodString;
    }, z.core.$strict>>>;
    findings: z.ZodArray<z.ZodObject<{
        severity: z.ZodEnum<{
            blocking: "blocking";
            note: "note";
        }>;
        message: z.ZodString;
        path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        rule: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        consequence: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        evidence: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        reproduction: z.ZodCatch<z.ZodOptional<z.ZodNullable<z.ZodObject<{
            property: z.ZodNullable<z.ZodString>;
            input: z.ZodString;
            expected: z.ZodNullable<z.ZodString>;
            actual: z.ZodNullable<z.ZodString>;
            command: z.ZodNullable<z.ZodArray<z.ZodString>>;
            executed: z.ZodBoolean;
            run: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>>>>;
    }, z.core.$strip>>;
    previous: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        status: z.ZodEnum<{
            open: "open";
            closed: "closed";
            withdrawn: "withdrawn";
        }>;
        basis: z.ZodString;
    }, z.core.$strict>>>;
}, z.core.$strip>;
export type ReviewResult = z.infer<typeof reviewResultSchema>;
/** Идентичность находки: предмет, класс и текст. Новый текст — новая находка. */
export declare const findingId: (subject: string, finding: {
    rule?: string | null;
    message: string;
}) => string;
export declare const reviewFindingSchema: z.ZodObject<{
    id: z.ZodString;
    severity: z.ZodEnum<{
        blocking: "blocking";
        note: "note";
    }>;
    message: z.ZodString;
    rule: z.ZodOptional<z.ZodString>;
    path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    status: z.ZodEnum<{
        open: "open";
        closed: "closed";
        withdrawn: "withdrawn";
    }>;
    openedIn: z.ZodNumber;
    changedIn: z.ZodNumber;
    basis: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
/**
 * Раунд технического ревью плана (графа) или контракта. Раунды предмета
 * нумеруются подряд и не переписываются; переименование предмета не
 * начинает историю заново — предмет задаётся ID, а не заголовком.
 */
export declare const reviewRecordSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        plan: "plan";
        contract: "contract";
    }>;
    subject: z.ZodString;
    digest: z.ZodString;
    round: z.ZodNumber;
    at: z.ZodISODateTime;
    approved: z.ZodBoolean;
    summary: z.ZodString;
    authorRuntime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
        fixture: "fixture";
        external: "external";
    }>;
    reviewerRuntime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
        fixture: "fixture";
    }>;
    reviewerModel: z.ZodOptional<z.ZodString>;
    sameVendor: z.ZodBoolean;
    reviewerBinding: z.ZodOptional<z.ZodString>;
    contextDigest: z.ZodOptional<z.ZodString>;
    findings: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        severity: z.ZodEnum<{
            blocking: "blocking";
            note: "note";
        }>;
        message: z.ZodString;
        rule: z.ZodOptional<z.ZodString>;
        path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        status: z.ZodEnum<{
            open: "open";
            closed: "closed";
            withdrawn: "withdrawn";
        }>;
        openedIn: z.ZodNumber;
        changedIn: z.ZodNumber;
        basis: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    artifact: z.ZodString;
}, z.core.$strict>;
export type ReviewRecord = z.infer<typeof reviewRecordSchema>;
/**
 * Согласованность ответа reviewer с историей предмета: approved без
 * блокирующих находок и без открытых блокирующих прежних, у каждой прежней
 * открытой находки названо состояние, ссылки только на известные находки.
 */
export declare function reviewIssues(result: ReviewResult, previousOpen: {
    id: string;
    severity: 'blocking' | 'note';
}[]): string[];
