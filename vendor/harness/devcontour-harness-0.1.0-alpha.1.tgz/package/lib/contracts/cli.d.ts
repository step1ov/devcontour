import { z } from 'zod';
import { API_VERSION } from './version.ts';
import { type ErrorCode } from './errors.ts';
/**
 * Договор CLI `harness`.
 *
 * - Каждая команда получает явные пути; бинарник не хранит настроек проекта
 *   и не помнит «последний активный проект».
 * - `--state <каталог>` — каталог состояния исполнения (SQLite, артефакты
 *   попыток). Создаётся только командами, которые пишут (`run`,
 *   `review-*`, `approve`); читающие команды на отсутствующем каталоге
 *   отвечают `NOT_FOUND` и ничего не создают.
 * - stdout — ровно один JSON `CliEnvelope`; диагностика — stderr.
 * - Exit: 0 — успех; 2 — неверный вход; 3 — отказ или блокировка по
 *   правилам; 4 — инфраструктура. Exit 1 не используется.
 *
 * Библиотека и CLI вызывают одни и те же доменные операции; у CLI нет
 * операции «передать PASS» или «принять без проверок».
 */
export interface CliArgument {
    name: string;
    value: 'path' | 'dir' | 'id' | 'digest' | 'number' | 'text' | 'flag' | 'sink';
    required: boolean;
    description: string;
}
export interface CliCommandContract {
    description: string;
    /** Пишет ли команда состояние. `false` — гарантированно без побочных эффектов. */
    writes: boolean;
    /** Что делает повтор той же команды с теми же аргументами. */
    idempotency: string;
    args: CliArgument[];
    /** Отказы по существу (exit 3), которые команда обязана различать кодом. */
    refusals: ErrorCode[];
}
export declare const cliCommands: {
    readonly validate: {
        readonly description: "Проверить граф, политику, их связь и (если задан) снимок контекста без вызова моделей и записи состояния";
        readonly writes: false;
        readonly idempotency: "Чистая функция входов";
        readonly args: [CliArgument, CliArgument, CliArgument];
        readonly refusals: [];
    };
    readonly 'review-plan': {
        readonly description: "Техническое ревью плана (графа) с конкретным digest; новый раунд сохраняет историю находок предмета";
        readonly writes: true;
        readonly idempotency: "Повтор с тем же digest и тем же автором, уже согласованный последним раундом, возвращает этот раунд без вызова модели; иначе — новый раунд в пределах maxAttempts. Автор, не допускаемый правилом вендора, — REVIEWER_SAME_VENDOR до вызова модели";
        readonly args: [CliArgument, CliArgument, CliArgument, CliArgument, CliArgument];
        readonly refusals: ["REVIEW_REJECTED", "ATTEMPTS_EXHAUSTED", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN"];
    };
    readonly 'review-contract': {
        readonly description: "Техническое ревью контракта с конкретным digest";
        readonly writes: true;
        readonly idempotency: "Как review-plan, предмет — ID контракта";
        readonly args: [CliArgument, {
            readonly name: "--contract";
            readonly value: "path";
            readonly required: true;
            readonly description: "ContractDocument JSON";
        }, CliArgument, CliArgument];
        readonly refusals: ["REVIEW_REJECTED", "ATTEMPTS_EXHAUSTED", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN"];
    };
    readonly approve: {
        readonly description: "Согласование оператором (approvalMode: operator) конкретного digest графа или контракта, уже прошедшего ревью";
        readonly writes: true;
        readonly idempotency: "Повтор для того же digest ничего не меняет";
        readonly args: [CliArgument, {
            readonly name: "--digest";
            readonly value: "digest";
            readonly required: true;
            readonly description: "Digest из ReviewRecord последнего раунда";
        }, {
            readonly name: "--subject";
            readonly value: "id";
            readonly required: true;
            readonly description: "ID графа или контракта";
        }];
        readonly refusals: ["APPROVAL_STALE", "APPROVAL_REQUIRED", "REVIEW_REJECTED"];
    };
    readonly run: {
        readonly description: "Зарегистрировать согласованный граф (идемпотентно по connector, ref, revision, digest) и вести работу до простоя";
        readonly writes: true;
        readonly idempotency: "Тот же граф той же редакции продолжает прежнюю работу; другой digest для той же редакции источника — REVISION_CONFLICT";
        readonly args: [CliArgument, CliArgument, CliArgument, CliArgument, {
            readonly name: "--sink";
            readonly value: "sink";
            readonly required: false;
            readonly description: "Получатель результата, `file:<каталог>`";
        }, {
            readonly name: "--once";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Один шаг очереди вместо работы до простоя";
        }, {
            readonly name: "--author";
            readonly value: "id";
            readonly required: false;
            readonly description: "Автор графа для ревью плана; по умолчанию external";
        }];
        readonly refusals: ["APPROVAL_REQUIRED", "APPROVAL_STALE", "PAUSED", "CONTROLLER_BUSY", "REVISION_CONFLICT", "GATE_FAILED", "REVIEW_REJECTED", "SCOPE_VIOLATION", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN", "ATTEMPTS_EXHAUSTED"];
    };
    readonly status: {
        readonly description: "Состояние очереди, графов и поручений с причинами блокировки";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, {
            readonly name: "--graph";
            readonly value: "id";
            readonly required: false;
            readonly description: "Только этот граф";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly events: {
        readonly description: "События строго после номера, по возрастанию";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, {
            readonly name: "--after";
            readonly value: "number";
            readonly required: false;
            readonly description: "Номер, по умолчанию 0";
        }, {
            readonly name: "--limit";
            readonly value: "number";
            readonly required: false;
            readonly description: "1–500, по умолчанию 100";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly pause: {
        readonly description: "Пауза оператора: новые claims запрещены, активные попытки продолжаются";
        readonly writes: true;
        readonly idempotency: "Повтор ничего не меняет";
        readonly args: [CliArgument];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly resume: {
        readonly description: "Снять паузу — решение человека: паузу оператора, штатной остановки и отказа runtime (с её классами отказов); паузу операции reconfigure не снимает";
        readonly writes: true;
        readonly idempotency: "Повтор без паузы ничего не меняет";
        readonly args: [CliArgument];
        readonly refusals: ["NOT_FOUND", "PAUSED"];
    };
    readonly cancel: {
        readonly description: "Отменить поручение: активная попытка теряет владение, поручение становится cancelled; это не retry";
        readonly writes: true;
        readonly idempotency: "Повтор для отменённого ничего не меняет";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--reason";
            readonly value: "text";
            readonly required: false;
            readonly description: "Причина";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly retry: {
        readonly description: "Новая попытка неуспешного (failed) поручения в пределах maxAttempts и бюджета; --reset сбрасывает счётчик попыток с причиной, учёт расходов не сбрасывается";
        readonly writes: true;
        readonly idempotency: "Повтор для уже готового к выдаче поручения ничего не меняет";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--reset";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Сбросить счётчик попыток; требует --reason";
        }, {
            readonly name: "--reason";
            readonly value: "text";
            readonly required: false;
            readonly description: "Причина сброса";
        }];
        readonly refusals: ["NOT_FOUND", "ATTEMPTS_EXHAUSTED", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN"];
    };
    readonly result: {
        readonly description: "Машинный результат последней завершённой попытки поручения и состояние доставки";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, CliArgument];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly deliver: {
        readonly description: "Повторить доставку результата получателю с тем же ключом; модели, gates и интеграция не вызываются";
        readonly writes: true;
        readonly idempotency: "Доставленный результат повторно не доставляется";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--sink";
            readonly value: "sink";
            readonly required: true;
            readonly description: "Получатель, `file:<каталог>`";
        }];
        readonly refusals: ["NOT_FOUND", "REVISION_CONFLICT"];
    };
    readonly profile: {
        readonly description: "Разрешить профиль стека (встроенный ID или ./file.json репозитория): слои, gates, закрепление; только чтение манифестов, без команд проекта";
        readonly writes: false;
        readonly idempotency: "Чистая функция файлов профиля";
        readonly args: [{
            readonly name: "--profile";
            readonly value: "text";
            readonly required: true;
            readonly description: "Встроенный ID профиля или относительный ./file.json";
        }, {
            readonly name: "--repository";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Корень репозитория для локального профиля";
        }];
        readonly refusals: [];
    };
    readonly doctor: {
        readonly description: "Версии, наличие runtime и их capabilities, OS-sandbox, совместимость каталога состояния; без live-вызова модели";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [{
            readonly required: false;
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly description: string;
        }, {
            readonly required: false;
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly description: string;
        }];
        readonly refusals: [];
    };
};
export type CliCommand = keyof typeof cliCommands;
export declare const validateDataSchema: z.ZodObject<{
    graphId: z.ZodString;
    graphDigest: z.ZodString;
    policyDigest: z.ZodString;
    contextDigest: z.ZodOptional<z.ZodString>;
    orders: z.ZodNumber;
}, z.core.$strict>;
export declare const statusDataSchema: z.ZodObject<{
    stateVersion: z.ZodLiteral<1>;
    control: z.ZodObject<{
        paused: z.ZodBoolean;
        pauseReason: z.ZodOptional<z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>>;
        pausedAt: z.ZodOptional<z.ZodISODateTime>;
        pauseOperation: z.ZodOptional<z.ZodString>;
        pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            environment: "environment";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            merge: "merge";
            budget: "budget";
        }>>>;
        waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                "base-check": "base-check";
                "context-lock": "context-lock";
            }>;
            detail: z.ZodString;
            at: z.ZodISODateTime;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        appliedPolicy: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodOptional<z.ZodNumber>;
            at: z.ZodISODateTime;
            by: z.ZodString;
        }, z.core.$strict>>;
        reconfigure: z.ZodOptional<z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            requestedAt: z.ZodISODateTime;
            appliedAt: z.ZodOptional<z.ZodISODateTime>;
            appliedBy: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    controller: z.ZodOptional<z.ZodObject<{
        owner: z.ZodString;
        leaseUntil: z.ZodNumber;
    }, z.core.$strict>>;
    graphs: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        digest: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        approved: z.ZodBoolean;
    }, z.core.$strict>>;
    works: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        graphId: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        activeRunId: z.ZodOptional<z.ZodString>;
        resultSha: z.ZodOptional<z.ZodString>;
        blockers: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            message: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    budgets: z.ZodOptional<z.ZodObject<{
        onUnknown: z.ZodEnum<{
            stop: "stop";
            continue: "continue";
        }>;
        budgets: z.ZodArray<z.ZodObject<{
            scope: z.ZodObject<{
                kind: z.ZodEnum<{
                    work: "work";
                    group: "group";
                    total: "total";
                }>;
                id: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
                within: "within";
            }>;
            limit: z.ZodObject<{
                usd: z.ZodOptional<z.ZodNumber>;
                timeMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            reportedUsd: z.ZodNumber;
            estimatedUsd: z.ZodNumber;
            unknownCalls: z.ZodNumber;
            unfinishedCalls: z.ZodNumber;
            abandonedCalls: z.ZodNumber;
            errorCalls: z.ZodNumber;
            uncoveredRuns: z.ZodNumber;
            durationMs: z.ZodNumber;
            remainingUsd: z.ZodNullable<z.ZodNumber>;
            remainingMs: z.ZodNullable<z.ZodNumber>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const eventsDataSchema: z.ZodObject<{
    events: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        seq: z.ZodNumber;
        at: z.ZodISODateTime;
        graphId: z.ZodOptional<z.ZodString>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        attempt: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict">;
        payload: z.ZodObject<{
            digest: z.ZodString;
            orders: z.ZodNumber;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodEnum<{
                plan: "plan";
                contract: "contract";
            }>;
            subject: z.ZodString;
            digest: z.ZodString;
            round: z.ZodNumber;
            approved: z.ZodBoolean;
            open: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            actor: z.ZodEnum<{
                agent: "agent";
                operator: "operator";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            orderDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            released: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            policyDigest: z.ZodString;
            engineVersion: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            sameVendor: z.ZodBoolean;
            blocking: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            failureKind: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                merge: "merge";
                budget: "budget";
            }>;
            message: z.ZodString;
            blocked: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            leaseUntil: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            integrationSha: z.ZodString;
            accepted: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            resultSha: z.ZodString;
            integrationSha: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
            failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                merge: "merge";
                budget: "budget";
            }>>>;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            scope: z.ZodEnum<{
                work: "work";
                group: "group";
                total: "total";
            }>;
            scopeId: z.ZodOptional<z.ZodString>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
            }>;
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            suite: z.ZodString;
            pending: z.ZodString;
            version: z.ZodNumber;
            digest: z.ZodString;
            status: z.ZodEnum<{
                completed: "completed";
                waiting: "waiting";
            }>;
            accepted: z.ZodArray<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            recoveryId: z.ZodString;
            property: z.ZodString;
            status: z.ZodEnum<{
                stopped: "stopped";
                closed: "closed";
                "awaiting-lead": "awaiting-lead";
                analyzing: "analyzing";
                applying: "applying";
                retry: "retry";
                retrying: "retrying";
                "awaiting-user": "awaiting-user";
            }>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            policyDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>;
            manifestDigest: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodNumber;
            by: z.ZodString;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                requested: "requested";
                cleared: "cleared";
            }>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            receipt: z.ZodOptional<z.ZodString>;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            error: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            currentRevision: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>, ...z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        seq: z.ZodNumber;
        at: z.ZodISODateTime;
        graphId: z.ZodOptional<z.ZodString>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        attempt: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict">;
        payload: z.ZodObject<{
            digest: z.ZodString;
            orders: z.ZodNumber;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodEnum<{
                plan: "plan";
                contract: "contract";
            }>;
            subject: z.ZodString;
            digest: z.ZodString;
            round: z.ZodNumber;
            approved: z.ZodBoolean;
            open: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            actor: z.ZodEnum<{
                agent: "agent";
                operator: "operator";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            orderDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            released: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            policyDigest: z.ZodString;
            engineVersion: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            sameVendor: z.ZodBoolean;
            blocking: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            failureKind: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                merge: "merge";
                budget: "budget";
            }>;
            message: z.ZodString;
            blocked: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            leaseUntil: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            integrationSha: z.ZodString;
            accepted: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            resultSha: z.ZodString;
            integrationSha: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
            failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                merge: "merge";
                budget: "budget";
            }>>>;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            scope: z.ZodEnum<{
                work: "work";
                group: "group";
                total: "total";
            }>;
            scopeId: z.ZodOptional<z.ZodString>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
            }>;
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            suite: z.ZodString;
            pending: z.ZodString;
            version: z.ZodNumber;
            digest: z.ZodString;
            status: z.ZodEnum<{
                completed: "completed";
                waiting: "waiting";
            }>;
            accepted: z.ZodArray<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            recoveryId: z.ZodString;
            property: z.ZodString;
            status: z.ZodEnum<{
                stopped: "stopped";
                closed: "closed";
                "awaiting-lead": "awaiting-lead";
                analyzing: "analyzing";
                applying: "applying";
                retry: "retry";
                retrying: "retrying";
                "awaiting-user": "awaiting-user";
            }>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            policyDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>;
            manifestDigest: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodNumber;
            by: z.ZodString;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                requested: "requested";
                cleared: "cleared";
            }>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            receipt: z.ZodOptional<z.ZodString>;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            error: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            currentRevision: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>[]], "type">>;
    next: z.ZodNumber;
}, z.core.$strict>;
export declare const runDataSchema: z.ZodObject<{
    graphId: z.ZodString;
    digest: z.ZodString;
    resumed: z.ZodBoolean;
    works: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        runId: z.ZodOptional<z.ZodString>;
        resultSha: z.ZodOptional<z.ZodString>;
        blockers: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            message: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    workflow: z.ZodOptional<z.ZodObject<{
        key: z.ZodString;
        kind: z.ZodString;
        id: z.ZodString;
        stage: z.ZodNumber;
        status: z.ZodEnum<{
            failed: "failed";
            completed: "completed";
            running: "running";
            queued: "queued";
            stale: "stale";
        }>;
        attempts: z.ZodNumber;
        repairs: z.ZodNumber;
        repairBudget: z.ZodNumber;
        error: z.ZodOptional<z.ZodString>;
        history: z.ZodArray<z.ZodObject<{
            at: z.ZodISODateTime;
            stage: z.ZodNumber;
            event: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const controlDataSchema: z.ZodObject<{
    control: z.ZodObject<{
        paused: z.ZodBoolean;
        pauseReason: z.ZodOptional<z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>>;
        pausedAt: z.ZodOptional<z.ZodISODateTime>;
        pauseOperation: z.ZodOptional<z.ZodString>;
        pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            environment: "environment";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            merge: "merge";
            budget: "budget";
        }>>>;
        waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                "base-check": "base-check";
                "context-lock": "context-lock";
            }>;
            detail: z.ZodString;
            at: z.ZodISODateTime;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        appliedPolicy: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodOptional<z.ZodNumber>;
            at: z.ZodISODateTime;
            by: z.ZodString;
        }, z.core.$strict>>;
        reconfigure: z.ZodOptional<z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            requestedAt: z.ZodISODateTime;
            appliedAt: z.ZodOptional<z.ZodISODateTime>;
            appliedBy: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    changed: z.ZodBoolean;
}, z.core.$strict>;
export declare const workActionDataSchema: z.ZodObject<{
    workId: z.ZodString;
    status: z.ZodEnum<{
        ready: "ready";
        failed: "failed";
        cancelled: "cancelled";
        draft: "draft";
        running: "running";
        verifying: "verifying";
        reviewing: "reviewing";
        integrating: "integrating";
        done: "done";
    }>;
    attempt: z.ZodNumber;
    changed: z.ZodBoolean;
}, z.core.$strict>;
export declare const approveDataSchema: z.ZodObject<{
    subject: z.ZodString;
    digest: z.ZodString;
    at: z.ZodISODateTime;
    changed: z.ZodBoolean;
}, z.core.$strict>;
export declare const doctorDataSchema: z.ZodObject<{
    harness: z.ZodString;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    node: z.ZodString;
    platform: z.ZodString;
    runtimes: z.ZodArray<z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        available: z.ZodBoolean;
        version: z.ZodOptional<z.ZodString>;
        structuredOutput: z.ZodBoolean;
        cancellation: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    sandbox: z.ZodObject<{
        os: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    state: z.ZodOptional<z.ZodObject<{
        stateVersion: z.ZodNumber;
        compatible: z.ZodBoolean;
        writer: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    problems: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const profileDataSchema: z.ZodObject<{
    pin: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        source: z.ZodOptional<z.ZodObject<{
            repositoryId: z.ZodString;
            path: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    profile: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        capabilities: z.ZodArray<z.ZodString>;
        gates: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"test">;
            report: z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>;
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"check">;
            report: z.ZodOptional<z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>>;
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>], "kind">>;
        prepare: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
        environment: z.ZodOptional<z.ZodObject<{
            inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
            values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        }, z.core.$strict>>;
        lifecycle: z.ZodOptional<z.ZodObject<{
            setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            teardown: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        protectedPaths: z.ZodArray<z.ZodString>;
        generatedPaths: z.ZodArray<z.ZodString>;
        concurrency: z.ZodOptional<z.ZodNumber>;
        runTimeoutMs: z.ZodOptional<z.ZodNumber>;
        roles: z.ZodRecord<z.ZodString, z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
            writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
            reviewer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            title: z.ZodOptional<z.ZodString>;
            requiresContract: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        contextPacks: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            repositoryId: z.ZodOptional<z.ZodString>;
            roles: z.ZodDefault<z.ZodArray<z.ZodString>>;
            files: z.ZodArray<z.ZodString>;
            references: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        source: z.ZodOptional<z.ZodObject<{
            repositoryId: z.ZodString;
            path: z.ZodString;
        }, z.core.$strict>>;
        closure: z.ZodArray<z.ZodObject<{
            ref: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const versionDataSchema: z.ZodObject<{
    harness: z.ZodString;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
}, z.core.$strict>;
/** Схема `data` каждой команды. */
export declare const cliDataSchemas: {
    readonly validate: z.ZodObject<{
        graphId: z.ZodString;
        graphDigest: z.ZodString;
        policyDigest: z.ZodString;
        contextDigest: z.ZodOptional<z.ZodString>;
        orders: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'review-plan': z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        at: z.ZodISODateTime;
        approved: z.ZodBoolean;
        summary: z.ZodString;
        authorRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
            external: "external";
        }>;
        reviewerRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewerModel: z.ZodOptional<z.ZodString>;
        sameVendor: z.ZodBoolean;
        reviewerBinding: z.ZodOptional<z.ZodString>;
        contextDigest: z.ZodOptional<z.ZodString>;
        findings: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            severity: z.ZodEnum<{
                blocking: "blocking";
                note: "note";
            }>;
            message: z.ZodString;
            rule: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            status: z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>;
            openedIn: z.ZodNumber;
            changedIn: z.ZodNumber;
            basis: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        artifact: z.ZodString;
    }, z.core.$strict>;
    readonly 'review-contract': z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        at: z.ZodISODateTime;
        approved: z.ZodBoolean;
        summary: z.ZodString;
        authorRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
            external: "external";
        }>;
        reviewerRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewerModel: z.ZodOptional<z.ZodString>;
        sameVendor: z.ZodBoolean;
        reviewerBinding: z.ZodOptional<z.ZodString>;
        contextDigest: z.ZodOptional<z.ZodString>;
        findings: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            severity: z.ZodEnum<{
                blocking: "blocking";
                note: "note";
            }>;
            message: z.ZodString;
            rule: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            status: z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>;
            openedIn: z.ZodNumber;
            changedIn: z.ZodNumber;
            basis: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        artifact: z.ZodString;
    }, z.core.$strict>;
    readonly approve: z.ZodObject<{
        subject: z.ZodString;
        digest: z.ZodString;
        at: z.ZodISODateTime;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly run: z.ZodObject<{
        graphId: z.ZodString;
        digest: z.ZodString;
        resumed: z.ZodBoolean;
        works: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            status: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            runId: z.ZodOptional<z.ZodString>;
            resultSha: z.ZodOptional<z.ZodString>;
            blockers: z.ZodArray<z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workflow: z.ZodOptional<z.ZodObject<{
            key: z.ZodString;
            kind: z.ZodString;
            id: z.ZodString;
            stage: z.ZodNumber;
            status: z.ZodEnum<{
                failed: "failed";
                completed: "completed";
                running: "running";
                queued: "queued";
                stale: "stale";
            }>;
            attempts: z.ZodNumber;
            repairs: z.ZodNumber;
            repairBudget: z.ZodNumber;
            error: z.ZodOptional<z.ZodString>;
            history: z.ZodArray<z.ZodObject<{
                at: z.ZodISODateTime;
                stage: z.ZodNumber;
                event: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly status: z.ZodObject<{
        stateVersion: z.ZodLiteral<1>;
        control: z.ZodObject<{
            paused: z.ZodBoolean;
            pauseReason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            pausedAt: z.ZodOptional<z.ZodISODateTime>;
            pauseOperation: z.ZodOptional<z.ZodString>;
            pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                merge: "merge";
                budget: "budget";
            }>>>;
            waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    "base-check": "base-check";
                    "context-lock": "context-lock";
                }>;
                detail: z.ZodString;
                at: z.ZodISODateTime;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            appliedPolicy: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodOptional<z.ZodNumber>;
                at: z.ZodISODateTime;
                by: z.ZodString;
            }, z.core.$strict>>;
            reconfigure: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                requestedAt: z.ZodISODateTime;
                appliedAt: z.ZodOptional<z.ZodISODateTime>;
                appliedBy: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        controller: z.ZodOptional<z.ZodObject<{
            owner: z.ZodString;
            leaseUntil: z.ZodNumber;
        }, z.core.$strict>>;
        graphs: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            digest: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            approved: z.ZodBoolean;
        }, z.core.$strict>>;
        works: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            graphId: z.ZodString;
            status: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            attempt: z.ZodNumber;
            activeRunId: z.ZodOptional<z.ZodString>;
            resultSha: z.ZodOptional<z.ZodString>;
            blockers: z.ZodArray<z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        budgets: z.ZodOptional<z.ZodObject<{
            onUnknown: z.ZodEnum<{
                stop: "stop";
                continue: "continue";
            }>;
            budgets: z.ZodArray<z.ZodObject<{
                scope: z.ZodObject<{
                    kind: z.ZodEnum<{
                        work: "work";
                        group: "group";
                        total: "total";
                    }>;
                    id: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                state: z.ZodEnum<{
                    exceeded: "exceeded";
                    undetermined: "undetermined";
                    within: "within";
                }>;
                limit: z.ZodObject<{
                    usd: z.ZodOptional<z.ZodNumber>;
                    timeMs: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>;
                reportedUsd: z.ZodNumber;
                estimatedUsd: z.ZodNumber;
                unknownCalls: z.ZodNumber;
                unfinishedCalls: z.ZodNumber;
                abandonedCalls: z.ZodNumber;
                errorCalls: z.ZodNumber;
                uncoveredRuns: z.ZodNumber;
                durationMs: z.ZodNumber;
                remainingUsd: z.ZodNullable<z.ZodNumber>;
                remainingMs: z.ZodNullable<z.ZodNumber>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly events: z.ZodObject<{
        events: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            seq: z.ZodNumber;
            at: z.ZodISODateTime;
            graphId: z.ZodOptional<z.ZodString>;
            workId: z.ZodOptional<z.ZodString>;
            runId: z.ZodOptional<z.ZodString>;
            attempt: z.ZodOptional<z.ZodNumber>;
            type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict">;
            payload: z.ZodObject<{
                digest: z.ZodString;
                orders: z.ZodNumber;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
            }, z.core.$strict> | z.ZodObject<{
                kind: z.ZodEnum<{
                    plan: "plan";
                    contract: "contract";
                }>;
                subject: z.ZodString;
                digest: z.ZodString;
                round: z.ZodNumber;
                approved: z.ZodBoolean;
                open: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                actor: z.ZodEnum<{
                    agent: "agent";
                    operator: "operator";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                orderDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
                released: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                policyDigest: z.ZodString;
                engineVersion: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    ready: "ready";
                    failed: "failed";
                    cancelled: "cancelled";
                    draft: "draft";
                    running: "running";
                    verifying: "verifying";
                    reviewing: "reviewing";
                    integrating: "integrating";
                    done: "done";
                }>;
                sha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                sameVendor: z.ZodBoolean;
                blocking: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                failureKind: z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    environment: "environment";
                    cancelled: "cancelled";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    "scope-violation": "scope-violation";
                    merge: "merge";
                    budget: "budget";
                }>;
                message: z.ZodString;
                blocked: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                leaseUntil: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                integrationSha: z.ZodString;
                accepted: z.ZodBoolean;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                resultSha: z.ZodString;
                integrationSha: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                code: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
                failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    environment: "environment";
                    cancelled: "cancelled";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    "scope-violation": "scope-violation";
                    merge: "merge";
                    budget: "budget";
                }>>>;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                scope: z.ZodEnum<{
                    work: "work";
                    group: "group";
                    total: "total";
                }>;
                scopeId: z.ZodOptional<z.ZodString>;
                state: z.ZodEnum<{
                    exceeded: "exceeded";
                    undetermined: "undetermined";
                }>;
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                suite: z.ZodString;
                pending: z.ZodString;
                version: z.ZodNumber;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    completed: "completed";
                    waiting: "waiting";
                }>;
                accepted: z.ZodArray<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                recoveryId: z.ZodString;
                property: z.ZodString;
                status: z.ZodEnum<{
                    stopped: "stopped";
                    closed: "closed";
                    "awaiting-lead": "awaiting-lead";
                    analyzing: "analyzing";
                    applying: "applying";
                    retry: "retry";
                    retrying: "retrying";
                    "awaiting-user": "awaiting-user";
                }>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                workIds: z.ZodArray<z.ZodString>;
                policyDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                }>;
                manifestDigest: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodNumber;
                by: z.ZodString;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    failed: "failed";
                    requested: "requested";
                    cleared: "cleared";
                }>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                receipt: z.ZodOptional<z.ZodString>;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                error: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                currentRevision: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict>;
        }, z.core.$strict>, ...z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            seq: z.ZodNumber;
            at: z.ZodISODateTime;
            graphId: z.ZodOptional<z.ZodString>;
            workId: z.ZodOptional<z.ZodString>;
            runId: z.ZodOptional<z.ZodString>;
            attempt: z.ZodOptional<z.ZodNumber>;
            type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict">;
            payload: z.ZodObject<{
                digest: z.ZodString;
                orders: z.ZodNumber;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
            }, z.core.$strict> | z.ZodObject<{
                kind: z.ZodEnum<{
                    plan: "plan";
                    contract: "contract";
                }>;
                subject: z.ZodString;
                digest: z.ZodString;
                round: z.ZodNumber;
                approved: z.ZodBoolean;
                open: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                actor: z.ZodEnum<{
                    agent: "agent";
                    operator: "operator";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                orderDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
                released: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                policyDigest: z.ZodString;
                engineVersion: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    ready: "ready";
                    failed: "failed";
                    cancelled: "cancelled";
                    draft: "draft";
                    running: "running";
                    verifying: "verifying";
                    reviewing: "reviewing";
                    integrating: "integrating";
                    done: "done";
                }>;
                sha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                sameVendor: z.ZodBoolean;
                blocking: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                failureKind: z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    environment: "environment";
                    cancelled: "cancelled";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    "scope-violation": "scope-violation";
                    merge: "merge";
                    budget: "budget";
                }>;
                message: z.ZodString;
                blocked: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                leaseUntil: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                integrationSha: z.ZodString;
                accepted: z.ZodBoolean;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                resultSha: z.ZodString;
                integrationSha: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                code: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
                failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    environment: "environment";
                    cancelled: "cancelled";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    "scope-violation": "scope-violation";
                    merge: "merge";
                    budget: "budget";
                }>>>;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                scope: z.ZodEnum<{
                    work: "work";
                    group: "group";
                    total: "total";
                }>;
                scopeId: z.ZodOptional<z.ZodString>;
                state: z.ZodEnum<{
                    exceeded: "exceeded";
                    undetermined: "undetermined";
                }>;
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                suite: z.ZodString;
                pending: z.ZodString;
                version: z.ZodNumber;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    completed: "completed";
                    waiting: "waiting";
                }>;
                accepted: z.ZodArray<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                recoveryId: z.ZodString;
                property: z.ZodString;
                status: z.ZodEnum<{
                    stopped: "stopped";
                    closed: "closed";
                    "awaiting-lead": "awaiting-lead";
                    analyzing: "analyzing";
                    applying: "applying";
                    retry: "retry";
                    retrying: "retrying";
                    "awaiting-user": "awaiting-user";
                }>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                workIds: z.ZodArray<z.ZodString>;
                policyDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                }>;
                manifestDigest: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodNumber;
                by: z.ZodString;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    failed: "failed";
                    requested: "requested";
                    cleared: "cleared";
                }>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                receipt: z.ZodOptional<z.ZodString>;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                error: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                currentRevision: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict>;
        }, z.core.$strict>[]], "type">>;
        next: z.ZodNumber;
    }, z.core.$strict>;
    readonly pause: z.ZodObject<{
        control: z.ZodObject<{
            paused: z.ZodBoolean;
            pauseReason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            pausedAt: z.ZodOptional<z.ZodISODateTime>;
            pauseOperation: z.ZodOptional<z.ZodString>;
            pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                merge: "merge";
                budget: "budget";
            }>>>;
            waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    "base-check": "base-check";
                    "context-lock": "context-lock";
                }>;
                detail: z.ZodString;
                at: z.ZodISODateTime;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            appliedPolicy: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodOptional<z.ZodNumber>;
                at: z.ZodISODateTime;
                by: z.ZodString;
            }, z.core.$strict>>;
            reconfigure: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                requestedAt: z.ZodISODateTime;
                appliedAt: z.ZodOptional<z.ZodISODateTime>;
                appliedBy: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly resume: z.ZodObject<{
        control: z.ZodObject<{
            paused: z.ZodBoolean;
            pauseReason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            pausedAt: z.ZodOptional<z.ZodISODateTime>;
            pauseOperation: z.ZodOptional<z.ZodString>;
            pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                merge: "merge";
                budget: "budget";
            }>>>;
            waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    "base-check": "base-check";
                    "context-lock": "context-lock";
                }>;
                detail: z.ZodString;
                at: z.ZodISODateTime;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            appliedPolicy: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodOptional<z.ZodNumber>;
                at: z.ZodISODateTime;
                by: z.ZodString;
            }, z.core.$strict>>;
            reconfigure: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                requestedAt: z.ZodISODateTime;
                appliedAt: z.ZodOptional<z.ZodISODateTime>;
                appliedBy: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly cancel: z.ZodObject<{
        workId: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly retry: z.ZodObject<{
        workId: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly result: z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        result: z.ZodDiscriminatedUnion<[z.ZodObject<{
            outcome: z.ZodLiteral<"accepted">;
            shas: z.ZodObject<{
                base: z.ZodString;
                candidate: z.ZodString;
                integration: z.ZodString;
                result: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    property: "property";
                    review: "review";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            outcome: z.ZodEnum<{
                rejected: "rejected";
                blocked: "blocked";
                cancelled: "cancelled";
                stopped: "stopped";
            }>;
            shas: z.ZodObject<{
                base: z.ZodOptional<z.ZodString>;
                candidate: z.ZodOptional<z.ZodString>;
                integration: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            stopReason: z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    property: "property";
                    review: "review";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>], "outcome">;
        delivery: z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly deliver: z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        result: z.ZodDiscriminatedUnion<[z.ZodObject<{
            outcome: z.ZodLiteral<"accepted">;
            shas: z.ZodObject<{
                base: z.ZodString;
                candidate: z.ZodString;
                integration: z.ZodString;
                result: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    property: "property";
                    review: "review";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            outcome: z.ZodEnum<{
                rejected: "rejected";
                blocked: "blocked";
                cancelled: "cancelled";
                stopped: "stopped";
            }>;
            shas: z.ZodObject<{
                base: z.ZodOptional<z.ZodString>;
                candidate: z.ZodOptional<z.ZodString>;
                integration: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            stopReason: z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    property: "property";
                    review: "review";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>], "outcome">;
        delivery: z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly profile: z.ZodObject<{
        pin: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            source: z.ZodOptional<z.ZodObject<{
                repositoryId: z.ZodString;
                path: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        profile: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            capabilities: z.ZodArray<z.ZodString>;
            gates: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"test">;
                report: z.ZodObject<{
                    type: z.ZodLiteral<"junit">;
                    path: z.ZodString;
                }, z.core.$strict>;
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
                property: z.ZodOptional<z.ZodObject<{
                    path: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
                cwd: z.ZodOptional<z.ZodString>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"check">;
                report: z.ZodOptional<z.ZodObject<{
                    type: z.ZodLiteral<"junit">;
                    path: z.ZodString;
                }, z.core.$strict>>;
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
                property: z.ZodOptional<z.ZodObject<{
                    path: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
                cwd: z.ZodOptional<z.ZodString>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>], "kind">>;
            prepare: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
            environment: z.ZodOptional<z.ZodObject<{
                inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
                values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
                secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            }, z.core.$strict>>;
            lifecycle: z.ZodOptional<z.ZodObject<{
                setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>>;
                ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>>;
                teardown: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            protectedPaths: z.ZodArray<z.ZodString>;
            generatedPaths: z.ZodArray<z.ZodString>;
            concurrency: z.ZodOptional<z.ZodNumber>;
            runTimeoutMs: z.ZodOptional<z.ZodNumber>;
            roles: z.ZodRecord<z.ZodString, z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
                writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                title: z.ZodOptional<z.ZodString>;
                requiresContract: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strict>>;
            contextPacks: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                version: z.ZodString;
                repositoryId: z.ZodOptional<z.ZodString>;
                roles: z.ZodDefault<z.ZodArray<z.ZodString>>;
                files: z.ZodArray<z.ZodString>;
                references: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            source: z.ZodOptional<z.ZodObject<{
                repositoryId: z.ZodString;
                path: z.ZodString;
            }, z.core.$strict>>;
            closure: z.ZodArray<z.ZodObject<{
                ref: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    readonly doctor: z.ZodObject<{
        harness: z.ZodString;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        node: z.ZodString;
        platform: z.ZodString;
        runtimes: z.ZodArray<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            available: z.ZodBoolean;
            version: z.ZodOptional<z.ZodString>;
            structuredOutput: z.ZodBoolean;
            cancellation: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        sandbox: z.ZodObject<{
            os: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        state: z.ZodOptional<z.ZodObject<{
            stateVersion: z.ZodNumber;
            compatible: z.ZodBoolean;
            writer: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        problems: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    readonly version: z.ZodObject<{
        harness: z.ZodString;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    }, z.core.$strict>;
};
export declare const cliErrorSchema: z.ZodObject<{
    code: z.ZodEnum<{
        INVALID_INPUT: "INVALID_INPUT";
        UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
        UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
        GRAPH_CYCLE: "GRAPH_CYCLE";
        GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
        GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
        GATE_UNKNOWN: "GATE_UNKNOWN";
        GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
        REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
        REVIEWER_MISSING: "REVIEWER_MISSING";
        APPROVAL_STALE: "APPROVAL_STALE";
        APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
        LEASE_STALE: "LEASE_STALE";
        CONTROLLER_BUSY: "CONTROLLER_BUSY";
        PAUSED: "PAUSED";
        NOT_READY: "NOT_READY";
        SCOPE_VIOLATION: "SCOPE_VIOLATION";
        GATE_FAILED: "GATE_FAILED";
        REVIEW_REJECTED: "REVIEW_REJECTED";
        BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
        BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
        ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
        REVISION_CONFLICT: "REVISION_CONFLICT";
        CANCELLED: "CANCELLED";
        NOT_FOUND: "NOT_FOUND";
        STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
        RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
        SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
        GIT_FAILED: "GIT_FAILED";
        STORAGE_FAILED: "STORAGE_FAILED";
        DELIVERY_FAILED: "DELIVERY_FAILED";
        INTERNAL: "INTERNAL";
    }>;
    class: z.ZodEnum<{
        input: "input";
        refused: "refused";
        infrastructure: "infrastructure";
    }>;
    message: z.ZodString;
    issues: z.ZodArray<z.ZodObject<{
        path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        message: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CliEnvelope<C extends CliCommand | 'version' = CliCommand | 'version'> = {
    apiVersion: typeof API_VERSION;
    command: C;
    ok: true;
    data: z.infer<(typeof cliDataSchemas)[C]>;
} | {
    apiVersion: typeof API_VERSION;
    command: C | null;
    ok: false;
    error: z.infer<typeof cliErrorSchema>;
};
/** Входной документ контракта для `review-contract` — см. `checks.ts`. */
export { contractDocumentSchema, type ContractDocument } from './checks.ts';
