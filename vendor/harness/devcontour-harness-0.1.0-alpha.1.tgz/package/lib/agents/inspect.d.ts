import type { EvidenceRecord } from '../contracts/index.ts';
type ReviewInspection = NonNullable<EvidenceRecord['inspection']>;
export declare const unobservedReview: () => ReviewInspection;
/** Что reviewer действительно выполнил — по событиям runtime, а не по словам модели. */
export declare function inspectReview(runtime: string, output: string): ReviewInspection;
export {};
