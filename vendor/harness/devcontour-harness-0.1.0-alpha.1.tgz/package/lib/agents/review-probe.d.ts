import { z } from 'zod';
import type { ExecutionPolicy, ProbeServer } from '../contracts/index.ts';
/**
 * Пробные проверки reviewer под пределами harness.
 *
 * Reviewer, запускавший проверки своим shell, зависал на проверяемом коде:
 * срок команды задавал сам CLI модели, и одна зависшая команда съедала весь
 * срок ревью — готовый кандидат падал без вердикта. Здесь срок задаёт
 * controller: команда исполняется тем же исполнителем, что и gates (песочница
 * ОС, исходники только для чтения, остановка потомков), с пределом на
 * команду, общим бюджетом проверок и резервом времени на заключение.
 * Превышение — результат, который получает модель, а не зависание.
 */
export declare const probeServer = "devcontour_probe";
export declare const probeTool = "run_check";
export declare const probeSpec: z.ZodObject<{
    cwd: z.ZodString;
    controller: z.ZodArray<z.ZodString>;
    readable: z.ZodArray<z.ZodString>;
    isolation: z.ZodObject<{
        mode: z.ZodEnum<{
            os: "os";
            none: "none";
        }>;
        domains: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    commandTimeoutMs: z.ZodNumber;
    budgetMs: z.ZodNumber;
    deadline: z.ZodNumber;
    env: z.ZodArray<z.ZodString>;
    secrets: z.ZodArray<z.ZodString>;
    settingsDir: z.ZodString;
    log: z.ZodString;
}, z.core.$strip>;
export type ProbeSpec = z.infer<typeof probeSpec>;
export declare const probeInput: z.ZodObject<{
    argv: z.ZodArray<z.ZodString>;
    timeoutMs: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export type ProbeResult = {
    /**
     * Id запуска. Reviewer ссылается на него в воспроизведении, и «наблюдено»
     * ставится по журналу controller, а не по тексту команды: замаскированные
     * аргументы разных команд могут совпадать.
     */
    runId: string;
    argv: string[];
    /**
     * `timeout` — команда не уложилась в предел и остановлена вместе с
     * потомками; это наблюдение о команде на данном входе, а не доказанный
     * дефект. `budget-exhausted` — команда не запускалась: бюджет проверок или
     * время до заключения исчерпаны. `error` — команда не запустилась.
     */
    status: 'passed' | 'failed' | 'timeout' | 'budget-exhausted' | 'error';
    exitCode: number | null;
    durationMs: number;
    limitMs: number;
    budgetLeftMs: number;
    stdout: string;
    stderr: string;
    note?: string;
};
export declare class ReviewProbes {
    readonly spec: ProbeSpec;
    private readonly now;
    private readonly environment;
    private spent;
    constructor(spec: ProbeSpec, now?: () => number, environment?: NodeJS.ProcessEnv);
    /** Сколько может длиться следующая команда: меньшее из трёх пределов. */
    limit(requested?: number): number;
    run(input: z.infer<typeof probeInput>, signal?: AbortSignal): Promise<ProbeResult>;
}
/**
 * Stdio MCP-сервер с одним инструментом — его запускает CLI reviewer.
 * Протокол — построчный JSON-RPC 2.0 (`initialize`, `tools/list`,
 * `tools/call`, `ping`); вызовы исполняются одновременно, бюджет общий —
 * один экземпляр `ReviewProbes` на сервер.
 */
export declare function serveReviewProbes(probes: ReviewProbes, input?: NodeJS.ReadableStream, output?: NodeJS.WritableStream): {
    lines: import("readline").Interface;
    pending: Set<Promise<unknown>>;
};
/** Пределы проверок ревью, выведенные из срока фазы. */
export declare function probeLimits(policy: Pick<ExecutionPolicy, 'runTimeoutMs' | 'reviewProbes'>): {
    commandTimeoutMs: number;
    budgetMs: number;
    reserveMs: number;
};
/** Срок вызова инструмента в CLI — с запасом сверх предела команды controller. */
export declare const probeCallMs: (probe: ProbeServer) => number;
/**
 * Команда, которой CLI reviewer запускает сервер проверок — этот же пакет.
 * CLI стартует её из проверяемого каталога, поэтому загрузчик исходников
 * указан абсолютным путём: из worktree он бы не разрешился.
 */
export declare function probeCommand(specPath: string): {
    command: string;
    args: string[];
};
/** Запуск из журнала controller в том виде, в каком он входит в review.json. */
export interface ProbeRecord {
    runId: string;
    argv: string[];
    status: ProbeResult['status'];
    durationMs: number;
    limitMs: number;
}
/** Журнал проверок reviewer: по записи на запуск; нечитаемая строка — не запуск. */
export declare function probeRecords(log: string): Promise<ProbeRecord[]>;
/**
 * Воспроизведения находок, сверенные с журналом controller. «Наблюдено» —
 * только по запуску, на который сослался reviewer: он состоялся (исчерпанный
 * бюджет и отказ до старта — не наблюдение), совпадение единственное, и
 * команда в записи — та, что действительно запускалась. Команда из текста
 * находки не исполняется. Ответ reviewer мог прийти уже замаскированным, и
 * короткий секрет задевает символы id: id журнала сравниваются и в той же маске.
 */
export declare function observeReproductions<F extends {
    reproduction?: {
        command: string[] | null;
        run?: string | null;
    } | null;
}>(findings: F[], probes: ProbeRecord[] | undefined, redact: (text: string) => string): F[];
