export declare const implementationOutputSchema: {
    type: string;
    additionalProperties: boolean;
    properties: {
        completed: {
            type: string;
        };
        summary: {
            type: string;
        };
        discoveries: {
            type: string;
            maxItems: number;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    kind: {
                        type: string;
                        enum: string[];
                    };
                    title: {
                        type: string;
                    };
                    path: {
                        type: string;
                    };
                    line: {
                        type: string;
                        minimum: number;
                    };
                    observation: {
                        type: string;
                    };
                    consequence: {
                        type: string;
                    };
                    reproduction: {
                        type: string;
                    };
                };
                required: string[];
            };
        };
    };
    required: string[];
};
export declare const reviewOutputSchema: {
    type: string;
    additionalProperties: boolean;
    properties: {
        execution: {
            type: string;
            additionalProperties: boolean;
            properties: {
                commands: {
                    type: string;
                    maxItems: number;
                    items: {
                        type: string;
                        additionalProperties: boolean;
                        properties: {
                            command: {
                                type: string;
                            };
                            exitCode: {
                                type: string;
                            };
                            summary: {
                                type: string;
                            };
                        };
                        required: string[];
                    };
                };
                noCommandsReason: {
                    type: string[];
                };
            };
            required: string[];
        };
        approved: {
            type: string;
        };
        summary: {
            type: string;
        };
        discoveries: {
            type: string;
            maxItems: number;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    kind: {
                        type: string;
                        enum: string[];
                    };
                    title: {
                        type: string;
                    };
                    path: {
                        type: string;
                    };
                    line: {
                        type: string;
                        minimum: number;
                    };
                    observation: {
                        type: string;
                    };
                    consequence: {
                        type: string;
                    };
                    reproduction: {
                        type: string;
                    };
                };
                required: string[];
            };
        };
        findings: {
            type: string;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    severity: {
                        type: string;
                        enum: string[];
                    };
                    message: {
                        type: string;
                    };
                    path: {
                        type: string[];
                    };
                    line: {
                        type: string[];
                        minimum: number;
                    };
                    rule: {
                        type: string[];
                    };
                    consequence: {
                        type: string[];
                    };
                    evidence: {
                        type: string[];
                    };
                    reproduction: {
                        anyOf: ({
                            type: string;
                            additionalProperties?: undefined;
                            properties?: undefined;
                            required?: undefined;
                        } | {
                            type: string;
                            additionalProperties: boolean;
                            properties: {
                                property: {
                                    type: string[];
                                };
                                input: {
                                    type: string;
                                };
                                expected: {
                                    type: string[];
                                };
                                actual: {
                                    type: string[];
                                };
                                command: {
                                    type: string[];
                                    items: {
                                        type: string;
                                    };
                                };
                                executed: {
                                    type: string;
                                };
                                run: {
                                    type: string[];
                                };
                            };
                            required: string[];
                        })[];
                    };
                };
                required: string[];
            };
        };
        previous: {
            type: string;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    id: {
                        type: string;
                    };
                    status: {
                        type: string;
                        enum: string[];
                    };
                    basis: {
                        type: string;
                    };
                };
                required: string[];
            };
        };
    };
    required: string[];
};
