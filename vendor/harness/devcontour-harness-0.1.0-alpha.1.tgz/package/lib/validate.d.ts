import { type ErrorIssue, type ExecutionPolicy, type WorkGraph } from './contracts/index.ts';
type CodedIssue = ErrorIssue & {
    code: string;
};
/** Путь внутри одного из префиксов (как `withinPaths` DevContour). */
export declare const withinPaths: (path: string, prefixes: string[]) => boolean;
/**
 * Связь поручений с политикой — проверки DevContour `validateTaskContext`,
 * выполнимые без модели и без внешних источников: репозиторий и роль
 * объявлены; ресурсы известны; область записи пересекается с областью роли;
 * область доказательства раскрывается, замкнута по `dependsOn` gates и
 * содержит test gate; требования не повторяются, их текст совпадает с
 * digest, а gate — test gate из области; потребители уникальны, отличны от
 * провайдера, зависят от него и проверяются test gate; поручение уровня
 * workspace затрагивает минимум два известных репозитория.
 *
 * Не проверяется здесь: байты и digests контекста и контрактов — их
 * сверяет движок с `ContextSource` при регистрации графа.
 */
export declare function crossIssues(graph: WorkGraph, policy: ExecutionPolicy): CodedIssue[];
/**
 * Проверка входов без вызова моделей и без записи состояния. Ошибки
 * собираются все сразу; код первой определяет класс отказа.
 */
export declare function validateInputs(input: {
    graph: unknown;
    policy: unknown;
    context?: unknown;
}): {
    contextDigest?: string | undefined;
    graphId: string;
    graphDigest: string;
    policyDigest: string;
    orders: number;
};
export {};
