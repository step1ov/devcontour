import { type Activity, type EvidenceRecord, type ExecutionPolicy, type GatePolicy } from '../contracts/index.ts';
import { isolationSupport, type Isolation, type SandboxViolation } from '../environment/isolation.ts';
import { TaskFailure } from '../engine/failure.ts';
import { type CheckManifest } from './property.ts';
/** Длинное имя testcase заменяется хешем, а не обрезается: обрезка дала бы ложные совпадения. */
export declare const TEST_ID_LIMIT = 1000;
export declare function portableTest<T extends {
    id: string;
    opaque?: true;
}>(test: T): T;
/**
 * Сводка JUnit-отчёта.
 *
 * `redact` применяется к именам и сообщениям до любой обрезки: обрезанный
 * секрет redactor уже не узнаёт, и в сводке оставался бы его префикс. Имя
 * testcase тоже проходит redact — оно попадает в состояние, журнал и API.
 * Изменённое так имя не совпадёт с названным критерием, и подтверждения
 * не будет: для секрета в имени теста это правильный исход.
 */
/**
 * Значение атрибута XML: парсер работает без обработки сущностей (DOCTYPE
 * запрещён, внешних сущностей нет), поэтому предопределённые сущности и
 * числовые ссылки раскрываются здесь — один раз, без рекурсии. Иначе testcase
 * `a["b"]` сохранялся как `a[&quot;b&quot;]` и не совпадал с названным
 * testId требования или критерия. Репортер JUnit Node.js экранирует `"`
 * дважды (`&amp;quot;`); оставшийся после раскрытия `&quot;` поэтому тоже
 * читается как `"`.
 */
export declare function xmlAttribute(value: string): string;
export declare function junitSummary(xml: string, redact?: (value: string) => string): {
    tests: number;
    failures: number;
    skipped: number;
    /** Имена провалившихся testcases: по ним различаются разные провалы. */
    failed: string[];
    /** Те же testcases с первыми словами сообщения о провале. */
    failedDetails: string[];
    /** Что именно выполнилось и с каким исходом. */
    cases: NonNullable<EvidenceRecord['tests']>;
    /** Список обрезан: отсутствие теста по нему доказать нельзя. */
    truncated: boolean;
};
/**
 * Песочница отказала до запуска команды: процесс завершился неуспешно, а
 * обёртка не дошла до exec — нет ни метки-файла, ни токена старта, который
 * она печатает в stderr перед exec (`printed`). Метку команда может стереть,
 * напечатанный токен — нет; подделать токен значит лишь признать старт.
 * Текст stderr сам признаком не служит — его может напечатать и проверка.
 */
export declare function sandboxNotStarted(result: {
    code: number;
}, started: string | undefined, printed: boolean): boolean;
/**
 * Фильтр сырого stderr, вырезающий строку токена старта, которую обёртка
 * печатает перед exec. Ищет до маски: маска по значениям окружения (`1`,
 * `8080`) задевала бы шестнадцатеричный токен, и старт не узнавался. Хвост,
 * который может оказаться началом токена, придерживается до следующего
 * куска. Вырезается только первое вхождение; `onSeen` — при нём.
 */
export declare function startTokenFilter(token: string, onSeen: () => void): (text: string, final: boolean) => string;
/**
 * Известные отказы запуска самой песочницы — не содержимого проверяемого
 * дерева: поиск shell и порождение процесса песочницы. Только они при
 * доказанном «не стартовала» делают отказ классом `environment`; прочие
 * отказы srt до старта (например, сборка запретов по дереву на Linux) могут
 * зависеть от кандидата и остаются провалом проверки. Весь stderr должен
 * состоять только из таких строк srt: строка внутри другого вывода не в счёт.
 */
export declare function sandboxLaunchFailure(stderr: string): boolean;
/**
 * Путь отчёта внутри корня, созданный без выхода за него.
 *
 * Раньше каталоги создавались рекурсивно, а граница проверялась потом:
 * symlink внутри worktree успевал увести создание каталога наружу до отказа.
 * Теперь путь проходится от корня по одному компоненту: существующий symlink
 * или не-каталог — отказ до любой записи, недостающий каталог создаётся
 * только внутри уже проверенного родителя.
 */
export declare function prepareReportPath(root: string, path: string, escape: string): Promise<string>;
/**
 * Команда проверки — задачи или общей приёмки workspace — в песочнице ОС.
 *
 * Прежде проверка шла обычным процессом хоста и могла читать базу контура и
 * соседние файлы, писать вне worktree и ходить в сеть: сверка HEAD и
 * отслеживаемых файлов после неё этого не видит. Без механизма песочницы
 * проверка не запускается — снять изоляцию можно только явным
 * isolation.mode: none. Запись — в `write` и собственный scratch (TMPDIR).
 */
export declare function runCheck(h: {
    config: Pick<ExecutionPolicy, 'isolation'>;
}, options: {
    argv: string[];
    cwd: string;
    env: NodeJS.ProcessEnv;
    redact?: (value: string) => string;
    timeoutMs?: number;
    signal: AbortSignal;
    write: string[];
    readable: string[];
    controller: string[];
    /** Корни рабочих деревьев вне каталога состояния: закрыты целиком, свои деревья открыты. */
    checkouts?: string[];
    settingsDir: string;
    /**
     * Собрать отказы песочницы из журнала ядра (macOS): по ним, а не по
     * тексту вывода, отказ среды отличается от ошибки кода.
     */
    violations?: boolean;
    /**
     * Запуск проверки подтверждён: без песочницы — порождён её процесс, в
     * песочнице — обёртка напечатала токен старта (или создала метку) перед
     * exec. Запуск самой
     * обёртки песочницы запуском проверки не считается. Вызывается не более
     * одного раза, в том числе когда проверка затем завершилась исключением.
     */
    onStart?: () => void;
    /** Что это за команда для обхода зависших попыток (`command`). */
    activity?: Activity;
}): Promise<{
    violations?: SandboxViolation[] | undefined;
    isolation?: Isolation | undefined;
    attempts: number;
    started: boolean;
    notStarted: boolean;
    launchFailed: boolean;
    code: number;
    stdout: string;
    stderr: string;
    timedOut: boolean;
    diagnostics: import("../contracts/execution.ts").RuntimeDiagnostics;
}>;
/** Исход проверки, завершившейся до исключения (например, отказа уборки), если он есть. */
export declare function completedCheck(error: unknown): {
    violations?: SandboxViolation[] | undefined;
    isolation?: Isolation | undefined;
    attempts: number;
    started: boolean;
    notStarted: boolean;
    launchFailed: boolean;
    code: number;
    stdout: string;
    stderr: string;
    timedOut: boolean;
    diagnostics: import("../contracts/execution.ts").RuntimeDiagnostics;
} | undefined;
/** Уборка каталогов проверки; тест подменяет её, чтобы проверить отказ после исхода. */
export declare const checkCleanup: {
    remove: (dir: string) => Promise<void>;
};
/** Проверка механизма песочницы; тест подменяет её, чтобы проверить отказ. */
export declare const isolationBackend: {
    check: typeof isolationSupport;
};
/**
 * Хосты, в сети к которым проверке, по всей видимости, отказала песочница.
 *
 * Прокси песочницы отвечает на запрещённый домен `403`, но клиенты вроде
 * pnpm показывают только «Forbidden - 403» и URL. На пилоте такой отказ
 * записывался провалом проверки, и контур переписывал код, который был ни
 * при чём. Признак узкий: в выводе есть отказ (403, Forbidden, прокси или
 * тело ответа песочницы) и URL хоста, которого нет в `isolation.domains`.
 */
export declare function sandboxBlockedHosts(output: string, allowed: string[]): string[];
/**
 * Окружение свежести test gate: те же переменные у gate движка и у gate,
 * запущенного проверкой reviewer, — иначе probe мог бы прочитать cache там,
 * где gate исполняет тесты заново.
 */
/**
 * Переменная пути отчёта свойств. Ту же и только её выставляет и probe
 * reviewer (путь — в его scratch): проверка видит одно имя в обоих запусках.
 */
export declare const propertyReportEnv = "DEVCONTOUR_PROPERTY_REPORT";
export declare function freshnessEnv(kind: GatePolicy['kind'], env: NodeJS.ProcessEnv): Record<string, string>;
/**
 * Граница проверки: закрытое (состояние controller, исходные checkout),
 * открытое внутри него и корни рабочих деревьев вне каталога состояния,
 * закрытые целиком (свои деревья проверки открыты).
 */
export interface Boundary {
    hidden: string[];
    readable: string[];
    checkouts?: string[];
}
/**
 * Нагрузка хоста на одно ядро (средняя за минуту), начиная с которой gate,
 * исчерпавший свой предел времени, повторяется один раз на том же SHA
 * (`GateTimeout.overloaded`). Под такой нагрузкой предел gate меряет очередь
 * к процессору, а не его код; проверка, которая и на свободной машине не
 * укладывается в предел, повтора не получает.
 */
export declare const HOST_LOAD_RECHECK_PER_CPU = 2;
/** Снимок нагрузки хоста; объект — чтобы тест мог подменить чтение. */
export declare const hostLoad: {
    read: () => HostLoad;
};
export interface HostLoad {
    /** Средняя нагрузка за минуту (`os.loadavg()[0]`; на Windows — 0). */
    load1: number;
    /** Доступные процессу ядра. */
    cpus: number;
}
/**
 * Gate исчерпал свой предел времени (не отмена попытки). Класс отказа —
 * прежний `gate`; нагрузка в момент таймаута решает, повторить ли gate один
 * раз (`Runner`): повтор прошёл — исход `flaky`, попытка не тратится; снова
 * таймаут — провал засчитан как прежде.
 */
export declare class GateTimeout extends TaskFailure {
    readonly load: HostLoad;
    constructor(message: string, load: HostLoad);
    get overloaded(): boolean;
}
/** Что нужно для запуска gate попытки. */
export interface GateRun {
    policy: Pick<ExecutionPolicy, 'isolation' | 'gateTimeoutFloorMs'>;
    /** Запись evidence под fencing попытки. */
    record: (evidence: Omit<EvidenceRecord, 'id' | 'runId' | 'createdAt'>) => EvidenceRecord;
    cwd: string;
    sha: string;
    phase: EvidenceRecord['phase'];
    gate: GatePolicy;
    artifactDir: string;
    signal: AbortSignal;
    /** Окружение фазы: переменные и маска секретов. */
    execution: {
        env: NodeJS.ProcessEnv;
        redact: (value: string) => string;
        /** Вложенные `.git`, созданные подготовкой фазы: их исчезновение сверка не считает. */
        prepared?: ReadonlySet<string>;
    };
    /** Закрытое проверке (состояние controller, чужие checkout) и открытое внутри него. */
    boundary: Boundary;
    /** Проверка потребителя: evidence несёт его компонент и не закрывает собственные gates. */
    consumer?: string;
    /** Повтор провала: ID записи, которую повторяет запуск; исход пишется в `recheck`. */
    recheck?: string;
    /**
     * Закреплённый SHA базы попытки: только при нём упавшая установка
     * зависимостей может стать отказом среды `dependency-network` — входы
     * менеджера в дереве сверяются с этой базой. Нет — классификации нет.
     */
    trustedBase?: string;
    /**
     * Генеративный gate (`gate.property`): попытка, от которой seed, и
     * ожидаемая проверка поручения. Без `expected` — прежний уровень (отчёт
     * сверяется сам с собой и с JUnit).
     */
    property?: {
        runId: string;
        expected?: CheckManifest;
        /** Закреплённый корпус попытки: материализуется вне worktree только для чтения. */
        corpus?: {
            digest: string;
            content: string;
        };
        /** Контракты поручения по digest и их закреплённые файлы. */
        contracts: Record<string, string>;
        artifacts: {
            path: string;
            blob: string;
        }[];
    };
}
/**
 * Gate попытки. `test` принимается только по свежему (прежний отчёт удалён до
 * запуска) непустому JUnit без failures, errors и skips на этом SHA; exit 0
 * без отчёта — отказ. Gate, изменивший HEAD или отслеживаемые файлы, не
 * проходит. Evidence записывается при любом исходе; провал — `TaskFailure`.
 */
export declare function runGate(run: GateRun): Promise<EvidenceRecord>;
/** Что нужно для установки зависимостей в дереве исполнителя до его работы. */
export interface WriterDependenciesRun {
    policy: Pick<ExecutionPolicy, 'isolation' | 'gateTimeoutFloorMs'>;
    /** Рабочее дерево исполнителя: база попытки, возможно с наложенным черновиком. */
    cwd: string;
    /** SHA базы попытки (HEAD дерева). */
    base: string;
    /**
     * Дерево — сама база (черновик не наложен): защищённый путь, созданный
     * установкой, — отказ среды. С черновиком манифесты писал прежний
     * исполнитель, и это нарушение области, как у gate кандидата.
     */
    trusted: boolean;
    /** Gates установки из обязательных gates попытки (`writerDependencyGates`), в их порядке. */
    gates: GatePolicy[];
    /** Защищённые пути репозитория: по ним заметка говорит, заморожены ли манифесты. */
    protectedPaths?: string[];
    /** Каталог журналов и квитанции (`artifacts/candidate/writer-dependencies`). */
    artifactDir: string;
    signal: AbortSignal;
    /** Окружение фазы — с окружением хранилища зависимостей, как у gate. */
    execution: {
        env: NodeJS.ProcessEnv;
        redact: (value: string) => string;
        /** Вложенные `.git`, созданные подготовкой фазы: их исчезновение сверка не считает. */
        prepared?: ReadonlySet<string>;
    };
    boundary: Boundary;
}
/** Исход установки для исполнителя: что поставлено и почему нет. Evidence не пишется. */
export interface WriterDependencies {
    /** ID gates, исполненных с кодом 0. */
    installed: string[];
    /** Первый отказ: gate и короткая сводка; дальше установка не идёт. */
    failed?: {
        gate: string;
        summary: string;
    };
    /** Отслеживаемые файлы, которые изменила установка и вернул controller. */
    reverted?: string[];
    /** Манифесты и lockfiles в каталогах установки есть, и все они в защищённых путях. */
    frozen: boolean;
    /** Новые `node_modules`, скрытые от git своим `.gitignore`. */
    sealed?: string[];
    /** Пути, которых до установки не было и которые она оставила вне `node_modules`: убраны. */
    removed?: string[];
    /** Сколько всего убрано (список — первые `WRITER_DEPENDENCIES_LIST_LIMIT`). */
    removedCount?: number;
    /** Новые пути, которые не убраны: вложенный репозиторий, содержимое прежнего `node_modules`. */
    kept?: string[];
    /** Обход дерева в поисках `node_modules` не закончен (предел элементов). */
    incomplete?: string;
}
/**
 * Gates установки из обязательных gates попытки: только однозначный argv
 * менеджера пакетов (`isDependencyInstall`). Скрипты, `npx` и shell сюда не
 * попадают — они остаются только gates. `dependsOn` не исполняется: проверки,
 * от которых зависит gate установки, остаются gates кандидата.
 */
export declare function writerDependencyGates(gates: readonly GatePolicy[]): ({
    kind: "test";
    report: {
        type: "junit";
        path: string;
    };
    id: string;
    command: string[];
    timeoutMs: number;
    artifacts?: string[] | undefined;
    property?: {
        path?: string | undefined;
    } | undefined;
    dependsOn?: string[] | undefined;
    cwd?: string | undefined;
    resources?: string[] | undefined;
} | {
    kind: "check";
    id: string;
    command: string[];
    timeoutMs: number;
    report?: {
        type: "junit";
        path: string;
    } | undefined;
    artifacts?: string[] | undefined;
    property?: {
        path?: string | undefined;
    } | undefined;
    dependsOn?: string[] | undefined;
    cwd?: string | undefined;
    resources?: string[] | undefined;
})[];
/**
 * Установка зависимостей в дереве исполнителя до его работы. Песочница
 * Claude Code закрывает запись в `**\/.idea` и `**\/.vscode` от своего
 * рабочего каталога, и установка пакета с такими каталогами в ней падает; у
 * codex по умолчанию нет сети. Поэтому controller исполняет здесь сами gates
 * установки попытки — те же argv, та же изоляция, что у gate (`runCheck`: запись
 * только в дерево, граница, сеть `isolation.domains`, окружение фазы с
 * хранилищем, сверка защищённых путей; при `isolation.mode: none` — как gates,
 * без песочницы).
 *
 * Evidence не пишется: она привязана к SHA кандидата, а настоящий gate
 * установки исполняется на нём после работы исполнителя. Отказ установки
 * попытку не роняет: он становится заметкой исполнителю. Исключение —
 * защищённый путь, созданный или изменённый установкой: над базой это отказ
 * среды (`sandbox-policy`), над черновиком — нарушение области.
 *
 * Следы установки не достаются исполнителю: новые `node_modules` скрываются
 * своим `.gitignore`, прочие новые неотслеживаемые пути (сборка, логи,
 * сгенерированный код) убираются, правка отслеживаемых файлов и HEAD
 * откатывается. Пути, бывшие до установки, не трогаются.
 */
export declare function prepareWriterDependencies(run: WriterDependenciesRun): Promise<WriterDependencies>;
/**
 * Заметка исполнителю об установке зависимостей до его работы. Вывод
 * установки и имена путей — данные инструмента, а не указания: они
 * приводятся строками JSON с явной пометкой.
 */
export declare function writerDependenciesNote(outcome: WriterDependencies): string;
export declare function draftTouchesInstall(files: string[]): boolean;
