import { type ExecutionPolicy, type ExecutionView, type JointVerification, type JointVerificationState, type JointBudgetCheckpoint } from '../contracts/index.ts';
/**
 * Совместная проверка закреплённой комбинации SHA репозиториев.
 *
 * Поручения принимаются по одному, каждое — в своём репозитории. Совместная
 * проверка отвечает на другой вопрос: работает ли вместе комбинация их
 * результатов. Она привязана к manifest (SHA и tree каждого репозитория), к
 * политике совместной проверки и к основанию — постановкам, статусам и
 * результатам поручений. Сменилось любое из них — прежний результат
 * устарел. Атомарного продвижения нескольких Git-репозиториев здесь нет;
 * продуктовое принятие комбинации решает хост.
 */
/** Политика совместной проверки: всё, от чего зависит её результат. */
export declare function jointPolicyDigest(policy: ExecutionPolicy): string;
/** Основание проверки: поручения, их постановки, статусы и результаты. */
export declare function jointSpecDigest(view: ExecutionView, workIds: string[]): string;
/** Один и тот же набор поручений — один предмет проверки, независимо от порядка. */
export declare const sameWorks: (a: string[], b: string[]) => boolean;
/**
 * Проверка, прерванная до результата gates (остановка хоста, потеря
 * владения): без evidence она не говорит ничего о комбинации и предел не тратит.
 */
export declare const jointInterrupted: (v: JointVerificationState) => boolean;
/**
 * Окно бюджета набора: проверки, не закрытые принятием хоста и не снятые
 * явным сбросом (`joint-budget-resets`). Checkpoints доверенного хоста
 * проверяются целиком.
 */
export declare function jointBudgetWindow(view: ExecutionView, workIds: string[], checkpoints: readonly JointBudgetCheckpoint[]): ({
    status: "active";
    apiVersion: "devcontour-harness/v1alpha1";
    id: string;
    startedAt: string;
    policyDigest: string;
    specDigest: string;
    workIds: string[];
    evidence: {
        gate: string;
        passed: boolean;
        command: string[];
        exitCode: number;
        log: string;
        digest: string;
        summary: string;
        artifacts: {
            path: string;
            digest: string;
        }[];
        artifactFiles?: {
            dir: string;
            files: {
                path: string;
                sha256: string;
                bytes: number;
                redacted?: true | undefined;
            }[];
            skipped: {
                path: string;
                reason: "missing" | "symlink" | "outside" | "not-regular" | "hardlink" | "secret" | "extension" | "file-limit" | "total-limit" | "count-limit" | "scan-limit" | "copy-failed";
                detail?: string | undefined;
            }[];
            skippedMore?: number | undefined;
        } | undefined;
        durationMs?: number | undefined;
    }[];
    token: string;
    leaseUntil: number;
    manifest?: Record<string, {
        sha: string;
        tree: string;
    }> | undefined;
    manifestDigest?: string | undefined;
    impact?: {
        changed: string[];
        affected: string[];
        gateIds: string[];
        mode: "affected" | "all";
        reason: string;
        baseline?: string | undefined;
    } | undefined;
    engineVersion?: string | undefined;
} | {
    status: "failed";
    finishedAt: string;
    error: string;
    apiVersion: "devcontour-harness/v1alpha1";
    id: string;
    startedAt: string;
    policyDigest: string;
    specDigest: string;
    workIds: string[];
    evidence: {
        gate: string;
        passed: boolean;
        command: string[];
        exitCode: number;
        log: string;
        digest: string;
        summary: string;
        artifacts: {
            path: string;
            digest: string;
        }[];
        artifactFiles?: {
            dir: string;
            files: {
                path: string;
                sha256: string;
                bytes: number;
                redacted?: true | undefined;
            }[];
            skipped: {
                path: string;
                reason: "missing" | "symlink" | "outside" | "not-regular" | "hardlink" | "secret" | "extension" | "file-limit" | "total-limit" | "count-limit" | "scan-limit" | "copy-failed";
                detail?: string | undefined;
            }[];
            skippedMore?: number | undefined;
        } | undefined;
        durationMs?: number | undefined;
    }[];
    token: string;
    leaseUntil: number;
    manifest?: Record<string, {
        sha: string;
        tree: string;
    }> | undefined;
    manifestDigest?: string | undefined;
    interrupted?: true | undefined;
    impact?: {
        changed: string[];
        affected: string[];
        gateIds: string[];
        mode: "affected" | "all";
        reason: string;
        baseline?: string | undefined;
    } | undefined;
    engineVersion?: string | undefined;
} | {
    status: "passed";
    finishedAt: string;
    manifest: Record<string, {
        sha: string;
        tree: string;
    }>;
    manifestDigest: string;
    apiVersion: "devcontour-harness/v1alpha1";
    id: string;
    startedAt: string;
    policyDigest: string;
    specDigest: string;
    workIds: string[];
    evidence: {
        gate: string;
        passed: boolean;
        command: string[];
        exitCode: number;
        log: string;
        digest: string;
        summary: string;
        artifacts: {
            path: string;
            digest: string;
        }[];
        artifactFiles?: {
            dir: string;
            files: {
                path: string;
                sha256: string;
                bytes: number;
                redacted?: true | undefined;
            }[];
            skipped: {
                path: string;
                reason: "missing" | "symlink" | "outside" | "not-regular" | "hardlink" | "secret" | "extension" | "file-limit" | "total-limit" | "count-limit" | "scan-limit" | "copy-failed";
                detail?: string | undefined;
            }[];
            skippedMore?: number | undefined;
        } | undefined;
        durationMs?: number | undefined;
    }[];
    token: string;
    leaseUntil: number;
    impact?: {
        changed: string[];
        affected: string[];
        gateIds: string[];
        mode: "affected" | "all";
        reason: string;
        baseline?: string | undefined;
    } | undefined;
    engineVersion?: string | undefined;
})[];
/**
 * Проверки набора, тратящие его предел: окно бюджета без прерванных до
 * результата gates. Прерванная после evidence и отказ gate тратят.
 */
export declare function jointBudgetAttempts(view: ExecutionView, workIds: string[], checkpoints: readonly JointBudgetCheckpoint[]): ({
    status: "active";
    apiVersion: "devcontour-harness/v1alpha1";
    id: string;
    startedAt: string;
    policyDigest: string;
    specDigest: string;
    workIds: string[];
    evidence: {
        gate: string;
        passed: boolean;
        command: string[];
        exitCode: number;
        log: string;
        digest: string;
        summary: string;
        artifacts: {
            path: string;
            digest: string;
        }[];
        artifactFiles?: {
            dir: string;
            files: {
                path: string;
                sha256: string;
                bytes: number;
                redacted?: true | undefined;
            }[];
            skipped: {
                path: string;
                reason: "missing" | "symlink" | "outside" | "not-regular" | "hardlink" | "secret" | "extension" | "file-limit" | "total-limit" | "count-limit" | "scan-limit" | "copy-failed";
                detail?: string | undefined;
            }[];
            skippedMore?: number | undefined;
        } | undefined;
        durationMs?: number | undefined;
    }[];
    token: string;
    leaseUntil: number;
    manifest?: Record<string, {
        sha: string;
        tree: string;
    }> | undefined;
    manifestDigest?: string | undefined;
    impact?: {
        changed: string[];
        affected: string[];
        gateIds: string[];
        mode: "affected" | "all";
        reason: string;
        baseline?: string | undefined;
    } | undefined;
    engineVersion?: string | undefined;
} | {
    status: "failed";
    finishedAt: string;
    error: string;
    apiVersion: "devcontour-harness/v1alpha1";
    id: string;
    startedAt: string;
    policyDigest: string;
    specDigest: string;
    workIds: string[];
    evidence: {
        gate: string;
        passed: boolean;
        command: string[];
        exitCode: number;
        log: string;
        digest: string;
        summary: string;
        artifacts: {
            path: string;
            digest: string;
        }[];
        artifactFiles?: {
            dir: string;
            files: {
                path: string;
                sha256: string;
                bytes: number;
                redacted?: true | undefined;
            }[];
            skipped: {
                path: string;
                reason: "missing" | "symlink" | "outside" | "not-regular" | "hardlink" | "secret" | "extension" | "file-limit" | "total-limit" | "count-limit" | "scan-limit" | "copy-failed";
                detail?: string | undefined;
            }[];
            skippedMore?: number | undefined;
        } | undefined;
        durationMs?: number | undefined;
    }[];
    token: string;
    leaseUntil: number;
    manifest?: Record<string, {
        sha: string;
        tree: string;
    }> | undefined;
    manifestDigest?: string | undefined;
    interrupted?: true | undefined;
    impact?: {
        changed: string[];
        affected: string[];
        gateIds: string[];
        mode: "affected" | "all";
        reason: string;
        baseline?: string | undefined;
    } | undefined;
    engineVersion?: string | undefined;
} | {
    status: "passed";
    finishedAt: string;
    manifest: Record<string, {
        sha: string;
        tree: string;
    }>;
    manifestDigest: string;
    apiVersion: "devcontour-harness/v1alpha1";
    id: string;
    startedAt: string;
    policyDigest: string;
    specDigest: string;
    workIds: string[];
    evidence: {
        gate: string;
        passed: boolean;
        command: string[];
        exitCode: number;
        log: string;
        digest: string;
        summary: string;
        artifacts: {
            path: string;
            digest: string;
        }[];
        artifactFiles?: {
            dir: string;
            files: {
                path: string;
                sha256: string;
                bytes: number;
                redacted?: true | undefined;
            }[];
            skipped: {
                path: string;
                reason: "missing" | "symlink" | "outside" | "not-regular" | "hardlink" | "secret" | "extension" | "file-limit" | "total-limit" | "count-limit" | "scan-limit" | "copy-failed";
                detail?: string | undefined;
            }[];
            skippedMore?: number | undefined;
        } | undefined;
        durationMs?: number | undefined;
    }[];
    token: string;
    leaseUntil: number;
    impact?: {
        changed: string[];
        affected: string[];
        gateIds: string[];
        mode: "affected" | "all";
        reason: string;
        baseline?: string | undefined;
    } | undefined;
    engineVersion?: string | undefined;
})[];
/** Gates совместной проверки в порядке их зависимостей. */
export declare function orderedWorkspaceGates(gates: ExecutionPolicy['workspaceGates']): ({
    kind: "test";
    report: {
        type: "junit";
        path: string;
    };
    repositoryId: string;
    artifacts: string[];
    id: string;
    command: string[];
    timeoutMs: number;
    property?: {
        path?: string | undefined;
    } | undefined;
    dependsOn?: string[] | undefined;
    cwd?: string | undefined;
    resources?: string[] | undefined;
} | {
    kind: "check";
    repositoryId: string;
    artifacts: string[];
    id: string;
    command: string[];
    timeoutMs: number;
    report?: {
        type: "junit";
        path: string;
    } | undefined;
    property?: {
        path?: string | undefined;
    } | undefined;
    dependsOn?: string[] | undefined;
    cwd?: string | undefined;
    resources?: string[] | undefined;
})[];
/**
 * Какие gates исполнять. По умолчанию — все. В режиме `affected` при
 * известной прежней успешной комбинации под той же политикой — только
 * изменённые компоненты, их транзитивные потребители и prerequisites их
 * проверок; без достаточного теста в этой области — снова все.
 */
export declare function jointImpact(policy: ExecutionPolicy, manifest: NonNullable<JointVerification['manifest']>, policyDigest: string, baseline?: JointVerificationState): NonNullable<JointVerification['impact']>;
/** Публичная форма: без токена и срока владения. */
export declare function publicJoint(v: JointVerificationState): JointVerification;
