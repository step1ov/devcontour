import type { z } from 'zod';
import { environmentSchema, lifecycleSchema, stepSchema, type ExecutionPolicy } from '../contracts/index.ts';
import { type Redactor } from './redaction.ts';
export { redactor } from './redaction.ts';
type Environment = z.infer<typeof environmentSchema>;
type Lifecycle = z.infer<typeof lifecycleSchema>;
type Step = z.infer<typeof stepSchema>;
/** Отказ обязательной очистки окружения: приёмка с ним не происходит. */
export declare class CleanupFailure extends Error {
    name: string;
}
/** Жив ли процесс (сигнал 0 не доставляется, только проверяется). */
export declare function processAlive(pid: number): boolean;
export declare function executionEnvironment(profiles: (Environment | undefined)[], devcontour?: NodeJS.ProcessEnv, source?: NodeJS.ProcessEnv): {
    env: NodeJS.ProcessEnv;
    redact: Redactor;
    /** Вложенные `.git`, созданные подготовкой фазы (`preparationGuard`). */
    prepared?: PreparedProtected;
};
/** Наименьшая длина наследуемого значения без секретного имени, которое маскируется. */
export declare const INHERITED_SECRET_MIN = 8;
/**
 * Маскировать ли наследуемое значение: имя похоже на секрет (значение не
 * короче 4 знаков, как у настроек коннектора) или значение длинное
 * (`INHERITED_SECRET_MIN`). Объявленные `secrets` маскируются всегда.
 */
export declare const inheritedSecret: (key: string, value: string) => boolean;
/**
 * Маска по тем секретам и наследуемым значениям, что заданы, — даже когда
 * окружение целиком собрать нельзя. Незаданный секрет — причина отказа, но не
 * повод снимать маску с остальных: известный секрет иначе сохранялся бы в
 * команде и итоге проверки.
 */
export declare function availableRedactor(profiles: (Environment | undefined)[], source?: NodeJS.ProcessEnv): Redactor;
export declare function runSteps(steps: Step[], cwd: string, dir: string, execution: ReturnType<typeof executionEnvironment>, signal: AbortSignal, 
/** SHA базы попытки: только с ним шаг установки может стать `dependency-network`. */
trustedBase?: string): Promise<void>;
/**
 * Защищённые пути, которыми владеет подготовка фазы: вложенные `.git`
 * (подмодули, клоны зависимостей), созданные или изменённые её шагами. Пути —
 * относительно корня дерева фазы. Сверки исполнителя, установки и gates той
 * же фазы не считают нарушением только их исчезновение; изменение остаётся
 * нарушением.
 */
export type PreparedProtected = Set<string>;
/** Есть ли у фазы подготовка, которую стоит сверять. */
export declare function preparesTree(lifecycle: Lifecycle | undefined, prepare: readonly Step[], store: unknown): boolean;
/**
 * Сверка защищённых путей вокруг подготовки фазы: шагов lifecycle `setup` и
 * `ready`, хранилища зависимостей и шагов `prepare`. Их задаёт политика, и
 * исполняются они обычным процессом хоста, вне песочницы, — запреты имён на
 * них не действуют. Снимок снимается до `withEnvironment`, сверка — сразу
 * после `prepare`, до черновика, установки и исполнителя.
 *
 * - Вложенный `.git`, созданный или изменённый подготовкой (`git submodule
 *   update --init`, клоны менеджеров зависимостей), разрешён и переходит во
 *   владение подготовки: проверка записывает его в `execution.prepared`, и
 *   сверки исполнителя, установки и gates этой фазы его исчезновение
 *   (уборка фикстуры переносом родителя) нарушением не считают. Изменение
 *   его содержимого или подмена другим `.git` — по-прежнему нарушение.
 * - Любой другой защищённый путь — конфигурация IDE, агента, shell или
 *   корневого `.git` — созданный, изменённый или удалённый подготовкой, —
 *   отказ среды (`sandbox-policy`) с путями в сообщении: его чинит политика,
 *   а не код задачи.
 *
 * Без песочницы ОС (`os = false`) или без подготовки (`active = false`)
 * сверки нет: обходить дерево незачем.
 */
export declare function preparationGuard(os: boolean, root: string, active?: boolean): (execution?: {
    prepared?: PreparedProtected;
}) => void;
/**
 * Точка подмены для тестов: фазы берут сверку подготовки отсюда (как
 * `hostLoad` у gate), и тест проверяет, что каждая фаза её вызывает.
 */
export declare const preparation: {
    guard: typeof preparationGuard;
};
export declare function withEnvironment<T>(lifecycle: Lifecycle | undefined, cwd: string, dir: string, execution: ReturnType<typeof executionEnvironment>, signal: AbortSignal, action: () => Promise<T>, measure?: <R>(stage: string, action: () => Promise<R>) => Promise<R>): Promise<T>;
/**
 * Завершить очистку окружения, прерванную падением процесса: по сохранённому
 * receipt, только внутри разрешённых корней, только при той же политике
 * очистки и только когда процесс-владелец уже не существует (или это он сам,
 * `options.owner`, после окончания попытки).
 */
export declare function cleanupEnvironment(receiptPath: string, policy: ExecutionPolicy, allowedRoots: string[], 
/** `owner` — процесс, который вправе повторить очистку своего окружения сам. */
options?: {
    owner?: number;
}): Promise<{
    status: "already-cleaned";
} | {
    status: "cleaned";
}>;
