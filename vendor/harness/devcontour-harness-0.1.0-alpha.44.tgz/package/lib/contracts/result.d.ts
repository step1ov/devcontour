import { z } from 'zod';
export declare const findingSchema: z.ZodObject<{
    severity: z.ZodString;
    message: z.ZodString;
    path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    rule: z.ZodOptional<z.ZodString>;
    id: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodEnum<{
        closed: "closed";
        open: "open";
        withdrawn: "withdrawn";
    }>>;
}, z.core.$strict>;
export type Finding = z.infer<typeof findingSchema>;
/**
 * Ссылка на доказательство. Само evidence (логи, отчёты) хранит
 * ExecutionStore; результат несёт digest и SHA, по которым его сверяют.
 */
export declare const evidenceRefSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        check: "check";
        review: "review";
        test: "test";
        property: "property";
        consumer: "consumer";
    }>;
    phase: z.ZodEnum<{
        candidate: "candidate";
        integration: "integration";
    }>;
    gate: z.ZodString;
    sha: z.ZodString;
    passed: z.ZodBoolean;
    digest: z.ZodString;
    summary: z.ZodString;
    consumer: z.ZodOptional<z.ZodString>;
    checks: z.ZodOptional<z.ZodString>;
    tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
            skipped: "skipped";
        }>;
        opaque: z.ZodOptional<z.ZodLiteral<true>>;
    }, z.core.$strict>>>;
    testsTruncated: z.ZodOptional<z.ZodBoolean>;
    property: z.ZodOptional<z.ZodObject<{
        level: z.ZodOptional<z.ZodEnum<{
            manifest: "manifest";
            legacy: "legacy";
        }>>;
        manifest: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            properties: z.ZodArray<z.ZodString>;
            corpus: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                cases: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    reviewer: z.ZodOptional<z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        model: z.ZodOptional<z.ZodString>;
        sameVendor: z.ZodBoolean;
    }, z.core.$strict>>;
    review: z.ZodOptional<z.ZodObject<{
        round: z.ZodNumber;
        call: z.ZodNumber;
        protocol: z.ZodEnum<{
            valid: "valid";
            invalid: "invalid";
            unsafe: "unsafe";
        }>;
        issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            reason: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>>>;
        transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            from: z.ZodEnum<{
                closed: "closed";
                open: "open";
                withdrawn: "withdrawn";
            }>;
            to: z.ZodEnum<{
                closed: "closed";
                open: "open";
                withdrawn: "withdrawn";
            }>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type EvidenceRef = z.infer<typeof evidenceRefSchema>;
/**
 * Против чего проверена попытка: снимки зависимостей и их свежесть на момент
 * окончания, проверенная комбинация каждого потребителя. Свежесть
 * записывается, а не запрещает приёмку: устаревший снимок — сведение для
 * получателя, а не отказ (семантика DevContour сохраняется).
 */
export declare const checkedInputsSchema: z.ZodObject<{
    dependencies: z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        sha: z.ZodString;
        tree: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    freshness: z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        snapshot: z.ZodString;
        head: z.ZodString;
        fresh: z.ZodBoolean;
    }, z.core.$strict>>;
    consumers: z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        gates: z.ZodArray<z.ZodString>;
        sha: z.ZodString;
        tree: z.ZodString;
        dependencies: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            sha: z.ZodString;
            tree: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        freshness: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            snapshot: z.ZodString;
            head: z.ZodString;
            fresh: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const outcomes: readonly ["accepted", "rejected", "blocked", "cancelled", "stopped"];
/**
 * Итог работы над одной редакцией поручения. `accepted` — result SHA уже в
 * target ref (result = integration), evidence обеих фаз записано; остальные
 * исходы называют причину остановки кодом из договора ошибок. Различие
 * выражено вариантами, а не проверкой после разбора, поэтому JSON Schema
 * задаёт то же правило.
 */
export declare const runResultSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    outcome: z.ZodLiteral<"accepted">;
    shas: z.ZodObject<{
        base: z.ZodString;
        candidate: z.ZodString;
        integration: z.ZodString;
        result: z.ZodString;
    }, z.core.$strict>;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    workOrderId: z.ZodString;
    graphId: z.ZodString;
    source: z.ZodObject<{
        connector: z.ZodString;
        ref: z.ZodString;
        revision: z.ZodString;
    }, z.core.$strict>;
    runId: z.ZodString;
    attempt: z.ZodNumber;
    repositoryId: z.ZodString;
    targetRef: z.ZodString;
    inputs: z.ZodObject<{
        harnessVersion: z.ZodString;
        consumerVersion: z.ZodOptional<z.ZodString>;
        stateVersion: z.ZodLiteral<1>;
        workOrderDigest: z.ZodString;
        graphDigest: z.ZodString;
        policyDigest: z.ZodString;
        contextDigest: z.ZodOptional<z.ZodString>;
        checks: z.ZodOptional<z.ZodString>;
        corpus: z.ZodOptional<z.ZodObject<{
            suite: z.ZodString;
            number: z.ZodNumber;
            digest: z.ZodString;
        }, z.core.$strict>>;
        requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        writer: z.ZodOptional<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    checked: z.ZodObject<{
        dependencies: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            sha: z.ZodString;
            tree: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        freshness: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            snapshot: z.ZodString;
            head: z.ZodString;
            fresh: z.ZodBoolean;
        }, z.core.$strict>>;
        consumers: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            gates: z.ZodArray<z.ZodString>;
            sha: z.ZodString;
            tree: z.ZodString;
            dependencies: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                sha: z.ZodString;
                tree: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            freshness: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                snapshot: z.ZodString;
                head: z.ZodString;
                fresh: z.ZodBoolean;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    evidence: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            check: "check";
            review: "review";
            test: "test";
            property: "property";
            consumer: "consumer";
        }>;
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        gate: z.ZodString;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        digest: z.ZodString;
        summary: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
        checks: z.ZodOptional<z.ZodString>;
        tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
                skipped: "skipped";
            }>;
            opaque: z.ZodOptional<z.ZodLiteral<true>>;
        }, z.core.$strict>>>;
        testsTruncated: z.ZodOptional<z.ZodBoolean>;
        property: z.ZodOptional<z.ZodObject<{
            level: z.ZodOptional<z.ZodEnum<{
                manifest: "manifest";
                legacy: "legacy";
            }>>;
            manifest: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                properties: z.ZodArray<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodString;
                    cases: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        reviewer: z.ZodOptional<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
            sameVendor: z.ZodBoolean;
        }, z.core.$strict>>;
        review: z.ZodOptional<z.ZodObject<{
            round: z.ZodNumber;
            call: z.ZodNumber;
            protocol: z.ZodEnum<{
                valid: "valid";
                invalid: "invalid";
                unsafe: "unsafe";
            }>;
            issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                reason: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict>>>;
            transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                from: z.ZodEnum<{
                    closed: "closed";
                    open: "open";
                    withdrawn: "withdrawn";
                }>;
                to: z.ZodEnum<{
                    closed: "closed";
                    open: "open";
                    withdrawn: "withdrawn";
                }>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
        severity: z.ZodString;
        message: z.ZodString;
        path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        rule: z.ZodOptional<z.ZodString>;
        id: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<{
            closed: "closed";
            open: "open";
            withdrawn: "withdrawn";
        }>>;
    }, z.core.$strict>>>;
    limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
    finishedAt: z.ZodISODateTime;
}, z.core.$strict>, z.ZodObject<{
    outcome: z.ZodEnum<{
        cancelled: "cancelled";
        rejected: "rejected";
        blocked: "blocked";
        stopped: "stopped";
    }>;
    shas: z.ZodObject<{
        base: z.ZodOptional<z.ZodString>;
        candidate: z.ZodOptional<z.ZodString>;
        integration: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    stopReason: z.ZodObject<{
        code: z.ZodEnum<{
            INVALID_INPUT: "INVALID_INPUT";
            UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
            UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
            GRAPH_CYCLE: "GRAPH_CYCLE";
            GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
            GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
            GATE_UNKNOWN: "GATE_UNKNOWN";
            GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
            REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
            REVIEWER_MISSING: "REVIEWER_MISSING";
            RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
            APPROVAL_STALE: "APPROVAL_STALE";
            APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
            LEASE_STALE: "LEASE_STALE";
            CONTROLLER_BUSY: "CONTROLLER_BUSY";
            PAUSED: "PAUSED";
            NOT_READY: "NOT_READY";
            SCOPE_VIOLATION: "SCOPE_VIOLATION";
            GATE_FAILED: "GATE_FAILED";
            REVIEW_REJECTED: "REVIEW_REJECTED";
            BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
            BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
            ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
            CONTEXT_EXHAUSTED: "CONTEXT_EXHAUSTED";
            INPUT_REQUIRED: "INPUT_REQUIRED";
            REVISION_CONFLICT: "REVISION_CONFLICT";
            CANCELLED: "CANCELLED";
            NOT_FOUND: "NOT_FOUND";
            PATH_CONFLICT: "PATH_CONFLICT";
            STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
            RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
            REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
            SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
            GIT_FAILED: "GIT_FAILED";
            STORAGE_FAILED: "STORAGE_FAILED";
            DELIVERY_FAILED: "DELIVERY_FAILED";
            INTERNAL: "INTERNAL";
        }>;
        message: z.ZodString;
    }, z.core.$strict>;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    workOrderId: z.ZodString;
    graphId: z.ZodString;
    source: z.ZodObject<{
        connector: z.ZodString;
        ref: z.ZodString;
        revision: z.ZodString;
    }, z.core.$strict>;
    runId: z.ZodString;
    attempt: z.ZodNumber;
    repositoryId: z.ZodString;
    targetRef: z.ZodString;
    inputs: z.ZodObject<{
        harnessVersion: z.ZodString;
        consumerVersion: z.ZodOptional<z.ZodString>;
        stateVersion: z.ZodLiteral<1>;
        workOrderDigest: z.ZodString;
        graphDigest: z.ZodString;
        policyDigest: z.ZodString;
        contextDigest: z.ZodOptional<z.ZodString>;
        checks: z.ZodOptional<z.ZodString>;
        corpus: z.ZodOptional<z.ZodObject<{
            suite: z.ZodString;
            number: z.ZodNumber;
            digest: z.ZodString;
        }, z.core.$strict>>;
        requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        writer: z.ZodOptional<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    checked: z.ZodObject<{
        dependencies: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            sha: z.ZodString;
            tree: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        freshness: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            snapshot: z.ZodString;
            head: z.ZodString;
            fresh: z.ZodBoolean;
        }, z.core.$strict>>;
        consumers: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            gates: z.ZodArray<z.ZodString>;
            sha: z.ZodString;
            tree: z.ZodString;
            dependencies: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                sha: z.ZodString;
                tree: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            freshness: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                snapshot: z.ZodString;
                head: z.ZodString;
                fresh: z.ZodBoolean;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    evidence: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            check: "check";
            review: "review";
            test: "test";
            property: "property";
            consumer: "consumer";
        }>;
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        gate: z.ZodString;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        digest: z.ZodString;
        summary: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
        checks: z.ZodOptional<z.ZodString>;
        tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
                skipped: "skipped";
            }>;
            opaque: z.ZodOptional<z.ZodLiteral<true>>;
        }, z.core.$strict>>>;
        testsTruncated: z.ZodOptional<z.ZodBoolean>;
        property: z.ZodOptional<z.ZodObject<{
            level: z.ZodOptional<z.ZodEnum<{
                manifest: "manifest";
                legacy: "legacy";
            }>>;
            manifest: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                properties: z.ZodArray<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodString;
                    cases: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        reviewer: z.ZodOptional<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
            sameVendor: z.ZodBoolean;
        }, z.core.$strict>>;
        review: z.ZodOptional<z.ZodObject<{
            round: z.ZodNumber;
            call: z.ZodNumber;
            protocol: z.ZodEnum<{
                valid: "valid";
                invalid: "invalid";
                unsafe: "unsafe";
            }>;
            issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                reason: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict>>>;
            transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                from: z.ZodEnum<{
                    closed: "closed";
                    open: "open";
                    withdrawn: "withdrawn";
                }>;
                to: z.ZodEnum<{
                    closed: "closed";
                    open: "open";
                    withdrawn: "withdrawn";
                }>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
        severity: z.ZodString;
        message: z.ZodString;
        path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        rule: z.ZodOptional<z.ZodString>;
        id: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<{
            closed: "closed";
            open: "open";
            withdrawn: "withdrawn";
        }>>;
    }, z.core.$strict>>>;
    limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
    finishedAt: z.ZodISODateTime;
}, z.core.$strict>], "outcome">;
export type RunResult = z.infer<typeof runResultSchema>;
/**
 * Состояние доставки результата получателю — отдельно от исхода исполнения.
 * Недоступность получателя не откатывает принятый код; повтор доставки
 * идёт с тем же ключом и не вызывает моделей или интеграции.
 */
export declare const deliveryStateSchema: z.ZodObject<{
    sink: z.ZodString;
    key: z.ZodString;
    revision: z.ZodString;
    status: z.ZodEnum<{
        pending: "pending";
        delivered: "delivered";
        failed: "failed";
        conflict: "conflict";
        uncertain: "uncertain";
    }>;
    attempts: z.ZodNumber;
    lastError: z.ZodOptional<z.ZodString>;
    operation: z.ZodOptional<z.ZodString>;
    currentRevision: z.ZodOptional<z.ZodString>;
    receipt: z.ZodOptional<z.ZodString>;
    updatedAt: z.ZodISODateTime;
}, z.core.$strict>;
export type DeliveryState = z.infer<typeof deliveryStateSchema>;
/** Выход `harness result`: результат и состояние его доставки. */
export declare const resultEnvelopeSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    result: z.ZodDiscriminatedUnion<[z.ZodObject<{
        outcome: z.ZodLiteral<"accepted">;
        shas: z.ZodObject<{
            base: z.ZodString;
            candidate: z.ZodString;
            integration: z.ZodString;
            result: z.ZodString;
        }, z.core.$strict>;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        workOrderId: z.ZodString;
        graphId: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        runId: z.ZodString;
        attempt: z.ZodNumber;
        repositoryId: z.ZodString;
        targetRef: z.ZodString;
        inputs: z.ZodObject<{
            harnessVersion: z.ZodString;
            consumerVersion: z.ZodOptional<z.ZodString>;
            stateVersion: z.ZodLiteral<1>;
            workOrderDigest: z.ZodString;
            graphDigest: z.ZodString;
            policyDigest: z.ZodString;
            contextDigest: z.ZodOptional<z.ZodString>;
            checks: z.ZodOptional<z.ZodString>;
            corpus: z.ZodOptional<z.ZodObject<{
                suite: z.ZodString;
                number: z.ZodNumber;
                digest: z.ZodString;
            }, z.core.$strict>>;
            requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            writer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        checked: z.ZodObject<{
            dependencies: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                sha: z.ZodString;
                tree: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            freshness: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                snapshot: z.ZodString;
                head: z.ZodString;
                fresh: z.ZodBoolean;
            }, z.core.$strict>>;
            consumers: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodString>;
                sha: z.ZodString;
                tree: z.ZodString;
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        evidence: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                check: "check";
                review: "review";
                test: "test";
                property: "property";
                consumer: "consumer";
            }>;
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            digest: z.ZodString;
            summary: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
            checks: z.ZodOptional<z.ZodString>;
            tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                    skipped: "skipped";
                }>;
                opaque: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>>;
            testsTruncated: z.ZodOptional<z.ZodBoolean>;
            property: z.ZodOptional<z.ZodObject<{
                level: z.ZodOptional<z.ZodEnum<{
                    manifest: "manifest";
                    legacy: "legacy";
                }>>;
                manifest: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodString;
                    properties: z.ZodArray<z.ZodString>;
                    corpus: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        cases: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            reviewer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                sameVendor: z.ZodBoolean;
            }, z.core.$strict>>;
            review: z.ZodOptional<z.ZodObject<{
                round: z.ZodNumber;
                call: z.ZodNumber;
                protocol: z.ZodEnum<{
                    valid: "valid";
                    invalid: "invalid";
                    unsafe: "unsafe";
                }>;
                issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    reason: z.ZodString;
                    message: z.ZodString;
                }, z.core.$strict>>>;
                transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    from: z.ZodEnum<{
                        closed: "closed";
                        open: "open";
                        withdrawn: "withdrawn";
                    }>;
                    to: z.ZodEnum<{
                        closed: "closed";
                        open: "open";
                        withdrawn: "withdrawn";
                    }>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
            severity: z.ZodString;
            message: z.ZodString;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            rule: z.ZodOptional<z.ZodString>;
            id: z.ZodOptional<z.ZodString>;
            status: z.ZodOptional<z.ZodEnum<{
                closed: "closed";
                open: "open";
                withdrawn: "withdrawn";
            }>>;
        }, z.core.$strict>>>;
        limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
        finishedAt: z.ZodISODateTime;
    }, z.core.$strict>, z.ZodObject<{
        outcome: z.ZodEnum<{
            cancelled: "cancelled";
            rejected: "rejected";
            blocked: "blocked";
            stopped: "stopped";
        }>;
        shas: z.ZodObject<{
            base: z.ZodOptional<z.ZodString>;
            candidate: z.ZodOptional<z.ZodString>;
            integration: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        stopReason: z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                CONTEXT_EXHAUSTED: "CONTEXT_EXHAUSTED";
                INPUT_REQUIRED: "INPUT_REQUIRED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            message: z.ZodString;
        }, z.core.$strict>;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        workOrderId: z.ZodString;
        graphId: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        runId: z.ZodString;
        attempt: z.ZodNumber;
        repositoryId: z.ZodString;
        targetRef: z.ZodString;
        inputs: z.ZodObject<{
            harnessVersion: z.ZodString;
            consumerVersion: z.ZodOptional<z.ZodString>;
            stateVersion: z.ZodLiteral<1>;
            workOrderDigest: z.ZodString;
            graphDigest: z.ZodString;
            policyDigest: z.ZodString;
            contextDigest: z.ZodOptional<z.ZodString>;
            checks: z.ZodOptional<z.ZodString>;
            corpus: z.ZodOptional<z.ZodObject<{
                suite: z.ZodString;
                number: z.ZodNumber;
                digest: z.ZodString;
            }, z.core.$strict>>;
            requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            writer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        checked: z.ZodObject<{
            dependencies: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                sha: z.ZodString;
                tree: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            freshness: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                snapshot: z.ZodString;
                head: z.ZodString;
                fresh: z.ZodBoolean;
            }, z.core.$strict>>;
            consumers: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodString>;
                sha: z.ZodString;
                tree: z.ZodString;
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        evidence: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                check: "check";
                review: "review";
                test: "test";
                property: "property";
                consumer: "consumer";
            }>;
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            digest: z.ZodString;
            summary: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
            checks: z.ZodOptional<z.ZodString>;
            tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                    skipped: "skipped";
                }>;
                opaque: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>>;
            testsTruncated: z.ZodOptional<z.ZodBoolean>;
            property: z.ZodOptional<z.ZodObject<{
                level: z.ZodOptional<z.ZodEnum<{
                    manifest: "manifest";
                    legacy: "legacy";
                }>>;
                manifest: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodString;
                    properties: z.ZodArray<z.ZodString>;
                    corpus: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        cases: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            reviewer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                sameVendor: z.ZodBoolean;
            }, z.core.$strict>>;
            review: z.ZodOptional<z.ZodObject<{
                round: z.ZodNumber;
                call: z.ZodNumber;
                protocol: z.ZodEnum<{
                    valid: "valid";
                    invalid: "invalid";
                    unsafe: "unsafe";
                }>;
                issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    reason: z.ZodString;
                    message: z.ZodString;
                }, z.core.$strict>>>;
                transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    from: z.ZodEnum<{
                        closed: "closed";
                        open: "open";
                        withdrawn: "withdrawn";
                    }>;
                    to: z.ZodEnum<{
                        closed: "closed";
                        open: "open";
                        withdrawn: "withdrawn";
                    }>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
            severity: z.ZodString;
            message: z.ZodString;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            rule: z.ZodOptional<z.ZodString>;
            id: z.ZodOptional<z.ZodString>;
            status: z.ZodOptional<z.ZodEnum<{
                closed: "closed";
                open: "open";
                withdrawn: "withdrawn";
            }>>;
        }, z.core.$strict>>>;
        limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
        finishedAt: z.ZodISODateTime;
    }, z.core.$strict>], "outcome">;
    delivery: z.ZodArray<z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        status: z.ZodEnum<{
            pending: "pending";
            delivered: "delivered";
            failed: "failed";
            conflict: "conflict";
            uncertain: "uncertain";
        }>;
        attempts: z.ZodNumber;
        lastError: z.ZodOptional<z.ZodString>;
        operation: z.ZodOptional<z.ZodString>;
        currentRevision: z.ZodOptional<z.ZodString>;
        receipt: z.ZodOptional<z.ZodString>;
        updatedAt: z.ZodISODateTime;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ResultEnvelope = z.infer<typeof resultEnvelopeSchema>;
/**
 * Совместная проверка закреплённой комбинации SHA нескольких репозиториев
 * gates уровня workspace (`policy.workspaceGates`). Это техническая
 * проверка; решение о продуктовом принятии (ChangeSet, релиз) принимает
 * хост. Атомарность продвижения нескольких Git-репозиториев не заявляется:
 * результат привязан к manifest, и смена любого SHA делает его устаревшим.
 */
export declare const jointManifestSchema: z.ZodRecord<z.ZodString, z.ZodObject<{
    sha: z.ZodString;
    tree: z.ZodString;
}, z.core.$strict>>;
/** Пределы сохранения artifacts одного gate (`gates[].artifacts`, `workspaceGates[].artifacts`). */
export declare const gateArtifactLimits: {
    /** Объявленных путей у gate задачи. */
    readonly paths: 16;
    readonly files: 64;
    readonly fileBytes: number;
    readonly totalBytes: number;
    /** Записей обхода каталогов: дальше обход не идёт. */
    readonly scan: 4096;
    /** Перечисленных пропусков; остальные считаются в `skippedMore`. */
    readonly skipped: 100;
};
export declare const gateArtifactExtensions: readonly [".png", ".json", ".txt", ".xml", ".log"];
/**
 * Почему файл artifacts не сохранён: `missing` — пути нет; `symlink` — путь
 * или его компонент — ссылка (не разыменовывается); `outside` — путь вне
 * дерева; `not-regular` — не обычный файл; `hardlink` — у файла больше одной
 * жёсткой ссылки (мог быть файлом вне дерева); `secret` — в имени или в байтах
 * не текстового файла найден секрет окружения (изображение не переписывается);
 * `extension` — расширение вне списка; `file-limit`, `total-limit`,
 * `count-limit`, `scan-limit` — пределы; `copy-failed` — чтение или запись
 * копии не удались либо проверка отменена (причина в `detail`).
 */
export declare const gateArtifactSkipReasons: readonly ["missing", "symlink", "outside", "not-regular", "hardlink", "secret", "extension", "file-limit", "total-limit", "count-limit", "scan-limit", "copy-failed"];
/**
 * Artifacts gate, сохранённые как evidence при любом исходе gate: копии в
 * `dir` по путям относительно дерева, SHA-256 и размер сохранённых байтов.
 * `redacted` — в текстовом файле замаскирован секрет окружения: digest
 * относится к копии. Пропуски названы с причиной; исход gate от них не
 * зависит.
 */
export declare const gateArtifactFilesSchema: z.ZodObject<{
    dir: z.ZodString;
    files: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        sha256: z.ZodString;
        bytes: z.ZodNumber;
        redacted: z.ZodOptional<z.ZodLiteral<true>>;
    }, z.core.$strict>>;
    skipped: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        reason: z.ZodEnum<{
            missing: "missing";
            symlink: "symlink";
            outside: "outside";
            "not-regular": "not-regular";
            hardlink: "hardlink";
            secret: "secret";
            extension: "extension";
            "file-limit": "file-limit";
            "total-limit": "total-limit";
            "count-limit": "count-limit";
            "scan-limit": "scan-limit";
            "copy-failed": "copy-failed";
        }>;
        detail: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    skippedMore: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export type GateArtifactFiles = z.infer<typeof gateArtifactFilesSchema>;
export declare const jointEvidenceSchema: z.ZodObject<{
    gate: z.ZodString;
    passed: z.ZodBoolean;
    command: z.ZodArray<z.ZodString>;
    exitCode: z.ZodNumber;
    log: z.ZodString;
    digest: z.ZodString;
    summary: z.ZodString;
    artifacts: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        digest: z.ZodString;
    }, z.core.$strict>>;
    artifactFiles: z.ZodOptional<z.ZodObject<{
        dir: z.ZodString;
        files: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            sha256: z.ZodString;
            bytes: z.ZodNumber;
            redacted: z.ZodOptional<z.ZodLiteral<true>>;
        }, z.core.$strict>>;
        skipped: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            reason: z.ZodEnum<{
                missing: "missing";
                symlink: "symlink";
                outside: "outside";
                "not-regular": "not-regular";
                hardlink: "hardlink";
                secret: "secret";
                extension: "extension";
                "file-limit": "file-limit";
                "total-limit": "total-limit";
                "count-limit": "count-limit";
                "scan-limit": "scan-limit";
                "copy-failed": "copy-failed";
            }>;
            detail: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        skippedMore: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    durationMs: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const jointImpactSchema: z.ZodObject<{
    changed: z.ZodArray<z.ZodString>;
    affected: z.ZodArray<z.ZodString>;
    gateIds: z.ZodArray<z.ZodString>;
    mode: z.ZodEnum<{
        affected: "affected";
        all: "all";
    }>;
    reason: z.ZodString;
    baseline: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
/**
 * Состояния совместной проверки. `active` — начата, manifest ещё может
 * отсутствовать (снимок SHA делается после старта); `failed` — отказ, в том
 * числе до получения manifest; `passed` — только с manifest и его digest.
 * Выдумывать manifest для ранних состояний нельзя.
 */
export declare const jointActiveSchema: z.ZodObject<{
    status: z.ZodLiteral<"active">;
    manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        sha: z.ZodString;
        tree: z.ZodString;
    }, z.core.$strict>>>;
    manifestDigest: z.ZodOptional<z.ZodString>;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    startedAt: z.ZodISODateTime;
    policyDigest: z.ZodString;
    specDigest: z.ZodString;
    workIds: z.ZodArray<z.ZodString>;
    impact: z.ZodOptional<z.ZodObject<{
        changed: z.ZodArray<z.ZodString>;
        affected: z.ZodArray<z.ZodString>;
        gateIds: z.ZodArray<z.ZodString>;
        mode: z.ZodEnum<{
            affected: "affected";
            all: "all";
        }>;
        reason: z.ZodString;
        baseline: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    evidence: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        passed: z.ZodBoolean;
        command: z.ZodArray<z.ZodString>;
        exitCode: z.ZodNumber;
        log: z.ZodString;
        digest: z.ZodString;
        summary: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
        artifactFiles: z.ZodOptional<z.ZodObject<{
            dir: z.ZodString;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                sha256: z.ZodString;
                bytes: z.ZodNumber;
                redacted: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>;
            skipped: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                reason: z.ZodEnum<{
                    missing: "missing";
                    symlink: "symlink";
                    outside: "outside";
                    "not-regular": "not-regular";
                    hardlink: "hardlink";
                    secret: "secret";
                    extension: "extension";
                    "file-limit": "file-limit";
                    "total-limit": "total-limit";
                    "count-limit": "count-limit";
                    "scan-limit": "scan-limit";
                    "copy-failed": "copy-failed";
                }>;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            skippedMore: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const jointFailedSchema: z.ZodObject<{
    status: z.ZodLiteral<"failed">;
    finishedAt: z.ZodISODateTime;
    manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        sha: z.ZodString;
        tree: z.ZodString;
    }, z.core.$strict>>>;
    manifestDigest: z.ZodOptional<z.ZodString>;
    error: z.ZodString;
    interrupted: z.ZodOptional<z.ZodLiteral<true>>;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    startedAt: z.ZodISODateTime;
    policyDigest: z.ZodString;
    specDigest: z.ZodString;
    workIds: z.ZodArray<z.ZodString>;
    impact: z.ZodOptional<z.ZodObject<{
        changed: z.ZodArray<z.ZodString>;
        affected: z.ZodArray<z.ZodString>;
        gateIds: z.ZodArray<z.ZodString>;
        mode: z.ZodEnum<{
            affected: "affected";
            all: "all";
        }>;
        reason: z.ZodString;
        baseline: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    evidence: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        passed: z.ZodBoolean;
        command: z.ZodArray<z.ZodString>;
        exitCode: z.ZodNumber;
        log: z.ZodString;
        digest: z.ZodString;
        summary: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
        artifactFiles: z.ZodOptional<z.ZodObject<{
            dir: z.ZodString;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                sha256: z.ZodString;
                bytes: z.ZodNumber;
                redacted: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>;
            skipped: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                reason: z.ZodEnum<{
                    missing: "missing";
                    symlink: "symlink";
                    outside: "outside";
                    "not-regular": "not-regular";
                    hardlink: "hardlink";
                    secret: "secret";
                    extension: "extension";
                    "file-limit": "file-limit";
                    "total-limit": "total-limit";
                    "count-limit": "count-limit";
                    "scan-limit": "scan-limit";
                    "copy-failed": "copy-failed";
                }>;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            skippedMore: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const jointPassedSchema: z.ZodObject<{
    status: z.ZodLiteral<"passed">;
    finishedAt: z.ZodISODateTime;
    manifest: z.ZodRecord<z.ZodString, z.ZodObject<{
        sha: z.ZodString;
        tree: z.ZodString;
    }, z.core.$strict>>;
    manifestDigest: z.ZodString;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    startedAt: z.ZodISODateTime;
    policyDigest: z.ZodString;
    specDigest: z.ZodString;
    workIds: z.ZodArray<z.ZodString>;
    impact: z.ZodOptional<z.ZodObject<{
        changed: z.ZodArray<z.ZodString>;
        affected: z.ZodArray<z.ZodString>;
        gateIds: z.ZodArray<z.ZodString>;
        mode: z.ZodEnum<{
            affected: "affected";
            all: "all";
        }>;
        reason: z.ZodString;
        baseline: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    evidence: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        passed: z.ZodBoolean;
        command: z.ZodArray<z.ZodString>;
        exitCode: z.ZodNumber;
        log: z.ZodString;
        digest: z.ZodString;
        summary: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
        artifactFiles: z.ZodOptional<z.ZodObject<{
            dir: z.ZodString;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                sha256: z.ZodString;
                bytes: z.ZodNumber;
                redacted: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>;
            skipped: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                reason: z.ZodEnum<{
                    missing: "missing";
                    symlink: "symlink";
                    outside: "outside";
                    "not-regular": "not-regular";
                    hardlink: "hardlink";
                    secret: "secret";
                    extension: "extension";
                    "file-limit": "file-limit";
                    "total-limit": "total-limit";
                    "count-limit": "count-limit";
                    "scan-limit": "scan-limit";
                    "copy-failed": "copy-failed";
                }>;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            skippedMore: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const jointVerificationSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    status: z.ZodLiteral<"active">;
    manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        sha: z.ZodString;
        tree: z.ZodString;
    }, z.core.$strict>>>;
    manifestDigest: z.ZodOptional<z.ZodString>;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    startedAt: z.ZodISODateTime;
    policyDigest: z.ZodString;
    specDigest: z.ZodString;
    workIds: z.ZodArray<z.ZodString>;
    impact: z.ZodOptional<z.ZodObject<{
        changed: z.ZodArray<z.ZodString>;
        affected: z.ZodArray<z.ZodString>;
        gateIds: z.ZodArray<z.ZodString>;
        mode: z.ZodEnum<{
            affected: "affected";
            all: "all";
        }>;
        reason: z.ZodString;
        baseline: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    evidence: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        passed: z.ZodBoolean;
        command: z.ZodArray<z.ZodString>;
        exitCode: z.ZodNumber;
        log: z.ZodString;
        digest: z.ZodString;
        summary: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
        artifactFiles: z.ZodOptional<z.ZodObject<{
            dir: z.ZodString;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                sha256: z.ZodString;
                bytes: z.ZodNumber;
                redacted: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>;
            skipped: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                reason: z.ZodEnum<{
                    missing: "missing";
                    symlink: "symlink";
                    outside: "outside";
                    "not-regular": "not-regular";
                    hardlink: "hardlink";
                    secret: "secret";
                    extension: "extension";
                    "file-limit": "file-limit";
                    "total-limit": "total-limit";
                    "count-limit": "count-limit";
                    "scan-limit": "scan-limit";
                    "copy-failed": "copy-failed";
                }>;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            skippedMore: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"failed">;
    finishedAt: z.ZodISODateTime;
    manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        sha: z.ZodString;
        tree: z.ZodString;
    }, z.core.$strict>>>;
    manifestDigest: z.ZodOptional<z.ZodString>;
    error: z.ZodString;
    interrupted: z.ZodOptional<z.ZodLiteral<true>>;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    startedAt: z.ZodISODateTime;
    policyDigest: z.ZodString;
    specDigest: z.ZodString;
    workIds: z.ZodArray<z.ZodString>;
    impact: z.ZodOptional<z.ZodObject<{
        changed: z.ZodArray<z.ZodString>;
        affected: z.ZodArray<z.ZodString>;
        gateIds: z.ZodArray<z.ZodString>;
        mode: z.ZodEnum<{
            affected: "affected";
            all: "all";
        }>;
        reason: z.ZodString;
        baseline: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    evidence: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        passed: z.ZodBoolean;
        command: z.ZodArray<z.ZodString>;
        exitCode: z.ZodNumber;
        log: z.ZodString;
        digest: z.ZodString;
        summary: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
        artifactFiles: z.ZodOptional<z.ZodObject<{
            dir: z.ZodString;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                sha256: z.ZodString;
                bytes: z.ZodNumber;
                redacted: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>;
            skipped: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                reason: z.ZodEnum<{
                    missing: "missing";
                    symlink: "symlink";
                    outside: "outside";
                    "not-regular": "not-regular";
                    hardlink: "hardlink";
                    secret: "secret";
                    extension: "extension";
                    "file-limit": "file-limit";
                    "total-limit": "total-limit";
                    "count-limit": "count-limit";
                    "scan-limit": "scan-limit";
                    "copy-failed": "copy-failed";
                }>;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            skippedMore: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"passed">;
    finishedAt: z.ZodISODateTime;
    manifest: z.ZodRecord<z.ZodString, z.ZodObject<{
        sha: z.ZodString;
        tree: z.ZodString;
    }, z.core.$strict>>;
    manifestDigest: z.ZodString;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    startedAt: z.ZodISODateTime;
    policyDigest: z.ZodString;
    specDigest: z.ZodString;
    workIds: z.ZodArray<z.ZodString>;
    impact: z.ZodOptional<z.ZodObject<{
        changed: z.ZodArray<z.ZodString>;
        affected: z.ZodArray<z.ZodString>;
        gateIds: z.ZodArray<z.ZodString>;
        mode: z.ZodEnum<{
            affected: "affected";
            all: "all";
        }>;
        reason: z.ZodString;
        baseline: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    evidence: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        passed: z.ZodBoolean;
        command: z.ZodArray<z.ZodString>;
        exitCode: z.ZodNumber;
        log: z.ZodString;
        digest: z.ZodString;
        summary: z.ZodString;
        artifacts: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
        artifactFiles: z.ZodOptional<z.ZodObject<{
            dir: z.ZodString;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                sha256: z.ZodString;
                bytes: z.ZodNumber;
                redacted: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>;
            skipped: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                reason: z.ZodEnum<{
                    missing: "missing";
                    symlink: "symlink";
                    outside: "outside";
                    "not-regular": "not-regular";
                    hardlink: "hardlink";
                    secret: "secret";
                    extension: "extension";
                    "file-limit": "file-limit";
                    "total-limit": "total-limit";
                    "count-limit": "count-limit";
                    "scan-limit": "scan-limit";
                    "copy-failed": "copy-failed";
                }>;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            skippedMore: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>], "status">;
export type JointVerification = z.infer<typeof jointVerificationSchema>;
