import type { FailureKind } from './execution.ts';
import type { EnvironmentCause } from './events.ts';
/** Отказ окружения до начала работы: попытка не засчитывается. */
export declare class BlockedError extends Error {
    name: string;
}
/** Отказ с известным классом. Класс ставит тот, кто отказ обнаружил. */
export declare class TaskFailure extends Error {
    readonly kind: FailureKind;
    /**
     * Свойства, с которыми связан отказ: `bound` — объявленные задачей
     * property ID, `unbound` — названные проверкой или ревьюером, но не
     * объявленные (только для разбора, счётчик эпизода они не выбирают);
     * `classes` — классы входов, названные ревьюером; `pairs` — свойство и
     * класс одной находки.
     */
    readonly properties?: {
        bound: string[];
        unbound: string[];
        classes?: string[];
        pairs?: {
            property: string;
            inputClass: string;
        }[];
    } | undefined;
    /** Причина отказа окружения, известная в точке обнаружения (`attempt.diagnosed`). */
    readonly diagnosis?: EnvironmentCause | undefined;
    constructor(kind: FailureKind, message: string, 
    /**
     * Свойства, с которыми связан отказ: `bound` — объявленные задачей
     * property ID, `unbound` — названные проверкой или ревьюером, но не
     * объявленные (только для разбора, счётчик эпизода они не выбирают);
     * `classes` — классы входов, названные ревьюером; `pairs` — свойство и
     * класс одной находки.
     */
    properties?: {
        bound: string[];
        unbound: string[];
        classes?: string[];
        pairs?: {
            property: string;
            inputClass: string;
        }[];
    } | undefined, 
    /** Причина отказа окружения, известная в точке обнаружения (`attempt.diagnosed`). */
    diagnosis?: EnvironmentCause | undefined);
}
/**
 * Отпечаток отказа: одинаковые сбои должны совпадать, разные — расходиться.
 *
 * Из сообщения убирается всё, что меняется от попытки к попытке, — SHA, id
 * прогонов, пути с временными каталогами, числа, время. Иначе два одинаковых
 * провала одной проверки выглядели бы как два разных, и предел одинаковых
 * повторов не сработал бы ни разу.
 */
export declare function failureFingerprint(kind: FailureKind, message: string): string;
export { MAX_NEUTRAL_FAILURES, repairPolicy, type RepairRule } from './repair-policy.ts';
