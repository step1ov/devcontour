import { type ExecutionPolicy, type ExecutionStore, type ExecutionView, type NotPromise, type WorkflowJob } from '../contracts/index.ts';
/** Стадии работы над графом: 0 — ревью и согласование плана, 1 — исполнение, 2 — завершено. */
export declare const GRAPH_STAGES = 2;
/**
 * Техническая очередь ведущего: долговечные задания над группой поручений
 * (у standalone — граф). Постановка идемпотентна по ключу (предмет и digest
 * входа); владелец задания fenced токеном и сроком; смена или удаление входа
 * делает задание `stale`; стадия сохраняется и переживает рестарт процесса;
 * автоматические восстановления считаются в задании и списываются в одной
 * транзакции с самим повтором.
 */
export declare class WorkflowQueue {
    private readonly store;
    private readonly policy;
    private readonly now;
    constructor(store: ExecutionStore, policy: ExecutionPolicy, now?: () => number);
    /** Digest входа задания: граф, политика и режим согласования. Нет графа — входа нет. */
    input(kind: string, id: string, view: ExecutionView): string | undefined;
    private current;
    list(): {
        kind: string;
        id: string;
        authorRuntime: "codex" | "claude";
        maxAttempts: number;
        key: string;
        inputDigest: string;
        stage: number;
        attempts: number;
        status: "failed" | "completed" | "running" | "queued" | "stale";
        startedAt: string;
        history: {
            at: string;
            stage: number;
            event: string;
        }[];
        owner?: string | undefined;
        repairs?: number | undefined;
        token?: string | undefined;
        leaseUntil?: number | undefined;
        finishedAt?: string | undefined;
        error?: string | undefined;
    }[];
    get(key: string): {
        kind: string;
        id: string;
        authorRuntime: "codex" | "claude";
        maxAttempts: number;
        key: string;
        inputDigest: string;
        stage: number;
        attempts: number;
        status: "failed" | "completed" | "running" | "queued" | "stale";
        startedAt: string;
        history: {
            at: string;
            stage: number;
            event: string;
        }[];
        owner?: string | undefined;
        repairs?: number | undefined;
        token?: string | undefined;
        leaseUntil?: number | undefined;
        finishedAt?: string | undefined;
        error?: string | undefined;
    };
    /** Безопасное представление задания: без токена и срока владения. */
    view(key: string): {
        history: {
            at: string;
            stage: number;
            event: string;
        }[];
        error?: string | undefined;
        key: string;
        kind: string;
        id: string;
        stage: number;
        status: "failed" | "completed" | "running" | "queued" | "stale";
        attempts: number;
        repairs: number;
        repairBudget: number;
    };
    /** Поставить задание; повтор того же входа возвращает прежнее, другой автор — отказ. */
    start(input: {
        kind: 'graph';
        id: string;
        authorRuntime: WorkflowJob['authorRuntime'];
        maxAttempts?: number;
    }): {
        kind: string;
        id: string;
        authorRuntime: "codex" | "claude";
        maxAttempts: number;
        key: string;
        inputDigest: string;
        stage: number;
        attempts: number;
        status: "failed" | "completed" | "running" | "queued" | "stale";
        startedAt: string;
        history: {
            at: string;
            stage: number;
            event: string;
        }[];
        owner?: string | undefined;
        repairs?: number | undefined;
        token?: string | undefined;
        leaseUntil?: number | undefined;
        finishedAt?: string | undefined;
        error?: string | undefined;
    };
    /**
     * Взять стадию задания. Пока применяется политика, стадии не начинаются:
     * они читали бы прежний контекст. Изменившийся вход — `stale`; исчерпанные
     * попытки стадии — `failed`. Чужое действующее владение не перехватывается.
     */
    claim(key: string): {
        kind: string;
        id: string;
        authorRuntime: "codex" | "claude";
        maxAttempts: number;
        key: string;
        inputDigest: string;
        stage: number;
        attempts: number;
        status: "failed" | "completed" | "running" | "queued" | "stale";
        startedAt: string;
        history: {
            at: string;
            stage: number;
            event: string;
        }[];
        owner?: string | undefined;
        repairs?: number | undefined;
        token?: string | undefined;
        leaseUntil?: number | undefined;
        finishedAt?: string | undefined;
        error?: string | undefined;
    } | undefined;
    /** Владение заданием и актуальность входа; иначе — отказ. */
    guard(job: WorkflowJob, view?: ExecutionView): {
        kind: string;
        id: string;
        authorRuntime: "codex" | "claude";
        maxAttempts: number;
        key: string;
        inputDigest: string;
        stage: number;
        attempts: number;
        status: "failed" | "completed" | "running" | "queued" | "stale";
        startedAt: string;
        history: {
            at: string;
            stage: number;
            event: string;
        }[];
        owner?: string | undefined;
        repairs?: number | undefined;
        token?: string | undefined;
        leaseUntil?: number | undefined;
        finishedAt?: string | undefined;
        error?: string | undefined;
    };
    heartbeat(job: WorkflowJob): void;
    /**
     * Завершить стадию. `wait` — стадия ждёт доменного состояния (повтор,
     * пауза) и внешнего действия не выполняла: попытка стадии возвращается, а
     * её запись о захвате снимается. Именно запись о захвате: последним в
     * истории может стоять решение о восстановлении, и оно должно остаться.
     */
    finish(job: WorkflowJob, wait?: boolean, stages?: number): {
        kind: string;
        id: string;
        authorRuntime: "codex" | "claude";
        maxAttempts: number;
        key: string;
        inputDigest: string;
        stage: number;
        attempts: number;
        status: "failed" | "completed" | "running" | "queued" | "stale";
        startedAt: string;
        history: {
            at: string;
            stage: number;
            event: string;
        }[];
        owner?: string | undefined;
        repairs?: number | undefined;
        token?: string | undefined;
        leaseUntil?: number | undefined;
        finishedAt?: string | undefined;
        error?: string | undefined;
    };
    /** Отказ стадии: прерванная — снова в очереди, изменившийся вход — `stale`, иначе `failed`. */
    fail(job: WorkflowJob, message: string, interrupted?: boolean): void;
    /**
     * Записать восстановление и выполнить его одной транзакцией. Счётчик и само
     * действие неразделимы: прерывание между ними дало бы либо повтор без учёта
     * (цикл крутился бы мимо бюджета), либо учёт без повтора.
     */
    repair<T>(job: WorkflowJob, event: string, apply: () => NotPromise<T>): T;
    /** Повтор остановленного задания — решение человека, в пределах попыток стадии. */
    retry(key: string): {
        kind: string;
        id: string;
        authorRuntime: "codex" | "claude";
        maxAttempts: number;
        key: string;
        inputDigest: string;
        stage: number;
        attempts: number;
        status: "failed" | "completed" | "running" | "queued" | "stale";
        startedAt: string;
        history: {
            at: string;
            stage: number;
            event: string;
        }[];
        owner?: string | undefined;
        repairs?: number | undefined;
        token?: string | undefined;
        leaseUntil?: number | undefined;
        finishedAt?: string | undefined;
        error?: string | undefined;
    };
}
