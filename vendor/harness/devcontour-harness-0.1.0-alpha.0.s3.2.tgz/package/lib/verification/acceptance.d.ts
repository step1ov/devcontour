import { type CheckSuite, type ContractDocument, type EvidenceRecord, type ExecutionPolicy, type ExecutionView, type RunResult, type WorkOrder } from '../contracts/index.ts';
import { type CorpusSnapshot } from './checks.ts';
/**
 * Доказательство договора проверки на границе приёмки.
 *
 * Бит PASS и верная версия проверок не доказывают, что генеративный gate
 * исполнил договор поручения: сохранённое evidence без манифеста свойств
 * или с заниженным корпусом выдало бы прежний уровень за сильный. Поэтому и
 * `finish` (а через него recovery), и проверка переносимого результата
 * требуют для каждого gate объявленных свойств решающую запись обеих фаз с
 * манифестом ожидаемой проверки и исполненным обязательным корпусом
 * закреплённой версии. Поручение без `properties` — прежний уровень.
 */
type ProofEvidence = Pick<EvidenceRecord, 'kind' | 'phase' | 'gate' | 'sha' | 'passed'> & {
    consumer?: string | undefined;
    checks?: string | undefined;
    exitCode?: number | undefined;
    property?: Pick<NonNullable<EvidenceRecord['property']>, 'level' | 'manifest'> | undefined;
};
export interface PropertyProofInput {
    order: Pick<WorkOrder, 'properties'>;
    contracts: ContractDocument[];
    candidateSha: string;
    resultSha: string;
    /** Версия проверок попытки (`checks.effective`). */
    effective?: string | undefined;
    /** Случаи закреплённой версии корпуса; `null` — закреплённая версия не найдена. */
    corpus?: CorpusSnapshot | null | undefined;
    evidence: ProofEvidence[];
}
/** Gates объявленных свойств поручения и их свойства. */
export declare function propertyGates(order: Pick<WorkOrder, 'properties'>, contracts: ContractDocument[]): {
    problem: string;
    byGate?: undefined;
} | {
    byGate: Map<string, string[]>;
    problem?: undefined;
};
/** Причина отказа в доказательстве свойств или undefined. */
export declare function propertyProofProblem(input: PropertyProofInput): string | undefined;
/** Случаи закреплённой версии корпуса по состоянию исполнения. */
export declare function pinnedCorpus(view: ExecutionView, binding: {
    suite: string;
    digest: string;
}): CorpusSnapshot | null;
/** Случаи версии корпуса по digest; `null` — версии нет. */
export declare function suiteCorpus(suite: Pick<CheckSuite, 'versions' | 'cases'> | undefined, digest: string): CorpusSnapshot | null;
/** Политика получателя: репозитории (gates, группы, зависимости, target), роли и правила ревью. */
export type ReceiverPolicy = Pick<ExecutionPolicy, 'repositories' | 'roles' | 'review'>;
/**
 * Что получатель знает сам и передаёт проверке. Всё, что результат
 * утверждает о поручении, его области, входах и ревью, сверяется с этим, а не
 * с другими полями того же результата: согласованная сама с собой подделка
 * иначе проходила бы.
 */
export interface ReceiverContext {
    /** Постановка поручения у получателя. */
    order: WorkOrder;
    /** Граф, в котором получатель держит поручение. */
    graphId: string;
    /** Договоры поручения по его ссылкам (документы у получателя). */
    contracts: ContractDocument[];
    /** Политика получателя: репозиторий поручения, потребители и их зависимости, роли, ревью. */
    policy: ReceiverPolicy;
    /**
     * Снимок контекста, закреплённый согласованием графа у получателя; `null` —
     * согласование без контекста.
     */
    contextDigest: string | null;
    /** Корпус по id из копии получателя. */
    suite?: (id: string) => Pick<CheckSuite, 'versions' | 'cases' | 'contractId' | 'basis'> | undefined;
    /** Digest согласованной постановки у хоста получателя; по умолчанию — digest поручения. */
    specDigest?: string;
    /** Закреплённая за поручением версия корпуса у получателя (`null` — без корпуса). */
    checkVersion?: {
        suite: string;
        digest: string;
    } | null;
}
/**
 * Модель доверия получателя: для каждого поля принятого `RunResult` — как
 * оно участвует в вердикте.
 *
 * - `expected` — сверяется с ожиданием, которое получатель вычисляет сам из
 *   `ReceiverContext` (поручение, граф, политика, договоры, корпус, контекст);
 * - `consistency` — сверяется на согласованность с другими полями результата
 *   (SHA фаз, свежесть со снимками, уникальность записей);
 * - `informative` — сведение, которое ничего не доказывает: вердикт на него
 *   не опирается, и его изменение вердикт не меняет;
 * - `schema` — значение фиксировано схемой.
 *
 * Подлинность SHA, деревьев, artifacts и записей (их наличие в Git и в
 * хранилище исполнителя) получатель не удостоверяет: это транспорт хоста.
 * Таблица — проверяемое утверждение: `tests/receipt-trust.test.ts` строит
 * подделку каждого поля `expected`/`consistency` и требует отказа, а изменение
 * поля `informative` — того же вердикта.
 */
export declare const receiptTrust: {
    readonly apiVersion: readonly ["schema", "литерал версии API"];
    readonly outcome: readonly ["expected", "только accepted подтверждает приёмку"];
    readonly workOrderId: readonly ["expected", "ID поручения получателя"];
    readonly graphId: readonly ["expected", "граф поручения у получателя"];
    readonly 'source.connector': readonly ["expected", "источник поручения получателя"];
    readonly 'source.ref': readonly ["expected", "источник поручения получателя"];
    readonly 'source.revision': readonly ["expected", "редакция поручения получателя"];
    readonly runId: readonly ["informative", "идентификатор попытки у исполнителя"];
    readonly attempt: readonly ["informative", "номер попытки у исполнителя"];
    readonly repositoryId: readonly ["expected", "репозиторий поручения"];
    readonly targetRef: readonly ["expected", "target ref репозитория в политике получателя"];
    readonly 'inputs.harnessVersion': readonly ["informative", "версия исполнителя"];
    readonly 'inputs.consumerVersion': readonly ["informative", "версия хоста исполнителя"];
    readonly 'inputs.stateVersion': readonly ["schema", "литерал версии состояния"];
    readonly 'inputs.workOrderDigest': readonly ["expected", "digest поручения получателя"];
    readonly 'inputs.graphDigest': readonly ["informative", "граф мог получить новую редакцию при неизменном поручении; привязка — digest поручения и его источник"];
    readonly 'inputs.policyDigest': readonly ["consistency", "входит в вычисление версии проверок"];
    readonly 'inputs.contextDigest': readonly ["expected", "снимок контекста согласования у получателя"];
    readonly 'inputs.checks': readonly ["expected", "версия проверок, вычисленная получателем"];
    readonly 'inputs.corpus.suite': readonly ["expected", "корпус, закреплённый за поручением у получателя"];
    readonly 'inputs.corpus.number': readonly ["expected", "номер этой версии в корпусе получателя"];
    readonly 'inputs.corpus.digest': readonly ["expected", "версия корпуса, закреплённая у получателя"];
    readonly 'inputs.corpus': readonly ["expected", "привязка к корпусу, закреплённому у получателя"];
    readonly 'inputs.requiredGates': readonly ["expected", "область поручения, раскрытая по политике получателя; без поля — область получателя"];
    readonly 'inputs.requiredGates[]': readonly ["expected", "ровно эта область, без повторов"];
    readonly 'inputs.writer': readonly ["expected", "writer роли поручения; без поля — writer роли получателя"];
    readonly 'inputs.writer.runtime': readonly ["expected", "writer роли поручения в политике получателя"];
    readonly 'inputs.writer.model': readonly ["informative", "модель writer"];
    readonly 'checked.dependencies': readonly ["expected", "замыкание зависимостей репозитория по политике получателя"];
    readonly 'checked.dependencies[]': readonly ["expected", "ровно один снимок каждой зависимости замыкания"];
    readonly 'checked.dependencies[].repositoryId': readonly ["expected", "зависимость из замыкания"];
    readonly 'checked.dependencies[].sha': readonly ["consistency", "совпадает со снимком в свежести"];
    readonly 'checked.dependencies[].tree': readonly ["informative", "подлинность дерева — Git хоста"];
    readonly 'checked.dependencies[].artifacts': readonly ["informative", "подлинность artifacts — Git хоста"];
    readonly 'checked.dependencies[].artifacts[]': readonly ["informative", "подлинность artifacts — Git хоста"];
    readonly 'checked.dependencies[].artifacts[].path': readonly ["informative", "подлинность artifacts — Git хоста"];
    readonly 'checked.dependencies[].artifacts[].digest': readonly ["informative", "подлинность artifacts — Git хоста"];
    readonly 'checked.freshness': readonly ["expected", "свежесть каждой зависимости замыкания"];
    readonly 'checked.freshness[]': readonly ["expected", "ровно одна запись на зависимость"];
    readonly 'checked.freshness[].repositoryId': readonly ["expected", "зависимость из замыкания"];
    readonly 'checked.freshness[].snapshot': readonly ["consistency", "совпадает со снимком зависимости"];
    readonly 'checked.freshness[].head': readonly ["consistency", "fresh ⇔ head = snapshot; значение головы — наблюдение"];
    readonly 'checked.freshness[].fresh': readonly ["consistency", "fresh ⇔ head = snapshot"];
    readonly 'checked.consumers': readonly ["expected", "объявленные потребители поручения"];
    readonly 'checked.consumers[]': readonly ["expected", "ровно одно описание каждого объявленного потребителя"];
    readonly 'checked.consumers[].repositoryId': readonly ["expected", "объявленный потребитель"];
    readonly 'checked.consumers[].gates': readonly ["expected", "область потребителя, раскрытая по политике получателя"];
    readonly 'checked.consumers[].gates[]': readonly ["expected", "ровно эта область, без повторов"];
    readonly 'checked.consumers[].sha': readonly ["consistency", "совпадает со снимком потребителя в его свежести"];
    readonly 'checked.consumers[].tree': readonly ["informative", "подлинность дерева — Git хоста"];
    readonly 'checked.consumers[].dependencies': readonly ["expected", "замыкание зависимостей потребителя по политике получателя"];
    readonly 'checked.consumers[].dependencies[]': readonly ["expected", "ровно один снимок каждой зависимости замыкания"];
    readonly 'checked.consumers[].dependencies[].repositoryId': readonly ["expected", "зависимость из замыкания"];
    readonly 'checked.consumers[].dependencies[].sha': readonly ["consistency", "у провайдера — result SHA; у прочих — снимок в свежести"];
    readonly 'checked.consumers[].dependencies[].tree': readonly ["informative", "подлинность дерева — Git хоста"];
    readonly 'checked.consumers[].dependencies[].artifacts': readonly ["informative", "подлинность artifacts — Git хоста"];
    readonly 'checked.consumers[].dependencies[].artifacts[]': readonly ["informative", "подлинность artifacts — Git хоста"];
    readonly 'checked.consumers[].dependencies[].artifacts[].path': readonly ["informative", "подлинность artifacts — Git хоста"];
    readonly 'checked.consumers[].dependencies[].artifacts[].digest': readonly ["informative", "подлинность artifacts — Git хоста"];
    readonly 'checked.consumers[].freshness': readonly ["expected", "свежесть каждого входа потребителя, кроме провайдера, и его самого"];
    readonly 'checked.consumers[].freshness[]': readonly ["expected", "ровно одна запись на вход"];
    readonly 'checked.consumers[].freshness[].repositoryId': readonly ["expected", "вход потребителя"];
    readonly 'checked.consumers[].freshness[].snapshot': readonly ["consistency", "совпадает со снимком входа"];
    readonly 'checked.consumers[].freshness[].head': readonly ["consistency", "fresh ⇔ head = snapshot; значение головы — наблюдение"];
    readonly 'checked.consumers[].freshness[].fresh': readonly ["consistency", "fresh ⇔ head = snapshot"];
    readonly evidence: readonly ["expected", "решающие записи всех обязательных проверок обеих фаз"];
    readonly 'evidence[]': readonly ["consistency", "записи уникальны по ID"];
    readonly 'evidence[].id': readonly ["consistency", "уникален"];
    readonly 'evidence[].kind': readonly ["consistency", "согласован с gate (ревью ⇔ independent-review) и с потребителем"];
    readonly 'evidence[].phase': readonly ["consistency", "SHA записи — SHA её фазы"];
    readonly 'evidence[].gate': readonly ["expected", "обязательная проверка поручения, потребителя или ревью"];
    readonly 'evidence[].sha': readonly ["consistency", "SHA фазы: candidate или result"];
    readonly 'evidence[].passed': readonly ["expected", "решающая запись каждой обязательной проверки — PASS"];
    readonly 'evidence[].digest': readonly ["informative", "подлинность записи — хранилище исполнителя"];
    readonly 'evidence[].summary': readonly ["informative", "описание записи"];
    readonly 'evidence[].consumer': readonly ["expected", "объявленный потребитель"];
    readonly 'evidence[].checks': readonly ["expected", "версия проверок, вычисленная получателем, у каждой записи"];
    readonly 'evidence[].tests': readonly ["expected", "доказательство названного testcase решающей записью"];
    readonly 'evidence[].tests[]': readonly ["expected", "элемент названного testcase; прочие элементы — сведения"];
    readonly 'evidence[].tests[].id': readonly ["expected", "ID названного testcase"];
    readonly 'evidence[].tests[].status': readonly ["expected", "названный testcase прошёл"];
    readonly 'evidence[].tests[].opaque': readonly ["expected", "имя названного testcase не скрыто"];
    readonly 'evidence[].testsTruncated': readonly ["expected", "список решающей записи полон"];
    readonly 'evidence[].property': readonly ["expected", "доказательство договора проверки; у записи потребителя — только legacy без манифеста"];
    readonly 'evidence[].property.level': readonly ["expected", "уровень manifest; у записи потребителя — legacy"];
    readonly 'evidence[].property.manifest': readonly ["expected", "манифест договора поручения"];
    readonly 'evidence[].property.manifest.digest': readonly ["expected", "манифест, вычисленный получателем"];
    readonly 'evidence[].property.manifest.properties': readonly ["expected", "свойства поручения"];
    readonly 'evidence[].property.manifest.properties[]': readonly ["expected", "свойства поручения"];
    readonly 'evidence[].property.manifest.corpus': readonly ["expected", "корпус закреплённой версии"];
    readonly 'evidence[].property.manifest.corpus.digest': readonly ["expected", "версия корпуса у получателя"];
    readonly 'evidence[].property.manifest.corpus.cases': readonly ["expected", "число случаев этой версии"];
    readonly 'evidence[].reviewer': readonly ["expected", "reviewer, назначенный политикой получателя"];
    readonly 'evidence[].reviewer.runtime': readonly ["expected", "reviewer роли в политике получателя"];
    readonly 'evidence[].reviewer.model': readonly ["informative", "модель reviewer"];
    readonly 'evidence[].reviewer.sameVendor': readonly ["consistency", "вендоры writer и reviewer"];
    readonly findings: readonly ["informative", "сводка находок может относиться к отклонённым раундам"];
    readonly 'findings[]': readonly ["informative", "сводка находок"];
    readonly 'findings[].severity': readonly ["informative", "сводка находок"];
    readonly 'findings[].message': readonly ["informative", "сводка находок"];
    readonly 'findings[].path': readonly ["informative", "сводка находок"];
    readonly 'findings[].line': readonly ["informative", "сводка находок"];
    readonly 'findings[].rule': readonly ["informative", "сводка находок"];
    readonly limitations: readonly ["informative", "чего результат не доказывает"];
    readonly 'limitations[]': readonly ["informative", "чего результат не доказывает"];
    readonly finishedAt: readonly ["informative", "время окончания"];
    readonly 'shas.base': readonly ["informative", "база кандидата; подлинность — Git хоста"];
    readonly 'shas.candidate': readonly ["consistency", "SHA решающих записей кандидата"];
    readonly 'shas.integration': readonly ["consistency", "равен result SHA"];
    readonly 'shas.result': readonly ["consistency", "SHA решающих записей интеграции и снимка провайдера у потребителей"];
};
/**
 * Проверка переносимого результата (receipt) принятой попытки получателем.
 *
 * Получатель повторяет все условия приёмки, проверяемые по результату, против
 * того, что знает сам (`ReceiverContext`); как участвует каждое поле, задаёт
 * `receiptTrust`. Результат не может: относиться к другому поручению,
 * графу, редакции источника, репозиторию или ветке; сократить или подменить
 * область gates; выдать запись другого вида или ревью за test gate;
 * доказать testcase не решающей записью или записью другой версии; убрать
 * проверку источника требований; опустить, повторить или выдумать
 * потребителя, его область или входы; описать неполный, повторный или
 * противоречивый состав зависимостей и свежести; заявить ревью reviewer-ом,
 * которого политика получателя не назначает, или того же вендора без явного
 * разрешения; смешать версии проверок; убрать или занизить манифест и корпус.
 * Чего не хватает в контексте получателя, — отказ, а не PASS. Результат
 * прежнего формата (без версии проверок, области и writer) у поручения без
 * договора проверки читается на прежнем уровне.
 */
export declare function resultProblems(result: RunResult, context: ReceiverContext): string[];
/** Отказ получателя: результат не подтверждает приёмку. */
export declare function assertResult(...args: Parameters<typeof resultProblems>): void;
export {};
