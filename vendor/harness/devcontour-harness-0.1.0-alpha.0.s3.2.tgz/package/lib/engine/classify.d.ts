import { type FailureKind } from './failure.ts';
/** Отказ окружения до начала работы: попытка не засчитывается. */
export declare class BlockedError extends Error {
    name: string;
}
/**
 * Отказ провайдера, а не работы: он повторится на любой следующей выдаче.
 * Список узкий намеренно — временные ошибки сети сюда не входят.
 */
export declare const providerRefusal: (message: string) => boolean;
/** Класс отказа для случаев, где он не поставлен в точке обнаружения. */
export declare function classifyFailure(error: unknown, message: string): FailureKind;
