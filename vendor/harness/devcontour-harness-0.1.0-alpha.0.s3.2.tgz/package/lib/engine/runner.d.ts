import { type ContextSnapshot, type ExecutionPolicy, type RuntimeAdapter, type RuntimeName, type WorkState } from '../contracts/index.ts';
import type { Engine } from './engine.ts';
import { CorpusStore } from '../verification/corpus.ts';
type Repo = ExecutionPolicy['repositories'][number];
export interface RunnerOptions {
    engine: Engine;
    /** Каталог состояния: worktrees, артефакты попыток. Закрыт исполнителю, reviewer и gates. */
    stateDir: string;
    /** Каталог, от которого разрешаются относительные пути репозиториев политики. */
    baseDir: string;
    adapters: Partial<Record<RuntimeName, RuntimeAdapter>>;
    /** Закреплённый контекст поручения; без него — пустой снимок. */
    context?: (work: WorkState) => ContextSnapshot | undefined;
    owner?: string;
    /** Префикс веток попыток; DevContour передаёт свой прежний `devcontour/run-`. */
    branchPrefix?: string;
    /** Внешние значения окружения (секреты политики); по умолчанию — окружение процесса. */
    environment?: NodeJS.ProcessEnv;
    /** База блокировок ресурсов; по умолчанию общая для машины. */
    resourceDatabase?: string;
}
/**
 * Исполнитель очереди. Один действующий controller; попытка проходит
 * реализацию, проверку области, gates и независимое ревью кандидата, затем
 * интеграцию с текущей принятой веткой, gates и ревью integration SHA и
 * приёмку с CAS продвижения target ref внутри транзакции приёмки.
 */
export declare class Runner {
    readonly options: RunnerOptions;
    /** Предел git update-ref приёмки внутри транзакции; конечный и короче lease. */
    static refTimeoutMs: number;
    readonly owner: string;
    private readonly engine;
    private readonly policy;
    private jobs;
    private mergeTails;
    /** Входы незавершённой очистки проверок потребителей, по попыткам. */
    private retained;
    /** Самопроверка исполнителя попытки: каталог (читаем writer) и план. */
    private selfChecks;
    /** Корпус подтверждённых случаев: принятие версий и закреплённые snapshot. */
    readonly corpus: CorpusStore;
    constructor(options: RunnerOptions);
    repoPath(repo: Repo): string;
    private repo;
    /**
     * Закрыто процессам попытки: состояние controller и исходные checkout;
     * открыты их `.git` и закреплённые снимки зависимостей — на чтение.
     */
    private boundary;
    private repositories;
    /** Подготовка репозиториев: целевая ветка существует и не открыта ни в одном worktree. */
    init(): Promise<void>;
    private assertTargetDetached;
    get active(): number;
    /**
     * Актуальность требований на фазе: источник на HEAD репозитория и на
     * проверенном SHA совпадает с закреплённым; evidence псевдо-gate
     * `requirement-source` записывается только при совпадении.
     */
    private requirements;
    private leaseTimer?;
    /**
     * Роль controller продлевается, пока у процесса есть работа; утрата роли
     * прерывает его попытки — новый controller не делит очередь с прежним.
     */
    private keepLead;
    private stopLead;
    /** Освободить роль controller: процесс больше не ведёт очередь. */
    release(): void;
    /** Один шаг очереди до конца: выдать свободные слоты и довести выданное, без новых выдач. */
    step(): Promise<void>;
    /** Один шаг: роль controller, recovery, выдача свободных слотов. */
    tick(): Promise<void>;
    /** Вести очередь, пока есть работа, которую можно выдать или довести. */
    drain(): Promise<void>;
    /** Штатная остановка: пауза `shutdown`, прерывание попыток, освобождение роли controller. */
    stop(): Promise<void>;
    /**
     * Recovery после падения: истёкшая попытка с сохранённым integration SHA,
     * который уже в target ref, принимается заново проверкой всех evidence;
     * иначе она истекает с отказом окружения. Повторный recovery ничего не
     * дублирует: принятая попытка уже не активна.
     */
    /** Когда recovery последний раз искал прерванные вызовы. */
    private abandonScanAt;
    recover(): Promise<void>;
    /**
     * Окружение фазы: политика, репозиторий и — для вызова runtime — профиль
     * инструментов его назначения. Недостающий секрет — отказ окружения до
     * вызова, а не запуск без него.
     */
    private environment;
    private environmentOf;
    private call;
    private workOf;
    private history;
    private adapter;
    /** Область записи кандидата: защищённые пути, пустой результат, выход за область поручения и роли. */
    private assertScope;
    /** Стадия попытки с замером: начало, конец и исход записываются под fencing. */
    private timed;
    /**
     * Кандидат предыдущей попытки вместо новой реализации. Движок уже сверил
     * основания; здесь проверяется сам коммит: ровно один поверх той же базы,
     * рабочее дерево чистое, область прежняя. Проверки и ревью затем идут
     * заново — переиспользуется только написанный код.
     */
    private reuseCandidate;
    /**
     * Время реализации кончилось раньше работы, или она оборвалась. Изменения
     * в области поручения сохраняются патчем к базе: следующая попытка начнёт с
     * них, а не с пустого дерева. Не удалось сохранить — попытка просто
     * начнётся заново.
     */
    private keepDraft;
    /** Накладывает черновик предыдущей попытки, если он есть и годится. */
    private continueDraft;
    private execute;
    /**
     * Убрать рабочие деревья и снимки попытки. При незавершённой очистке
     * (`keep`) ничего не убирается; оставшееся записывается в
     * `cleanup-pending.json` артефактов попытки.
     */
    private removeTrees;
    /**
     * Довести очистку завершённой попытки: повторить незавершённый teardown по
     * каждому сохранённому `environment.json` (входы на месте), затем убрать
     * рабочие деревья и снимки. Идемпотентно: без записи — `nothing-pending`;
     * отказ повторной очистки оставляет запись и входы.
     */
    finishCleanup(attemptId: string): Promise<{
        status: "nothing-pending";
        receipts?: undefined;
    } | {
        status: "cleaned";
        receipts: string[];
    }>;
    private gate;
    /**
     * Ожидаемая проверка генеративного gate. Проверка потребителя исполняет
     * свою объявленную область целиком: договор свойств поручения к
     * одноимённому gate другого компонента не относится и не сужает его.
     */
    private propertyRun;
    /**
     * Проверки потребителей поручения — на integration, в рабочем дереве
     * каждого объявленного потребителя на голове его целевой ветки. Компонент
     * поручения подставлен рабочим деревом integration (его интегрированным
     * результатом), прочие зависимости потребителя — снимок их целевых веток,
     * собранный уже против подстановки. Договор окружения потребителя — как у
     * собственной integration: lifecycle, prepare, gates, cleanup. Что
     * проверено, записывается; рабочие деревья убираются и при отказе, а отказ
     * очистки не скрывается.
     */
    private consumers;
    /**
     * Независимое ревью точного SHA. Отказ — отсутствие одобрения, блокирующая
     * находка, ответ вне схемы, изменение дерева или HEAD reviewer-ом. Ответ
     * reviewer маскируется целиком перед записью.
     */
    /**
     * Инструмент проверок reviewer с пределами controller — только тому, кто и
     * так может запускать команды: права reviewer он не расширяет, а
     * ограничивает срок. Спецификация лежит в каталоге ревью; значения
     * переменных окружения CLI передаёт серверу по имени, на диск они не пишутся.
     */
    private reviewProbe;
    private review;
    /**
     * Обязательный корпус попытки (первые 20 случаев) и — исполнителю —
     * решение разбора ведущего, под которым выдан повтор.
     */
    /**
     * Самопроверка исполнителя для поручения со свойствами: закреплённый checker,
     * полный корпус версии попытки и seed. Диагностика: gates от неё не зависят.
     */
    private prepareSelfCheck;
    private notes;
    /**
     * Ограниченный эксперимент выполнимости тяжёлого обязательства: команда на
     * закреплённом SHA под изоляцией gates, с пределом времени на размер.
     */
    spike(raw: unknown): Promise<{
        id: string;
        repositoryId: string;
        sha: string;
        command: string[];
        seed: number;
        sizes: number[];
        timeoutMs: number;
        question: string;
        results: {
            size: number;
            ms: number;
            outcome: "error" | "ok" | "timeout";
            exitCode: number;
        }[];
        outcome: "failed" | "feasible" | "inconclusive";
        limits: string;
        environment: {
            platform: string;
            arch: string;
            node: string;
            cpus: number;
            isolation: string;
        };
        at: string;
        digest: string;
    }>;
    /**
     * Подтвердить пример закреплённым эталоном (быстрый маршрут корпуса). Ни
     * команда воспроизведения, ни данные входа не исполняются.
     */
    submitCase(raw: unknown): Promise<{
        suite: string;
        repeated: boolean;
        decision: {
            id: string;
            property: string;
            input: string;
            inputHash: string;
            outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
            reason: string;
            source: {
                sha: string;
                runId?: string | undefined;
                taskId?: string | undefined;
            };
            origin: {
                kind: "review" | "agent" | "operator" | "lead";
                runtime?: string | undefined;
            };
            at: string;
            key?: string | undefined;
            claimed?: {
                expected: string | null;
                actual: string | null;
                reproduction?: string | undefined;
            } | undefined;
            observed?: {
                repeats: number;
                durationsMs: number[];
                expected?: string | undefined;
                actual?: string | undefined;
                equal?: boolean | undefined;
            } | undefined;
            method?: {
                gate: string;
                command: string[];
                artifacts: {
                    path: string;
                    blob: string;
                }[];
                contract: string;
                basis: string;
            } | undefined;
            caseId?: string | undefined;
            version?: number | undefined;
        };
        version: {
            number: number;
            digest: string;
            cases: number;
        } | null;
        adoption: {
            awaitingOperator?: true | undefined;
            id: string;
            status: "completed" | "waiting";
            results: Record<string, string>;
        }[];
    }>;
    /**
     * Воспроизведения из отклонившего ревью попытки по объявленным свойствам —
     * на подтверждение эталоном. Не больше пяти; отказ одного не мешает другим.
     */
    private confirmReproductions;
    private integrate;
}
export {};
