import type { Engine } from './engine.ts';
export interface JointRunnerOptions {
    engine: Engine;
    /** Каталог состояния: здесь снимки компонентов, manifest, логи и отчёты. */
    stateDir: string;
    baseDir: string;
    environment?: NodeJS.ProcessEnv;
    resourceDatabase?: string;
}
/**
 * Исполнение совместной проверки: снимки target ref всех репозиториев
 * (результат каждого поручения набора должен в них входить), manifest,
 * gates уровня workspace в песочнице проверок, сверка целостности после
 * каждого gate. Записи — только через fencing движка; отказ сохраняется с
 * маской окружений всех репозиториев.
 */
export declare class JointRunner {
    readonly options: JointRunnerOptions;
    readonly engine: Engine;
    private readonly policy;
    constructor(options: JointRunnerOptions);
    private repoPath;
    /** Начать и провести проверку набора поручений. */
    verify(workIds: string[], options?: {
        baseline?: string;
        signal?: AbortSignal;
    }): Promise<{
        status: "active";
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "failed";
        finishedAt: string;
        error: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "passed";
        finishedAt: string;
        manifest: Record<string, {
            sha: string;
            tree: string;
        }>;
        manifestDigest: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    }>;
    private execute;
}
