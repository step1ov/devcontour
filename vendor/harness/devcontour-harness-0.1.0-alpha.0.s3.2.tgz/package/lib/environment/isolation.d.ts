/**
 * Одна политика изоляции для исполнителя, ревьюера и проверок.
 *
 * Раньше граница зависела от того, кто исполняет: codex-исполнитель читал
 * любые файлы пользователя, claude-ревьюер без песочницы мог писать куда
 * угодно, а проверки шли обычным процессом хоста. Здесь граница описана один
 * раз, а применяет её механизм, родной для каждого: песочница codex (профиль
 * прав), песочница Claude Code (sandbox settings) и sandbox-runtime для
 * проверок. Все три — один класс механизма ОС (Seatbelt на macOS,
 * bubblewrap на Linux).
 *
 * - `write` — куда можно писать; всё остальное закрыто на запись.
 * - `hidden` — что закрыто на чтение: база и рабочие каталоги контура,
 *   каталоги учётных данных.
 * - `readable` — что внутри скрытого снова открыто: собственный worktree,
 *   закреплённые зависимости. Более конкретный путь побеждает.
 * - `domains` — внешние адреса; без них сеть закрыта. Проверкам остаётся
 *   localhost: тесты сервисов поднимают его сами.
 */
export interface Isolation {
    write: string[];
    hidden: string[];
    readable: string[];
    domains: string[];
}
/**
 * Каталоги учётных данных. Закрыть весь $HOME нельзя — там проверяемый
 * checkout и инструменты, — поэтому закрываются известные места ключей и
 * токенов. Пути абсолютные: не каждый механизм раскрывает `~`.
 */
export declare function credentialPaths(home?: string): string[];
export declare function isolation(options: {
    write: string[];
    controller: string[];
    readable?: string[];
    domains?: string[];
}): Isolation;
/** Sandbox Claude Code: применяется к Bash; без запасного выхода из песочницы. */
export declare function claudeSandbox(policy: Isolation, review: boolean, cwd: string): {
    permissions: {
        deny: string[];
    };
    sandbox: {
        enabled: boolean;
        failIfUnavailable: boolean;
        allowUnsandboxedCommands: boolean;
        autoAllowBashIfSandboxed: boolean;
        network: {
            allowedDomains: string[];
            allowLocalBinding: boolean;
        };
        filesystem: {
            denyRead: string[];
            allowRead: string[];
            denyWrite?: string[] | undefined;
            allowWrite: string[];
        };
    };
};
/**
 * Запреты для встроенных файловых инструментов claude (Read, Edit, Write…).
 *
 * Песочница Claude Code применяется только к Bash; файловые инструменты
 * подчиняются правилам прав. Скрытый путь закрывается правилом, если он не
 * предок рабочего каталога: иначе запрет закрыл бы и сам worktree. Такие
 * предки лежат вне рабочего каталога, а чтение вне него в неинтерактивном
 * режиме и так отклоняется. Главное здесь — скрытое внутри рабочего каталога:
 * база контура в embedded-режиме лежит прямо в проверяемом checkout.
 */
export declare function claudeFileDenies(policy: Isolation, cwd: string | undefined): string[];
/** Файловые инструменты claude: их заранее выданные разрешения при изоляции снимаются. */
export declare const claudeFileTools: string[];
/**
 * Профиль прав codex: карта путей с уровнем доступа. Более конкретный путь
 * побеждает, поэтому worktree внутри скрытого каталога контура остаётся
 * доступным. Временный каталог открыт на запись: проверкам ревьюера и
 * исполнителя нужна запись вне проверяемого кода.
 */
export declare function codexPermissions(policy: Isolation, network: boolean): string[];
/** Готов ли механизм изоляции проверок на этой машине. */
export declare function isolationSupport(): {
    ok: boolean;
    detail: string;
};
/**
 * Команда проверки внутри sandbox-runtime.
 *
 * Настройки пишутся в файл: srt отказывает, если файл пуст или невалиден, и
 * не откатывается к умолчаниям. Собственный служебный сокет srt кладёт во
 * временный каталог процесса, поэтому srt получает короткий системный
 * TMPDIR, а команде внутри передаётся свой scratch.
 */
export declare function isolatedCommand(policy: Isolation, argv: string[], settingsDir: string, scratch: string, 
/**
 * Файл, который обёртка создаёт внутри песочницы перед exec команды. Его
 * отсутствие — единственный достоверный признак, что команда не начиналась.
 */
started: string): Promise<{
    argv: string[];
    env: {
        TMPDIR: string;
    };
}>;
