import { type Author, type ContextSnapshot, type ExecutionPolicy, type WorkGraph } from '../../contracts/index.ts';
import type { Harness } from '../../control/harness.ts';
import type { RunnerHooks } from '../../engine/runner.ts';
import { type LoadedConfig } from './config.ts';
import { RelaySink, type ReconcileDecision } from './delivery.ts';
import { HistoryRecorder } from './history.ts';
import { type BaselineManifest } from './snapshot.ts';
import { RelayWorkSource } from './source.ts';
import { ConnectorStore } from './store.ts';
import type { RelayTransport } from './transport.ts';
/**
 * Пользовательский путь коннектора — общий для CLI и библиотеки:
 * `check` → `snapshot` → (review-plan/approve) → `run` → `status` →
 * `deliver`/`reconcile`. Ни одна операция не требует писать TypeScript.
 */
export declare const OWNERSHIP_NOTE = "\u041E\u0434\u0438\u043D \u0432\u043B\u0430\u0434\u0435\u043B\u0435\u0446 \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0438 \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0440\u043E\u0432\u0430\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0432 \u0441 \u043E\u0431\u0449\u0438\u043C \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u043E\u043C \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u043A\u043E\u043D\u043D\u0435\u043A\u0442\u043E\u0440\u0430 (lease \u0441 fencing \u0432 \u0435\u0433\u043E SQLite). \u041D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u0435 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0438 \u0441 \u0440\u0430\u0437\u043D\u044B\u043C\u0438 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430\u043C\u0438 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u0432\u043D\u0435 \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0438: \u043E\u043D\u0438 \u043C\u043E\u0433\u0443\u0442 \u0434\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043E\u0434\u043D\u0443 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044E \u0434\u0432\u0430\u0436\u0434\u044B.";
export interface OpenOptions {
    /** Каталог состояния harness (`--state`); используется, если в конфигурации нет `stateDir`. */
    stateDir: string;
    /** Готовый транспорт (тесты, библиотека); без него — адаптер по provider. */
    transport?: RelayTransport;
    /** Значения, которые маскируются в итогах для получателя. */
    secrets?: string[];
    /** Точка отказа записи состояния коннектора (тесты). */
    onStoreWrite?: (what: string) => void;
    owner?: string;
}
export declare function openConnector(source: string | LoadedConfig, options: OpenOptions): Promise<Connector>;
export declare class Connector {
    readonly loaded: LoadedConfig;
    readonly options: OpenOptions;
    readonly id: string;
    readonly stateDir: string;
    readonly storeFile: string;
    private storeInstance?;
    private readonly redact;
    /** Транспорт с замаскированными ошибками (известные секреты не выходят в диагностику). */
    readonly transport: RelayTransport;
    constructor(loaded: LoadedConfig, transport: RelayTransport, options: OpenOptions);
    get config(): {
        provider: "relay-v1-http";
        relay: Record<string, unknown> & {
            [x: string]: unknown;
            endpoint: string;
        };
        version: 1;
        projectId: string;
        actor: string;
        repository: {
            id: string;
            path?: string | undefined;
        };
        tasks: {
            ref: string;
            role: string;
            writeScope: string[];
            criteria: {
                gate: string;
                evidence: "gate" | "test";
                id?: string | undefined;
                title?: string | undefined;
                testId?: string | undefined;
            }[];
            requiredDocuments: string[];
            repositoryId?: string | undefined;
            gates?: string[] | undefined;
            context?: string[] | undefined;
        }[];
        completion: {
            mode: "complete" | "review-only";
            historicalComment: boolean;
            column?: "ready" | "review" | "cancelled" | "done" | "in-progress" | "inbox" | undefined;
        };
        eligibility: {
            columns: ("ready" | "review" | "cancelled" | "done" | "in-progress" | "inbox")[];
        };
        limits: {
            documents: number;
            documentBytes: number;
            totalBytes: number;
            taskBytes: number;
            rereads: number;
            leaseMs: number;
        };
        history: {
            enabled: boolean;
            client: string;
        };
        stateDir?: string | undefined;
        contextDir?: string | undefined;
        baseline?: {
            sha: string;
            tasks: string[];
            reason: string;
        } | undefined;
    } | {
        provider: "relay-v2-cli";
        relay: Record<string, unknown> & {
            [x: string]: unknown;
            binary: string;
            config: string;
            project?: string | undefined;
            env?: Record<string, string> | undefined;
        };
        version: 1;
        projectId: string;
        actor: string;
        repository: {
            id: string;
            path?: string | undefined;
        };
        tasks: {
            ref: string;
            role: string;
            writeScope: string[];
            criteria: {
                gate: string;
                evidence: "gate" | "test";
                id?: string | undefined;
                title?: string | undefined;
                testId?: string | undefined;
            }[];
            requiredDocuments: string[];
            repositoryId?: string | undefined;
            gates?: string[] | undefined;
            context?: string[] | undefined;
        }[];
        completion: {
            mode: "complete" | "review-only";
            historicalComment: boolean;
            column?: "ready" | "review" | "cancelled" | "done" | "in-progress" | "inbox" | undefined;
        };
        eligibility: {
            columns: ("ready" | "review" | "cancelled" | "done" | "in-progress" | "inbox")[];
        };
        limits: {
            documents: number;
            documentBytes: number;
            totalBytes: number;
            taskBytes: number;
            rereads: number;
            leaseMs: number;
        };
        history: {
            enabled: boolean;
            client: string;
        };
        stateDir?: string | undefined;
        contextDir?: string | undefined;
        baseline?: {
            sha: string;
            tasks: string[];
            reason: string;
        } | undefined;
    };
    /** Каталог пакетов `tasks[].context`: `contextDir` конфигурации, иначе `work/context` рядом с ней. */
    get contextDir(): string;
    /** Состояние коннектора (создаётся при первой записи). */
    get store(): ConnectorStore;
    /** Только чтение: без создания файла; нет состояния — `undefined`. */
    private readStore;
    get source(): RelayWorkSource;
    get history(): HistoryRecorder;
    get sink(): RelaySink;
    /** Хуки runner для `HarnessOptions.hooks`: история до исполнения попытки. */
    hooks(): RunnerHooks;
    close(): void;
    /**
     * `baseline` — решение человека, поэтому файл конфигурации не должен быть
     * доступен писателю поручения: он вне репозиториев политики или в их
     * `protectedPaths` (runner отказывает попытке, которая их меняет).
     */
    baselineIssue(policy: ExecutionPolicy, baseDir: string): string | undefined;
    assertBaselineProtected(policy: ExecutionPolicy, baseDir: string): void;
    /**
     * Подключение, идентичность, capabilities, совпадение проекта и mapping —
     * только чтением: без мутаций backend, без записи истории и без создания
     * состояния коннектора.
     */
    check(policy?: ExecutionPolicy, baseDir?: string): Promise<{
        history: {
            enabled: boolean;
            capability: boolean;
        };
        mapping: {
            ref: string;
            key?: string;
            problems: string[];
        }[];
        ownership: {
            stateDir: string;
            store: string;
            note: string;
        };
        problems: string[];
        identity?: {
            capabilities: string[];
            build: Record<string, string>;
        } | undefined;
        provider: "relay-v1-http" | "relay-v2-cli";
        projectId: string;
        connector: string;
        connected: boolean;
        projectMatches: boolean;
    }>;
    private checkReport;
    /**
     * Прочитать и предпросмотреть снимок; записать graph/context/manifest для
     * `review-plan`/`approve`. Снимок закрепляется в состоянии коннектора по
     * semantic digest: повтор неизменной постановки ничего не меняет, а возврат
     * к прежней редакции снова закрепляет её запись (`created: false`).
     */
    snapshot(outDir?: string): Promise<{
        tasks: {
            identity: string;
            key: string;
            orderId: string;
            semanticDigest: string;
            casRevision: number;
            column: string;
        }[];
        files: {
            graph: string;
            context: string;
            manifest: string;
        };
        snapshot: import("./snapshot.ts").BuiltSnapshot;
        baseline?: BaselineManifest | undefined;
        revision: string;
        created: boolean;
        eligible: boolean;
        problems: string[];
        truncated: string[];
        localContext?: {
            id: string;
            digest: string;
            files: number;
            references: number;
            bytes: number;
        }[] | undefined;
        connector: string;
        graphId: string;
        graphDigest: string;
        contextDigest: string;
    }>;
    /**
     * Перед запуском — свежее чтение: semantic digest обязан совпасть с
     * закреплённым снимком (тем, что прошёл ревью/согласование), eligibility —
     * выполняться. Иначе отказ до любого вызова runtime. Исполняется ровно
     * закреплённый граф и контекст (те же байты, что видел reviewer плана).
     */
    prepareRun(h: Harness): Promise<{
        graph: WorkGraph;
        context: ContextSnapshot;
        baseline?: BaselineManifest;
    }>;
    run(h: Harness, options?: {
        author?: Author;
        once?: boolean;
    }): Promise<{
        baseline?: BaselineManifest | undefined;
        works: {
            blockers: {
                code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT";
                message: string;
            }[];
            resultSha?: string | undefined;
            runId?: string | undefined;
            id: string;
            status: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        }[];
        workflow?: {
            history: {
                at: string;
                stage: number;
                event: string;
            }[];
            error?: string | undefined;
            key: string;
            kind: string;
            id: string;
            stage: number;
            status: "failed" | "completed" | "running" | "queued" | "stale";
            attempts: number;
            repairs: number;
            repairBudget: number;
        } | undefined;
        graphId: string;
        digest: string;
        resumed: boolean;
    }>;
    private workIds;
    /**
     * Локальное состояние (принято, доставлено, конфликт, неизвестный исход) и
     * независимое чтение получателя. Ошибка чтения получателя показывается, а не
     * заменяется пустым состоянием.
     */
    status(h?: Harness): Promise<{
        ownership: {
            stateDir: string;
            store: string;
            note: string;
        };
        tasks: {
            workId: string;
            local: {
                resultSha?: string | undefined;
                status: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
                attempt: number;
            } | {
                status: string;
            };
            deliveries: {
                status: string;
                key: string;
                operation?: string;
            }[];
            operations: {
                steps: {
                    n: number;
                    kind: "history" | "comment" | "historical-comment" | "criterion" | "move" | "session.start" | "session.intent" | "session.fork" | "session.attach" | "session.checkpoint" | "session.finish";
                    status: import("./store.ts").StepStatus;
                    marker: string;
                }[];
                lease: {
                    owner: string;
                    expiresAt: string;
                } | undefined;
                currentRevision?: string | undefined;
                reason?: string | undefined;
                key: string;
                runId: string;
                outcome: string;
                status: import("./store.ts").OperationStatus;
            }[];
            remote: Record<string, unknown>;
            key?: string | undefined;
            identity?: string | undefined;
            index: number;
            ref: string;
        }[];
        snapshot?: {
            baseline?: BaselineManifest | undefined;
            revision: string;
            graphId: string;
        } | undefined;
        connector: string;
        provider: "relay-v1-http" | "relay-v2-cli";
        projectId: string;
    }>;
    /** Доставить результаты (повтор — с тем же ключом, без writer/reviewer и Git). */
    deliver(h: Harness, workId?: string): Promise<{
        connector: string;
        deliveries: {
            workId: string;
            delivery: {
                sink: string;
                key: string;
                revision: string;
                status: "failed" | "pending" | "delivered" | "conflict" | "uncertain";
                attempts: number;
                updatedAt: string;
                lastError?: string | undefined;
                operation?: string | undefined;
                currentRevision?: string | undefined;
                receipt?: string | undefined;
            }[];
            outcome: "accepted" | "rejected" | "blocked" | "cancelled" | "stopped";
        }[];
    }>;
    /** Разбор неизвестного исхода/конфликта и, если факты позволяют, продолжение доставки. */
    reconcile(h: Harness, operation: string, decision?: ReconcileDecision): Promise<{
        delivery?: {
            sink: string;
            key: string;
            revision: string;
            status: "failed" | "pending" | "delivered" | "conflict" | "uncertain";
            attempts: number;
            updatedAt: string;
            lastError?: string | undefined;
            operation?: string | undefined;
            currentRevision?: string | undefined;
            receipt?: string | undefined;
        }[] | undefined;
        operation: string;
        workId: string;
        before: "failed" | "delivered" | "conflict" | "uncertain" | "intent" | "in-progress";
        after: import("./store.ts").OperationStatus;
        resolved: boolean;
        facts: string[];
    }>;
    /** Расшифровка решения CLI `--decision resend|recheck|adopt:<id>`. */
    static decision(text: string | undefined): ReconcileDecision | undefined;
}
