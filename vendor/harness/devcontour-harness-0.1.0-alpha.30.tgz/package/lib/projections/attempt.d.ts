import type { WorkStatus } from './enums.ts';
/** Сохранённая попытка в объёме, который нужен проекции (`AttemptState`). */
export interface AttemptViewInput {
    id: string;
    workId: string;
    attempt: number;
    status: string;
    /** Статус поручения на этой попытке (`AttemptState.phase`). */
    phase: WorkStatus;
    owner: string;
    runtime: string;
    model?: string;
    startedAt: string;
    /** Срок владения, epoch ms. */
    leaseUntil: number;
    timings?: readonly {
        id: string;
        stage: string;
        startedAt: string;
        finishedAt?: string;
        outcome?: 'passed' | 'failed';
    }[];
    /** Кандидат и интеграция попытки: gates считаются только по записям текущего SHA фазы. */
    candidateSha?: string;
    integrationSha?: string;
    evidence: readonly {
        kind: 'test' | 'review';
        phase: 'candidate' | 'integration';
        sha: string;
        gate: string;
        passed: boolean;
        consumer?: string;
    }[];
    /** Gates, которые попытка обязана пройти в каждой фазе (`AttemptState.requiredGates`). */
    requiredGates?: readonly string[];
}
export interface AttemptViewOptions {
    /** Текущее время, epoch ms. */
    now: number;
    /**
     * Длина владения политики (`leaseMs`): heartbeat продлевает срок на неё.
     * У CLI — политика из `binding.json` каталога состояния, у библиотеки —
     * политика `Harness`; другая политика процесса-владельца даст другую оценку.
     */
    leaseMs: number;
    /** Gates репозитория, когда у попытки нет `requiredGates` (прежние записи). */
    repositoryGates?: readonly string[];
}
export interface AttemptView {
    runId: string;
    workId: string;
    attempt: number;
    status: string;
    phase: WorkStatus;
    runtime: string;
    model?: string;
    startedAt: string;
    elapsedMs: number;
    /**
     * Текущая стадия — последний начатый и не закрытый замер; нет — между
     * стадиями. `family` — имя без уточнений после `:` (`candidate-test`).
     */
    stage?: {
        name: string;
        family: string;
        startedAt: string;
        elapsedMs: number;
    };
    /**
     * Владение: последний heartbeat выводится из срока (`leaseUntil − leaseMs`);
     * `stale` — срок истёк, владелец больше не может писать. Срок `0` (владение
     * отозвано, например отказом recovery) heartbeat не означает:
     * `sinceHeartbeatMs` тогда нет.
     */
    lease: {
        owner: string;
        leaseUntil: number;
        leaseMs: number;
        sinceHeartbeatMs?: number;
        stale: boolean;
    };
    /**
     * Обязательные gates текущей фазы (интеграции — в `integrating`, иначе
     * кандидата) по последней записи каждого gate на текущем SHA фазы, без
     * проверок потребителей: прошли, не прошли, ещё без записи. Записи других
     * gates и других SHA не считаются: `passed + failed + remaining = required`.
     */
    gates: {
        phase: 'candidate' | 'integration';
        required: number;
        passed: number;
        failed: number;
        remaining: number;
    };
}
/**
 * Активная попытка глазами наблюдателя: стадия и её длительность, свежесть
 * владения, прогресс gates. Чистая функция сохранённой попытки и часов —
 * без node:*, её же используют `status --detail` и хост.
 */
export declare function attemptView(input: AttemptViewInput, options: AttemptViewOptions): AttemptView;
