import type { AttemptState, CallRecord, GraphState, WorkState } from '../contracts/execution.ts';
import type { RunEvent } from '../contracts/events.ts';
import type { ReviewRecord } from '../contracts/review.ts';
import type { FailureBucket, ValueReport } from '../contracts/report.ts';
/** Литералы `src/contracts/report.ts` (тест сверяет поэлементно). */
export declare const reportVersion = 1;
export declare const reportLimits: {
    readonly works: 50;
    readonly evidence: 50;
    readonly weeks: 12;
    readonly rows: 50;
    readonly jsonBytes: number;
    readonly htmlBytes: number;
};
export declare const failureBucketNames: readonly ["defect", "incomplete", "integration", "environment", "time-limit", "tool", "operator", "budget", "unknown", "unclassified"];
/** Данные исполнения: те же формы, что отдают `ExecutionView` и `events()`. */
export interface ValueReportInput {
    works: readonly WorkState[];
    attempts: readonly AttemptState[];
    /** Записи учёта вызовов (`locals('usage')`). */
    calls?: readonly CallRecord[];
    /** Раунды ревью плана и контрактов (`locals('reviews')`). */
    reviews?: readonly ReviewRecord[];
    /** Журнал событий: паузы и согласования. */
    events?: readonly RunEvent[];
    /** Графы: согласования, если событий нет. */
    graphs?: readonly GraphState[];
}
export interface ValueReportOptions {
    /** Начало окна (включительно): ISO-время с поясом, дата `YYYY-MM-DD` или `7d`/`4w` до `asOf`. */
    since?: string;
    /** Конец окна (не включительно): ISO-время с поясом или дата. */
    until?: string;
    /** Момент отчёта; по умолчанию — последняя метка времени в данных (не часы). */
    asOf?: string;
    /** Без заголовков поручений и метки проекта. */
    noTitles?: boolean;
    /** Версия harness в заголовке. */
    harnessVersion?: string;
    /** Метка проекта (например, имя каталога состояния). */
    label?: string;
    /** Каталог состояния: пути evidence записываются относительно него. */
    stateDir?: string;
}
/**
 * Корзина отказа попытки; `null` — попытка не отказ (успех, идёт) или
 * прервана штатной остановкой (`interrupted`, считается отдельно).
 * Отказ окружения (`blocked`) и истёкшее владение — `environment`; попытка
 * без класса (записана до классификации) — `unclassified`, а не «проект».
 */
export declare function failureBucketOf(a: AttemptState): FailureBucket | null;
/**
 * Путь evidence для отчёта: относительно каталога состояния; путь вне него
 * (в том числе в домашнем каталоге) — только имя файла после `…/`.
 */
export declare function reportPath(path: string | undefined, stateDir: string | undefined): string | null;
/** Цена вызова известна — то же правило, что `knownCost` учёта (`src/engine/usage.ts`). */
export declare const callCostKnown: (r: CallRecord) => boolean;
/**
 * Отчёт об эффекте: что дали проверки, ревью и исполнение на данных
 * проекта. Чистая функция: тот же вход и те же параметры — тот же объект
 * (порядок входных массивов, часы и часовой пояс не влияют). Ответ
 * соответствует `valueReportSchema`.
 */
export declare function valueReport(input: ValueReportInput, options?: ValueReportOptions): ValueReport;
/**
 * Предел размера отчёта (`REPORT_LIMITS`): его обеспечивают пределы списков,
 * поэтому превышение — дефект harness (`INTERNAL`), а не усечение молча.
 */
export declare function assertReportBytes(text: string, limit: number, what: string): void;
/** ISO-неделя `2026-W44` по понедельнику (UTC). */
export declare function isoWeekOf(ms: number): string;
