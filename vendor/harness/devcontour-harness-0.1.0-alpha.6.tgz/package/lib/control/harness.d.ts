import { type Author, type ContextSnapshot, type ContractDocument, type PropertyRecovery, type ExecutionPolicy, type ResultEnvelope, type ResultSink, type WorkSource, type RuntimeAdapter, type RuntimeName, type WorkGraph } from '../contracts/index.ts';
import { Engine } from '../engine/engine.ts';
import { Runner, type RunnerHooks } from '../engine/runner.ts';
import { SqliteExecutionStore } from '../storage/sqlite.ts';
import { WorkflowQueue } from './workflow.ts';
import { type PolicySource } from './provenance.ts';
import { JointRunner } from '../engine/joint-runner.ts';
export interface HarnessOptions {
    /** Каталог состояния исполнения: база, worktrees, артефакты. */
    stateDir: string;
    policy: ExecutionPolicy;
    /** Каталог, от которого разрешаются относительные пути репозиториев политики. */
    baseDir: string;
    /** Подключённые runtime; по умолчанию — CLI codex и claude из PATH. */
    adapters?: Partial<Record<RuntimeName, RuntimeAdapter>>;
    /** Читающие операции не создают каталог состояния. */
    readOnly?: boolean;
    /**
     * Открыть базу состояния только для чтения (status, events, result): процесс
     * не записывает даже метку писателя. Любая запись — отказ.
     */
    readOnlyState?: boolean;
    environment?: NodeJS.ProcessEnv;
    /**
     * Файл, из которого загружена политика. С ним процесс может записать свою
     * политику применённой, только пока файл не менялся; без него политика —
     * объект вызывающего, и право ограничено остальными условиями.
     */
    policySource?: PolicySource;
    /** База блокировок ресурсов; по умолчанию — общая для машины. */
    resourceDatabase?: string;
    /**
     * Дополнения хоста к попыткам (например, история работы внешнего
     * хранилища задач до исполнения). Приёмку не решают: отказ хука — отказ
     * попытки.
     */
    hooks?: RunnerHooks;
}
/**
 * Доменные операции harness — общие для библиотеки и CLI. Здесь нет
 * операции «передать PASS» или «принять без проверок»: приёмка возможна
 * только через движок после evidence обеих фаз.
 */
export declare class Harness {
    readonly options: HarnessOptions;
    readonly engine: Engine;
    readonly runner: Runner;
    readonly store: SqliteExecutionStore;
    readonly policy: ExecutionPolicy;
    /** Техническая очередь: сохранённые стадии и ограниченное восстановление графа. */
    readonly workflows: WorkflowQueue;
    /** Совместная проверка комбинации репозиториев. */
    readonly joint: JointRunner;
    private readonly adapters;
    static open(options: HarnessOptions): Harness;
    private constructor();
    close(): void;
    /**
     * Совместная проверка набора принятых поручений на текущих target ref.
     * Возвращает итог (`passed` или `failed` с причиной); продуктовое принятие
     * комбинации решает хост.
     */
    verifyJoint(workIds: string[], options?: {
        baseline?: string;
    }): Promise<{
        status: "active";
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "failed";
        finishedAt: string;
        error: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "passed";
        finishedAt: string;
        manifest: Record<string, {
            sha: string;
            tree: string;
        }>;
        manifestDigest: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    }>;
    /**
     * Актуальность результата совместной проверки набора и свежесть его
     * manifest: SHA каждого репозитория сравнивается с текущим target ref.
     * Свежесть — наблюдение, а не запрет: решение о принятии — за хостом.
     */
    jointResult(workIds: string[]): Promise<{
        verification?: import("../contracts/result.ts").JointVerification;
        current: boolean;
        reason?: string;
    } | {
        freshness: {
            fresh: boolean;
            head?: string | undefined;
            repositoryId: string;
            sha: string;
        }[];
        verification?: import("../contracts/result.ts").JointVerification;
        current: boolean;
        reason?: string;
    }>;
    /** Запросить применение политики с digest `policyDigest(next)`; держит новые выдачи. */
    requestReconfigure(operation: string, digest: string): {
        operation: string;
        digest: string;
        changed: boolean;
        retried?: undefined;
    } | {
        operation: string;
        digest: string;
        changed: boolean;
        retried: boolean;
    };
    /** Применить запрос политикой этого процесса (после drain), см. `Engine.applyReconfigure`. */
    applyReconfigure(by?: string): {
        status: "none";
    } | {
        status: "busy";
        busy: string[];
    } | {
        status: "waiting";
        expected: string;
    } | {
        status: "failed";
        error: string;
    } | {
        status: "applied";
        generation: number;
    };
    policyState(): {
        stale?: string | undefined;
        reconfigure?: {
            operation: string;
            digest: string;
            requestedAt: string;
            appliedAt?: string | undefined;
            appliedBy?: string | undefined;
            error?: string | undefined;
        } | undefined;
        applied?: {
            digest: string;
            at: string;
            by: string;
            generation?: number | undefined;
        } | undefined;
        loaded: string;
    };
    /**
     * Довести незавершённую очистку закончившейся попытки: повторить teardown по
     * сохранённым receipt окружений и убрать её рабочие деревья и снимки.
     */
    cleanup(runId: string): Promise<{
        status: "nothing-pending";
        receipts?: undefined;
    } | {
        status: "cleaned";
        receipts: string[];
    }>;
    private repoPath;
    /**
     * Снимок контекста для ревью плана: без нужного графу источника — отказ
     * `NOT_READY`, нарушения снимка (digest, размер) — `INVALID_INPUT`.
     * Поручения без контекста — снимок не нужен.
     */
    private planContext;
    /**
     * Раунд технического ревью предмета (граф или контракт) с конкретным
     * digest. Тот же digest и автор, уже согласованные последним раундом, —
     * тот же раунд без вызова модели. Reviewer — по правилу вендора политики;
     * недопустимый автор — `REVIEWER_SAME_VENDOR` до вызова. Reviewer называет
     * состояние каждой прежней открытой находки; история не переписывается.
     */
    review(input: {
        kind: 'plan';
        graph: WorkGraph;
        context?: ContextSnapshot;
        author: Author;
    } | {
        kind: 'contract';
        contract: ContractDocument;
        author: Author;
    }): Promise<{
        id: string;
        kind: "plan" | "contract";
        subject: string;
        digest: string;
        round: number;
        at: string;
        approved: boolean;
        summary: string;
        authorRuntime: "codex" | "claude" | "fixture" | "external";
        reviewerRuntime: "codex" | "claude" | "fixture";
        sameVendor: boolean;
        findings: {
            id: string;
            severity: "blocking" | "note";
            message: string;
            status: "open" | "closed" | "withdrawn";
            openedIn: number;
            changedIn: number;
            rule?: string | undefined;
            path?: string | null | undefined;
            line?: number | null | undefined;
            basis?: string | undefined;
        }[];
        artifact: string;
        reviewerModel?: string | undefined;
        reviewerBinding?: string | undefined;
        contextDigest?: string | undefined;
    }>;
    /**
     * Эксперименты, на которые ссылаются тяжёлые обязательства: reviewer читает
     * фактический результат, а не пересказ автора.
     */
    private spikeNote;
    private assertContract;
    /** Корпус: принятые версии, решения, отложенные принятия. */
    get corpus(): import("../index.ts").CorpusStore;
    /**
     * Ограниченный эксперимент выполнимости до реализации тяжёлого обязательства.
     * Таймаут — `inconclusive`: не доказательство невыполнимости и не основание
     * ослаблять обязательство.
     */
    spike(input: unknown): Promise<{
        id: string;
        repositoryId: string;
        sha: string;
        command: string[];
        seed: number;
        sizes: number[];
        timeoutMs: number;
        question: string;
        results: {
            size: number;
            ms: number;
            outcome: "error" | "ok" | "timeout";
            exitCode: number;
        }[];
        outcome: "failed" | "feasible" | "inconclusive";
        limits: string;
        environment: {
            platform: string;
            arch: string;
            node: string;
            cpus: number;
            isolation: string;
        };
        at: string;
        digest: string;
    }>;
    /** Эксперименты выполнимости репозитория (по умолчанию — всех). */
    spikes(repositoryId?: string): {
        id: string;
        repositoryId: string;
        sha: string;
        command: string[];
        seed: number;
        sizes: number[];
        timeoutMs: number;
        question: string;
        results: {
            size: number;
            ms: number;
            outcome: "error" | "ok" | "timeout";
            exitCode: number;
        }[];
        outcome: "failed" | "feasible" | "inconclusive";
        limits: string;
        environment: {
            platform: string;
            arch: string;
            node: string;
            cpus: number;
            isolation: string;
        };
        at: string;
        digest: string;
    }[];
    /** Подтвердить пример закреплённым эталоном; подтверждённый — новая версия корпуса. */
    submitCase(input: unknown): Promise<{
        suite: string;
        repeated: boolean;
        decision: {
            id: string;
            property: string;
            input: string;
            inputHash: string;
            outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
            reason: string;
            source: {
                sha: string;
                runId?: string | undefined;
                taskId?: string | undefined;
            };
            origin: {
                kind: "review" | "agent" | "operator" | "lead";
                runtime?: string | undefined;
            };
            at: string;
            key?: string | undefined;
            claimed?: {
                expected: string | null;
                actual: string | null;
                reproduction?: string | undefined;
            } | undefined;
            observed?: {
                repeats: number;
                durationsMs: number[];
                expected?: string | undefined;
                actual?: string | undefined;
                equal?: boolean | undefined;
            } | undefined;
            method?: {
                gate: string;
                artifacts: {
                    path: string;
                    blob: string;
                }[];
                contract: string;
                basis: string;
                command?: string[] | undefined;
            } | undefined;
            caseId?: string | undefined;
            version?: number | undefined;
        };
        version: {
            number: number;
            digest: string;
            cases: number;
        } | null;
        adoption: {
            awaitingOperator?: true | undefined;
            id: string;
            status: "completed" | "waiting";
            results: Record<string, string>;
        }[];
    }>;
    /** Ручное техническое подтверждение принятия версии корпуса (operator mode). */
    approveAdoption(suiteId: string, pendingId: string): {
        pending: {
            id: string;
            version: number;
            tasks: string[];
            status: "completed" | "waiting";
            results: Record<string, string>;
            actor: string;
            reason: string;
            requestedAt: string;
            digest?: string | undefined;
            awaitingOperator?: boolean | undefined;
            completedAt?: string | undefined;
        };
        suite: {
            id: string;
            repositoryId: string;
            contractId: string;
            contractDigest: string;
            gate: string;
            basis: string;
            cases: Record<string, {
                id: string;
                property: string;
                input: string;
                expected: string;
                source: {
                    kind: "oracle";
                    decision: string;
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                    reproduction?: string | undefined;
                };
                addedAt: string;
            }>;
            versions: {
                number: number;
                digest: string;
                previous: string | null;
                cases: string[];
                blob: string;
                createdAt: string;
                reason: string;
                decisions: string[];
            }[];
            decisions: {
                id: string;
                property: string;
                input: string;
                inputHash: string;
                outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
                reason: string;
                source: {
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                };
                origin: {
                    kind: "review" | "agent" | "operator" | "lead";
                    runtime?: string | undefined;
                };
                at: string;
                key?: string | undefined;
                claimed?: {
                    expected: string | null;
                    actual: string | null;
                    reproduction?: string | undefined;
                } | undefined;
                observed?: {
                    repeats: number;
                    durationsMs: number[];
                    expected?: string | undefined;
                    actual?: string | undefined;
                    equal?: boolean | undefined;
                } | undefined;
                method?: {
                    gate: string;
                    artifacts: {
                        path: string;
                        blob: string;
                    }[];
                    contract: string;
                    basis: string;
                    command?: string[] | undefined;
                } | undefined;
                caseId?: string | undefined;
                version?: number | undefined;
            }[];
            adoptions: {
                id: string;
                taskId: string;
                from: {
                    number: number;
                    digest: string;
                } | null;
                to: {
                    number: number;
                    digest: string;
                };
                actor: string;
                reason: string;
                operation: string;
                at: string;
            }[];
            pending: {
                id: string;
                version: number;
                tasks: string[];
                status: "completed" | "waiting";
                results: Record<string, string>;
                actor: string;
                reason: string;
                requestedAt: string;
                digest?: string | undefined;
                awaitingOperator?: boolean | undefined;
                completedAt?: string | undefined;
            }[];
            operations: Record<string, {
                key: string;
                status: "completed" | "running";
                startedAt: string;
                token?: string | undefined;
                leaseUntil?: number | undefined;
                decision?: string | undefined;
            }>;
            revision: number;
        };
    };
    /** Решение эпизода по свойству человеком: CAS по версии записи. */
    decideRecovery(workId: string, recoveryId: string, decision: Omit<NonNullable<PropertyRecovery['decision']>, 'source' | 'decidedAt'>, version: number): {
        id: string;
        property: string;
        basis: string;
        runs: string[];
        openedAt: string;
        status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
        calls: number;
        history: {
            at: string;
            event: string;
            detail?: string | undefined;
        }[];
        version: number;
        decision?: {
            action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
            reason: string;
            evidence: string[];
            source: {
                kind: "operator" | "lead";
                runtime?: string | undefined;
                model?: string | undefined;
            };
            decidedAt: string;
            hypothesis?: string | undefined;
            plan?: string | undefined;
            cases?: {
                input: string;
                expected?: string | null | undefined;
            }[] | undefined;
            proposal?: string | undefined;
            conflict?: string | undefined;
        } | undefined;
        retryRun?: string | undefined;
        reason?: string | undefined;
    };
    /** Согласование оператором (approvalMode: operator) графа, digest которого прошёл ревью. */
    approve(subject: string, digest: string): {
        subject: string;
        digest: string;
        at: string;
        changed: boolean;
    };
    /**
     * Действующий контекст графа — снимок, связанный с его согласованием, а не
     * последний переданный: отклонённый или ещё не согласованный снимок не
     * исполняется.
     */
    private contextOf;
    /**
     * Зарегистрировать граф (идемпотентно по редакции), в режиме `agent`
     * провести ревью плана, если его нет, согласовать и вести очередь до
     * простоя. Результаты доставляются получателю с идемпотентным ключом.
     */
    run(input: {
        graph: WorkGraph;
        context?: ContextSnapshot;
        author: Author;
        sink?: ResultSink;
        once?: boolean;
        /**
         * Источник, из которого прочитан граф. Его решение `trusts` — единственное
         * основание принять внешнюю предпосылку с receipt `trusted`; доступность
         * result SHA в target ref проверяется в любом случае. Без источника
         * доверенных receipt нет.
         */
        source?: WorkSource;
    }): Promise<{
        works: {
            blockers: {
                code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT";
                message: string;
            }[];
            resultSha?: string | undefined;
            runId?: string | undefined;
            id: string;
            status: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        }[];
        workflow?: {
            history: {
                at: string;
                stage: number;
                event: string;
            }[];
            error?: string | undefined;
            key: string;
            kind: string;
            id: string;
            stage: number;
            status: "failed" | "completed" | "running" | "queued" | "stale";
            attempts: number;
            repairs: number;
            repairBudget: number;
        } | undefined;
        graphId: string;
        digest: string;
        resumed: boolean;
    }>;
    /**
     * Вести задание графа: стадия согласования уже пройдена синхронно; стадия
     * исполнения — очередь до простоя, затем решение о восстановлении по
     * записанному состоянию. Повтор назначается и списывается одной
     * транзакцией; остановка записывает причину в задание.
     */
    private advance;
    /**
     * Эпизоды повторяющихся отказов по свойству. Возвращает true, когда
     * разрешённое действие назначено и его результата нужно дождаться;
     * останавливается с причиной там, где автоматического действия нет.
     * Бюджет восстановлений и разбор эпизода учитываются одной транзакцией до
     * вызова модели: рестарт и повтор бесплатного вызова не получают.
     */
    private recoverProperties;
    private applyRecovery;
    private afterDecision;
    /**
     * Восстановление упавшего поручения группы. Решение и его исполнение — одна
     * транзакция: между чтением и записью никто не успеет отменить поручение.
     * Возвращает true, когда повтор назначен; остановка — исключение с причиной.
     */
    private repair;
    status(graphId?: string): {
        budgets: {
            onUnknown: "stop" | "continue";
            budgets: {
                reason?: string | undefined;
                scope: import("../engine/budget.ts").BudgetScope;
                state: "exceeded" | "undetermined" | "within";
                limit: {
                    usd?: number;
                    timeMs?: number;
                };
                reportedUsd: number;
                estimatedUsd: number;
                unknownCalls: number;
                unfinishedCalls: number;
                abandonedCalls: number;
                errorCalls: number;
                uncoveredRuns: number;
                durationMs: number;
                remainingUsd: number | null;
                remainingMs: number | null;
            }[];
        };
        graphs: {
            id: string;
            digest: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            approved: boolean;
        }[];
        works: {
            blockers: {
                code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT";
                message: string;
            }[];
            resultSha?: string | undefined;
            activeRunId?: string | undefined;
            id: string;
            graphId: string;
            status: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
            attempt: number;
        }[];
        controller?: {
            owner: string;
            leaseUntil: number;
            engineVersion?: string | undefined;
        } | undefined;
        stateVersion: 1;
        control: {
            paused: boolean;
            pauseReason?: "runtime" | "operator" | "shutdown" | "base-check" | "reconfigure" | undefined;
            pausedAt?: string | undefined;
            pauseOperation?: string | undefined;
            pauseFailures?: ("gate" | "unknown" | "review" | "environment" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "scope-violation" | "review-protocol" | "merge" | "budget")[] | undefined;
            waits?: {
                kind: "base-check" | "context-lock";
                detail: string;
                at: string;
                operation?: string | undefined;
            }[] | undefined;
            appliedPolicy?: {
                digest: string;
                at: string;
                by: string;
                generation?: number | undefined;
            } | undefined;
            reconfigure?: {
                operation: string;
                digest: string;
                requestedAt: string;
                appliedAt?: string | undefined;
                appliedBy?: string | undefined;
                error?: string | undefined;
            } | undefined;
        };
    } | {
        budgets?: undefined;
        graphs: {
            id: string;
            digest: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            approved: boolean;
        }[];
        works: {
            blockers: {
                code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT";
                message: string;
            }[];
            resultSha?: string | undefined;
            activeRunId?: string | undefined;
            id: string;
            graphId: string;
            status: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
            attempt: number;
        }[];
        controller?: {
            owner: string;
            leaseUntil: number;
            engineVersion?: string | undefined;
        } | undefined;
        stateVersion: 1;
        control: {
            paused: boolean;
            pauseReason?: "runtime" | "operator" | "shutdown" | "base-check" | "reconfigure" | undefined;
            pausedAt?: string | undefined;
            pauseOperation?: string | undefined;
            pauseFailures?: ("gate" | "unknown" | "review" | "environment" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "scope-violation" | "review-protocol" | "merge" | "budget")[] | undefined;
            waits?: {
                kind: "base-check" | "context-lock";
                detail: string;
                at: string;
                operation?: string | undefined;
            }[] | undefined;
            appliedPolicy?: {
                digest: string;
                at: string;
                by: string;
                generation?: number | undefined;
            } | undefined;
            reconfigure?: {
                operation: string;
                digest: string;
                requestedAt: string;
                appliedAt?: string | undefined;
                appliedBy?: string | undefined;
                error?: string | undefined;
            } | undefined;
        };
    };
    events(after?: number, limit?: number): {
        events: import("../contracts/events.ts").RunEvent[];
        next: number;
    };
    /** Результат завершённой попытки поручения (последней или `runId`) и состояние его доставки. */
    result(workId: string, runId?: string): ResultEnvelope;
    /**
     * Доставка результата поручения получателю. Ключ — получатель, поручение и
     * попытка: повтор не создаёт второй записи и не вызывает моделей или
     * интеграции. Конфликт редакции записывается, результат её не закрывает.
     */
    deliver(workId: string, sink: ResultSink): Promise<{
        apiVersion: "devcontour-harness/v1alpha1";
        result: {
            outcome: "accepted";
            shas: {
                base: string;
                candidate: string;
                integration: string;
                result: string;
            };
            apiVersion: "devcontour-harness/v1alpha1";
            workOrderId: string;
            graphId: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            runId: string;
            attempt: number;
            repositoryId: string;
            targetRef: string;
            inputs: {
                harnessVersion: string;
                stateVersion: 1;
                workOrderDigest: string;
                graphDigest: string;
                policyDigest: string;
                consumerVersion?: string | undefined;
                contextDigest?: string | undefined;
                checks?: string | undefined;
                corpus?: {
                    suite: string;
                    number: number;
                    digest: string;
                } | undefined;
                requiredGates?: string[] | undefined;
                writer?: {
                    runtime: "codex" | "claude" | "fixture";
                    model?: string | undefined;
                } | undefined;
            };
            checked: {
                dependencies: {
                    repositoryId: string;
                    sha: string;
                    tree: string;
                    artifacts: {
                        path: string;
                        digest: string;
                    }[];
                }[];
                freshness: {
                    repositoryId: string;
                    snapshot: string;
                    head: string;
                    fresh: boolean;
                }[];
                consumers: {
                    repositoryId: string;
                    gates: string[];
                    sha: string;
                    tree: string;
                    dependencies: {
                        repositoryId: string;
                        sha: string;
                        tree: string;
                        artifacts: {
                            path: string;
                            digest: string;
                        }[];
                    }[];
                    freshness: {
                        repositoryId: string;
                        snapshot: string;
                        head: string;
                        fresh: boolean;
                    }[];
                }[];
            };
            evidence: {
                id: string;
                kind: "check" | "test" | "property" | "review" | "consumer";
                phase: "candidate" | "integration";
                gate: string;
                sha: string;
                passed: boolean;
                digest: string;
                summary: string;
                consumer?: string | undefined;
                checks?: string | undefined;
                tests?: {
                    id: string;
                    status: "passed" | "failed" | "skipped";
                    opaque?: true | undefined;
                }[] | undefined;
                testsTruncated?: boolean | undefined;
                property?: {
                    level?: "manifest" | "legacy" | undefined;
                    manifest?: {
                        digest: string;
                        properties: string[];
                        corpus?: {
                            digest: string;
                            cases: number;
                        } | undefined;
                    } | undefined;
                } | undefined;
                reviewer?: {
                    runtime: "codex" | "claude" | "fixture";
                    sameVendor: boolean;
                    model?: string | undefined;
                } | undefined;
                review?: {
                    round: number;
                    call: number;
                    protocol: "valid" | "invalid" | "unsafe";
                    issues?: {
                        path: string;
                        reason: string;
                        message: string;
                    }[] | undefined;
                    transitions?: {
                        id: string;
                        from: "open" | "closed" | "withdrawn";
                        to: "open" | "closed" | "withdrawn";
                    }[] | undefined;
                } | undefined;
            }[];
            findings: {
                severity: string;
                message: string;
                path?: string | null | undefined;
                line?: number | null | undefined;
                rule?: string | undefined;
                id?: string | undefined;
                status?: "open" | "closed" | "withdrawn" | undefined;
            }[];
            limitations: string[];
            finishedAt: string;
        } | {
            outcome: "rejected" | "blocked" | "cancelled" | "stopped";
            shas: {
                base?: string | undefined;
                candidate?: string | undefined;
                integration?: string | undefined;
            };
            stopReason: {
                code: "INVALID_INPUT" | "UNSUPPORTED_COMMAND" | "UNSUPPORTED_VERSION" | "GRAPH_CYCLE" | "GRAPH_UNKNOWN_DEPENDENCY" | "GRAPH_DUPLICATE_ID" | "GATE_UNKNOWN" | "GATE_GROUP_CYCLE" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "LEASE_STALE" | "CONTROLLER_BUSY" | "PAUSED" | "NOT_READY" | "SCOPE_VIOLATION" | "GATE_FAILED" | "REVIEW_REJECTED" | "BUDGET_EXHAUSTED" | "BUDGET_UNKNOWN" | "ATTEMPTS_EXHAUSTED" | "REVISION_CONFLICT" | "CANCELLED" | "NOT_FOUND" | "STATE_VERSION_UNSUPPORTED" | "RUNTIME_UNAVAILABLE" | "REVIEW_PROTOCOL_INVALID" | "SANDBOX_UNAVAILABLE" | "GIT_FAILED" | "STORAGE_FAILED" | "DELIVERY_FAILED" | "INTERNAL";
                message: string;
            };
            apiVersion: "devcontour-harness/v1alpha1";
            workOrderId: string;
            graphId: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            runId: string;
            attempt: number;
            repositoryId: string;
            targetRef: string;
            inputs: {
                harnessVersion: string;
                stateVersion: 1;
                workOrderDigest: string;
                graphDigest: string;
                policyDigest: string;
                consumerVersion?: string | undefined;
                contextDigest?: string | undefined;
                checks?: string | undefined;
                corpus?: {
                    suite: string;
                    number: number;
                    digest: string;
                } | undefined;
                requiredGates?: string[] | undefined;
                writer?: {
                    runtime: "codex" | "claude" | "fixture";
                    model?: string | undefined;
                } | undefined;
            };
            checked: {
                dependencies: {
                    repositoryId: string;
                    sha: string;
                    tree: string;
                    artifacts: {
                        path: string;
                        digest: string;
                    }[];
                }[];
                freshness: {
                    repositoryId: string;
                    snapshot: string;
                    head: string;
                    fresh: boolean;
                }[];
                consumers: {
                    repositoryId: string;
                    gates: string[];
                    sha: string;
                    tree: string;
                    dependencies: {
                        repositoryId: string;
                        sha: string;
                        tree: string;
                        artifacts: {
                            path: string;
                            digest: string;
                        }[];
                    }[];
                    freshness: {
                        repositoryId: string;
                        snapshot: string;
                        head: string;
                        fresh: boolean;
                    }[];
                }[];
            };
            evidence: {
                id: string;
                kind: "check" | "test" | "property" | "review" | "consumer";
                phase: "candidate" | "integration";
                gate: string;
                sha: string;
                passed: boolean;
                digest: string;
                summary: string;
                consumer?: string | undefined;
                checks?: string | undefined;
                tests?: {
                    id: string;
                    status: "passed" | "failed" | "skipped";
                    opaque?: true | undefined;
                }[] | undefined;
                testsTruncated?: boolean | undefined;
                property?: {
                    level?: "manifest" | "legacy" | undefined;
                    manifest?: {
                        digest: string;
                        properties: string[];
                        corpus?: {
                            digest: string;
                            cases: number;
                        } | undefined;
                    } | undefined;
                } | undefined;
                reviewer?: {
                    runtime: "codex" | "claude" | "fixture";
                    sameVendor: boolean;
                    model?: string | undefined;
                } | undefined;
                review?: {
                    round: number;
                    call: number;
                    protocol: "valid" | "invalid" | "unsafe";
                    issues?: {
                        path: string;
                        reason: string;
                        message: string;
                    }[] | undefined;
                    transitions?: {
                        id: string;
                        from: "open" | "closed" | "withdrawn";
                        to: "open" | "closed" | "withdrawn";
                    }[] | undefined;
                } | undefined;
            }[];
            findings: {
                severity: string;
                message: string;
                path?: string | null | undefined;
                line?: number | null | undefined;
                rule?: string | undefined;
                id?: string | undefined;
                status?: "open" | "closed" | "withdrawn" | undefined;
            }[];
            limitations: string[];
            finishedAt: string;
        };
        delivery: {
            sink: string;
            key: string;
            revision: string;
            status: "failed" | "pending" | "delivered" | "conflict" | "uncertain";
            attempts: number;
            updatedAt: string;
            lastError?: string | undefined;
            operation?: string | undefined;
            currentRevision?: string | undefined;
            receipt?: string | undefined;
        }[];
    }>;
    private deliverAll;
}
