import { z } from 'zod';
export declare const draftPathSchema: z.ZodString;
export declare const draftRequirementSchema: z.ZodObject<{
    id: z.ZodString;
    source: z.ZodString;
    digest: z.ZodString;
    text: z.ZodString;
    gate: z.ZodString;
    scenario: z.ZodString;
    testId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
/** Общие поля задачи draft. Порядок ключей нормативен: по нему строится JSON Schema. */
export declare const planDraftTaskShape: {
    requirements: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        source: z.ZodString;
        digest: z.ZodString;
        text: z.ZodString;
        gate: z.ZodString;
        scenario: z.ZodString;
        testId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    scope: z.ZodDefault<z.ZodEnum<{
        component: "component";
        workspace: "workspace";
    }>>;
    relatedRepositories: z.ZodOptional<z.ZodArray<z.ZodString>>;
    contextPacks: z.ZodOptional<z.ZodArray<z.ZodString>>;
    writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
    gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
    properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
    resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    repositoryId: z.ZodDefault<z.ZodString>;
    key: z.ZodString;
    title: z.ZodString;
    description: z.ZodString;
    role: z.ZodString;
    dependsOn: z.ZodArray<z.ZodString>;
    acceptance: z.ZodArray<z.ZodString>;
    contracts: z.ZodArray<z.ZodString>;
};
export type PlanDraftTaskShape = typeof planDraftTaskShape;
/**
 * Схема draft с полями хоста. `keyOrder` — полная перестановка ключей задачи:
 * хост сохраняет прежний порядок полей своей схемы (а с ним байты JSON Schema
 * и digest своего каталога). Без него — общие поля, затем поля расширения.
 */
export declare function planDraft<E extends z.ZodRawShape = Record<never, never>>(taskExtension?: E, options?: {
    keyOrder?: readonly string[];
}): z.ZodObject<{
    title: z.ZodString;
    description: z.ZodString;
    tasks: z.ZodArray<z.ZodObject<{
        requirements: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            source: z.ZodString;
            digest: z.ZodString;
            text: z.ZodString;
            gate: z.ZodString;
            scenario: z.ZodString;
            testId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        scope: z.ZodDefault<z.ZodEnum<{
            component: "component";
            workspace: "workspace";
        }>>;
        relatedRepositories: z.ZodOptional<z.ZodArray<z.ZodString>>;
        contextPacks: z.ZodOptional<z.ZodArray<z.ZodString>>;
        writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
        gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        repositoryId: z.ZodDefault<z.ZodString>;
        key: z.ZodString;
        title: z.ZodString;
        description: z.ZodString;
        role: z.ZodString;
        dependsOn: z.ZodArray<z.ZodString>;
        acceptance: z.ZodArray<z.ZodString>;
        contracts: z.ZodArray<z.ZodString>;
    } & E extends infer T ? { -readonly [P in keyof T]: T[P]; } : never, z.core.$strip>>;
}, z.core.$strip>;
/** Draft самостоятельного проекта: общие поля и проверка потребителей библиотеки. */
export declare const planDraftSchema: z.ZodObject<{
    title: z.ZodString;
    description: z.ZodString;
    tasks: z.ZodArray<z.ZodObject<{
        requirements: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            source: z.ZodString;
            digest: z.ZodString;
            text: z.ZodString;
            gate: z.ZodString;
            scenario: z.ZodString;
            testId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        scope: z.ZodDefault<z.ZodEnum<{
            component: "component";
            workspace: "workspace";
        }>>;
        relatedRepositories: z.ZodOptional<z.ZodArray<z.ZodString>>;
        contextPacks: z.ZodOptional<z.ZodArray<z.ZodString>>;
        writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
        gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        repositoryId: z.ZodDefault<z.ZodString>;
        key: z.ZodString;
        title: z.ZodString;
        description: z.ZodString;
        role: z.ZodString;
        dependsOn: z.ZodArray<z.ZodString>;
        acceptance: z.ZodArray<z.ZodString>;
        contracts: z.ZodArray<z.ZodString>;
        consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            gates: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type PlanDraft = z.output<ReturnType<typeof planDraft<Record<never, never>>>>;
export type StandalonePlanDraft = z.output<typeof planDraftSchema>;
/** JSON Schema draft для `--output-schema` runtime и для агента. */
export declare function planDraftJsonSchema(schema: z.ZodType): Record<string, unknown>;
/** Факты проекта, по которым составляется и проверяется план. */
export interface PlanningFacts {
    repositories: {
        id: string;
        name?: string;
        kind?: string;
        path: string;
    }[];
    roles: {
        repositoryId: string;
        roles: {
            role: string;
            title?: string;
            writePaths?: string[];
            requiresContract: boolean;
        }[];
    }[];
    gates: {
        repositoryId: string;
        gates: {
            id: string;
            kind: string;
        }[];
        groups?: Record<string, string[]>;
    }[];
    contextPacks: {
        id: string;
        version?: string;
        repositoryId?: string;
        roles?: string[];
        files?: string[];
    }[];
    resources: {
        id: string;
        kind: string;
    }[];
    /** Записи контрактов целиком: prompt получает их как есть. */
    contracts: (Record<string, unknown> & {
        id: string;
        digest: string;
    })[];
}
export declare const planningFactsSchema: z.ZodObject<{
    repositories: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodOptional<z.ZodString>;
        kind: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
    }, z.core.$strict>>;
    roles: z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        roles: z.ZodArray<z.ZodObject<{
            role: z.ZodString;
            title: z.ZodOptional<z.ZodString>;
            writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
            requiresContract: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    gates: z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        gates: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodString;
        }, z.core.$strict>>;
        groups: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    }, z.core.$strict>>;
    contextPacks: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodOptional<z.ZodString>;
        repositoryId: z.ZodOptional<z.ZodString>;
        roles: z.ZodOptional<z.ZodArray<z.ZodString>>;
        files: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    resources: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodString;
    }, z.core.$strict>>;
    contracts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        digest: z.ZodString;
    }, z.core.$loose>>;
}, z.core.$strict>;
export declare const codedIssueSchema: z.ZodObject<{
    code: z.ZodEnum<{
        INVALID_INPUT: "INVALID_INPUT";
        UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
        UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
        GRAPH_CYCLE: "GRAPH_CYCLE";
        GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
        GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
        GATE_UNKNOWN: "GATE_UNKNOWN";
        GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
        REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
        REVIEWER_MISSING: "REVIEWER_MISSING";
        RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
        APPROVAL_STALE: "APPROVAL_STALE";
        APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
        LEASE_STALE: "LEASE_STALE";
        CONTROLLER_BUSY: "CONTROLLER_BUSY";
        PAUSED: "PAUSED";
        NOT_READY: "NOT_READY";
        SCOPE_VIOLATION: "SCOPE_VIOLATION";
        GATE_FAILED: "GATE_FAILED";
        REVIEW_REJECTED: "REVIEW_REJECTED";
        BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
        BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
        ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
        CONTEXT_EXHAUSTED: "CONTEXT_EXHAUSTED";
        REVISION_CONFLICT: "REVISION_CONFLICT";
        CANCELLED: "CANCELLED";
        NOT_FOUND: "NOT_FOUND";
        PATH_CONFLICT: "PATH_CONFLICT";
        STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
        RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
        REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
        SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
        GIT_FAILED: "GIT_FAILED";
        STORAGE_FAILED: "STORAGE_FAILED";
        DELIVERY_FAILED: "DELIVERY_FAILED";
        INTERNAL: "INTERNAL";
    }>;
    path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
    message: z.ZodString;
}, z.core.$strict>;
/** Чего не хватает для проверки плана: агент готовит проверку, а не убирает её. */
export declare const checkGapKinds: readonly ["gate-undeclared", "test-gate-missing"];
export declare const checkGapSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        "gate-undeclared": "gate-undeclared";
        "test-gate-missing": "test-gate-missing";
    }>;
    taskKey: z.ZodString;
    repositoryId: z.ZodString;
    ref: z.ZodOptional<z.ZodString>;
    testGates: z.ZodArray<z.ZodString>;
    action: z.ZodEnum<{
        "declare-gate": "declare-gate";
        "add-test-gate": "add-test-gate";
    }>;
}, z.core.$strict>;
export type CheckGap = z.infer<typeof checkGapSchema>;
/** `plan-request`: запрос планирования для ведущего агента; модель не вызывается. */
export declare const planRequestDataSchema: z.ZodObject<{
    prompt: z.ZodString;
    readOnly: z.ZodLiteral<true>;
    recommendedTasks: z.ZodNumber;
    maxTasks: z.ZodLiteral<30>;
    basis: z.ZodString;
    facts: z.ZodObject<{
        repositories: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodOptional<z.ZodString>;
            kind: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
        }, z.core.$strict>>;
        roles: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            roles: z.ZodArray<z.ZodObject<{
                role: z.ZodString;
                title: z.ZodOptional<z.ZodString>;
                writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
                requiresContract: z.ZodBoolean;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        gates: z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            gates: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodString;
            }, z.core.$strict>>;
            groups: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
        }, z.core.$strict>>;
        contextPacks: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            version: z.ZodOptional<z.ZodString>;
            repositoryId: z.ZodOptional<z.ZodString>;
            roles: z.ZodOptional<z.ZodArray<z.ZodString>>;
            files: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        resources: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodString;
        }, z.core.$strict>>;
        contracts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            digest: z.ZodString;
        }, z.core.$loose>>;
    }, z.core.$strict>;
    draftSchema: z.ZodLiteral<"plan-draft">;
}, z.core.$strict>;
/** `plan-check`: проблемы draft либо собранный граф; согласования не выдаёт. */
export declare const planCheckDataSchema: z.ZodObject<{
    issues: z.ZodArray<z.ZodObject<{
        code: z.ZodEnum<{
            INVALID_INPUT: "INVALID_INPUT";
            UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
            UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
            GRAPH_CYCLE: "GRAPH_CYCLE";
            GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
            GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
            GATE_UNKNOWN: "GATE_UNKNOWN";
            GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
            REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
            REVIEWER_MISSING: "REVIEWER_MISSING";
            RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
            APPROVAL_STALE: "APPROVAL_STALE";
            APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
            LEASE_STALE: "LEASE_STALE";
            CONTROLLER_BUSY: "CONTROLLER_BUSY";
            PAUSED: "PAUSED";
            NOT_READY: "NOT_READY";
            SCOPE_VIOLATION: "SCOPE_VIOLATION";
            GATE_FAILED: "GATE_FAILED";
            REVIEW_REJECTED: "REVIEW_REJECTED";
            BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
            BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
            ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
            CONTEXT_EXHAUSTED: "CONTEXT_EXHAUSTED";
            REVISION_CONFLICT: "REVISION_CONFLICT";
            CANCELLED: "CANCELLED";
            NOT_FOUND: "NOT_FOUND";
            PATH_CONFLICT: "PATH_CONFLICT";
            STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
            RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
            REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
            SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
            GIT_FAILED: "GIT_FAILED";
            STORAGE_FAILED: "STORAGE_FAILED";
            DELIVERY_FAILED: "DELIVERY_FAILED";
            INTERNAL: "INTERNAL";
        }>;
        path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        message: z.ZodString;
    }, z.core.$strict>>;
    checkPlan: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            "gate-undeclared": "gate-undeclared";
            "test-gate-missing": "test-gate-missing";
        }>;
        taskKey: z.ZodString;
        repositoryId: z.ZodString;
        ref: z.ZodOptional<z.ZodString>;
        testGates: z.ZodArray<z.ZodString>;
        action: z.ZodEnum<{
            "declare-gate": "declare-gate";
            "add-test-gate": "add-test-gate";
        }>;
    }, z.core.$strict>>;
    graph: z.ZodOptional<z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        orders: z.ZodArray<z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            id: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            title: z.ZodString;
            goal: z.ZodString;
            acceptance: z.ZodArray<z.ZodString>;
            role: z.ZodString;
            repositoryId: z.ZodString;
            relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
            writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
            dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
            gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>>;
            properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                source: z.ZodString;
                digest: z.ZodString;
                text: z.ZodString;
                gate: z.ZodString;
                scenario: z.ZodString;
                testId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>>;
            context: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        prerequisites: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            repositoryId: z.ZodString;
            resultSha: z.ZodString;
            receipt: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"engine">;
                runId: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"trusted">;
                issuer: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>], "kind">;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    graphDigest: z.ZodOptional<z.ZodString>;
    basis: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
