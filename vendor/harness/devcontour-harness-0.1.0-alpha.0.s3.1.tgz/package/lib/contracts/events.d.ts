import { z } from 'zod';
/**
 * Нагрузка каждого типа события — закрытая схема: лишних полей нет, и
 * поэтому в событие нельзя положить fencing-токен, секрет или произвольный
 * объект попытки. Событие читают внешние получатели и CLI.
 */
export declare const eventPayloads: {
    readonly 'graph.registered': z.ZodObject<{
        digest: z.ZodString;
        orders: z.ZodNumber;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>;
    readonly 'graph.reviewed': z.ZodObject<{
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        approved: z.ZodBoolean;
        open: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'graph.approved': z.ZodObject<{
        digest: z.ZodString;
        actor: z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>;
    }, z.core.$strict>;
    readonly 'work.ready': z.ZodObject<{
        orderDigest: z.ZodString;
    }, z.core.$strict>;
    readonly 'work.held': z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        released: z.ZodBoolean;
    }, z.core.$strict>;
    readonly 'attempt.claimed': z.ZodObject<{
        owner: z.ZodString;
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        policyDigest: z.ZodString;
        engineVersion: z.ZodString;
    }, z.core.$strict>;
    readonly 'attempt.phase': z.ZodObject<{
        phase: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        sha: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    readonly 'attempt.gate': z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        gate: z.ZodString;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    readonly 'attempt.review': z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        sameVendor: z.ZodBoolean;
        blocking: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'attempt.failed': z.ZodObject<{
        failureKind: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            environment: "environment";
            review: "review";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            merge: "merge";
            budget: "budget";
        }>;
        message: z.ZodString;
        blocked: z.ZodBoolean;
    }, z.core.$strict>;
    readonly 'attempt.expired': z.ZodObject<{
        leaseUntil: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'attempt.cancelled': z.ZodObject<{
        reason: z.ZodString;
    }, z.core.$strict>;
    readonly 'attempt.recovered': z.ZodObject<{
        integrationSha: z.ZodString;
        accepted: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    readonly 'work.accepted': z.ZodObject<{
        resultSha: z.ZodString;
        integrationSha: z.ZodString;
    }, z.core.$strict>;
    readonly 'work.blocked': z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict>;
    readonly 'control.paused': z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
        failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            environment: "environment";
            review: "review";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            merge: "merge";
            budget: "budget";
        }>>>;
    }, z.core.$strict>;
    readonly 'control.resumed': z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
    }, z.core.$strict>;
    readonly 'controller.acquired': z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict>;
    readonly 'controller.released': z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict>;
    readonly 'budget.blocked': z.ZodObject<{
        scope: z.ZodEnum<{
            work: "work";
            group: "group";
            total: "total";
        }>;
        scopeId: z.ZodOptional<z.ZodString>;
        state: z.ZodEnum<{
            exceeded: "exceeded";
            undetermined: "undetermined";
        }>;
        reason: z.ZodString;
    }, z.core.$strict>;
    /** Задачи приняли версию корпуса; тела случаев в журнал не попадают. */
    readonly 'corpus.adopted': z.ZodObject<{
        suite: z.ZodString;
        pending: z.ZodString;
        version: z.ZodNumber;
        digest: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            waiting: "waiting";
        }>;
        accepted: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    /** Эпизод повторяющихся отказов по свойству сменил состояние. */
    readonly 'work.recovery': z.ZodObject<{
        recoveryId: z.ZodString;
        property: z.ZodString;
        status: z.ZodEnum<{
            stopped: "stopped";
            closed: "closed";
            "awaiting-lead": "awaiting-lead";
            analyzing: "analyzing";
            applying: "applying";
            retry: "retry";
            retrying: "retrying";
            "awaiting-user": "awaiting-user";
        }>;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    /** Совместная проверка комбинации репозиториев началась (без manifest). */
    readonly 'joint.started': z.ZodObject<{
        verificationId: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        policyDigest: z.ZodString;
    }, z.core.$strict>;
    /** Совместная проверка закончилась: `passed` — только с manifest. */
    readonly 'joint.finished': z.ZodObject<{
        verificationId: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    /** Политика стала применённой: запуском процесса или операцией reconfigure. */
    readonly 'policy.applied': z.ZodObject<{
        digest: z.ZodString;
        generation: z.ZodNumber;
        by: z.ZodString;
        operation: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    /** Запрос операции применить политику с ожидаемым digest или его отказ. */
    readonly 'policy.reconfigure': z.ZodObject<{
        operation: z.ZodString;
        digest: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            requested: "requested";
            cleared: "cleared";
        }>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    readonly 'delivery.pending': z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'delivery.delivered': z.ZodObject<{
        receipt: z.ZodOptional<z.ZodString>;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'delivery.failed': z.ZodObject<{
        error: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'delivery.conflict': z.ZodObject<{
        currentRevision: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
};
export type EventType = keyof typeof eventPayloads;
export declare const eventTypes: EventType[];
declare const envelopeSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    seq: z.ZodNumber;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    attempt: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
type Envelope = z.infer<typeof envelopeSchema>;
/** Событие: общий конверт и нагрузка своего типа (дискриминатор `type`). */
export declare const runEventSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    seq: z.ZodNumber;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    attempt: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict">;
    payload: z.ZodObject<{
        digest: z.ZodString;
        orders: z.ZodNumber;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict> | z.ZodObject<{
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        approved: z.ZodBoolean;
        open: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        actor: z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        orderDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        released: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        policyDigest: z.ZodString;
        engineVersion: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        sha: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        gate: z.ZodString;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        sameVendor: z.ZodBoolean;
        blocking: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        failureKind: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            environment: "environment";
            review: "review";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            merge: "merge";
            budget: "budget";
        }>;
        message: z.ZodString;
        blocked: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        leaseUntil: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        integrationSha: z.ZodString;
        accepted: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        resultSha: z.ZodString;
        integrationSha: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
        failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            environment: "environment";
            review: "review";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            merge: "merge";
            budget: "budget";
        }>>>;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        scope: z.ZodEnum<{
            work: "work";
            group: "group";
            total: "total";
        }>;
        scopeId: z.ZodOptional<z.ZodString>;
        state: z.ZodEnum<{
            exceeded: "exceeded";
            undetermined: "undetermined";
        }>;
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        suite: z.ZodString;
        pending: z.ZodString;
        version: z.ZodNumber;
        digest: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            waiting: "waiting";
        }>;
        accepted: z.ZodArray<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        recoveryId: z.ZodString;
        property: z.ZodString;
        status: z.ZodEnum<{
            stopped: "stopped";
            closed: "closed";
            "awaiting-lead": "awaiting-lead";
            analyzing: "analyzing";
            applying: "applying";
            retry: "retry";
            retrying: "retrying";
            "awaiting-user": "awaiting-user";
        }>;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        policyDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        generation: z.ZodNumber;
        by: z.ZodString;
        operation: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        digest: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            requested: "requested";
            cleared: "cleared";
        }>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        receipt: z.ZodOptional<z.ZodString>;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        error: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        currentRevision: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>, ...z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    seq: z.ZodNumber;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    workId: z.ZodOptional<z.ZodString>;
    runId: z.ZodOptional<z.ZodString>;
    attempt: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict">;
    payload: z.ZodObject<{
        digest: z.ZodString;
        orders: z.ZodNumber;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict> | z.ZodObject<{
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        approved: z.ZodBoolean;
        open: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        actor: z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        orderDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        reason: z.ZodString;
        released: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        policyDigest: z.ZodString;
        engineVersion: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        sha: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        gate: z.ZodString;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        consumer: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        phase: z.ZodEnum<{
            candidate: "candidate";
            integration: "integration";
        }>;
        sha: z.ZodString;
        passed: z.ZodBoolean;
        evidenceId: z.ZodString;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        sameVendor: z.ZodBoolean;
        blocking: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        failureKind: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            environment: "environment";
            review: "review";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            merge: "merge";
            budget: "budget";
        }>;
        message: z.ZodString;
        blocked: z.ZodBoolean;
    }, z.core.$strict> | z.ZodObject<{
        leaseUntil: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        integrationSha: z.ZodString;
        accepted: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        resultSha: z.ZodString;
        integrationSha: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
        failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            environment: "environment";
            review: "review";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            merge: "merge";
            budget: "budget";
        }>>>;
    }, z.core.$strict> | z.ZodObject<{
        reason: z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        owner: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        scope: z.ZodEnum<{
            work: "work";
            group: "group";
            total: "total";
        }>;
        scopeId: z.ZodOptional<z.ZodString>;
        state: z.ZodEnum<{
            exceeded: "exceeded";
            undetermined: "undetermined";
        }>;
        reason: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        suite: z.ZodString;
        pending: z.ZodString;
        version: z.ZodNumber;
        digest: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            waiting: "waiting";
        }>;
        accepted: z.ZodArray<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        recoveryId: z.ZodString;
        property: z.ZodString;
        status: z.ZodEnum<{
            stopped: "stopped";
            closed: "closed";
            "awaiting-lead": "awaiting-lead";
            analyzing: "analyzing";
            applying: "applying";
            retry: "retry";
            retrying: "retrying";
            "awaiting-user": "awaiting-user";
        }>;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        policyDigest: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        verificationId: z.ZodString;
        status: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
        }>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        digest: z.ZodString;
        generation: z.ZodNumber;
        by: z.ZodString;
        operation: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        operation: z.ZodString;
        digest: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            requested: "requested";
            cleared: "cleared";
        }>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict> | z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        receipt: z.ZodOptional<z.ZodString>;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        error: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        currentRevision: z.ZodString;
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        attempts: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>[]], "type">;
export type RunEvent = {
    [T in EventType]: Envelope & {
        type: T;
        payload: z.infer<(typeof eventPayloads)[T]>;
    };
}[EventType];
export type RunEventDraft = {
    [T in EventType]: Omit<Envelope, 'apiVersion' | 'seq' | 'at'> & {
        type: T;
        payload: z.infer<(typeof eventPayloads)[T]>;
    };
}[EventType];
/**
 * Типы транзакций исполнения. Это сохранённые строки: DevContour пишет их
 * в журнал аудита как тип события и разбирает (`scheduler.error` — причина
 * остановки очереди), поэтому harness использует те же имена, а не новые.
 * `heartbeat` продлевает сроки и события не создаёт.
 */
export declare const transactionKinds: readonly ["run.claimed", "heartbeat", "run.heartbeat-failed", "run.phase", "run.context", "run.dependencies", "run.dependency-freshness", "run.consumer-checked", "run.implementation-basis", "run.partial", "run.continuation", "run.model", "run.timing.started", "run.timing.finished", "evidence.recorded", "reproduction.recorded", "findings.recorded", "task.done", "run.failed", "run.recovered", "recovery.rejected", "runs.expired", "task.retry", "task.cancelled", "task.held", "task.released", "task.hold-transferred", "wait.started", "wait.cleared", "recovery.reserved", "recovery.decided", "recovery.applied", "recovery.interrupted", "scheduler.started", "scheduler.paused", "scheduler.released", "scheduler.error", "scheduler.blockers", "config.started", "config.reconfigured", "config.reconfigure-requested", "config.reconfigure-cleared", "graph.registered", "graph.reviewed", "graph.approved", "delivery.recorded", "workspace.verification.started", "workspace.manifest", "workspace.evidence", "workspace.verified", "workspace.failed", "base.moved", "workflow.updated", "usage.recorded", "checks.recorded", "checks.adopted", "checks.awaiting-operator", "checks.adoption-abandoned", "checks.spike"];
export type TransactionKind = (typeof transactionKinds)[number];
export {};
