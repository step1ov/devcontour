import { z } from 'zod';
import type { ErrorIssue } from './errors.ts';
/**
 * Откуда пришло поручение: коннектор, ключ записи в нём и её редакция.
 * Результат всегда относится к этой редакции; более новая редакция в
 * источнике старым результатом не закрывается.
 */
export declare const sourceRefSchema: z.ZodObject<{
    connector: z.ZodString;
    ref: z.ZodString;
    revision: z.ZodString;
}, z.core.$strict>;
export type SourceRef = z.infer<typeof sourceRefSchema>;
export declare const propertyIdSchema: z.ZodString;
/** Требование, закреплённое за поручением: текст, digest источника и проверяющий gate. */
export declare const requirementSchema: z.ZodObject<{
    id: z.ZodString;
    source: z.ZodString;
    digest: z.ZodString;
    text: z.ZodString;
    gate: z.ZodString;
    scenario: z.ZodString;
    testId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
/** Ссылка на закреплённый контракт: исполнение идёт против этого digest. */
export declare const contractRefSchema: z.ZodObject<{
    id: z.ZodString;
    digest: z.ZodString;
}, z.core.$strict>;
/** Проверка потребителя: компонент и его gates против integration результата. */
export declare const consumerSchema: z.ZodObject<{
    repositoryId: z.ZodString;
    gates: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
/**
 * Исполняемое поручение. Это снимок постановки, а не редактируемая задача:
 * изменение любого поля — новая редакция источника и новый digest, и прежнее
 * согласование к ней не относится.
 */
export declare const workOrderSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    source: z.ZodObject<{
        connector: z.ZodString;
        ref: z.ZodString;
        revision: z.ZodString;
    }, z.core.$strict>;
    title: z.ZodString;
    goal: z.ZodString;
    acceptance: z.ZodArray<z.ZodString>;
    role: z.ZodString;
    repositoryId: z.ZodString;
    relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
    writeScope: z.ZodArray<z.ZodString>;
    dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
    gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
    consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        gates: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>>;
    properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
    resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        source: z.ZodString;
        digest: z.ZodString;
        text: z.ZodString;
        gate: z.ZodString;
        scenario: z.ZodString;
        testId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        digest: z.ZodString;
    }, z.core.$strict>>>;
    context: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export type WorkOrder = z.infer<typeof workOrderSchema>;
export type WorkOrderInput = z.input<typeof workOrderSchema>;
/**
 * Выполненная внешняя предпосылка. Принимается, только если её подтвердил
 * сам движок (`engine`) либо доверенный получателем receipt; в обоих случаях
 * result SHA обязан быть доступен в целевой ветке. Отметка `done` без SHA
 * доказательством не является.
 */
export declare const prerequisiteSchema: z.ZodObject<{
    id: z.ZodString;
    repositoryId: z.ZodString;
    resultSha: z.ZodString;
    receipt: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"engine">;
        runId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"trusted">;
        issuer: z.ZodString;
        digest: z.ZodString;
    }, z.core.$strict>], "kind">;
}, z.core.$strict>;
export type Prerequisite = z.infer<typeof prerequisiteSchema>;
/** Неизменяемый снимок состава и зависимостей поручений одного согласования. */
export declare const workGraphSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    id: z.ZodString;
    source: z.ZodObject<{
        connector: z.ZodString;
        ref: z.ZodString;
        revision: z.ZodString;
    }, z.core.$strict>;
    orders: z.ZodArray<z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        title: z.ZodString;
        goal: z.ZodString;
        acceptance: z.ZodArray<z.ZodString>;
        role: z.ZodString;
        repositoryId: z.ZodString;
        relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
        writeScope: z.ZodArray<z.ZodString>;
        dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
        gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            gates: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>>;
        properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            source: z.ZodString;
            digest: z.ZodString;
            text: z.ZodString;
            gate: z.ZodString;
            scenario: z.ZodString;
            testId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>>;
        context: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    prerequisites: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        repositoryId: z.ZodString;
        resultSha: z.ZodString;
        receipt: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"engine">;
            runId: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"trusted">;
            issuer: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>], "kind">;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type WorkGraph = z.infer<typeof workGraphSchema>;
export type WorkGraphInput = z.input<typeof workGraphSchema>;
export declare const workOrderDigest: (order: WorkOrder) => string;
/** Digest графа закрепляет согласование: смена состава или поручения — новый digest. */
export declare const workGraphDigest: (graph: WorkGraph) => string;
/**
 * Структурная проверка графа до любой записи: повтор ID, неизвестная
 * зависимость, цикл. Зависимость разрешается поручением этого графа либо
 * подтверждённой предпосылкой; другого способа считать её выполненной нет.
 */
export declare function graphIssues(graph: WorkGraph): (ErrorIssue & {
    code: string;
})[];
