import { type AttemptState, type ControlState, type ControllerLease, type ExecutionDocument, type GraphState, type JointVerificationState, type WorkState } from '../contracts/index.ts';
/**
 * Пустой документ: очередь ещё не запускалась — пауза без причины. Причина
 * появляется только у решения (оператор, штатная остановка, отказ, операция):
 * так первый запуск отличим от паузы, которую поставил человек.
 */
export declare const emptyDocument: () => ExecutionDocument;
/** Чтение и запись записей модели поверх документа — общая часть адаптеров хранилища. */
export declare class DocumentView {
    readonly doc: ExecutionDocument;
    constructor(doc: ExecutionDocument);
    control(): ControlState;
    controller(): ControllerLease | undefined;
    graph(id: string): {
        id: string;
        digest: string;
        graph: {
            apiVersion: "devcontour-harness/v1alpha1";
            id: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            orders: {
                apiVersion: "devcontour-harness/v1alpha1";
                id: string;
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                title: string;
                goal: string;
                acceptance: string[];
                role: string;
                repositoryId: string;
                relatedRepositories: string[];
                writeScope: string[];
                dependsOn: string[];
                requirements: {
                    id: string;
                    source: string;
                    digest: string;
                    text: string;
                    gate: string;
                    scenario: string;
                    testId?: string | undefined;
                }[];
                contracts: {
                    id: string;
                    digest: string;
                }[];
                context: string[];
                gates?: string[] | undefined;
                consumers?: {
                    repositoryId: string;
                    gates: string[];
                }[] | undefined;
                properties?: string[] | undefined;
                resources?: string[] | undefined;
            }[];
            prerequisites: {
                id: string;
                repositoryId: string;
                resultSha: string;
                receipt: {
                    kind: "engine";
                    runId: string;
                } | {
                    kind: "trusted";
                    issuer: string;
                    digest: string;
                };
            }[];
        };
        policyDigest: string;
        registeredAt: string;
        approval?: {
            actor: "agent" | "operator";
            at: string;
            authorRuntime?: "codex" | "claude" | "fixture" | undefined;
            reviewerRuntime?: "codex" | "claude" | "fixture" | undefined;
            artifact?: string | undefined;
            digest?: string | undefined;
            context?: {
                digest: string | null;
            } | undefined;
        } | undefined;
    } | undefined;
    graphs(): {
        id: string;
        digest: string;
        graph: {
            apiVersion: "devcontour-harness/v1alpha1";
            id: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            orders: {
                apiVersion: "devcontour-harness/v1alpha1";
                id: string;
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                title: string;
                goal: string;
                acceptance: string[];
                role: string;
                repositoryId: string;
                relatedRepositories: string[];
                writeScope: string[];
                dependsOn: string[];
                requirements: {
                    id: string;
                    source: string;
                    digest: string;
                    text: string;
                    gate: string;
                    scenario: string;
                    testId?: string | undefined;
                }[];
                contracts: {
                    id: string;
                    digest: string;
                }[];
                context: string[];
                gates?: string[] | undefined;
                consumers?: {
                    repositoryId: string;
                    gates: string[];
                }[] | undefined;
                properties?: string[] | undefined;
                resources?: string[] | undefined;
            }[];
            prerequisites: {
                id: string;
                repositoryId: string;
                resultSha: string;
                receipt: {
                    kind: "engine";
                    runId: string;
                } | {
                    kind: "trusted";
                    issuer: string;
                    digest: string;
                };
            }[];
        };
        policyDigest: string;
        registeredAt: string;
        approval?: {
            actor: "agent" | "operator";
            at: string;
            authorRuntime?: "codex" | "claude" | "fixture" | undefined;
            reviewerRuntime?: "codex" | "claude" | "fixture" | undefined;
            artifact?: string | undefined;
            digest?: string | undefined;
            context?: {
                digest: string | null;
            } | undefined;
        } | undefined;
    }[];
    work(id: string): {
        id: string;
        graphId: string;
        order: {
            apiVersion: "devcontour-harness/v1alpha1";
            id: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            title: string;
            goal: string;
            acceptance: string[];
            role: string;
            repositoryId: string;
            relatedRepositories: string[];
            writeScope: string[];
            dependsOn: string[];
            requirements: {
                id: string;
                source: string;
                digest: string;
                text: string;
                gate: string;
                scenario: string;
                testId?: string | undefined;
            }[];
            contracts: {
                id: string;
                digest: string;
            }[];
            context: string[];
            gates?: string[] | undefined;
            consumers?: {
                repositoryId: string;
                gates: string[];
            }[] | undefined;
            properties?: string[] | undefined;
            resources?: string[] | undefined;
        };
        status: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        attempt: number;
        activeRunId?: string | undefined;
        resultSha?: string | undefined;
        failure?: string | undefined;
        failureKind?: "gate" | "unknown" | "environment" | "review" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "scope-violation" | "merge" | "budget" | undefined;
        failureFingerprint?: string | undefined;
        approvedAt?: string | undefined;
        approvedDigest?: string | undefined;
        approvedScope?: string | undefined;
        approval?: {
            actor: "agent" | "operator";
            authorRuntime?: "codex" | "claude" | "fixture" | undefined;
            reviewerRuntime?: "codex" | "claude" | "fixture" | undefined;
            artifact?: string | undefined;
            digest?: string | undefined;
            context?: {
                digest: string | null;
            } | undefined;
        } | undefined;
        hold?: {
            operation: string;
            reason: string;
        } | undefined;
        budgetBlock?: {
            reason: string;
            at: string;
        } | undefined;
        checkVersion?: {
            suite: string;
            number: number;
            digest: string;
        } | undefined;
        recovery?: {
            id: string;
            property: string;
            basis: string;
            runs: string[];
            openedAt: string;
            status: "stopped" | "closed" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
            calls: number;
            history: {
                at: string;
                event: string;
                detail?: string | undefined;
            }[];
            version: number;
            decision?: {
                action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                reason: string;
                evidence: string[];
                source: {
                    kind: "operator" | "lead";
                    runtime?: string | undefined;
                    model?: string | undefined;
                };
                decidedAt: string;
                hypothesis?: string | undefined;
                plan?: string | undefined;
                cases?: {
                    input: string;
                    expected?: string | null | undefined;
                }[] | undefined;
                proposal?: string | undefined;
                conflict?: string | undefined;
            } | undefined;
            retryRun?: string | undefined;
            reason?: string | undefined;
        } | undefined;
        recoveryHistory?: {
            id: string;
            property: string;
            basis: string;
            runs: string[];
            openedAt: string;
            status: "stopped" | "closed" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
            calls: number;
            history: {
                at: string;
                event: string;
                detail?: string | undefined;
            }[];
            version: number;
            decision?: {
                action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                reason: string;
                evidence: string[];
                source: {
                    kind: "operator" | "lead";
                    runtime?: string | undefined;
                    model?: string | undefined;
                };
                decidedAt: string;
                hypothesis?: string | undefined;
                plan?: string | undefined;
                cases?: {
                    input: string;
                    expected?: string | null | undefined;
                }[] | undefined;
                proposal?: string | undefined;
                conflict?: string | undefined;
            } | undefined;
            retryRun?: string | undefined;
            reason?: string | undefined;
        }[] | undefined;
    } | undefined;
    works(graphId?: string): {
        id: string;
        graphId: string;
        order: {
            apiVersion: "devcontour-harness/v1alpha1";
            id: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            title: string;
            goal: string;
            acceptance: string[];
            role: string;
            repositoryId: string;
            relatedRepositories: string[];
            writeScope: string[];
            dependsOn: string[];
            requirements: {
                id: string;
                source: string;
                digest: string;
                text: string;
                gate: string;
                scenario: string;
                testId?: string | undefined;
            }[];
            contracts: {
                id: string;
                digest: string;
            }[];
            context: string[];
            gates?: string[] | undefined;
            consumers?: {
                repositoryId: string;
                gates: string[];
            }[] | undefined;
            properties?: string[] | undefined;
            resources?: string[] | undefined;
        };
        status: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        attempt: number;
        activeRunId?: string | undefined;
        resultSha?: string | undefined;
        failure?: string | undefined;
        failureKind?: "gate" | "unknown" | "environment" | "review" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "scope-violation" | "merge" | "budget" | undefined;
        failureFingerprint?: string | undefined;
        approvedAt?: string | undefined;
        approvedDigest?: string | undefined;
        approvedScope?: string | undefined;
        approval?: {
            actor: "agent" | "operator";
            authorRuntime?: "codex" | "claude" | "fixture" | undefined;
            reviewerRuntime?: "codex" | "claude" | "fixture" | undefined;
            artifact?: string | undefined;
            digest?: string | undefined;
            context?: {
                digest: string | null;
            } | undefined;
        } | undefined;
        hold?: {
            operation: string;
            reason: string;
        } | undefined;
        budgetBlock?: {
            reason: string;
            at: string;
        } | undefined;
        checkVersion?: {
            suite: string;
            number: number;
            digest: string;
        } | undefined;
        recovery?: {
            id: string;
            property: string;
            basis: string;
            runs: string[];
            openedAt: string;
            status: "stopped" | "closed" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
            calls: number;
            history: {
                at: string;
                event: string;
                detail?: string | undefined;
            }[];
            version: number;
            decision?: {
                action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                reason: string;
                evidence: string[];
                source: {
                    kind: "operator" | "lead";
                    runtime?: string | undefined;
                    model?: string | undefined;
                };
                decidedAt: string;
                hypothesis?: string | undefined;
                plan?: string | undefined;
                cases?: {
                    input: string;
                    expected?: string | null | undefined;
                }[] | undefined;
                proposal?: string | undefined;
                conflict?: string | undefined;
            } | undefined;
            retryRun?: string | undefined;
            reason?: string | undefined;
        } | undefined;
        recoveryHistory?: {
            id: string;
            property: string;
            basis: string;
            runs: string[];
            openedAt: string;
            status: "stopped" | "closed" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
            calls: number;
            history: {
                at: string;
                event: string;
                detail?: string | undefined;
            }[];
            version: number;
            decision?: {
                action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                reason: string;
                evidence: string[];
                source: {
                    kind: "operator" | "lead";
                    runtime?: string | undefined;
                    model?: string | undefined;
                };
                decidedAt: string;
                hypothesis?: string | undefined;
                plan?: string | undefined;
                cases?: {
                    input: string;
                    expected?: string | null | undefined;
                }[] | undefined;
                proposal?: string | undefined;
                conflict?: string | undefined;
            } | undefined;
            retryRun?: string | undefined;
            reason?: string | undefined;
        }[] | undefined;
    }[];
    attempt(id: string): {
        id: string;
        workId: string;
        repositoryId: string;
        attempt: number;
        token: string;
        owner: string;
        runtime: "codex" | "claude" | "fixture";
        reviewer: "codex" | "claude" | "fixture";
        policyDigest: string;
        status: "failed" | "cancelled" | "active" | "succeeded" | "expired";
        phase: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        startedAt: string;
        leaseUntil: number;
        evidence: {
            id: string;
            runId: string;
            kind: "test" | "review";
            phase: "candidate" | "integration";
            sha: string;
            gate: string;
            passed: boolean;
            createdAt: string;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            consumer?: string | undefined;
            inspection?: {
                mode: "commands" | "diff-only";
                source: "codex-events" | "unavailable";
                commands: {
                    command: string;
                    exitCode: number;
                    output: string;
                }[];
                reason: string | null;
            } | undefined;
            findings?: {
                severity: string;
                message: string;
                path?: string | null | undefined;
                line?: number | null | undefined;
            }[] | undefined;
            tests?: {
                id: string;
                status: "passed" | "failed" | "skipped";
                opaque?: true | undefined;
            }[] | undefined;
            testsTruncated?: boolean | undefined;
            property?: {
                seed: number;
                reproduce: string;
                contracts: Record<string, string>;
                artifacts: {
                    path: string;
                    blob: string;
                }[];
                report?: {
                    version: 1;
                    properties: {
                        testId: string;
                        status: "passed" | "failed" | "running";
                        cases: number;
                        families?: Record<string, number> | undefined;
                        error?: string | undefined;
                        current?: unknown;
                        counterexample?: {
                            original: unknown;
                            reduced?: unknown;
                            expected?: unknown;
                            actual?: unknown;
                            reductionTimedOut?: boolean | undefined;
                            case?: string | undefined;
                        } | undefined;
                    }[];
                    seed?: number | undefined;
                    corpus?: {
                        digest: string;
                        executed: number;
                        passed: number;
                        witness: string;
                        failed: {
                            id: string;
                            property: string;
                            expected?: unknown;
                            actual?: unknown;
                        }[];
                    } | undefined;
                } | undefined;
                problem?: string | undefined;
                level?: "manifest" | "legacy" | undefined;
                manifest?: {
                    digest: string;
                    properties: string[];
                    corpus?: {
                        digest: string;
                        cases: number;
                    } | undefined;
                } | undefined;
                coverage?: string[] | undefined;
            } | undefined;
            checks?: string | undefined;
        }[];
        model?: string | undefined;
        reviewerModel?: string | undefined;
        effort?: string | undefined;
        reviewerEffort?: string | undefined;
        finishedAt?: string | undefined;
        worktree?: string | undefined;
        baseSha?: string | undefined;
        candidateSha?: string | undefined;
        integrationSha?: string | undefined;
        error?: string | undefined;
        blocked?: boolean | undefined;
        failureKind?: "gate" | "unknown" | "environment" | "review" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "scope-violation" | "merge" | "budget" | undefined;
        failureFingerprint?: string | undefined;
        requiredGates?: string[] | undefined;
        consumers?: {
            repositoryId: string;
            gates: string[];
            checked?: {
                sha: string;
                tree: string;
                dependencies: {
                    repositoryId: string;
                    sha: string;
                    tree: string;
                    artifacts: {
                        path: string;
                        digest: string;
                    }[];
                }[];
                freshness?: {
                    repositoryId: string;
                    snapshot: string;
                    head: string;
                    fresh: boolean;
                }[] | undefined;
                observedAt?: string | undefined;
            } | undefined;
        }[] | undefined;
        checks?: {
            effective: string;
            corpus?: {
                suite: string;
                number: number;
                digest: string;
            } | undefined;
        } | undefined;
        context?: {
            id: string;
            version: string;
            repositoryId: string;
            revision: string;
            digest: string;
        }[] | undefined;
        contextSnapshot?: string | undefined;
        resources?: {
            id: string;
            kind: "device" | "port" | "account" | "service";
            value: string;
        }[] | undefined;
        dependencies?: {
            repositoryId: string;
            sha: string;
            tree: string;
            path: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
        }[] | undefined;
        dependencyFreshness?: {
            repositoryId: string;
            snapshot: string;
            head: string;
            fresh: boolean;
        }[] | undefined;
        properties?: string[] | undefined;
        unboundProperties?: string[] | undefined;
        episodeBasis?: string | undefined;
        implementationBasis?: string | undefined;
        reusedFrom?: {
            runId: string;
            candidateSha: string;
        } | undefined;
        partial?: {
            patch: string;
            digest: string;
            files: string[];
            spec: string;
            contracts: Record<string, string>;
        } | undefined;
        continuedFrom?: {
            runId: string;
            kind: "candidate" | "unfinished";
            applied: boolean;
            files: string[];
            reason?: "gate" | "unknown" | "environment" | "review" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "scope-violation" | "merge" | "budget" | undefined;
            respecified?: boolean | undefined;
        } | undefined;
        callsRecorded?: true | undefined;
        dispatch?: {
            policy: "fifo-ready-v1";
            at: string;
            eligible: {
                taskId: string;
                attempt: number;
                repositoryId?: string | undefined;
            }[];
            activeCount: number;
            concurrency: number;
            inputDigest: string;
        } | undefined;
        wait?: {
            approvedAt?: string | undefined;
            readyAt?: string | undefined;
        } | undefined;
        timings?: {
            id: string;
            stage: string;
            startedAt: string;
            finishedAt?: string | undefined;
            outcome?: "passed" | "failed" | undefined;
        }[] | undefined;
        pinned?: {
            graphId: string;
            graphDigest: string;
            orderDigest: string;
            targetRef: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
        } | undefined;
        engineVersion?: string | undefined;
        consumerVersion?: string | undefined;
    } | undefined;
    attempts(workId?: string): {
        id: string;
        workId: string;
        repositoryId: string;
        attempt: number;
        token: string;
        owner: string;
        runtime: "codex" | "claude" | "fixture";
        reviewer: "codex" | "claude" | "fixture";
        policyDigest: string;
        status: "failed" | "cancelled" | "active" | "succeeded" | "expired";
        phase: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        startedAt: string;
        leaseUntil: number;
        evidence: {
            id: string;
            runId: string;
            kind: "test" | "review";
            phase: "candidate" | "integration";
            sha: string;
            gate: string;
            passed: boolean;
            createdAt: string;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            consumer?: string | undefined;
            inspection?: {
                mode: "commands" | "diff-only";
                source: "codex-events" | "unavailable";
                commands: {
                    command: string;
                    exitCode: number;
                    output: string;
                }[];
                reason: string | null;
            } | undefined;
            findings?: {
                severity: string;
                message: string;
                path?: string | null | undefined;
                line?: number | null | undefined;
            }[] | undefined;
            tests?: {
                id: string;
                status: "passed" | "failed" | "skipped";
                opaque?: true | undefined;
            }[] | undefined;
            testsTruncated?: boolean | undefined;
            property?: {
                seed: number;
                reproduce: string;
                contracts: Record<string, string>;
                artifacts: {
                    path: string;
                    blob: string;
                }[];
                report?: {
                    version: 1;
                    properties: {
                        testId: string;
                        status: "passed" | "failed" | "running";
                        cases: number;
                        families?: Record<string, number> | undefined;
                        error?: string | undefined;
                        current?: unknown;
                        counterexample?: {
                            original: unknown;
                            reduced?: unknown;
                            expected?: unknown;
                            actual?: unknown;
                            reductionTimedOut?: boolean | undefined;
                            case?: string | undefined;
                        } | undefined;
                    }[];
                    seed?: number | undefined;
                    corpus?: {
                        digest: string;
                        executed: number;
                        passed: number;
                        witness: string;
                        failed: {
                            id: string;
                            property: string;
                            expected?: unknown;
                            actual?: unknown;
                        }[];
                    } | undefined;
                } | undefined;
                problem?: string | undefined;
                level?: "manifest" | "legacy" | undefined;
                manifest?: {
                    digest: string;
                    properties: string[];
                    corpus?: {
                        digest: string;
                        cases: number;
                    } | undefined;
                } | undefined;
                coverage?: string[] | undefined;
            } | undefined;
            checks?: string | undefined;
        }[];
        model?: string | undefined;
        reviewerModel?: string | undefined;
        effort?: string | undefined;
        reviewerEffort?: string | undefined;
        finishedAt?: string | undefined;
        worktree?: string | undefined;
        baseSha?: string | undefined;
        candidateSha?: string | undefined;
        integrationSha?: string | undefined;
        error?: string | undefined;
        blocked?: boolean | undefined;
        failureKind?: "gate" | "unknown" | "environment" | "review" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "scope-violation" | "merge" | "budget" | undefined;
        failureFingerprint?: string | undefined;
        requiredGates?: string[] | undefined;
        consumers?: {
            repositoryId: string;
            gates: string[];
            checked?: {
                sha: string;
                tree: string;
                dependencies: {
                    repositoryId: string;
                    sha: string;
                    tree: string;
                    artifacts: {
                        path: string;
                        digest: string;
                    }[];
                }[];
                freshness?: {
                    repositoryId: string;
                    snapshot: string;
                    head: string;
                    fresh: boolean;
                }[] | undefined;
                observedAt?: string | undefined;
            } | undefined;
        }[] | undefined;
        checks?: {
            effective: string;
            corpus?: {
                suite: string;
                number: number;
                digest: string;
            } | undefined;
        } | undefined;
        context?: {
            id: string;
            version: string;
            repositoryId: string;
            revision: string;
            digest: string;
        }[] | undefined;
        contextSnapshot?: string | undefined;
        resources?: {
            id: string;
            kind: "device" | "port" | "account" | "service";
            value: string;
        }[] | undefined;
        dependencies?: {
            repositoryId: string;
            sha: string;
            tree: string;
            path: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
        }[] | undefined;
        dependencyFreshness?: {
            repositoryId: string;
            snapshot: string;
            head: string;
            fresh: boolean;
        }[] | undefined;
        properties?: string[] | undefined;
        unboundProperties?: string[] | undefined;
        episodeBasis?: string | undefined;
        implementationBasis?: string | undefined;
        reusedFrom?: {
            runId: string;
            candidateSha: string;
        } | undefined;
        partial?: {
            patch: string;
            digest: string;
            files: string[];
            spec: string;
            contracts: Record<string, string>;
        } | undefined;
        continuedFrom?: {
            runId: string;
            kind: "candidate" | "unfinished";
            applied: boolean;
            files: string[];
            reason?: "gate" | "unknown" | "environment" | "review" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "scope-violation" | "merge" | "budget" | undefined;
            respecified?: boolean | undefined;
        } | undefined;
        callsRecorded?: true | undefined;
        dispatch?: {
            policy: "fifo-ready-v1";
            at: string;
            eligible: {
                taskId: string;
                attempt: number;
                repositoryId?: string | undefined;
            }[];
            activeCount: number;
            concurrency: number;
            inputDigest: string;
        } | undefined;
        wait?: {
            approvedAt?: string | undefined;
            readyAt?: string | undefined;
        } | undefined;
        timings?: {
            id: string;
            stage: string;
            startedAt: string;
            finishedAt?: string | undefined;
            outcome?: "passed" | "failed" | undefined;
        }[] | undefined;
        pinned?: {
            graphId: string;
            graphDigest: string;
            orderDigest: string;
            targetRef: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
        } | undefined;
        engineVersion?: string | undefined;
        consumerVersion?: string | undefined;
    }[];
    verification(id: string): {
        status: "active";
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        token: string;
        leaseUntil: number;
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "failed";
        finishedAt: string;
        error: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        token: string;
        leaseUntil: number;
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "passed";
        finishedAt: string;
        manifest: Record<string, {
            sha: string;
            tree: string;
        }>;
        manifestDigest: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        token: string;
        leaseUntil: number;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | undefined;
    verifications(): ({
        status: "active";
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        token: string;
        leaseUntil: number;
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "failed";
        finishedAt: string;
        error: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        token: string;
        leaseUntil: number;
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "passed";
        finishedAt: string;
        manifest: Record<string, {
            sha: string;
            tree: string;
        }>;
        manifestDigest: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        token: string;
        leaseUntil: number;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    })[];
    putGraph(graph: GraphState): void;
    putWork(work: WorkState): void;
    putAttempt(attempt: AttemptState): void;
    putVerification(verification: JointVerificationState): void;
    setControl(control: ControlState): void;
    setController(lease: ControllerLease | undefined): void;
}
