import { type ExecutionPolicy } from '../contracts/index.ts';
type Resource = ExecutionPolicy['resources'][number];
export declare const resourceKey: (r: Resource) => string;
/**
 * База блокировок ресурсов машины. Общая с DevContour (`~/.devcontour-local/
 * resources.sqlite`): устройство или порт исключительны для всех контуров
 * одной машины, а не для одного каталога состояния.
 */
export declare const defaultResourceDatabase: () => string;
type LeaseRow = {
    key: string;
    resource: string;
    owner: string;
    token: string;
    pid: number;
    expires: number;
};
export declare class ResourcePool {
    private db;
    constructor(path: string);
    list(): LeaseRow[];
    tryAcquire(resources: Resource[], owner: string, token: string, ttl: number): boolean;
    heartbeat(token: string, count: number, ttl: number): void;
    release(token: string): void;
    clearAbandoned(key: string, token: string): void;
    close(): void;
}
export declare function withResources<T>(config: Pick<ExecutionPolicy, 'resources' | 'leaseMs'> & {
    resourceDatabase: string;
}, ids: string[], owner: string, signal: AbortSignal, work: (signal: AbortSignal, resources: Resource[]) => Promise<T>): Promise<T>;
export {};
