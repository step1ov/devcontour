import type { z } from 'zod';
import { environmentSchema, lifecycleSchema, stepSchema, type ExecutionPolicy } from '../contracts/index.ts';
export { redactor } from './redaction.ts';
type Environment = z.infer<typeof environmentSchema>;
type Lifecycle = z.infer<typeof lifecycleSchema>;
type Step = z.infer<typeof stepSchema>;
/** Отказ обязательной очистки окружения: приёмка с ним не происходит. */
export declare class CleanupFailure extends Error {
    name: string;
}
/** Жив ли процесс (сигнал 0 не доставляется, только проверяется). */
export declare function processAlive(pid: number): boolean;
export declare function executionEnvironment(profiles: (Environment | undefined)[], devcontour?: NodeJS.ProcessEnv, source?: NodeJS.ProcessEnv): {
    env: NodeJS.ProcessEnv;
    redact: import("./redaction.ts").Redactor;
};
/**
 * Маска по тем секретам и наследуемым значениям, что заданы, — даже когда
 * окружение целиком собрать нельзя. Незаданный секрет — причина отказа, но не
 * повод снимать маску с остальных: известный секрет иначе сохранялся бы в
 * команде и итоге проверки.
 */
export declare function availableRedactor(profiles: (Environment | undefined)[], source?: NodeJS.ProcessEnv): import("./redaction.ts").Redactor;
export declare function runSteps(steps: Step[], cwd: string, dir: string, execution: ReturnType<typeof executionEnvironment>, signal: AbortSignal): Promise<void>;
export declare function withEnvironment<T>(lifecycle: Lifecycle | undefined, cwd: string, dir: string, execution: ReturnType<typeof executionEnvironment>, signal: AbortSignal, action: () => Promise<T>, measure?: <R>(stage: string, action: () => Promise<R>) => Promise<R>): Promise<T>;
/**
 * Завершить очистку окружения, прерванную падением процесса: по сохранённому
 * receipt, только внутри разрешённых корней, только при той же политике
 * очистки и только когда процесс-владелец уже не существует (или это он сам,
 * `options.owner`, после окончания попытки).
 */
export declare function cleanupEnvironment(receiptPath: string, policy: ExecutionPolicy, allowedRoots: string[], 
/** `owner` — процесс, который вправе повторить очистку своего окружения сам. */
options?: {
    owner?: number;
}): Promise<{
    status: "already-cleaned";
} | {
    status: "cleaned";
}>;
