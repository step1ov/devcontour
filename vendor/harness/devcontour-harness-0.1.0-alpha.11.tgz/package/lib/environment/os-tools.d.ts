/**
 * Системные утилиты, которыми ядро наблюдает процессы (`ps`, `lsof`) и
 * владение вызовами (`sysctl`). Они ищутся по фиксированным абсолютным путям
 * ОС раньше PATH: урезанный PATH (только node и git) не лишает ядро
 * containment, а файл из проекта или worktree с тем же именем не
 * запускается. PATH — только запасной путь, когда ни одного штатного
 * расположения нет (нестандартная ОС); поведение тогда прежнее.
 */
export declare const OS_TOOL_CANDIDATES: {
    readonly ps: readonly ["/bin/ps", "/usr/bin/ps"];
    readonly lsof: readonly ["/usr/sbin/lsof", "/usr/bin/lsof", "/sbin/lsof", "/bin/lsof"];
    readonly sysctl: readonly ["/usr/sbin/sysctl", "/sbin/sysctl", "/usr/bin/sysctl"];
};
export type OsTool = keyof typeof OS_TOOL_CANDIDATES;
/** Исполняемый файл утилиты: первый существующий штатный путь, иначе имя для PATH. */
export declare function osTool(name: OsTool, candidates?: readonly string[]): string;
