import { type CallOwner } from '../engine/usage.ts';
/** Момент старта процесса по данным ОС, мс; `undefined` — узнать нельзя. */
export declare function processStartedAt(pid: number): number | undefined;
/**
 * Этот процесс: по нему восстановление и бюджет отличают свои идущие вызовы.
 * Момент старта отличает процесс от другого, получившего тот же pid.
 */
export declare const CURRENT_PROCESS: CallOwner;
/**
 * Идентификатор текущей загрузки ОС: Linux сообщает его прямо, macOS — момент
 * загрузки. `undefined` — узнать нельзя, и монотонные часы ОС между
 * процессами не сравниваются.
 */
export declare const BOOT_ID: string | undefined;
