import { type Redactor } from './redaction.ts';
import type { RuntimeDiagnostics } from '../contracts/index.ts';
export interface CommandResult {
    code: number;
    stdout: string;
    stderr: string;
    timedOut: boolean;
    diagnostics: RuntimeDiagnostics;
}
export declare function command(argv: string[], cwd: string, options?: {
    signal?: AbortSignal;
    timeoutMs?: number;
    input?: string;
    env?: NodeJS.ProcessEnv;
    redact?: Redactor;
    onOutput?: (stream: 'stdout' | 'stderr', text: string) => void;
    /**
     * Немаскированный stdout — только в памяти вызывающего, для разбора
     * структуры (события runtime): маска по всему потоку портила бы и
     * служебные строки JSON. Сохранять его нельзя.
     */
    onRawStdout?: (text: string) => void;
    /** Процесс запущен (событие `spawn`): до него команда не исполнялась. */
    onSpawn?: () => void;
    /**
     * Владеть всеми потомками, включая сменивших группу или сессию: после
     * завершения они останавливаются, и результат не возвращается, пока
     * хотя бы один жив. Сигнал группе не достаёт отсоединившегося потомка.
     *
     * Потомок узнаётся по любому из трёх признаков: метка окружения (её
     * наследуют все, кто не очистил окружение), замеченное опросом родство с
     * командой и текущий каталог внутри `dirs` — каталогов, которые принадлежат
     * только этой команде (worktree, scratch). Ни один признак сам по себе не
     * полон: окружение можно очистить, опрос можно опередить, каталог сменить.
     */
    contain?: boolean | {
        dirs: string[];
    };
}): Promise<CommandResult>;
export declare function git(cwd: string, ...args: string[]): Promise<string>;
