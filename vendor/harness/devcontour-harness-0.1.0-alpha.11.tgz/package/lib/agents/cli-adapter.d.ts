import type { z } from 'zod';
import type { ProbeServer, RuntimeAdapter, toolProfileSchema } from '../contracts/index.ts';
type ToolProfile = z.infer<typeof toolProfileSchema>;
/** Встроенные инструменты исполнителя claude, когда профиль их не называет; shell — в песочнице ОС. */
export declare const claudeWriterTools: readonly ["Read", "Glob", "Grep", "Edit", "Write", "Bash"];
/** Может ли reviewer запускать проверки: у claude — только Bash, явно данный профилем. */
export declare function reviewerRunsChecks(runtime: 'codex' | 'claude', profile?: ToolProfile): boolean;
export declare function writerRunsChecks(runtime: 'codex' | 'claude', profile?: ToolProfile): boolean;
/**
 * MCP-серверы прогона codex: серверы профиля инструментов назначения и сервер
 * проверок reviewer, если он дан. Глобальная конфигурация оператора и её
 * серверы в прогон не попадают.
 */
export declare function codexServers(probe?: ProbeServer, profile?: ToolProfile): string;
/** MCP-конфигурация claude: серверы профиля и сервер проверок reviewer. */
export declare function claudeMcp(probe?: ProbeServer, profile?: ToolProfile): {
    mcpServers: {
        devcontour_probe?: {
            type: string;
            command: string;
            args: string[];
            env: {
                [k: string]: string;
            };
        } | undefined;
    };
};
export interface CliAdapterOptions {
    /** Исполняемый файл runtime; по умолчанию — имя runtime из PATH. Тесты подставляют fixture executable. */
    executable?: string;
    toolProfiles?: Record<string, ToolProfile>;
    /**
     * Имена элементов каталога состояния хоста (конфигурация, журналы, решения),
     * которые закрываются для runtime и тогда, когда появляются после старта
     * вызова. Каталог над открытым worktree закрывается поэлементно, и элемент,
     * которого нет в снимке и в этом перечне, остался бы открытым.
     */
    controllerEntries?: string[];
}
/**
 * Адаптер CLI codex или claude. Каждый вызов — новая сессия: reviewer и
 * planner не получают сессии writer (`continue` отклоняется). Граница
 * доступа — нативная песочница runtime с политикой harness: запись только
 * в разрешённые каталоги, состояние controller и учётные данные закрыты.
 * Ответ возвращается сырым (`output`); разбирает и проверяет его движок.
 */
export declare function cliAdapter(runtime: 'codex' | 'claude', options?: CliAdapterOptions): RuntimeAdapter;
export {};
