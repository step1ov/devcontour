import { z } from 'zod';
export declare function runtimeEvents(output: string): {
    events: Record<string, unknown>[];
    malformed: boolean;
};
export declare const claudeResult: z.ZodObject<{
    type: z.ZodLiteral<"result">;
    is_error: z.ZodOptional<z.ZodBoolean>;
    result: z.ZodOptional<z.ZodString>;
    structured_output: z.ZodUnknown;
}, z.core.$strip>;
