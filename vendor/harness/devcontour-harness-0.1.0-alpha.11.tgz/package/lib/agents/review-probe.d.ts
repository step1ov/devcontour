import { z } from 'zod';
import { type ExecutionPolicy, type GatePolicy, type ProbeServer } from '../contracts/index.ts';
/**
 * Пробные проверки reviewer под пределами harness.
 *
 * Reviewer, запускавший проверки своим shell, зависал на проверяемом коде:
 * срок команды задавал сам CLI модели, и одна зависшая команда съедала весь
 * срок ревью — готовый кандидат падал без вердикта. Здесь срок задаёт
 * controller: команда исполняется тем же исполнителем, что и gates (песочница
 * ОС, исходники только для чтения, остановка потомков), с пределом на
 * команду, общим бюджетом проверок и резервом времени на заключение.
 * Превышение — результат, который получает модель, а не зависание.
 *
 * Объявленный gate reviewer запускает по ID (`{"gate":"<id>"}`): argv, cwd и
 * окружение controller берёт из эффективной политики, JUnit пишется в
 * собственный scratch controller вне проверяемого дерева
 * (`HARNESS_REPORT_PATH`/`DEVCONTOUR_REPORT_PATH`), отчёт и метаданные
 * сохраняются в каталоге ревью до удаления scratch. На пилоте reviewer
 * запускал команду gate через argv, проверка писала `.reports/*.xml` в
 * дерево только для чтения и падала с EPERM. Ответ модели не задаёт ни
 * argv gate, ни пути, ни окружение: лишнее поле — отказ протокола.
 */
export declare const probeServer = "devcontour_probe";
export declare const probeTool = "run_check";
/** Объявленный gate в виде, в каком его исполняет probe: копия из эффективной политики. */
export declare const probeGate: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        check: "check";
        test: "test";
    }>;
    command: z.ZodArray<z.ZodString>;
    cwd: z.ZodOptional<z.ZodString>;
    timeoutMs: z.ZodNumber;
    report: z.ZodOptional<z.ZodObject<{
        type: z.ZodLiteral<"junit">;
        path: z.ZodString;
    }, z.core.$strict>>;
    property: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type ProbeGate = z.infer<typeof probeGate>;
export declare const probeSpec: z.ZodObject<{
    cwd: z.ZodString;
    controller: z.ZodArray<z.ZodString>;
    readable: z.ZodArray<z.ZodString>;
    isolation: z.ZodObject<{
        mode: z.ZodEnum<{
            os: "os";
            none: "none";
        }>;
        domains: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    commandTimeoutMs: z.ZodNumber;
    budgetMs: z.ZodNumber;
    deadline: z.ZodNumber;
    env: z.ZodArray<z.ZodString>;
    secrets: z.ZodArray<z.ZodString>;
    settingsDir: z.ZodString;
    log: z.ZodString;
    gates: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            check: "check";
            test: "test";
        }>;
        command: z.ZodArray<z.ZodString>;
        cwd: z.ZodOptional<z.ZodString>;
        timeoutMs: z.ZodNumber;
        report: z.ZodOptional<z.ZodObject<{
            type: z.ZodLiteral<"junit">;
            path: z.ZodString;
        }, z.core.$strict>>;
        property: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>>;
    phase: z.ZodOptional<z.ZodString>;
    sha: z.ZodOptional<z.ZodString>;
    scope: z.ZodOptional<z.ZodObject<{
        attempt: z.ZodString;
        phase: z.ZodString;
        sha: z.ZodString;
        call: z.ZodNumber;
    }, z.core.$strict>>;
    artifacts: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type ProbeSpec = z.infer<typeof probeSpec>;
export declare const probeInput: z.ZodObject<{
    argv: z.ZodOptional<z.ZodArray<z.ZodString>>;
    gate: z.ZodOptional<z.ZodString>;
    timeoutMs: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
/** Состояние JUnit-отчёта запуска gate, как его увидел controller. */
export type ProbeReport = {
    /**
     * `fresh` — обычный файл, созданный этим запуском в scratch controller и
     * разобранный; `missing` — отчёта нет; `stale` — файл старше запуска
     * (скопирован с прежним временем); `corrupt` — не JUnit или без testcases;
     * `unsafe` — symlink, жёсткая ссылка или путь вне scratch: не читается.
     */
    status: 'fresh' | 'missing' | 'stale' | 'corrupt' | 'unsafe';
    /** Сохранённая копия (замаскированная) в каталоге controller. */
    path?: string;
    digest?: string;
    tests?: number;
    failures?: number;
    skipped?: number;
    failed?: string[];
    problem?: string;
};
/** Запуск объявленного gate через probe: что, где и на чём исполнено. */
export type ProbeGateRun = {
    id: string;
    phase: string | null;
    sha: string | null;
    /** Каталог запуска относительно проверяемого дерева. */
    cwd: string;
    /** Фактический argv (замаскированный) — из политики, не из ответа модели. */
    argv: string[];
    /** Имена переменных, которые выставил controller (значения не пишутся). */
    controllerEnv: string[];
    report?: ProbeReport;
    /** Каталог evidence запуска в каталоге ревью controller. */
    artifacts?: string;
    /** Временный каталог отчёта; убран после сохранения evidence. */
    scratch?: string;
    scratchRemoved?: boolean;
};
export type ProbeResult = {
    /**
     * Id запуска. Reviewer ссылается на него в воспроизведении, и «наблюдено»
     * ставится по журналу controller, а не по тексту команды: замаскированные
     * аргументы разных команд могут совпадать.
     */
    runId: string;
    argv: string[];
    /**
     * `timeout` — команда не уложилась в предел и остановлена вместе с
     * потомками; это наблюдение о команде на данном входе, а не доказанный
     * дефект. `budget-exhausted` — команда не запускалась: бюджет проверок или
     * время до заключения исчерпаны. `error` — команда не запустилась или
     * отказала среда (`failure`). `rejected` — вход отклонён до запуска
     * (неизвестный gate). `cancelled` — вызов отменён, процессы остановлены.
     */
    status: 'passed' | 'failed' | 'timeout' | 'budget-exhausted' | 'error' | 'rejected' | 'cancelled';
    exitCode: number | null;
    durationMs: number;
    limitMs: number;
    budgetLeftMs: number;
    stdout: string;
    stderr: string;
    note?: string;
    /**
     * Причина неуспеха не в проверяемом коде: `environment` — среда или рецепт
     * отчёта (EPERM, scratch, песочница), `report` — отчёт отсутствует,
     * устарел, битый или небезопасен. Ни то, ни другое не находка в коде.
     */
    failure?: 'environment' | 'report';
    /** Запуск объявленного gate. */
    gate?: ProbeGateRun;
    /** Журнал controller, в котором записан этот запуск. */
    log?: string;
    /**
     * Запуск проверки подтверждён на границе исполнения (`runCheck`): процесс
     * порождён или обёртка песочницы создала метку старта. `false` — команда
     * не начиналась (отказ до старта, бюджет, неизвестный gate, отмена до
     * запуска). У записей alpha.6 и ранее поля нет.
     */
    started: boolean;
    /** Вызов reviewer, которому принадлежит запуск (из спецификации probe). */
    scope?: ProbeSpec['scope'];
};
/** Как сделать gate пригодным для probe: путь отчёта — из переменной controller. */
export declare const reportRecipe = "\u0420\u0435\u0446\u0435\u043F\u0442: \u043A\u043E\u043C\u0430\u043D\u0434\u0430 gate \u0431\u0435\u0440\u0451\u0442 \u043F\u0443\u0442\u044C JUnit \u0438\u0437 HARNESS_REPORT_PATH (\u0438\u043B\u0438 DEVCONTOUR_REPORT_PATH) \u0441 \u043F\u0440\u0435\u0436\u043D\u0438\u043C \u043F\u0443\u0442\u0451\u043C \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E \u2014 \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440 `sh -c 'gotestsum --junitfile \"${HARNESS_REPORT_PATH:-.reports/junit.xml}\" -- ./...'`, `pytest --junitxml=\"${HARNESS_REPORT_PATH:-.reports/junit.xml}\"`, `--test-reporter-destination=${HARNESS_REPORT_PATH:-.reports/junit.xml}` \u0432 package script (\u0441\u043C. docs/review-probes.md).";
/**
 * Аргумент argv, который сам задаёт путь отчёта gate внутри дерева: целиком
 * или после `=` (`--junitxml=…`), относительно cwd gate. Это диагностика, а
 * не подстановка: argv не переписывается, gate с таким аргументом в probe не
 * запускается — дерево там только для чтения.
 */
export declare function fixedReportArgument(argv: string[], cwd: string, report: string): {
    index: number;
    token: string;
} | undefined;
export declare class ReviewProbes {
    readonly spec: ProbeSpec;
    private readonly now;
    private readonly environment;
    private spent;
    constructor(spec: ProbeSpec, now?: () => number, environment?: NodeJS.ProcessEnv);
    /** Сколько может длиться следующая команда: меньшее из трёх пределов. */
    limit(requested?: number): number;
    /** Каталог evidence запусков gate: из спецификации или рядом с журналом. */
    get artifacts(): string;
    run(input: z.infer<typeof probeInput>, signal?: AbortSignal): Promise<ProbeResult>;
    /** Исследовательская команда reviewer: исходники только для чтения, запись — в TMPDIR. */
    private command;
    /**
     * Объявленный gate. Controller берёт argv, cwd и окружение из спецификации
     * (копии эффективной политики), отчёт направляет в собственный scratch вне
     * дерева, сохраняет отчёт, журнал и метаданные в каталоге ревью и только
     * потом убирает scratch. Дерево и `.git` остаются только для чтения;
     * прежние `.reports/*.xml` дерева не читаются, не удаляются и не
     * перезаписываются.
     */
    private gate;
}
/**
 * Stdio MCP-сервер с одним инструментом — его запускает CLI reviewer.
 * Протокол — построчный JSON-RPC 2.0 (`initialize`, `tools/list`,
 * `tools/call`, `ping`, уведомление `notifications/cancelled`); вызовы
 * исполняются одновременно, бюджет общий — один экземпляр `ReviewProbes` на
 * сервер. Отменённый вызов и закрытие входа останавливают свои проверки.
 */
export declare function serveReviewProbes(probes: ReviewProbes, input?: NodeJS.ReadableStream, output?: NodeJS.WritableStream): {
    lines: import("readline").Interface;
    pending: Set<Promise<unknown>>;
};
/** Объявленные gates репозитория в виде спецификации probe. */
export declare function probeGates(gates: GatePolicy[]): ProbeGate[];
/**
 * Часть запроса reviewer о запуске объявленных gates: готовый вызов по ID,
 * без самостоятельного env-wrapper. Пусто, если запускать нечего.
 */
export declare function gateProbePrompt(gates: ProbeGate[]): string;
/** Пределы проверок ревью, выведенные из срока фазы. */
export declare function probeLimits(policy: Pick<ExecutionPolicy, 'runTimeoutMs' | 'reviewProbes'>): {
    commandTimeoutMs: number;
    budgetMs: number;
    reserveMs: number;
};
/** Срок вызова инструмента в CLI — с запасом сверх предела команды controller. */
export declare const probeCallMs: (probe: ProbeServer) => number;
/**
 * Команда, которой CLI reviewer запускает сервер проверок — этот же пакет.
 * CLI стартует её из проверяемого каталога, поэтому загрузчик исходников
 * указан абсолютным путём: из worktree он бы не разрешился.
 */
export declare function probeCommand(specPath: string): {
    command: string;
    args: string[];
};
/** Запуск из журнала controller в том виде, в каком он входит в review.json. */
export interface ProbeRecord {
    runId: string;
    argv: string[];
    status: ProbeResult['status'];
    durationMs: number;
    limitMs: number;
    /** Отказ среды или отчёта — не наблюдение о коде. */
    failure?: ProbeResult['failure'];
    /** Запуск объявленного gate: ID, фаза, SHA, cwd, argv, отчёт и его digest. */
    gate?: ProbeGateRun;
    /** Журнал controller, где записан запуск (у gate — собственный файл). */
    log?: string;
    /** Код процесса; `null` — неизвестен (таймаут, отмена, не запускался). */
    exitCode?: number | null;
    /** Подтверждённый старт; нет у записей alpha.6 и ранее. */
    started?: boolean;
    /** Вызов reviewer, которому принадлежит запуск. */
    scope?: ProbeResult['scope'];
    /** Пояснение controller (ограничено). */
    note?: string;
}
/** Запись журнала с выводом команды — вход итога `inspection`. */
export interface ProbeJournalRecord extends ProbeRecord {
    stdout?: string;
    stderr?: string;
}
/** Журнал проверок вызова reviewer, как его читает controller. */
export interface ProbeJournal {
    /** Строки исхода в порядке журнала; повтор одного runId — одна запись (первая). */
    records: ProbeJournalRecord[];
    /** Строки, не являющиеся ни исходом, ни учётом бюджета: битый JSON, `{}`, чужая форма. */
    invalid: number;
    /** Резервы без строки исхода: учёт бюджета и recovery, не запуски. */
    reservations: {
        runId: string;
        abandoned: boolean;
    }[];
}
/** Статусы исхода probe; иной статус — диагностика, а не исход. */
export declare const probeStatuses: ReadonlySet<string>;
/**
 * Журнал проверок reviewer: по записи на запуск. Нечитаемая строка, объект
 * без формы исхода (`runId`, `argv`, `status`) и строки резерва/списания —
 * не запуски; они не роняют чтение остальных строк.
 */
export declare function readProbeJournal(log: string): Promise<ProbeJournal>;
/** Запуск в виде `review.json.probes`: без потоков вывода, пояснение ограничено. */
export declare function probeRecord(record: ProbeJournalRecord): ProbeRecord;
/** Журнал проверок reviewer: по записи на запуск; нечитаемая строка — не запуск. */
export declare function probeRecords(log: string): Promise<ProbeRecord[]>;
/** Переменная окружения с runId проверки: её наследуют все процессы запуска. */
export declare const probeRunEnv = "HARNESS_PROBE_RUN";
/**
 * Резерв проверки в журнале до её запуска: строка `start` с runId, резервом и
 * моментом начала, синхронно и с fsync. Возвращает ошибку, если записать не
 * удалось, — тогда проверка не запускается.
 */
export declare function reserveProbe(log: string, runId: string, reservedMs: number, argv: string[], gate?: string): Error | undefined;
/**
 * Расход бюджета проверок по журналу. Завершённый запуск — его фактическая
 * длительность; начатый без строки исхода (controller погиб посреди
 * команды) — весь резерв: время до гибели не меньше нуля и не больше
 * резерва, поэтому засчитывается верхняя граница, никогда не меньше.
 */
export declare function probeLedger(log: string): Promise<{
    spentMs: number;
    unfinished: {
        runId: string;
        reservedMs: number;
        startedAt: string;
        pid?: number;
    }[];
}>;
/**
 * Восстановление журнала проверок после гибели controller: процессы
 * незавершённых запусков останавливаются (по метке и их группам), запуск
 * списывается строкой `abandoned` на весь резерв, и возвращается расход.
 * Строка исхода, пришедшая позже, заменяет списание фактической
 * длительностью — двойного счёта нет.
 */
export declare function recoverProbeLog(log: string): Promise<{
    killed: number[];
    spentMs: number;
    unfinished: {
        runId: string;
        reservedMs: number;
        startedAt: string;
        pid?: number;
    }[];
}>;
/**
 * Воспроизведения находок, сверенные с журналом controller. «Наблюдено» —
 * только по запуску, на который сослался reviewer: он состоялся (исчерпанный
 * бюджет и отказ до старта — не наблюдение), совпадение единственное, и
 * команда в записи — та, что действительно запускалась. Команда из текста
 * находки не исполняется. Ответ reviewer мог прийти уже замаскированным, и
 * короткий секрет задевает символы id: id журнала сравниваются и в той же маске.
 */
export declare function observeReproductions<F extends {
    reproduction?: {
        command: string[] | null;
        run?: string | null;
    } | null;
}>(findings: F[], probes: ProbeRecord[] | undefined, redact: (text: string) => string): F[];
