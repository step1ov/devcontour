import { type Usage } from '../contracts/index.ts';
export declare const unknownUsage: () => Usage;
/** Только телеметрия runtime, никогда — структурированный ответ модели или её слова о стоимости. */
export declare function parseUsage(runtime: 'codex' | 'claude', stdout: string, completed: boolean): Usage;
/** Версия CLI runtime (`<executable> --version`); `null` — неизвестна. */
export declare function runtimeVersion(executable: string, env?: NodeJS.ProcessEnv): Promise<string | null>;
/** Модель, которую runtime выбрал на самом деле: событие system у claude, ключи modelUsage у codex. */
export declare function reportedModel(stdout: string): string | null;
