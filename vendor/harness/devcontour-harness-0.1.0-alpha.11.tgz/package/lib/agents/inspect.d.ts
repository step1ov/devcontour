import type { EvidenceRecord } from '../contracts/index.ts';
import { type ProbeJournal } from './review-probe.ts';
type ReviewInspection = NonNullable<EvidenceRecord['inspection']>;
export type InspectionContext = NonNullable<ReviewInspection['context']>;
/** Пределы итога: число команд и длины сохраняемых строк (docs/review-probes.md). */
export declare const inspectionLimits: {
    readonly commands: 100;
    readonly command: 12000;
    readonly output: 4000;
    readonly note: 2000;
    readonly excluded: 100;
};
export declare const unobservedReview: () => ReviewInspection;
/**
 * Что reviewer действительно выполнил — по событиям runtime, а не по словам
 * модели. Завершённая команда — выполнение при любом коде выхода: ненулевой
 * код — исход проверки, а не признак того, что её не было. Повтор события
 * того же item ID — одна команда.
 */
export declare function inspectReview(runtime: string, output: string, redact?: (text: string) => string): ReviewInspection;
/**
 * Итог `inspection` одного вызова reviewer: события runtime этого вызова и
 * журнал проверок controller этого вызова. Самоотчёт модели (`execution`,
 * `reproduction.executed`, runId в тексте) сюда не входит.
 *
 * Операция одна, если совпадает надёжная идентичность: runId запуска
 * controller, item ID runtime внутри его потока или явная структурированная
 * связь наблюдения runtime с runId controller (origin `controller` у команды
 * runtime). Совпадение текста, вывода или замаскированных аргументов
 * операции не склеивает.
 *
 * Порядок: команды runtime в порядке потока, затем запуски controller в
 * порядке журнала; при превышении предела сохраняются последние
 * {@link inspectionLimits.commands}, `total` — число всех подтверждённых.
 * Mode — по всему набору. Пользовательский текст маскируется до обрезки;
 * перечисления и идентификаторы controller не маскируются.
 */
export declare function reviewInspection(input: {
    /** Наблюдение runtime (ответ адаптера); нет — runtime его не дал. */
    runtime?: ReviewInspection;
    /** Журнал проверок controller этого вызова или сохранённая проекция `review.json.probes`. */
    journal?: ProbeJournal;
    context: InspectionContext;
    redact?: (text: string) => string;
}): ReviewInspection;
/**
 * Маскирование сохранённого inspection: только свободный текст (`command`,
 * `output`, `note`, `reason`) и с обрезкой до пределов после маски — замена
 * секрета может удлинить строку. Перечисления, origins, контекст и
 * идентификаторы controller не маскируются — короткий секрет, совпавший с
 * их частью, не делает запись невалидной.
 */
export declare function redactInspection(inspection: ReviewInspection, redact: (text: string) => string): ReviewInspection;
/**
 * Сохранённая проекция `review.json.probes` (alpha.6 и ранее: без кода, вывода и
 * признака старта) как журнал для {@link reviewInspection}. Пересчёт старого
 * состояния не выполняется: это вход для отдельной агрегации старых данных.
 */
export declare function journalFromProjection(probes: unknown): ProbeJournal;
export {};
