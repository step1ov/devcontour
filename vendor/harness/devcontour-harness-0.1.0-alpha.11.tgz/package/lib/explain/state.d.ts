import type { Harness } from '../control/harness.ts';
import type { StopInput } from '../projections/stop.ts';
export interface StopInputOptions {
    maxAttempts: number;
    repairBudget: number;
    workId?: string;
}
/**
 * Входы explainStop из сохранённого состояния; ничего не пишет.
 *
 * Класс отказа — сохранённый `failureKind` (его поставил классификатор в
 * точке отказа); текст ошибки здесь не разбирается. Счётчики восстановления
 * подставляются так, как их видит `repairDecision` (h1-spec K4): без
 * отпечатка повторять нечего, без задания графа движок сам не чинит.
 * Первым идёт вход действующей роли controller, затем поручения (кроме
 * принятых) в порядке состояния.
 */
export declare function stopInputsOf(h: Harness, options: StopInputOptions): StopInput[];
