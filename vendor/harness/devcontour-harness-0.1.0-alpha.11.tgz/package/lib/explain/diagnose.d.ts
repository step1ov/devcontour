import type { ExecutionPolicy, RuntimeName } from '../contracts/index.ts';
import type { RuntimeAdapter } from '../contracts/ports.ts';
import { type StopDiagnosis } from '../projections/stop.ts';
export interface DiagnoseOptions {
    stateDir: string;
    policy: ExecutionPolicy;
    baseDir: string;
    workId?: string;
    adapters?: Partial<Record<RuntimeName, RuntimeAdapter>>;
}
/**
 * `harness explain`: диагнозы runtime, controller и поручений; только чтение.
 *
 * Состояние открывается только для чтения (процесс не становится писателем);
 * отсутствующее состояние — `NOT_FOUND`, каталог не создаётся. Доступность
 * runtime — та же проба `--version`, что у `doctor`, без вызова модели.
 * Порядок: runtime (codex, claude), controller, поручения (h1-spec K3).
 */
export declare function diagnoseState(options: DiagnoseOptions): Promise<{
    diagnoses: StopDiagnosis[];
}>;
/** Текст `--human`: по строке на диагноз, сообщение и evidence — с отступом. */
export declare function explainText(data: {
    diagnoses: StopDiagnosis[];
}): string;
