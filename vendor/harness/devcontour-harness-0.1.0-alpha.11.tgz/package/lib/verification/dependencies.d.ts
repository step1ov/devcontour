import type { ExecutionPolicy } from '../contracts/index.ts';
import type { AttemptState } from '../contracts/index.ts';
type Repo = ExecutionPolicy['repositories'][number];
export type DependencySnapshot = NonNullable<AttemptState['dependencies']>[number];
export type DependencyFreshness = NonNullable<AttemptState['dependencyFreshness']>[number];
/** Репозитории политики с разрешёнными путями checkout. */
export interface Repositories {
    repo(id: string): Repo;
    path(repo: Repo): string;
}
/** Зависимости компонентов в топологическом порядке, транзитивно. */
export declare function dependencyOrder(repos: Repositories, ids: string[]): string[];
export declare function artifactDigest(root: string, path: string): Promise<string>;
/**
 * Снимок зависимостей компонента в топологическом порядке: рабочее дерево
 * целевой ветки каждой зависимости, её `dependencyBuild` и digests
 * `dependencyArtifacts`.
 *
 * `overrides` подставляет зависимость уже существующим деревом (проверка
 * потребителя: компонент поручения — его интегрированный результат).
 * Подстановка идёт до сборки: промежуточные зависимости собираются уже против
 * неё. `predecessors` — принятые результаты поручений, от которых зависит
 * работа: их SHA обязан быть в снимке. Каждое созданное здесь рабочее дерево
 * принадлежит снимку с момента создания: при отказе на любом шаге созданные
 * деревья убираются, и отказ очистки не скрывается.
 */
export declare function snapshotDependencies(input: {
    repos: Repositories;
    repositoryId: string;
    dir: string;
    artifacts: string;
    runId: string;
    policy: ExecutionPolicy;
    environment: NodeJS.ProcessEnv;
    signal: AbortSignal;
    predecessors?: {
        repositoryId: string;
        resultSha: string;
    }[];
    overrides?: Map<string, {
        path: string;
        sha: string;
    }>;
}): Promise<{
    repositoryId: string;
    sha: string;
    tree: string;
    path: string;
    artifacts: {
        path: string;
        digest: string;
    }[];
}[]>;
/** Убирает рабочие деревья снимков; возвращает отказы, а не скрывает их. */
export declare function removeSnapshots(repos: Repositories, snapshots: DependencySnapshot[]): Promise<string[]>;
/** Закреплённый снимок не изменён: HEAD, отслеживаемые файлы и artifacts. */
export declare function assertDependencies(snapshots: DependencySnapshot[]): Promise<void>;
/**
 * Свежесть снимка на момент окончания проверки: голова целевой ветки каждой
 * зависимости и совпадает ли она со снимком. Параллельная работа законно
 * двигает ветки зависимостей, поэтому сдвиг не отклоняет результат, а
 * фиксируется в попытке и результате; сочетание версий проверяет совместная
 * проверка по закреплённому манифесту.
 */
export declare function dependencyFreshness(repos: Repositories, snapshots: Pick<DependencySnapshot, 'repositoryId' | 'sha'>[]): Promise<DependencyFreshness[]>;
export {};
