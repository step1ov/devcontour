import { type ExecutionPolicy, type ExecutionView, type JointVerification, type JointVerificationState } from '../contracts/index.ts';
/**
 * Совместная проверка закреплённой комбинации SHA репозиториев.
 *
 * Поручения принимаются по одному, каждое — в своём репозитории. Совместная
 * проверка отвечает на другой вопрос: работает ли вместе комбинация их
 * результатов. Она привязана к manifest (SHA и tree каждого репозитория), к
 * политике совместной проверки и к основанию — постановкам, статусам и
 * результатам поручений. Сменилось любое из них — прежний результат
 * устарел. Атомарного продвижения нескольких Git-репозиториев здесь нет;
 * продуктовое принятие комбинации решает хост.
 */
/** Политика совместной проверки: всё, от чего зависит её результат. */
export declare function jointPolicyDigest(policy: ExecutionPolicy): string;
/** Основание проверки: поручения, их постановки, статусы и результаты. */
export declare function jointSpecDigest(view: ExecutionView, workIds: string[]): string;
/** Один и тот же набор поручений — один предмет проверки, независимо от порядка. */
export declare const sameWorks: (a: string[], b: string[]) => boolean;
/** Gates совместной проверки в порядке их зависимостей. */
export declare function orderedWorkspaceGates(gates: ExecutionPolicy['workspaceGates']): ({
    kind: "test";
    report: {
        type: "junit";
        path: string;
    };
    repositoryId: string;
    artifacts: string[];
    id: string;
    command: string[];
    timeoutMs: number;
    property?: {
        path?: string | undefined;
    } | undefined;
    dependsOn?: string[] | undefined;
    cwd?: string | undefined;
    resources?: string[] | undefined;
} | {
    kind: "check";
    repositoryId: string;
    artifacts: string[];
    id: string;
    command: string[];
    timeoutMs: number;
    report?: {
        type: "junit";
        path: string;
    } | undefined;
    property?: {
        path?: string | undefined;
    } | undefined;
    dependsOn?: string[] | undefined;
    cwd?: string | undefined;
    resources?: string[] | undefined;
})[];
/**
 * Какие gates исполнять. По умолчанию — все. В режиме `affected` при
 * известной прежней успешной комбинации под той же политикой — только
 * изменённые компоненты, их транзитивные потребители и prerequisites их
 * проверок; без достаточного теста в этой области — снова все.
 */
export declare function jointImpact(policy: ExecutionPolicy, manifest: NonNullable<JointVerification['manifest']>, policyDigest: string, baseline?: JointVerificationState): NonNullable<JointVerification['impact']>;
/** Публичная форма: без токена и срока владения. */
export declare function publicJoint(v: JointVerificationState): JointVerification;
