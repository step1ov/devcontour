import { type CheckSuite, type ExecutionView, type WorkState } from '../contracts/index.ts';
import type { Engine } from '../engine/engine.ts';
/**
 * Версионируемый корпус подтверждённых случаев.
 *
 * Воспроизведение из находки ревью — наблюдение, а не обязательство.
 * Обязательство хранится здесь: случай подтверждён закреплённым эталоном на
 * дефектном SHA, вошёл в неизменяемую добавочную версию корпуса, и поручение
 * приняло эту версию отдельной операцией. Корпус — локальная запись
 * владельца-репозитория (`check-suites`); в журнал событий тела случаев не
 * попадают.
 */
export type CorpusCase = CheckSuite['cases'][string];
export type CorpusVersion = CheckSuite['versions'][number];
export type CaseDecision = CheckSuite['decisions'][number];
export type PendingAdoption = CheckSuite['pending'][number];
/** Предел случая: вход и ожидание вместе. */
export declare const MAX_CASE_BYTES: number;
/** Предел корпуса целиком: запись переносится одним файлом. */
export declare const MAX_SUITE_BYTES = 1500000;
export declare const sha256: (text: string) => string;
/**
 * Канонический JSON в рамках объявленного формата: ключи объектов
 * сортируются (порядок ключей в JSON не несёт смысла), порядок массивов
 * сохраняется, числа и строки не смешиваются — `1` и `"1"` разные входы.
 */
export declare function canonicalJson(value: unknown): string;
export declare function parseCanonical(text: string, what: string): string;
/** Канонический файл корпуса версии — его байты дают digest и Git blob. */
export declare function corpusFile(suite: CheckSuite, cases: string[], number: number): string;
export declare function scrubLocalPaths(text: string, roots?: string[]): string;
/** Локальные корни установки — и в заданном, и в разрешённом виде. */
export declare function localRoots(paths: (string | undefined)[]): string[];
export declare const caseId: (property: string, input: string, basis: string) => string;
/**
 * Версия корпуса по ссылке. Digest однозначен; номер — только если в
 * истории одна версия с ним: после объединения клонов номера могут совпасть.
 */
export declare function versionOf(suite: CheckSuite, ref: {
    number?: number;
    digest?: string;
}): {
    number: number;
    digest: string;
    previous: string | null;
    cases: string[];
    blob: string;
    createdAt: string;
    reason: string;
    decisions: string[];
};
export { suiteBasis } from './checks.ts';
/**
 * Операции корпуса под транзакциями хранилища исполнения. Запись решения и
 * версии — одна транзакция; принятие версии поручениями меняет их
 * `checkVersion` и удержание в той же транзакции, что и запись корпуса.
 */
export declare class CorpusStore {
    readonly engine: Engine;
    /** Локальные корни для очистки переносимой диагностики. */
    readonly roots: string[];
    constructor(engine: Engine, 
    /** Локальные корни для очистки переносимой диагностики. */
    roots?: string[]);
    private get store();
    private now;
    private leaseMs;
    all(view: ExecutionView, repositoryId?: string): {
        id: string;
        repositoryId: string;
        contractId: string;
        contractDigest: string;
        gate: string;
        basis: string;
        cases: Record<string, {
            id: string;
            property: string;
            input: string;
            expected: string;
            source: {
                kind: "oracle";
                decision: string;
                sha: string;
                runId?: string | undefined;
                taskId?: string | undefined;
                reproduction?: string | undefined;
            };
            addedAt: string;
        }>;
        versions: {
            number: number;
            digest: string;
            previous: string | null;
            cases: string[];
            blob: string;
            createdAt: string;
            reason: string;
            decisions: string[];
        }[];
        decisions: {
            id: string;
            property: string;
            input: string;
            inputHash: string;
            outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
            reason: string;
            source: {
                sha: string;
                runId?: string | undefined;
                taskId?: string | undefined;
            };
            origin: {
                kind: "review" | "agent" | "operator" | "lead";
                runtime?: string | undefined;
            };
            at: string;
            key?: string | undefined;
            claimed?: {
                expected: string | null;
                actual: string | null;
                reproduction?: string | undefined;
            } | undefined;
            observed?: {
                repeats: number;
                durationsMs: number[];
                expected?: string | undefined;
                actual?: string | undefined;
                equal?: boolean | undefined;
            } | undefined;
            method?: {
                gate: string;
                artifacts: {
                    path: string;
                    blob: string;
                }[];
                contract: string;
                basis: string;
                command?: string[] | undefined;
            } | undefined;
            caseId?: string | undefined;
            version?: number | undefined;
        }[];
        adoptions: {
            id: string;
            taskId: string;
            from: {
                number: number;
                digest: string;
            } | null;
            to: {
                number: number;
                digest: string;
            };
            actor: string;
            reason: string;
            operation: string;
            at: string;
        }[];
        pending: {
            id: string;
            version: number;
            tasks: string[];
            status: "completed" | "waiting";
            results: Record<string, string>;
            actor: string;
            reason: string;
            requestedAt: string;
            digest?: string | undefined;
            awaitingOperator?: boolean | undefined;
            completedAt?: string | undefined;
        }[];
        operations: Record<string, {
            key: string;
            status: "completed" | "running";
            startedAt: string;
            token?: string | undefined;
            leaseUntil?: number | undefined;
            decision?: string | undefined;
        }>;
        revision: number;
    }[];
    get(view: ExecutionView, id: string): {
        id: string;
        repositoryId: string;
        contractId: string;
        contractDigest: string;
        gate: string;
        basis: string;
        cases: Record<string, {
            id: string;
            property: string;
            input: string;
            expected: string;
            source: {
                kind: "oracle";
                decision: string;
                sha: string;
                runId?: string | undefined;
                taskId?: string | undefined;
                reproduction?: string | undefined;
            };
            addedAt: string;
        }>;
        versions: {
            number: number;
            digest: string;
            previous: string | null;
            cases: string[];
            blob: string;
            createdAt: string;
            reason: string;
            decisions: string[];
        }[];
        decisions: {
            id: string;
            property: string;
            input: string;
            inputHash: string;
            outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
            reason: string;
            source: {
                sha: string;
                runId?: string | undefined;
                taskId?: string | undefined;
            };
            origin: {
                kind: "review" | "agent" | "operator" | "lead";
                runtime?: string | undefined;
            };
            at: string;
            key?: string | undefined;
            claimed?: {
                expected: string | null;
                actual: string | null;
                reproduction?: string | undefined;
            } | undefined;
            observed?: {
                repeats: number;
                durationsMs: number[];
                expected?: string | undefined;
                actual?: string | undefined;
                equal?: boolean | undefined;
            } | undefined;
            method?: {
                gate: string;
                artifacts: {
                    path: string;
                    blob: string;
                }[];
                contract: string;
                basis: string;
                command?: string[] | undefined;
            } | undefined;
            caseId?: string | undefined;
            version?: number | undefined;
        }[];
        adoptions: {
            id: string;
            taskId: string;
            from: {
                number: number;
                digest: string;
            } | null;
            to: {
                number: number;
                digest: string;
            };
            actor: string;
            reason: string;
            operation: string;
            at: string;
        }[];
        pending: {
            id: string;
            version: number;
            tasks: string[];
            status: "completed" | "waiting";
            results: Record<string, string>;
            actor: string;
            reason: string;
            requestedAt: string;
            digest?: string | undefined;
            awaitingOperator?: boolean | undefined;
            completedAt?: string | undefined;
        }[];
        operations: Record<string, {
            key: string;
            status: "completed" | "running";
            startedAt: string;
            token?: string | undefined;
            leaseUntil?: number | undefined;
            decision?: string | undefined;
        }>;
        revision: number;
    };
    read(id: string): {
        id: string;
        repositoryId: string;
        contractId: string;
        contractDigest: string;
        gate: string;
        basis: string;
        cases: Record<string, {
            id: string;
            property: string;
            input: string;
            expected: string;
            source: {
                kind: "oracle";
                decision: string;
                sha: string;
                runId?: string | undefined;
                taskId?: string | undefined;
                reproduction?: string | undefined;
            };
            addedAt: string;
        }>;
        versions: {
            number: number;
            digest: string;
            previous: string | null;
            cases: string[];
            blob: string;
            createdAt: string;
            reason: string;
            decisions: string[];
        }[];
        decisions: {
            id: string;
            property: string;
            input: string;
            inputHash: string;
            outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
            reason: string;
            source: {
                sha: string;
                runId?: string | undefined;
                taskId?: string | undefined;
            };
            origin: {
                kind: "review" | "agent" | "operator" | "lead";
                runtime?: string | undefined;
            };
            at: string;
            key?: string | undefined;
            claimed?: {
                expected: string | null;
                actual: string | null;
                reproduction?: string | undefined;
            } | undefined;
            observed?: {
                repeats: number;
                durationsMs: number[];
                expected?: string | undefined;
                actual?: string | undefined;
                equal?: boolean | undefined;
            } | undefined;
            method?: {
                gate: string;
                artifacts: {
                    path: string;
                    blob: string;
                }[];
                contract: string;
                basis: string;
                command?: string[] | undefined;
            } | undefined;
            caseId?: string | undefined;
            version?: number | undefined;
        }[];
        adoptions: {
            id: string;
            taskId: string;
            from: {
                number: number;
                digest: string;
            } | null;
            to: {
                number: number;
                digest: string;
            };
            actor: string;
            reason: string;
            operation: string;
            at: string;
        }[];
        pending: {
            id: string;
            version: number;
            tasks: string[];
            status: "completed" | "waiting";
            results: Record<string, string>;
            actor: string;
            reason: string;
            requestedAt: string;
            digest?: string | undefined;
            awaitingOperator?: boolean | undefined;
            completedAt?: string | undefined;
        }[];
        operations: Record<string, {
            key: string;
            status: "completed" | "running";
            startedAt: string;
            token?: string | undefined;
            leaseUntil?: number | undefined;
            decision?: string | undefined;
        }>;
        revision: number;
    };
    private save;
    /** Корпус договора поручения; создаётся (в памяти) при первом обращении. */
    suiteFor(view: ExecutionView, work: WorkState, property: string): {
        suite: {
            id: string;
            repositoryId: string;
            contractId: string;
            contractDigest: string;
            gate: string;
            basis: string;
            cases: Record<string, {
                id: string;
                property: string;
                input: string;
                expected: string;
                source: {
                    kind: "oracle";
                    decision: string;
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                    reproduction?: string | undefined;
                };
                addedAt: string;
            }>;
            versions: {
                number: number;
                digest: string;
                previous: string | null;
                cases: string[];
                blob: string;
                createdAt: string;
                reason: string;
                decisions: string[];
            }[];
            decisions: {
                id: string;
                property: string;
                input: string;
                inputHash: string;
                outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
                reason: string;
                source: {
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                };
                origin: {
                    kind: "review" | "agent" | "operator" | "lead";
                    runtime?: string | undefined;
                };
                at: string;
                key?: string | undefined;
                claimed?: {
                    expected: string | null;
                    actual: string | null;
                    reproduction?: string | undefined;
                } | undefined;
                observed?: {
                    repeats: number;
                    durationsMs: number[];
                    expected?: string | undefined;
                    actual?: string | undefined;
                    equal?: boolean | undefined;
                } | undefined;
                method?: {
                    gate: string;
                    artifacts: {
                        path: string;
                        blob: string;
                    }[];
                    contract: string;
                    basis: string;
                    command?: string[] | undefined;
                } | undefined;
                caseId?: string | undefined;
                version?: number | undefined;
            }[];
            adoptions: {
                id: string;
                taskId: string;
                from: {
                    number: number;
                    digest: string;
                } | null;
                to: {
                    number: number;
                    digest: string;
                };
                actor: string;
                reason: string;
                operation: string;
                at: string;
            }[];
            pending: {
                id: string;
                version: number;
                tasks: string[];
                status: "completed" | "waiting";
                results: Record<string, string>;
                actor: string;
                reason: string;
                requestedAt: string;
                digest?: string | undefined;
                awaitingOperator?: boolean | undefined;
                completedAt?: string | undefined;
            }[];
            operations: Record<string, {
                key: string;
                status: "completed" | "running";
                startedAt: string;
                token?: string | undefined;
                leaseUntil?: number | undefined;
                decision?: string | undefined;
            }>;
            revision: number;
        };
        contract: {
            apiVersion: "devcontour-harness/v1alpha1";
            id: string;
            title: string;
            content: string;
            repositoryId?: string | undefined;
            artifacts?: {
                path: string;
                blob: string;
            }[] | undefined;
            checks?: {
                version: 1;
                gate: string;
                obligations: {
                    property: string;
                    requirements: string[];
                    promise: "functional" | "accuracy" | "optimality" | "completeness" | "performance" | "invariant" | "other";
                    domain: {
                        inputs: string;
                        bounds: string;
                        invalid: string;
                        units?: string | undefined;
                    };
                    answer: {
                        rules: string;
                        ties?: string | undefined;
                        rounding?: string | undefined;
                        tolerance?: string | undefined;
                        refusals?: string | undefined;
                    };
                    method: {
                        kind: "scenario" | "invariant" | "other" | "oracle" | "certificate" | "analytic";
                        description: string;
                        applicability: string;
                        artifacts: string[];
                    };
                    coverage: {
                        families: {
                            id: string;
                            kind: "typical" | "boundary" | "adversarial";
                            description: string;
                            minCases: number;
                        }[];
                        minCases: number;
                        corpus: boolean;
                    };
                    resources: {
                        subject: string;
                        oracle: string;
                        benchmark?: {
                            method: string;
                            environment: string;
                        } | undefined;
                    };
                    hard: boolean;
                    explanation?: string | undefined;
                    feasibility?: {
                        spike: string;
                        digest: string;
                    } | undefined;
                }[];
                corpus?: {
                    format: string;
                    extensible: boolean;
                    maxCases: number;
                } | undefined;
            } | undefined;
        };
        obligation: {
            property: string;
            requirements: string[];
            promise: "functional" | "accuracy" | "optimality" | "completeness" | "performance" | "invariant" | "other";
            domain: {
                inputs: string;
                bounds: string;
                invalid: string;
                units?: string | undefined;
            };
            answer: {
                rules: string;
                ties?: string | undefined;
                rounding?: string | undefined;
                tolerance?: string | undefined;
                refusals?: string | undefined;
            };
            method: {
                kind: "scenario" | "invariant" | "other" | "oracle" | "certificate" | "analytic";
                description: string;
                applicability: string;
                artifacts: string[];
            };
            coverage: {
                families: {
                    id: string;
                    kind: "typical" | "boundary" | "adversarial";
                    description: string;
                    minCases: number;
                }[];
                minCases: number;
                corpus: boolean;
            };
            resources: {
                subject: string;
                oracle: string;
                benchmark?: {
                    method: string;
                    environment: string;
                } | undefined;
            };
            hard: boolean;
            explanation?: string | undefined;
            feasibility?: {
                spike: string;
                digest: string;
            } | undefined;
        };
    };
    head(suite: CheckSuite): {
        number: number;
        digest: string;
        previous: string | null;
        cases: string[];
        blob: string;
        createdAt: string;
        reason: string;
        decisions: string[];
    } | undefined;
    /** Случаи закреплённой версии и её канонический файл: их исполняет gate. */
    snapshot(view: ExecutionView, binding: NonNullable<WorkState['checkVersion']>): {
        digest: string;
        content: string;
        cases: {
            id: string;
            property: string;
        }[];
    };
    /** Начать операцию подтверждения или вернуть её прежний исход по ключу. */
    begin(initial: CheckSuite, key: string): {
        done: CaseDecision;
        token?: undefined;
    } | {
        token: string;
        done?: undefined;
    };
    heartbeat(suiteId: string, key: string, token: string): void;
    /** Снять владение операцией без решения: она завершилась отказом до проверки. */
    end(suiteId: string, key: string, token: string): void;
    private guard;
    /**
     * Записать решение и, если случай подтверждён, добавочную версию корпуса и
     * отложенное принятие её поручениями. Одна транзакция: решение без версии
     * или версия без решения не возникают. Конкурентная добавка не теряется:
     * новая версия строится от текущей головы с повторной проверкой конфликта
     * ожиданий.
     */
    record(initial: CheckSuite, key: string, token: string, decision: Omit<CaseDecision, 'id' | 'at' | 'caseId' | 'version'>, blobFor: (content: string) => string, adopt: {
        works: string[];
        actor: string;
        manual?: boolean;
    }): {
        decision: {
            id: string;
            property: string;
            input: string;
            inputHash: string;
            outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
            reason: string;
            source: {
                sha: string;
                runId?: string | undefined;
                taskId?: string | undefined;
            };
            origin: {
                kind: "review" | "agent" | "operator" | "lead";
                runtime?: string | undefined;
            };
            at: string;
            key?: string | undefined;
            claimed?: {
                expected: string | null;
                actual: string | null;
                reproduction?: string | undefined;
            } | undefined;
            observed?: {
                repeats: number;
                durationsMs: number[];
                expected?: string | undefined;
                actual?: string | undefined;
                equal?: boolean | undefined;
            } | undefined;
            method?: {
                gate: string;
                artifacts: {
                    path: string;
                    blob: string;
                }[];
                contract: string;
                basis: string;
                command?: string[] | undefined;
            } | undefined;
            caseId?: string | undefined;
            version?: number | undefined;
        };
        suite: {
            id: string;
            repositoryId: string;
            contractId: string;
            contractDigest: string;
            gate: string;
            basis: string;
            cases: Record<string, {
                id: string;
                property: string;
                input: string;
                expected: string;
                source: {
                    kind: "oracle";
                    decision: string;
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                    reproduction?: string | undefined;
                };
                addedAt: string;
            }>;
            versions: {
                number: number;
                digest: string;
                previous: string | null;
                cases: string[];
                blob: string;
                createdAt: string;
                reason: string;
                decisions: string[];
            }[];
            decisions: {
                id: string;
                property: string;
                input: string;
                inputHash: string;
                outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
                reason: string;
                source: {
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                };
                origin: {
                    kind: "review" | "agent" | "operator" | "lead";
                    runtime?: string | undefined;
                };
                at: string;
                key?: string | undefined;
                claimed?: {
                    expected: string | null;
                    actual: string | null;
                    reproduction?: string | undefined;
                } | undefined;
                observed?: {
                    repeats: number;
                    durationsMs: number[];
                    expected?: string | undefined;
                    actual?: string | undefined;
                    equal?: boolean | undefined;
                } | undefined;
                method?: {
                    gate: string;
                    artifacts: {
                        path: string;
                        blob: string;
                    }[];
                    contract: string;
                    basis: string;
                    command?: string[] | undefined;
                } | undefined;
                caseId?: string | undefined;
                version?: number | undefined;
            }[];
            adoptions: {
                id: string;
                taskId: string;
                from: {
                    number: number;
                    digest: string;
                } | null;
                to: {
                    number: number;
                    digest: string;
                };
                actor: string;
                reason: string;
                operation: string;
                at: string;
            }[];
            pending: {
                id: string;
                version: number;
                tasks: string[];
                status: "completed" | "waiting";
                results: Record<string, string>;
                actor: string;
                reason: string;
                requestedAt: string;
                digest?: string | undefined;
                awaitingOperator?: boolean | undefined;
                completedAt?: string | undefined;
            }[];
            operations: Record<string, {
                key: string;
                status: "completed" | "running";
                startedAt: string;
                token?: string | undefined;
                leaseUntil?: number | undefined;
                decision?: string | undefined;
            }>;
            revision: number;
        };
        pending: {
            id: string;
            version: number;
            tasks: string[];
            status: "completed" | "waiting";
            results: Record<string, string>;
            actor: string;
            reason: string;
            requestedAt: string;
            digest?: string | undefined;
            awaitingOperator?: boolean | undefined;
            completedAt?: string | undefined;
        } | undefined;
    };
    private declarationOf;
    /**
     * Принять версию корпуса явно перечисленными поручениями.
     *
     * Посередине активной попытки принятие недопустимо: выдача поручения
     * удерживается, и принятие завершится после окончания попытки. Принятое
     * поручение не меняется. Повтор идемпотентен; снимается только собственное
     * удержание операции.
     */
    adopt(suiteId: string, pendingId: string): {
        pending: {
            id: string;
            version: number;
            tasks: string[];
            status: "completed" | "waiting";
            results: Record<string, string>;
            actor: string;
            reason: string;
            requestedAt: string;
            digest?: string | undefined;
            awaitingOperator?: boolean | undefined;
            completedAt?: string | undefined;
        };
        suite: {
            id: string;
            repositoryId: string;
            contractId: string;
            contractDigest: string;
            gate: string;
            basis: string;
            cases: Record<string, {
                id: string;
                property: string;
                input: string;
                expected: string;
                source: {
                    kind: "oracle";
                    decision: string;
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                    reproduction?: string | undefined;
                };
                addedAt: string;
            }>;
            versions: {
                number: number;
                digest: string;
                previous: string | null;
                cases: string[];
                blob: string;
                createdAt: string;
                reason: string;
                decisions: string[];
            }[];
            decisions: {
                id: string;
                property: string;
                input: string;
                inputHash: string;
                outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
                reason: string;
                source: {
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                };
                origin: {
                    kind: "review" | "agent" | "operator" | "lead";
                    runtime?: string | undefined;
                };
                at: string;
                key?: string | undefined;
                claimed?: {
                    expected: string | null;
                    actual: string | null;
                    reproduction?: string | undefined;
                } | undefined;
                observed?: {
                    repeats: number;
                    durationsMs: number[];
                    expected?: string | undefined;
                    actual?: string | undefined;
                    equal?: boolean | undefined;
                } | undefined;
                method?: {
                    gate: string;
                    artifacts: {
                        path: string;
                        blob: string;
                    }[];
                    contract: string;
                    basis: string;
                    command?: string[] | undefined;
                } | undefined;
                caseId?: string | undefined;
                version?: number | undefined;
            }[];
            adoptions: {
                id: string;
                taskId: string;
                from: {
                    number: number;
                    digest: string;
                } | null;
                to: {
                    number: number;
                    digest: string;
                };
                actor: string;
                reason: string;
                operation: string;
                at: string;
            }[];
            pending: {
                id: string;
                version: number;
                tasks: string[];
                status: "completed" | "waiting";
                results: Record<string, string>;
                actor: string;
                reason: string;
                requestedAt: string;
                digest?: string | undefined;
                awaitingOperator?: boolean | undefined;
                completedAt?: string | undefined;
            }[];
            operations: Record<string, {
                key: string;
                status: "completed" | "running";
                startedAt: string;
                token?: string | undefined;
                leaseUntil?: number | undefined;
                decision?: string | undefined;
            }>;
            revision: number;
        };
    };
    private release;
    private adoptable;
    /**
     * Явно принять уже существующую версию корпуса перечисленными поручениями.
     * Новых случаев не создаёт. В operator mode агент только запрашивает.
     */
    request(suiteId: string, ref: {
        number?: number;
        digest?: string;
    }, works: string[], actor: string, reason: string, manual?: boolean): {
        pending: {
            id: string;
            version: number;
            tasks: string[];
            status: "completed" | "waiting";
            results: Record<string, string>;
            actor: string;
            reason: string;
            requestedAt: string;
            digest?: string | undefined;
            awaitingOperator?: boolean | undefined;
            completedAt?: string | undefined;
        };
        suite: {
            id: string;
            repositoryId: string;
            contractId: string;
            contractDigest: string;
            gate: string;
            basis: string;
            cases: Record<string, {
                id: string;
                property: string;
                input: string;
                expected: string;
                source: {
                    kind: "oracle";
                    decision: string;
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                    reproduction?: string | undefined;
                };
                addedAt: string;
            }>;
            versions: {
                number: number;
                digest: string;
                previous: string | null;
                cases: string[];
                blob: string;
                createdAt: string;
                reason: string;
                decisions: string[];
            }[];
            decisions: {
                id: string;
                property: string;
                input: string;
                inputHash: string;
                outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
                reason: string;
                source: {
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                };
                origin: {
                    kind: "review" | "agent" | "operator" | "lead";
                    runtime?: string | undefined;
                };
                at: string;
                key?: string | undefined;
                claimed?: {
                    expected: string | null;
                    actual: string | null;
                    reproduction?: string | undefined;
                } | undefined;
                observed?: {
                    repeats: number;
                    durationsMs: number[];
                    expected?: string | undefined;
                    actual?: string | undefined;
                    equal?: boolean | undefined;
                } | undefined;
                method?: {
                    gate: string;
                    artifacts: {
                        path: string;
                        blob: string;
                    }[];
                    contract: string;
                    basis: string;
                    command?: string[] | undefined;
                } | undefined;
                caseId?: string | undefined;
                version?: number | undefined;
            }[];
            adoptions: {
                id: string;
                taskId: string;
                from: {
                    number: number;
                    digest: string;
                } | null;
                to: {
                    number: number;
                    digest: string;
                };
                actor: string;
                reason: string;
                operation: string;
                at: string;
            }[];
            pending: {
                id: string;
                version: number;
                tasks: string[];
                status: "completed" | "waiting";
                results: Record<string, string>;
                actor: string;
                reason: string;
                requestedAt: string;
                digest?: string | undefined;
                awaitingOperator?: boolean | undefined;
                completedAt?: string | undefined;
            }[];
            operations: Record<string, {
                key: string;
                status: "completed" | "running";
                startedAt: string;
                token?: string | undefined;
                leaseUntil?: number | undefined;
                decision?: string | undefined;
            }>;
            revision: number;
        };
    };
    /**
     * В operator mode выдача перечисленных незавершённых поручений удерживается
     * до ручного подтверждения: иначе следующая попытка шла бы без нового корпуса.
     */
    private holdForOperator;
    /** Ручное техническое подтверждение принятия (operator mode). */
    approveAdoption(suiteId: string, pendingId: string): {
        pending: {
            id: string;
            version: number;
            tasks: string[];
            status: "completed" | "waiting";
            results: Record<string, string>;
            actor: string;
            reason: string;
            requestedAt: string;
            digest?: string | undefined;
            awaitingOperator?: boolean | undefined;
            completedAt?: string | undefined;
        };
        suite: {
            id: string;
            repositoryId: string;
            contractId: string;
            contractDigest: string;
            gate: string;
            basis: string;
            cases: Record<string, {
                id: string;
                property: string;
                input: string;
                expected: string;
                source: {
                    kind: "oracle";
                    decision: string;
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                    reproduction?: string | undefined;
                };
                addedAt: string;
            }>;
            versions: {
                number: number;
                digest: string;
                previous: string | null;
                cases: string[];
                blob: string;
                createdAt: string;
                reason: string;
                decisions: string[];
            }[];
            decisions: {
                id: string;
                property: string;
                input: string;
                inputHash: string;
                outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
                reason: string;
                source: {
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                };
                origin: {
                    kind: "review" | "agent" | "operator" | "lead";
                    runtime?: string | undefined;
                };
                at: string;
                key?: string | undefined;
                claimed?: {
                    expected: string | null;
                    actual: string | null;
                    reproduction?: string | undefined;
                } | undefined;
                observed?: {
                    repeats: number;
                    durationsMs: number[];
                    expected?: string | undefined;
                    actual?: string | undefined;
                    equal?: boolean | undefined;
                } | undefined;
                method?: {
                    gate: string;
                    artifacts: {
                        path: string;
                        blob: string;
                    }[];
                    contract: string;
                    basis: string;
                    command?: string[] | undefined;
                } | undefined;
                caseId?: string | undefined;
                version?: number | undefined;
            }[];
            adoptions: {
                id: string;
                taskId: string;
                from: {
                    number: number;
                    digest: string;
                } | null;
                to: {
                    number: number;
                    digest: string;
                };
                actor: string;
                reason: string;
                operation: string;
                at: string;
            }[];
            pending: {
                id: string;
                version: number;
                tasks: string[];
                status: "completed" | "waiting";
                results: Record<string, string>;
                actor: string;
                reason: string;
                requestedAt: string;
                digest?: string | undefined;
                awaitingOperator?: boolean | undefined;
                completedAt?: string | undefined;
            }[];
            operations: Record<string, {
                key: string;
                status: "completed" | "running";
                startedAt: string;
                token?: string | undefined;
                leaseUntil?: number | undefined;
                decision?: string | undefined;
            }>;
            revision: number;
        };
    };
    /** Продолжить отложенные принятия: поручение освободилось. Ничего не запускает. */
    resume(): void;
    /**
     * Снять удержание операции принятия. Только своё: чужая операция
     * чужое удержание не снимает.
     */
    abandon(suiteId: string, pendingId: string, operation: string): {
        pending: string;
    };
}
/**
 * Переносимая форма корпуса. Локальные операции (lease, token, отложенные
 * принятия) и исполняемая конфигурация (команда checker) не переносятся:
 * команда остаётся локальной политикой, и ссылка на artifact сама по себе
 * права исполнения не даёт.
 */
export type PortableSuite = Omit<CheckSuite, 'cases' | 'pending' | 'operations' | 'revision' | 'decisions'> & {
    cases: CorpusCase[];
    decisions: (Omit<CaseDecision, 'method'> & {
        method?: Omit<NonNullable<CaseDecision['method']>, 'command'>;
    })[];
};
export declare function portableSuite(suite: CheckSuite, roots?: string[]): PortableSuite;
/**
 * Диагностические поля проходят очистку путей и на экспорте, и на чтении:
 * запись прежней версии могла сохранить их до появления очистки. Очистка
 * идемпотентна, нормативные поля (вход, ожидание, digest) не меняются.
 */
export declare function scrubPortable(suite: PortableSuite, roots?: string[]): PortableSuite;
/**
 * Проверка переносимого корпуса: каждая версия собирается из своих случаев в
 * канонический файл, и его digest совпадает с записанным. Запись, где версия
 * ссылается на отсутствующий случай или подменён digest, не принимается.
 */
export declare function verifySuite(suite: PortableSuite): Map<string, string>;
