import type { EvidenceRecord, WorkOrder } from '../contracts/index.ts';
type Requirement = WorkOrder['requirements'][number];
/**
 * Что нужно доказательству от записи evidence: сама запись controller или её
 * переносимая форма в результате (у получателя).
 */
export type ProofRecord = Pick<EvidenceRecord, 'kind' | 'gate' | 'phase' | 'sha' | 'passed'> & {
    consumer?: string | undefined;
    checks?: string | undefined;
    tests?: EvidenceRecord['tests'];
    testsTruncated?: boolean | undefined;
};
/**
 * Уровни доказательства критерия. `testcase` — названный тест выполнился на
 * принятом SHA и прошёл; `gate` — известно лишь, что проверка зелёная;
 * `none` — подтверждения нет, причина названа.
 *
 * Доказательство — только решающая запись gate: последняя собственная
 * (не потребителя) запись вида `test` фазы интеграции на принятом SHA под
 * версией проверок попытки (`effective`, если она есть). Запись ревью под
 * именем gate, запись другой версии или более ранний прогон того же gate
 * testcase не подтверждают: приёмка решает по той же записи.
 */
export type ProofLevel = 'testcase' | 'gate' | 'none';
export declare function requirementProof(link: Pick<Requirement, 'id' | 'gate' | 'testId'>, evidence: readonly ProofRecord[], resultSha: string | undefined, effective?: string): {
    id: string;
    level: ProofLevel;
    reason: string;
    testId?: string;
};
/** Причина, по которой названные сценарии не подтверждены, или undefined. */
export declare function unprovenReason(requirements: readonly Requirement[] | undefined, evidence: readonly ProofRecord[], resultSha: string | undefined, effective?: string): string | undefined;
/**
 * Gates репозиториев, которые не прошли на integration ни одно из принятых
 * поручений набора. Покрывает gate только собственная (не потребителя)
 * запись вида `test` фазы интеграции на принятом SHA поручения: запись ревью
 * одноимённый test gate не закрывает. Какие записи относятся к поручению
 * (попытки под текущим основанием, переносимый результат другого clone), —
 * решает вызывающий; правило покрытия — одно.
 */
export declare function uncoveredGates(repositories: readonly {
    id: string;
    gates: readonly {
        id: string;
    }[];
}[], works: readonly {
    repositoryId: string;
    resultSha: string | undefined;
    evidence: readonly ProofRecord[];
}[]): {
    repositoryId: string;
    gates: string[];
}[];
export {};
