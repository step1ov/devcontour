import { type WorkOrder } from '../contracts/index.ts';
/** Требование заканчивается на следующем заголовке уровня 1–2; примеры в fenced-блоках не считаются. */
export declare function parseRequirements(markdown: string): {
    id: string;
    text: string;
    digest: string;
}[];
/** Требования источника на коммите: файл обязан быть обычным Git-файлом. */
export declare function requirementSnapshot(cwd: string, source: string, ref?: string): {
    source: string;
    sha: string;
    requirements: {
        id: string;
        text: string;
        digest: string;
    }[];
};
/**
 * Совпадают ли закреплённые требования поручения с источником на `ref`.
 * Изменённое или удалённое требование — отказ: исполнение по устаревшей
 * постановке не продолжается.
 */
export declare function assertRequirements(order: Pick<WorkOrder, 'requirements'>, cwd: string, ref?: string): void;
/** Псевдо-gate актуальности требований: обязателен в обеих фазах, если у поручения есть требования. */
export declare const REQUIREMENT_GATE = "requirement-source";
