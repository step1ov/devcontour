import { type CheckDeclaration, type CheckSuite, type ContractDocument, type ExecutionView, type GatePolicy, type Obligation, type WorkOrder, type WorkState } from '../contracts/index.ts';
import type { CheckManifest } from './property.ts';
/**
 * Договоры проверки поручения. Механизм включает само поручение полем
 * `properties`; поручение без него проверяется на прежнем уровне.
 */
/** Документы контрактов поручения по закреплённым digest; неизвестный — отсутствует. */
export declare function contractDocuments(order: Pick<WorkOrder, 'contracts'>, view: ExecutionView): ContractDocument[];
type Declared = {
    contract: ContractDocument;
    gate: string;
    obligation: Obligation;
};
/** Основание случаев корпуса: закреплённые файлы, gate и смысл обязательств. */
export declare function suiteBasis(contract: ContractDocument): string;
/**
 * Привязка поручения к версии корпуса остаётся в силе, только пока среди его
 * договоров есть договор этого корпуса с тем же нормативным основанием.
 * Изменение постороннего контракта её не снимает; новый ID или новые правила
 * того же ID — снимают: ожидания прежнего основания не становятся нормой для
 * новых правил.
 */
export declare function corpusBindingHolds(suite: Pick<CheckSuite, 'contractId' | 'basis'> | undefined, contracts: ContractDocument[], 
/** Основание корпуса по формуле хоста; без неё — формула harness. */
basisOf?: (contract: ContractDocument) => string): boolean;
/** Обязательство по property ID среди договоров поручения. */
export declare function obligationOf(contracts: ContractDocument[], id: string): Declared | undefined;
/**
 * Структурные пропуски договора проверки — до вызова модели. Способ проверки
 * обязан ссылаться на закреплённые файлы контракта: иначе происхождение
 * эталона не закреплено ничем.
 */
export declare function declarationProblems(declaration: CheckDeclaration, context: {
    gates: GatePolicy[];
    repositoryId: string;
    artifacts: string[];
    spike?: (id: string) => {
        digest: string;
    } | undefined;
}): string[];
/**
 * Свойства, объявленные поручением, существуют в его договорах и исполняются
 * его генеративными gates. Поручение без `properties` — прежний уровень.
 */
export declare function orderPropertyProblems(order: Pick<WorkOrder, 'id' | 'properties' | 'gates' | 'requirements'>, contracts: ContractDocument[], 
/** Gates репозитория поручения и раскрытая область поручения. */
gates: {
    configured: GatePolicy[];
    scope?: string[];
}): string[];
/** Случаи корпуса, закреплённые за попыткой. */
export interface CorpusSnapshot {
    digest: string;
    cases: {
        id: string;
        property: string;
    }[];
}
/**
 * Манифест ожидаемой проверки gate для поручения или undefined — прежний
 * уровень доказательства (поручение не включило механизм).
 */
export declare function orderCheckManifest(order: Pick<WorkOrder, 'properties'>, contracts: ContractDocument[], gate: string, corpus?: CorpusSnapshot): CheckManifest | undefined;
/**
 * Действующая версия проверок поручения: согласованная постановка,
 * контракты, политика и принятый snapshot корпуса. Закрепляется в попытке
 * при выдаче и участвует в evidence, finish, recovery и reuse.
 */
export declare function effectiveChecks(work: Pick<WorkState, 'approvedDigest' | 'order' | 'checkVersion'>, policyDigest: string): string;
/** Основание эпизода восстановления: согласованная постановка и контракты. */
export declare function episodeBasis(work: Pick<WorkState, 'approvedDigest' | 'order'>): string;
export {};
