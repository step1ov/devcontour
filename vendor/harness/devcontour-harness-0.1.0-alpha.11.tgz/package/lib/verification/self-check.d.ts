import type { ContractDocument, GatePolicy, WorkOrder } from '../contracts/index.ts';
/**
 * Самопроверка исполнителя: тот же закреплённый checker, полный корпус
 * закреплённой версии, генератор с воспроизводимым seed и селектор свойств
 * поручения. Проверяется рабочий, незакоммиченный код — результат
 * диагностический и не заменяет evidence controller на commit SHA: gates
 * исполняются всегда, с самопроверкой или без неё.
 */
export interface SelfCheckPlan {
    command: string[];
    corpus?: string;
    cases: number;
    seed: number;
    properties: string[];
}
export declare function writeSelfCheck(input: {
    order: Pick<WorkOrder, 'id' | 'properties'>;
    contracts: ContractDocument[];
    gates: GatePolicy[];
    dir: string;
    seed: number;
    /** Канонический файл закреплённой версии корпуса и число её случаев. */
    corpus?: {
        content: string;
        cases: number;
    };
}): Promise<SelfCheckPlan | undefined>;
/** Строка запроса исполнителю о самопроверке. */
export declare function selfCheckNote(plan: SelfCheckPlan): string;
