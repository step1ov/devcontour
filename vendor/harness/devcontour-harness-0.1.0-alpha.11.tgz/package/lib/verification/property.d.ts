import { type PropertyReport } from '../contracts/index.ts';
/**
 * Отчёт генеративной проверки: эталон, генератор, свойства и уменьшение
 * входа живут в проекте, а controller задаёт seed, читает отчёт при любом
 * исходе и сохраняет его как доказательство.
 *
 * Приёмка из отдельных точек проверяла примеры, а не обещание: контрпример
 * находил reviewer после полной попытки, и решение подгонялось под точки.
 * Генеративная проверка находит его сама, а seed controller делает отказ
 * воспроизводимым — даже если проверка зависла и ничего не успела записать.
 */
/** Seed controller: свой у каждой попытки, фазы и gate, но воспроизводимый. */
export declare function propertySeed(runId: string, phase: string, gateId: string): number;
/** Строка для итога gate: её видит следующая попытка в истории отказов. */
export declare function propertyFailure(report: PropertyReport): string;
/**
 * Ожидаемая проверка: что обязан подтвердить отчёт, чтобы gate прошёл.
 *
 * Зелёный код выхода и один зелёный testcase не говорят, что проверено
 * заявленное: harness с нулём входов писал `passed`, а пустой список свойств
 * проходил схему. Манифест закреплён вместе с договором проверки — свойства,
 * минимальное число входов по каждому и по семействам, обязательные случаи
 * корпуса — и отчёт сопоставляется с ним в controller, а не в подсказке
 * reviewer.
 */
export interface CheckManifest {
    properties: {
        id: string;
        minCases: number;
        families: {
            id: string;
            minCases: number;
        }[];
    }[];
    corpus?: {
        digest: string;
        cases: {
            id: string;
            property: string;
        }[];
    };
}
/** Свидетельство выполнения корпуса: hash отсортированных строк `id:pass|fail`. */
export declare function corpusWitness(cases: {
    id: string;
    passed: boolean;
}[]): string;
/** Выполненные testcases gate, как их сводит JUnit. */
export interface JunitCases {
    cases: {
        id: string;
        status: 'passed' | 'failed' | 'skipped';
        opaque?: true;
    }[];
    truncated: boolean;
}
/**
 * Почему отчёт не подтверждает покрытие. Пустой список — подтверждает.
 *
 * Без манифеста (поручение без свойств) проверяется прежний уровень: отчёт
 * не пуст, id не повторяются, `passed` означает хотя бы один проверенный
 * вход, а названные отчётом свойства есть среди testcases. С манифестом
 * обязательны все его свойства, их минимальные выборки и корпус. Id,
 * изменённый redaction или хешем, не совпадает ни с чем: скрытое имя не
 * подтверждает свойство, которое оно могло скрывать.
 */
export declare function propertyCoverage(report: PropertyReport, manifest: CheckManifest | undefined, junit: JunitCases | undefined): string[];
/** Digest манифеста: под ним evidence называет ту проверку, которую ждало. */
export declare function manifestDigest(manifest: CheckManifest): string;
/**
 * Прочитать отчёт. Отсутствие или повреждение — не исключение: исход команды
 * остаётся главным, отчёт его только дополняет. Причина называется.
 *
 * Читается только обычный файл внутри каталога отчёта. Команда проверки
 * могла заменить отчёт или его каталог на symlink наружу, и чужой файл —
 * например, из каталога controller — попал бы в evidence. Каталог сверяется
 * по realpath, файл открывается без следования за ссылкой, и проверка идёт
 * по уже открытому дескриптору: подмена между проверкой и чтением не проходит.
 */
export declare function readPropertyReport(path: string, root: string, redact?: (text: string) => string): Promise<{
    report: PropertyReport;
    problem?: undefined;
} | {
    problem: string;
    report?: undefined;
}>;
