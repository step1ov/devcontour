import { z } from 'zod';
import { type CheckpointInput, type CheckpointRecord, type CommentRecord, type HistoryMutation, type RelayTransport, type SessionRecord, type TaskColumn, type TaskRead, type TransportErrorKind, type TransportIdentity } from '../connector/transport.ts';
export declare const RELAY_V1_PROVIDER: "relay-v1-http";
/** Capability истории работы; без неё методы истории не вызывают routes. */
export declare const WORK_HISTORY_CAPABILITY = "relay-work-history-v1";
export declare const relayV1SettingsSchema: z.ZodObject<{
    endpoint: z.ZodString;
    projectId: z.ZodString;
    actor: z.ZodString;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
    maxResponseBytes: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export type RelayV1Settings = z.input<typeof relayV1SettingsSchema>;
type Settings = z.output<typeof relayV1SettingsSchema>;
export interface RelayV1Options {
    /** Подмена `fetch` (тесты); по умолчанию глобальный `fetch` Node. */
    fetch?: typeof fetch;
    /** Генератор requestId; по умолчанию `dc-<uuid>`. Не идемпотентность. */
    requestId?: () => string;
    /** Сколько раз перезапускать постраничное чтение при смене версии списка. */
    maxPageRestarts?: number;
    /** Сколько раз повторять полное чтение задачи при несогласованных токенах. */
    maxReadRetries?: number;
    /** Роль автора комментариев. */
    actorRole?: 'operator' | 'orchestrator' | 'worker';
}
export declare function classifyCode(code: string, status: number, mutation: boolean): TransportErrorKind;
export declare class RelayV1Transport implements RelayTransport {
    readonly provider: "relay-v1-http";
    readonly settings: Readonly<Settings>;
    private readonly base;
    private readonly fetchImpl;
    private readonly nextRequestId;
    private readonly maxPageRestarts;
    private readonly maxReadRetries;
    private readonly actorRole;
    private capabilities;
    constructor(settings: Settings, options?: RelayV1Options);
    private fail;
    private url;
    /** Один HTTP-вызов без повторов: envelope, классификация, схема данных. */
    private call;
    private transportFailure;
    private readLimited;
    /** Полное постраничное чтение offset/limit/version; частичный список не возвращается. */
    private pages;
    private pagesOnce;
    private enc;
    identity(signal?: AbortSignal): Promise<TransportIdentity>;
    /** Capability истории (кэш на транспорт); без неё route не вызывается. */
    private requireHistory;
    private summary;
    private readTaskOnce;
    /** Токен текущей редакции без полного чтения тел: ревизии и версии списков. */
    private probe;
    readTask(ref: string, signal?: AbortSignal): Promise<TaskRead>;
    listComments(ref: string, signal?: AbortSignal): Promise<CommentRecord[]>;
    addComment(ref: string, input: {
        title: string;
        body: string;
    }, signal?: AbortSignal): Promise<{
        commentId: string;
    }>;
    setCriterion(ref: string, input: {
        criterionId: string;
        completed: boolean;
        ifRevision: number;
    }, signal?: AbortSignal): Promise<{
        revision: number;
    }>;
    move(ref: string, input: {
        column: TaskColumn;
        ifRevision: number;
    }, signal?: AbortSignal): Promise<{
        revision: number;
    }>;
    private session;
    private checkpointRecord;
    private historyPost;
    startSession(input: {
        title: string;
        description: string;
        client: string;
        sourceSessionId?: string;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    getSession(ref: string, signal?: AbortSignal): Promise<SessionRecord>;
    findSessions(marker: string, signal?: AbortSignal): Promise<SessionRecord[]>;
    checkpoints(sessionRef: string, signal?: AbortSignal): Promise<CheckpointRecord[]>;
    private checkpointBody;
    openIntent(sessionRef: string, input: CheckpointInput & {
        runId: string;
        ifRevision: number;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    checkpoint(intentRef: string, kind: 'progress' | 'result' | 'cancel', input: CheckpointInput & {
        runId: string;
        ifRevision: number;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    fork(intentRef: string, input: {
        runId: string;
        ifRevision: number;
        title: string;
        description: string;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    attach(sessionRef: string, input: {
        ifRevision: number;
        client: string;
        sourceSessionId?: string;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    takeover(sessionRef: string, input: {
        ifRevision: number;
        reason: string;
        client: string;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    finishSession(sessionRef: string, outcome: 'complete' | 'cancel', input: {
        runId?: string;
        ifRevision: number;
        result: string;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
}
/** Создаёт транспорт Relay v1 по проверенным настройкам; неверные — `INVALID_INPUT`. */
export declare function createTransport(settings: unknown, options?: RelayV1Options): RelayV1Transport;
export {};
