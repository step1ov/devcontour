import { redactor, type Redactor } from '../../environment/redaction.ts';
import { type RelayTransport } from './transport.ts';
/**
 * Маскирование известных секретов в диагностике коннектора.
 *
 * Ошибка транспорта (HTTP body, stderr CLI) может дословно содержать значение
 * секрета. Обёртка маскирует сообщение каждой ошибки транспорта до того, как
 * она попадёт в отчёт `source-check`, `source-status`, сохранённые причины
 * шагов/операций, `lastError` доставки или вывод CLI. Данные успешных ответов
 * не меняются: это содержимое задач, которое закрепляется по digest.
 */
/** Значения секретов: `secrets`-карты политики (на любом уровне) из окружения controller. */
export declare function policySecrets(policy: unknown, env?: NodeJS.ProcessEnv): string[];
/** Значения настроек provider, по имени похожие на секрет (например, `relay.env.RELAY_TOKEN`). */
export declare function settingsSecrets(settings: unknown): string[];
export declare function maskError(error: unknown, redact: Redactor): unknown;
/** Транспорт, ошибки которого замаскированы `redact`. Повторная обёртка не создаётся. */
export declare function redactingTransport(inner: RelayTransport, redact: Redactor): RelayTransport;
export { redactor };
