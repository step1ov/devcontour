import { HarnessError, type ContextSnapshot, type WorkGraph } from '../../contracts/index.ts';
import { type ConnectorConfig, type TaskMapping } from './config.ts';
import type { ReceiptRecord } from './store.ts';
import { type CriterionRecord, type RelayTransport, type TaskRead, type TransportIdentity } from './transport.ts';
/**
 * Снимок задач backend: чтение без смешения редакций, semantic digest,
 * WorkGraph, ContextSnapshot и manifest.
 *
 * Semantic digest — то, к чему привязано согласование (`SourceRef.revision`):
 * текст требований, определения критериев (без отметок выполнения),
 * зависимости, подзадачи, значимые документы и digest mapping. Колонка, свой
 * in-progress, комментарии, история и отметки критериев в него не входят:
 * они не меняют постановку. CAS-ревизии, токены согласованности чтения и
 * идентичность сборки backend хранятся только в manifest — не в поле Git SHA
 * и не в графе.
 */
export interface SnapshotProblem {
    code: 'TASK_DONE' | 'TASK_CANCELLED' | 'COLUMN_NOT_ELIGIBLE' | 'DEPENDENCY_UNFINISHED' | 'DEPENDENCY_UNPROVEN' | 'LIMIT_EXCEEDED' | 'DOCUMENT_MISSING' | 'MAPPING_INVALID';
    taskId: string;
    key: string;
    message: string;
}
export interface DocumentManifest {
    id: string;
    key: string;
    name: string;
    revision: number;
    bytes: number;
    required: boolean;
    included: 'full' | 'truncated' | 'omitted';
    includedBytes: number;
    reason?: string;
}
export interface TaskManifest {
    ref: string;
    id: string;
    key: string;
    identity: string;
    orderId: string;
    semanticDigest: string;
    /** CAS-ревизия backend на момент чтения (не Git SHA). */
    casRevision: number;
    column: string;
    consistency: {
        before: string;
        after: string;
    };
    criteria: {
        id: string;
        title: string;
        mapped: boolean;
        completed: boolean;
    }[];
    dependencies: {
        id: string;
        key: string;
        column: string;
        finished: boolean;
        inGraph: boolean;
    }[];
    children: {
        id: string;
        key: string;
        column: string;
        finished: boolean;
    }[];
    documents: DocumentManifest[];
}
export interface SnapshotManifest {
    version: 1;
    provider: string;
    projectId: string;
    connector: string;
    build: Record<string, string>;
    capabilities: string[];
    graphId: string;
    graphDigest: string;
    contextDigest: string;
    /** Semantic digest набора задач — `graph.source.revision`. */
    revision: string;
    readAt: string;
    rounds: number;
    limits: ConnectorConfig['limits'];
    tasks: TaskManifest[];
    truncated: string[];
    problems: SnapshotProblem[];
}
export interface BuiltSnapshot {
    graph: WorkGraph;
    context: ContextSnapshot;
    manifest: SnapshotManifest;
    revision: string;
    problems: SnapshotProblem[];
}
/** Безопасная причина отказа транспорта при чтении: сеть/CLI — не пустой список. */
export declare function readFailure(error: unknown, what: string): HarnessError;
/** Проверка подключения: provider и projectId backend обязаны совпасть с настроенными. */
export declare function checkIdentity(transport: RelayTransport, config: ConnectorConfig, signal?: AbortSignal): Promise<TransportIdentity>;
/**
 * Полное согласованное чтение набора задач. Раунд — чтение всех задач; у
 * каждой `consistency.before === after`. Снимок принимается, когда два
 * последовательных раунда совпали токенами и содержимым: между ними ничего
 * не менялось, и граф не собирается из разных редакций. Изменения —
 * ограниченный повтор (`rereads`), затем явный отказ. Ошибка чтения —
 * отказ, а не пустой результат.
 */
export declare function readStable(transport: RelayTransport, refs: string[], rereads: number, signal?: AbortSignal): Promise<{
    reads: TaskRead[];
    rounds: number;
}>;
export declare const matchCriterion: (criteria: CriterionRecord[], m: TaskMapping["criteria"][number]) => CriterionRecord[];
/** Semantic digest задачи: смысл постановки без операционных полей. */
export declare function semanticDigest(config: ConnectorConfig, mapping: TaskMapping, read: TaskRead): string;
/** Прочитанная задача и её доверенные предпосылки → граф, контекст и manifest. */
export declare function buildSnapshot(input: {
    config: ConnectorConfig;
    identity: TransportIdentity;
    reads: TaskRead[];
    rounds: number;
    /** Доверенный receipt этого коннектора для задачи-зависимости вне графа. */
    receiptOf: (orderId: string) => ReceiptRecord | undefined;
}): BuiltSnapshot;
/** Прочитать, собрать и проверить идентичность: общий путь `source-snapshot` и `run --source`. */
export declare function takeSnapshot(input: {
    config: ConnectorConfig;
    transport: RelayTransport;
    receiptOf: (orderId: string) => ReceiptRecord | undefined;
    signal?: AbortSignal;
}): Promise<BuiltSnapshot>;
/** Отказ по eligibility/limits: причина и предел в сообщении, без запуска. */
export declare function assertEligible(snapshot: BuiltSnapshot): void;
