import { type AttemptState, type RunResult, type WorkState } from '../../contracts/index.ts';
import type { RunnerHooks } from '../../engine/runner.ts';
import { type Redactor } from '../../environment/redaction.ts';
import { type ConnectorConfig } from './config.ts';
import type { ConnectorStore, StepRecord } from './store.ts';
import type { RelayTransport } from './transport.ts';
/**
 * История работы в backend: корневая сессия поручения и дочерняя сессия на
 * каждую попытку.
 *
 * - До исполнения попытки (`prepared`, до writer) — корневая сессия с intent,
 *   затем fork + attach дочерней и её intent. Отказ обязательной записи —
 *   `BlockedError`: попытка не начинается, runtime не вызывается.
 * - Отказ попытки (`failed`) — cancel дочернего intent и сессии.
 * - Доставка результата — checkpoint с SHA и сводкой gates, завершение
 *   дочерней, приём её корневым intent, завершение корня (или отмена).
 *
 * Каждая запись — шаг с маркером в теле/описании; после неизвестного исхода
 * он находится read-back (`findSessions`/`checkpoints`) или сравнением
 * ревизии сессии, поэтому восстановление после перезапуска не дублирует
 * checkpoints. Ревизия сессии и run backend — fencing: если сессию перехватил
 * другой владелец, наш устаревший run её не завершит (`conflict`).
 *
 * Идентификаторы различны и не смешиваются: ID сессии/run backend, sessionId
 * runtime и lease token попытки harness. Lease token и полный runtime log в
 * историю не пишутся.
 */
export interface SessionLink {
    key: string;
    kind: 'root' | 'child';
    workId: string;
    attemptId?: string;
    rootKey?: string;
    /** Ключ маркеров шагов этой сессии. */
    opKey: string;
    taskKey: string;
    sessionId?: string;
    sessionKey?: string;
    /** Run backend (не lease token harness). */
    runId?: string;
    revision?: number;
    intentId?: string;
    intentClosed?: boolean;
    status: 'opening' | 'open' | 'completed' | 'cancelled' | 'conflict' | 'uncertain';
    steps: StepRecord[];
    reason?: string;
}
export declare class HistoryRecorder {
    readonly options: {
        config: ConnectorConfig;
        transport: RelayTransport;
        store: ConnectorStore;
        connectorId: string;
        redact?: Redactor;
    };
    private readonly redact;
    private readonly t;
    constructor(options: {
        config: ConnectorConfig;
        transport: RelayTransport;
        store: ConnectorStore;
        connectorId: string;
        redact?: Redactor;
    });
    get enabled(): boolean;
    /** Хуки runner: intent до исполнения попытки, отмена при отказе. */
    hooks(): RunnerHooks;
    links(workId?: string): SessionLink[];
    private link;
    private markerKey;
    /** Текущий корень поручения для редакции постановки; закрытый — новое поколение. */
    private rootKeyOf;
    private findByMarker;
    /** Факты получателя о шаге после неизвестного исхода. */
    private readBackFor;
    private applyResult;
    private saveStep;
    private writeStep;
    /** Выполнить шаг `n` записи `key` по протоколу шагов. */
    private exec;
    /**
     * Запись прерванной попытки (перезапуск controller): незавершённые шаги
     * только разбираются по фактам — `planned` не отправляется, `sending`
     * подтверждается read-back; повторной отправки нет.
     */
    private settle;
    private addSteps;
    private stepOf;
    private ensureRoot;
    /** Корень и дочерняя сессия попытки до её исполнения. */
    beginAttempt(work: WorkState, attempt: AttemptState, baseSha: string): Promise<void>;
    /** Закрыть intent и сессию записи `key`: итог или отмена. */
    private close;
    /**
     * Reconcile: неоднозначные шаги истории поручения снова разбираются
     * read-back (`sending`); сама запись не отправляется.
     */
    resetUncertain(workId: string): void;
    /** Отмена дочерней сессии попытки (отказ, прерывание). */
    cancelChild(attemptId: string, reason: string): Promise<void>;
    /**
     * Итог доставки: дочерняя сессия попытки результата и корень поручения.
     * Принятый результат — checkpoint с SHA и gates, завершение и приём
     * дочерней; иначе — отмена.
     */
    closeResult(result: RunResult, workId: string): Promise<{
        child: string;
        root: string;
        status: string;
    } | {
        child?: undefined;
        root: string;
        status: string;
    } | {
        child: string;
        root?: undefined;
        status: string;
    } | {
        child?: undefined;
        root?: undefined;
        status: string;
    }>;
    private clean;
}
