import type { StepRecord } from './store.ts';
/**
 * Протокол одного внешнего шага (комментарий, критерий, перемещение, запись
 * истории). Шаг сохраняется в состоянии коннектора до вызова:
 *
 * - `planned` — intent записан, вызова не было: отправка безопасна;
 * - `sending` — вызов мог дойти; после обрыва исход выясняется только
 *   read-back по маркеру (append-only) или сравнением состояния (CAS);
 * - `done` — получатель подтвердил запись (ответом или read-back);
 * - `uncertain` — исход доказать нельзя: автоматический повтор запрещён,
 *   нужен `source-reconcile`;
 * - `conflict` — CAS/доменный отказ или чужое изменение: старый результат
 *   не применяется к новой редакции.
 */
/** Итог read-back после неизвестного исхода. */
export type ReadBack = 
/** Запись найдена ровно одна (маркер) или целевое состояние достигнуто. */
{
    state: 'found';
    result: Record<string, unknown>;
}
/** Доказано, что запись не применена, и повтор защищён CAS (ревизия не изменилась). */
 | {
    state: 'absent';
    reason: string;
}
/** Неоднозначно: 0 маркеров после возможной отправки, больше одного, неполный read-back. */
 | {
    state: 'ambiguous';
    reason: string;
}
/** Чужое изменение: ревизия изменилась, а целевого состояния нет. */
 | {
    state: 'foreign';
    reason: string;
};
export declare class StepUncertain extends Error {
    readonly step: number;
    name: string;
    constructor(step: number, message: string);
}
export declare class StepConflict extends Error {
    readonly step: number;
    readonly currentRevision?: string | undefined;
    name: string;
    constructor(step: number, message: string, currentRevision?: string | undefined);
}
/** Отправка точно не состоялась (или доказано отсутствие записи): шаг можно повторить позже. */
export declare class StepRetry extends Error {
    readonly step: number;
    name: string;
    constructor(step: number, message: string);
}
export interface StepIo {
    load(): StepRecord;
    /** Сохранить шаг (под владением операции); отказ записи — исключение, вызова не будет. */
    save(step: StepRecord): void;
}
/**
 * Выполнить шаг по протоколу. `prepare` — входы, известные только в момент
 * отправки (CAS-ревизия), записываются вместе с `sending` до вызова.
 */
export declare function runStep(io: StepIo, handlers: {
    prepare?: () => Record<string, unknown>;
    send: (input: Record<string, unknown>) => Promise<Record<string, unknown>>;
    readBack: (input: Record<string, unknown>) => Promise<ReadBack>;
    /** Запись без CAS (append-only): ответ conflict — подтверждённый отказ, не повод для read-back. */
    appendOnly?: boolean;
}): Promise<Record<string, unknown>>;
export declare const markerOf: (key: string, n: number) => string;
export declare const newStep: (n: number, kind: StepRecord["kind"], key: string, input: Record<string, unknown>) => StepRecord;
