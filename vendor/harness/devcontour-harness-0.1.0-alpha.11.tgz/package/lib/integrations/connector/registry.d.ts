import { type LoadedConfig } from './config.ts';
import type { RelayTransport } from './transport.ts';
/**
 * Реестр транспортов по явному provider. Модуль адаптера загружается только
 * для выбранного provider (opt-in): core и файловый сценарий не загружают
 * Relay-адаптеры и не требуют их окружения.
 *
 * Договор адаптера: модуль `src/integrations/<adapter>/index.ts` экспортирует
 * `createTransport(settings, options?)`, где `settings` — объект `relay` из
 * конфигурации коннектора, дополненный `projectId` и `actor` верхнего уровня
 * (и для relay-v2-cli — абсолютными путями `binary`/`config`, разрешёнными от
 * каталога файла конфигурации). Неверные настройки — `INVALID_INPUT`.
 */
export declare function settingsFor(loaded: LoadedConfig): Record<string, unknown>;
export declare function createTransportFor(loaded: LoadedConfig): Promise<RelayTransport>;
