import { type ExecutionPolicy, type RuntimeAdapter, type RuntimeName, type RuntimeRequest } from '../../contracts/index.ts';
import { Harness } from '../../control/harness.ts';
import { type ConnectorConfigInput, type CriterionMapping, type LoadedConfig } from './config.ts';
import { Connector } from './commands.ts';
import { type FaultRule } from './fake.ts';
import type { ProviderId, RelayTransport, TaskColumn } from './transport.ts';
export { FakeAdmin, FakeRelayTransport, FileBarrier, LocalBarrier, emptyFakeState, faultyTransport, fileBackend, memoryBackend, type Barrier, type FakeBackend, type FakeState, type FaultAction, type FaultRule, } from './fake.ts';
/** Действия другого участника прямо в backend (постановка задач, правки, перехват). */
export interface SuiteAdmin {
    createTask(input: {
        title: string;
        description: string;
        column?: TaskColumn;
        criteria?: {
            title: string;
            summary?: string;
        }[];
        dependencies?: string[];
        parentId?: string;
    }): Promise<{
        id: string;
        key: string;
        criteria: string[];
    }>;
    updateTask(id: string, patch: {
        title?: string;
        description?: string;
    }): Promise<void>;
    updateCriterion(id: string, criterionId: string, title: string): Promise<void>;
    completeCriterion(id: string, criterionId: string, completed?: boolean): Promise<void>;
    addDocument(taskId: string, doc: {
        name: string;
        body: string;
    }): Promise<{
        id: string;
    }>;
    updateDocument(id: string, body: string): Promise<void>;
    addDependency(id: string, dependsOn: string): Promise<void>;
    /** Перемещение с done guards backend (как у человека). */
    move(id: string, column: TaskColumn): Promise<void>;
    /** Комментарий другого участника (может содержать любой текст, включая маркер). */
    comment(id: string, body: string): Promise<void>;
    /** Перехват открытой сессии истории другим владельцем. */
    takeover(sessionId: string): Promise<void>;
}
/** Как воссоздать транспорт в другом процессе (`testing-worker.ts`). */
export type WorkerTransport = 
/** Подделка над общим файлом состояния. */
{
    kind: 'fake';
    file: string;
    provider: ProviderId;
    actor: string;
}
/** Настоящий адаптер по конфигурации коннектора (`createTransportFor`). */
 | {
    kind: 'config';
};
export interface SuiteProject {
    provider: ProviderId;
    projectId: string;
    actor: string;
    /** Поле `relay` конфигурации коннектора (без projectId/actor). */
    relay: Record<string, unknown>;
    /** Новый экземпляр транспорта этого проекта. */
    transport(): RelayTransport;
    worker: WorkerTransport;
    admin: SuiteAdmin;
    cleanup(): Promise<void>;
}
/** Backend набора: каждый вызов `project()` — новый изолированный проект. */
export interface SuiteBackend {
    name: string;
    project(): Promise<SuiteProject>;
}
/** Backend набора на подделке; состояние каждого проекта — в своём файле SQLite. */
export declare function fakeSuiteBackend(provider?: ProviderId): SuiteBackend;
export declare const fixtureGreet = "exports.greet = (name) => 'Hello, ' + name + '!';\n";
export interface RuntimeCalls {
    writer: number;
    reviewer: number;
    plan: number;
}
export interface FixtureBehaviour {
    writer?: 'implement' | 'incomplete';
    reviewer?: 'approve' | 'reject';
    /** Вызывается при каждом вызове writer до ответа (проверка порядка, отмена). */
    onWriter?: (request: RuntimeRequest) => void | Promise<void>;
}
/** Runtime fixture в процессе: writer пишет greet, reviewer одобряет или отклоняет. */
export declare function fixtureAdapters(calls: RuntimeCalls, behaviour?: FixtureBehaviour): Partial<Record<RuntimeName, RuntimeAdapter>>;
/** Runtime, который не должен вызываться (доставка, reconcile): вызов — отказ и запись. */
export declare function forbiddenAdapters(file: string): Partial<Record<RuntimeName, RuntimeAdapter>>;
export declare function suitePolicy(repo: string, patch?: Partial<Record<string, unknown>>): ExecutionPolicy;
export interface ScenarioOptions extends FixtureBehaviour {
    criteria?: {
        title: string;
    }[];
    mapping?: (Partial<CriterionMapping> & {
        gate: string;
    })[];
    config?: (config: ConnectorConfigInput & Record<string, unknown>) => void;
    maxAttempts?: number;
    approvalMode?: 'agent' | 'operator';
    description?: string;
}
export interface Opened {
    connector: Connector;
    h: Harness;
    transport: RelayTransport & {
        calls: Record<string, number>;
    };
    close(): void;
}
export interface WorkerSpec {
    action: 'deliver' | 'reconcile' | 'begin-attempt';
    workId?: string;
    operation?: string;
    decision?: string;
    faults?: (Omit<FaultRule, 'barrier' | 'after'> & {
        barrier?: {
            dir: string;
            name: string;
        };
    })[];
    crashOnStoreWrite?: {
        what: string;
        nth: number;
    };
    owner?: string;
    attempt?: {
        work: unknown;
        attempt: unknown;
        baseSha: string;
    };
}
export interface WorkerResult {
    code: number | null;
    output?: {
        ok: boolean;
        result?: unknown;
        error?: {
            code?: string;
            message: string;
        };
    };
    stderr: string;
}
export interface Scenario {
    project: SuiteProject;
    task: {
        id: string;
        key: string;
        criteria: string[];
    };
    root: string;
    repo: string;
    state: string;
    policy: ExecutionPolicy;
    calls: RuntimeCalls;
    config: ConnectorConfigInput & Record<string, unknown>;
    loaded(): LoadedConfig;
    workId: string;
    open(o?: {
        faults?: FaultRule[];
        onStoreWrite?: (what: string) => void;
        transport?: RelayTransport;
        behaviour?: FixtureBehaviour;
        secrets?: string[];
    }): Promise<Opened>;
    /** Снимок и `run --source` (ревью плана, исполнение, доставка). */
    snapshotAndRun(o?: Parameters<Scenario['open']>[0]): Promise<{
        opened: Opened;
        run: Awaited<ReturnType<Connector['run']>>;
    }>;
    /** Снимок и исполнение без доставки (результат принят локально). */
    runOnly(o?: Parameters<Scenario['open']>[0]): Promise<Opened>;
    target(): string;
    worker(spec: WorkerSpec, timeoutMs?: number): Promise<WorkerResult>;
    /** Дождаться истечения lease упавшего владельца (перехват — только после срока). */
    waitLeases(): Promise<void>;
    cleanup(): Promise<void>;
}
export declare function scenario(backend: SuiteBackend, o?: ScenarioOptions): Promise<Scenario>;
/** Комментарии harness у задачи (по маркеру) — счёт у получателя, не локальных вызовов. */
export declare function harnessComments(t: RelayTransport, taskId: string): Promise<import("./transport.ts").CommentRecord[]>;
export declare function markerCount(t: RelayTransport, taskId: string, marker: string): Promise<number>;
/** Все чекпоинты сессий истории поручения у получателя. */
export declare function historyCheckpoints(opened: Opened, workId: string): Promise<{
    session: string;
    kind: string;
    title: string;
    body: string;
}[]>;
export interface SuiteOptions {
    /** Предел одного теста, мс. */
    timeoutMs?: number;
    /** Выполнить только тесты с этими ID (`W02`, `D03`…). */
    only?: string[];
}
/**
 * Общий контрактный набор коннектора для backend. Имена тестов содержат ID
 * условий приёмки и имя backend.
 */
export declare function connectorSuite(backend: SuiteBackend, options?: SuiteOptions): void;
