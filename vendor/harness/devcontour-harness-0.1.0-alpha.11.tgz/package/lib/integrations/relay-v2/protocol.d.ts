import { z } from 'zod';
import type { TransportErrorKind } from '../connector/transport.ts';
/**
 * Договор вывода Relay-2 CLI (`--format json`), проверенный на сборке
 * a3ee804: успех — одна JSON-строка `{ok:true,data,meta?}` в stdout и exit 0;
 * отказ — `{ok:false,error:{code,message,details?}}` в stderr и ненулевой exit.
 * Схемы проверяют только поля, которые читает адаптер; лишние поля допустимы.
 */
export declare const successSchema: z.ZodObject<{
    ok: z.ZodLiteral<true>;
    data: z.ZodUnknown;
    meta: z.ZodOptional<z.ZodUnknown>;
}, z.core.$strip>;
export declare const failureSchema: z.ZodObject<{
    ok: z.ZodLiteral<false>;
    error: z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
        details: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const columnSchema: z.ZodEnum<{
    ready: "ready";
    review: "review";
    cancelled: "cancelled";
    done: "done";
    "in-progress": "in-progress";
    inbox: "inbox";
}>;
export declare const criterionSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    summary: z.ZodPipe<z.ZodOptional<z.ZodNullable<z.ZodString>>, z.ZodTransform<string, string | null | undefined>>;
    description: z.ZodPipe<z.ZodOptional<z.ZodNullable<z.ZodString>>, z.ZodTransform<string, string | null | undefined>>;
    completed: z.ZodBoolean;
}, z.core.$strip>;
export declare const commentSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodPipe<z.ZodOptional<z.ZodNullable<z.ZodString>>, z.ZodTransform<string, string | null | undefined>>;
    body: z.ZodString;
    createdAt: z.ZodString;
    createdBy: z.ZodString;
}, z.core.$strip>;
export declare const taskSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodLiteral<string>;
    key: z.ZodString;
    revision: z.ZodNumber;
    createdAt: z.ZodOptional<z.ZodString>;
    createdBy: z.ZodOptional<z.ZodString>;
    data: z.ZodObject<{
        title: z.ZodString;
        description: z.ZodPipe<z.ZodOptional<z.ZodNullable<z.ZodString>>, z.ZodTransform<string, string | null | undefined>>;
        column: z.ZodEnum<{
            ready: "ready";
            review: "review";
            cancelled: "cancelled";
            done: "done";
            "in-progress": "in-progress";
            inbox: "inbox";
        }>;
        parentId: z.ZodNullable<z.ZodString>;
        dependencies: z.ZodArray<z.ZodString>;
        acceptanceCriteria: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            summary: z.ZodPipe<z.ZodOptional<z.ZodNullable<z.ZodString>>, z.ZodTransform<string, string | null | undefined>>;
            description: z.ZodPipe<z.ZodOptional<z.ZodNullable<z.ZodString>>, z.ZodTransform<string, string | null | undefined>>;
            completed: z.ZodBoolean;
        }, z.core.$strip>>;
        comments: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            title: z.ZodPipe<z.ZodOptional<z.ZodNullable<z.ZodString>>, z.ZodTransform<string, string | null | undefined>>;
            body: z.ZodString;
            createdAt: z.ZodString;
            createdBy: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const progressSchema: z.ZodObject<{
    completed: z.ZodBoolean;
    canComplete: z.ZodBoolean;
    blockers: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export declare const documentSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodLiteral<string>;
    key: z.ZodString;
    revision: z.ZodNumber;
    createdAt: z.ZodOptional<z.ZodString>;
    createdBy: z.ZodOptional<z.ZodString>;
    data: z.ZodObject<{
        name: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const sessionSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodLiteral<string>;
    key: z.ZodString;
    revision: z.ZodNumber;
    createdAt: z.ZodOptional<z.ZodString>;
    createdBy: z.ZodOptional<z.ZodString>;
    data: z.ZodObject<{
        title: z.ZodString;
        description: z.ZodPipe<z.ZodOptional<z.ZodNullable<z.ZodString>>, z.ZodTransform<string, string | null | undefined>>;
        status: z.ZodEnum<{
            open: "open";
            cancelled: "cancelled";
            pending: "pending";
            completed: "completed";
            paused: "paused";
        }>;
        currentRunId: z.ZodNullable<z.ZodString>;
        parentSessionId: z.ZodNullable<z.ZodString>;
        result: z.ZodPipe<z.ZodOptional<z.ZodNullable<z.ZodString>>, z.ZodTransform<string, string | null | undefined>>;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const checkpointSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodLiteral<string>;
    key: z.ZodString;
    revision: z.ZodNumber;
    createdAt: z.ZodOptional<z.ZodString>;
    createdBy: z.ZodOptional<z.ZodString>;
    data: z.ZodObject<{
        kind: z.ZodEnum<{
            result: "result";
            cancel: "cancel";
            intent: "intent";
            progress: "progress";
        }>;
        sessionId: z.ZodString;
        runId: z.ZodString;
        intentId: z.ZodNullable<z.ZodString>;
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const storageStatusSchema: z.ZodObject<{
    projectId: z.ZodString;
    databasePath: z.ZodString;
    generation: z.ZodNumber;
}, z.core.$strip>;
export declare const projectSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodLiteral<string>;
    key: z.ZodString;
    revision: z.ZodNumber;
    createdAt: z.ZodOptional<z.ZodString>;
    createdBy: z.ZodOptional<z.ZodString>;
    data: z.ZodObject<{
        name: z.ZodString;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const doctorSchema: z.ZodObject<{
    projectId: z.ZodString;
    generation: z.ZodNumber;
    valid: z.ZodBoolean;
    issues: z.ZodArray<z.ZodUnknown>;
}, z.core.$strip>;
export declare const pageMetaSchema: z.ZodObject<{
    page: z.ZodObject<{
        nextCursor: z.ZodNullable<z.ZodString>;
        consistency: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const itemsSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodUnknown>;
}, z.core.$strip>;
/** Стабильный код Relay-2 → класс отказа транспорта. Exit code — только грубый класс. */
export declare function classifyCode(code: string, exit: number | null, mutation: boolean): TransportErrorKind;
