import { z } from 'zod';
import { type CheckpointInput, type CheckpointRecord, type CommentRecord, type HistoryMutation, type RelayTransport, type SessionRecord, type TaskColumn, type TaskRead, type TransportErrorKind, type TransportIdentity } from '../connector/transport.ts';
export declare const PROVIDER: "relay-v2-cli";
export declare const relayV2SettingsSchema: z.ZodObject<{
    binary: z.ZodString;
    config: z.ZodString;
    project: z.ZodOptional<z.ZodString>;
    projectId: z.ZodString;
    actor: z.ZodString;
    env: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
    maxOutputBytes: z.ZodDefault<z.ZodNumber>;
    build: z.ZodOptional<z.ZodObject<{
        sha256: z.ZodOptional<z.ZodString>;
        commit: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type RelayV2Settings = z.input<typeof relayV2SettingsSchema>;
type Settings = z.output<typeof relayV2SettingsSchema>;
/** Запись об одном вызове CLI (для evidence/диагностики). Cursor маскирован. */
export interface RelayV2CallLog {
    operation: string;
    argv: string[];
    cwd: string;
    mutation: boolean;
    exitCode: number | null;
    signal: string | null;
    durationMs: number;
    code?: string;
    outcome: 'ok' | TransportErrorKind;
}
export interface RelayV2TransportOptions {
    /** cwd процесса; на выбор проекта не влияет (всегда `--config`). */
    cwd?: string;
    /** Пауза между SIGTERM и SIGKILL группе процессов. */
    killGraceMs?: number;
    /** Размер страницы списков (1..100). */
    pageLimit?: number;
    /** Предел страниц одного списка. */
    maxPages?: number;
    /** Сколько раз начать список заново после SNAPSHOT_CONFLICT. */
    snapshotRestarts?: number;
    onCall?: (call: RelayV2CallLog) => void;
}
/** Capabilities, выводимые пробами чтения несуществующей записи. */
export declare const RELAY_V2_CAPABILITIES: {
    readonly 'relay-2.task.read': readonly ["task", "get"];
    readonly 'relay-2.task.children': readonly ["task", "children"];
    readonly 'relay-2.task.progress': readonly ["task", "progress"];
    readonly 'relay-2.task.criterion': readonly ["task", "criterion", "list"];
    readonly 'relay-2.task.comment': readonly ["task", "comment", "list"];
    readonly 'relay-2.document.target': readonly ["document", "list", "--target"];
    readonly 'relay-2.history.session': readonly ["session", "get"];
    readonly 'relay-2.history.checkpoint': readonly ["checkpoint", "get"];
    readonly 'relay-2.history.list': readonly ["session", "history"];
};
export declare function createTransport(settings: RelayV2Settings, options?: RelayV2TransportOptions): RelayV2Transport;
export declare class RelayV2Transport implements RelayTransport {
    private readonly settings;
    private readonly options;
    readonly provider: "relay-v2-cli";
    private verified;
    private readonly cwd;
    constructor(settings: Settings, options?: RelayV2TransportOptions);
    private env;
    private argv;
    private fail;
    private log;
    /** Один вызов CLI → `{data, meta}` успешного envelope или TransportError. */
    private call;
    private shape;
    /** Полный список по `meta.page.nextCursor`; при SNAPSHOT_CONFLICT — заново, ограниченно. */
    private list;
    private ref;
    private status;
    private ensure;
    /** Перед мутацией: идентичность сборки/проекта и свежая сверка projectId. */
    private guard;
    identity(signal?: AbortSignal): Promise<TransportIdentity>;
    readTask(ref: string, signal?: AbortSignal): Promise<TaskRead>;
    private getTask;
    private summary;
    listComments(ref: string, signal?: AbortSignal): Promise<CommentRecord[]>;
    addComment(ref: string, input: {
        title: string;
        body: string;
    }, signal?: AbortSignal): Promise<{
        commentId: string;
    }>;
    setCriterion(ref: string, input: {
        criterionId: string;
        completed: boolean;
        ifRevision: number;
    }, signal?: AbortSignal): Promise<{
        revision: number;
    }>;
    move(ref: string, input: {
        column: TaskColumn;
        ifRevision: number;
    }, signal?: AbortSignal): Promise<{
        revision: number;
    }>;
    startSession(input: {
        title: string;
        description: string;
        client: string;
        sourceSessionId?: string;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    getSession(ref: string, signal?: AbortSignal): Promise<SessionRecord>;
    private readSession;
    findSessions(marker: string, signal?: AbortSignal): Promise<SessionRecord[]>;
    checkpoints(sessionRef: string, signal?: AbortSignal): Promise<CheckpointRecord[]>;
    openIntent(sessionRef: string, input: CheckpointInput & {
        runId: string;
        ifRevision: number;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    checkpoint(intentRef: string, kind: 'progress' | 'result' | 'cancel', input: CheckpointInput & {
        runId: string;
        ifRevision: number;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    private writeCheckpoint;
    fork(intentRef: string, input: {
        runId: string;
        ifRevision: number;
        title: string;
        description: string;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    attach(sessionRef: string, input: {
        ifRevision: number;
        client: string;
        sourceSessionId?: string;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    takeover(sessionRef: string, input: {
        ifRevision: number;
        reason: string;
        client: string;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    finishSession(sessionRef: string, outcome: 'complete' | 'cancel', input: {
        runId?: string;
        ifRevision: number;
        result: string;
    }, signal?: AbortSignal): Promise<HistoryMutation>;
    private sessionMutation;
}
export {};
