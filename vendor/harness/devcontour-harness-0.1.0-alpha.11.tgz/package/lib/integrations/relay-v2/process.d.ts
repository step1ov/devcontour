/**
 * Один вызов Relay-2 CLI: argv-массив без shell, ограниченные вывод и время,
 * завершение всей группы процессов при таймауте, отмене или переполнении.
 * Результат возвращается только после `close`: дочерний процесс к этому
 * моменту завершён и собран (нет зомби), pipes закрыты.
 */
export interface CliRun {
    /** Процесс так и не стартовал (нет binary, нет прав): запрос не ушёл. */
    spawnError?: NodeJS.ErrnoException;
    /** Процесс стартовал (запрос мог дойти до backend). */
    started: boolean;
    code: number | null;
    signal: NodeJS.Signals | null;
    stdout: string;
    stderr: string;
    timedOut: boolean;
    aborted: boolean;
    /** Суммарный вывод превысил лимит; процесс остановлен. */
    oversized: boolean;
    durationMs: number;
    pid?: number;
}
export interface CliRunOptions {
    cwd: string;
    env: Record<string, string>;
    timeoutMs: number;
    maxOutputBytes: number;
    /** Пауза между SIGTERM и SIGKILL группе. */
    killGraceMs: number;
    signal?: AbortSignal;
}
export declare function runCli(file: string, args: string[], options: CliRunOptions): Promise<CliRun>;
