import { z } from 'zod';
/**
 * Нейтральный договор внешней памяти (Hindsight и подобные). Harness не
 * зависит от SDK, MCP или сетевого клиента: реальный адаптер реализует эти
 * два метода у себя и подключается явно, через opt-in entrypoint
 * `devcontour-harness/integrations/memory`. Ядро и `./contracts` этот модуль
 * не импортируют.
 */
/** Запрос recall: identity банка/проекта, текст и пределы, которые провайдер обязан соблюдать. */
export interface MemoryQuery {
    bank: string;
    project: string;
    text: string;
    maxItems: number;
    maxBytes: number;
    maxCostUnits?: number;
}
/**
 * Ответ recall — фактические байты тела ответа провайдера (`body`, JSON по
 * `memoryRecallBodySchema`). Байты закрепляются как есть: digest считается
 * от них, а не от пересобранного объекта.
 */
export interface MemoryRecallResponse {
    body: string;
}
export declare const memoryItemSchema: z.ZodObject<{
    id: z.ZodString;
    text: z.ZodString;
    score: z.ZodOptional<z.ZodNumber>;
    mandatory: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type MemoryItem = z.infer<typeof memoryItemSchema>;
export declare const memoryRecallBodySchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        text: z.ZodString;
        score: z.ZodOptional<z.ZodNumber>;
        mandatory: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    costUnits: z.ZodOptional<z.ZodNumber>;
    providerVersion: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type MemoryRecallBody = z.infer<typeof memoryRecallBodySchema>;
/** Провайдер recall. Ошибка или ответ вне схемы — недоступность, а не пустой успех. */
export interface MemoryRecallProvider {
    readonly id: string;
    recall(query: MemoryQuery, signal: AbortSignal): Promise<MemoryRecallResponse>;
}
/**
 * Документ подтверждённого итога для retain. `documentId` — стабильная
 * identity одного результата (upsert документа); `operationId` — identity
 * одной операции доставки (идемпотентность асинхронного retain). Это разные
 * гарантии: upsert не предотвращает повторную асинхронную обработку.
 */
export interface MemoryDocument {
    bank: string;
    project: string;
    documentId: string;
    operationId: string;
    content: string;
    metadata: Record<string, string>;
}
export declare const memoryRetainAckSchema: z.ZodObject<{
    status: z.ZodEnum<{
        accepted: "accepted";
        stored: "stored";
    }>;
    receipt: z.ZodOptional<z.ZodString>;
    costUnits: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export type MemoryRetainAck = z.infer<typeof memoryRetainAckSchema>;
/** Провайдер retain. Исключение — сбой доставки памяти; harness записывает его отдельно. */
export interface MemoryRetainProvider {
    readonly id: string;
    retain(document: MemoryDocument, signal: AbortSignal): Promise<MemoryRetainAck>;
}
export type MemoryProvider = MemoryRecallProvider & MemoryRetainProvider;
/** ID провайдера входит в ID источника и получателя — та же форма, что у остальных ID. */
export declare const providerIdSchema: z.ZodString;
