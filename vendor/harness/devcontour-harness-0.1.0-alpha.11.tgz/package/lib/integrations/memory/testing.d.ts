import type { MemoryDocument, MemoryItem, MemoryProvider, MemoryQuery, MemoryRetainAck } from './provider.ts';
/**
 * FIXTURE ONLY. Детерминированный провайдер памяти для тестов: ответы по
 * сценарию, счётчики обращений, смена ответа, недоступность и отказ retain
 * до или после записи. Ни сети, ни ключей, ни SDK.
 */
export declare class FakeMemoryProvider implements MemoryProvider {
    readonly id: string;
    readonly extra: {
        costUnits?: number;
        providerVersion?: string;
    };
    readonly calls: {
        recall: number;
        retain: number;
    };
    readonly queries: MemoryQuery[];
    /** Документы по `documentId` — upsert, как у памяти с document identity. */
    readonly documents: Map<string, MemoryDocument>;
    /** Каждая принятая операция retain по порядку (`operationId`). */
    readonly operations: string[];
    /** Каждый вызов retain: какой документ и операция пришли (включая неудачные). */
    readonly log: {
        documentId: string;
        operationId: string;
    }[];
    private body;
    private down;
    private retainFailures;
    constructor(id: string, items: MemoryItem[], extra?: {
        costUnits?: number;
        providerVersion?: string;
    });
    /** Новый ответ recall (например, после согласования). */
    respond(items: MemoryItem[]): void;
    unavailable(reason?: string): void;
    available(): void;
    /** Следующие вызовы retain падают: до записи или после неё (неизвестный исход). */
    failRetain(...modes: ('before-store' | 'after-store')[]): void;
    recall(query: MemoryQuery): Promise<{
        body: string;
    }>;
    retain(document: MemoryDocument): Promise<MemoryRetainAck>;
}
