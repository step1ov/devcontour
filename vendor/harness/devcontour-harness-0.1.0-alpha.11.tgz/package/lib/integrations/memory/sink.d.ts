import { type DeliveryOutcome, type ResultSink, type RunResult } from '../../contracts/index.ts';
import { type MemoryDocument, type MemoryRetainProvider } from './provider.ts';
export interface MemoryResultSinkOptions {
    /** ID получателя; по умолчанию `memory-<provider.id>` — отдельный от Git и Relay ключ доставки. */
    id?: string;
    bank: string;
    project: string;
    timeoutMs?: number;
}
/** Учёт записи во внешнюю память — отдельно от usage coding runtime. */
export interface MemoryRetainUsage {
    retainCalls: number;
    costUnits: number;
}
/**
 * Детерминированный UUID (форма версии 5, вариант RFC 4122) из hex-digest:
 * `operation_id` Hindsight — UUID, а повтор обязан дать тот же.
 */
export declare function uuidOf(digest: string): string;
/**
 * Стабильная identity документа результата: провайдер, bank, project,
 * поручение, попытка и digest самого результата. Повтор доставки того же
 * результата даёт тот же `documentId` (upsert), другой результат — другой.
 */
export declare const memoryDocumentId: (providerId: string, bank: string, project: string, result: RunResult) => string;
/**
 * Текст подтверждённого итога: только то, что записал controller (исход,
 * SHA, gates и их итоги, находки ревью). Пересказ writer сюда не входит.
 */
export declare function memoryContent(result: RunResult): string;
/**
 * Получатель подтверждённого итога во внешней памяти. Это обычный
 * `ResultSink`: harness ведёт его доставку отдельной записью по своему
 * ключу (`<sink>:<work>:<run>`), так что сбой памяти не трогает принятый
 * Git-результат и receipt других получателей, а повтор
 * (`Harness.deliver(work, sink)`) отправляет только память — с тем же
 * `documentId` и `operationId`, без нового writer.
 *
 * Сохраняются только принятые результаты; остальные исходы доставляются
 * явной отметкой «пропущено» без обращения к провайдеру.
 */
export declare class MemoryResultSink implements ResultSink {
    readonly provider: MemoryRetainProvider;
    readonly options: MemoryResultSinkOptions;
    readonly id: string;
    readonly usage: MemoryRetainUsage;
    constructor(provider: MemoryRetainProvider, options: MemoryResultSinkOptions);
    documentId(result: RunResult): string;
    /** Документ доставки: `operationId` стабилен для ключа доставки и документа. */
    document(key: string, result: RunResult): MemoryDocument;
    deliver({ key, result }: {
        key: string;
        result: RunResult;
    }): Promise<DeliveryOutcome>;
}
export declare const memoryResultSink: (provider: MemoryRetainProvider, options: MemoryResultSinkOptions) => MemoryResultSink;
