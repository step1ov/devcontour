import { type ContextSnapshot, type ContextSource } from '../../contracts/index.ts';
import { type MemoryRecallProvider } from './provider.ts';
/** Часть составного снимка: источник и ID, которые у него запрашиваются. */
export interface ContextPart {
    source: ContextSource;
    ids: string[];
}
/**
 * Объединение снимков: источники и отсутствующие по порядку частей. Повтор ID
 * источника — отказ (`INVALID_INPUT`), а не молчаливая замена; итог
 * проверяется `contextIssues` и пределами снимка.
 */
export declare function mergeSnapshots(...snapshots: ContextSnapshot[]): ContextSnapshot;
/**
 * Снимок из нескольких `ContextSource` (например, файлы + память) — до ревью
 * плана и согласования. Части опрашиваются по порядку; отказ обязательной
 * части останавливает подготовку целиком: частичный снимок не возвращается.
 */
export declare function composeContext(parts: ContextPart[], at: {
    repositoryId: string;
    sha?: string;
}): Promise<ContextSnapshot>;
/**
 * `required` — без ответа памяти подготовка не идёт; `optional` — отсутствие
 * записывается в `missing` снимка; `disabled` — провайдер не вызывается,
 * снимок такой же, как без памяти.
 */
export type MemoryMode = 'required' | 'optional' | 'disabled';
export interface MemoryLimits {
    /** Сумма байтов (UTF-8) текстов элементов, вложенных в запрос. */
    maxBytes: number;
    maxItems: number;
    /** Предел стоимости одного recall в единицах провайдера. */
    maxCostUnits?: number;
}
export interface MemoryContextOptions {
    /** ID источника в снимке (и в `order.context`, если память обязательна для поручения). */
    id: string;
    mode: MemoryMode;
    /** Стабильный bank проекта и identity проекта: входят в запрос и provenance. */
    bank: string;
    project: string;
    query: string | ((at: {
        repositoryId: string;
        sha?: string;
    }) => string);
    limits: MemoryLimits;
    /**
     * `forbid` — превышение предела отказывает (по умолчанию для required);
     * `mark` — лишние элементы отбрасываются с явной пометкой (по умолчанию для
     * optional). Элементы `mandatory` не отбрасываются никогда.
     */
    truncation?: 'forbid' | 'mark';
    timeoutMs?: number;
    /** Часы recall — для детерминированного `recalledAt`. */
    now?: () => Date;
}
/** Учёт внешней памяти — отдельно от usage coding runtime. */
export interface MemoryUsage {
    recallCalls: number;
    costUnits: number;
}
/** Provenance закреплённого recall (`provenance.json` источника). */
export interface MemoryProvenance {
    provider: string;
    providerVersion?: string;
    mode: MemoryMode;
    bank: string;
    project: string;
    query: string;
    recalledAt: string;
    /** Фактический ответ: digest его байтов, размер, число элементов, стоимость, закреплён ли целиком. */
    response: {
        digest: string;
        bytes: number;
        items: number;
        costUnits: number;
        pinned: boolean;
    };
    limits: MemoryLimits;
    truncation: 'forbid' | 'mark';
    applied: {
        items: number;
        bytes: number;
    };
    truncated: {
        items: boolean;
        bytes: boolean;
        omitted: string[];
    };
}
/**
 * Источник контекста из внешней памяти. Recall выполняется в `snapshot` —
 * то есть до ревью плана и согласования; в снимок закрепляются фактические
 * байты ответа (`response.json`), вложенный текст для запроса (`recall.md`)
 * и provenance (`provenance.json`): провайдер, bank, project, запрос, время,
 * digest ответа, применённые пределы и признаки обрезки. После согласования
 * исполняется только закреплённый снимок: новый ответ провайдера в попытку
 * не попадает.
 *
 * Память — данные, а не постановка: источник не меняет поручение, область
 * записи, политику и ничего не разрешает.
 */
export declare class MemoryContextSource implements ContextSource {
    readonly provider: MemoryRecallProvider | undefined;
    readonly options: MemoryContextOptions;
    readonly id: string;
    readonly usage: MemoryUsage;
    constructor(provider: MemoryRecallProvider | undefined, options: MemoryContextOptions);
    /** Часть составного снимка с ID этого источника. */
    part(): ContextPart;
    snapshot(ids: string[], at: {
        repositoryId: string;
        sha?: string;
    }): Promise<ContextSnapshot>;
    private recall;
}
export declare const memoryContextSource: (provider: MemoryRecallProvider | undefined, options: MemoryContextOptions) => MemoryContextSource;
/** Provenance закреплённого источника памяти из снимка (для проверки и отчёта). */
export declare function memoryProvenance(snapshot: ContextSnapshot, id: string): MemoryProvenance | undefined;
