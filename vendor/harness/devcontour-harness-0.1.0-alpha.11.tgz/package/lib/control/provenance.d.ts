/**
 * Откуда загружена политика процесса: путь в том виде, как его задали,
 * разрешённая при загрузке цель и хэш именно тех байтов, которые разобраны.
 */
export interface PolicySource {
    path: string;
    real: string;
    sha: string;
}
export declare const policySourceOf: (path: string, text: string) => PolicySource;
/**
 * Источник сейчас содержит ровно разобранные байты по той же цели. Сверяется
 * содержимое, а не mtime и размер: их сохраняют копирование и перезапись тем
 * же размером; переключённая ссылка на другой файл — другой источник.
 * `undefined` — не менялся, иначе причина.
 */
export declare function policySourceChanged(source: PolicySource): string | undefined;
