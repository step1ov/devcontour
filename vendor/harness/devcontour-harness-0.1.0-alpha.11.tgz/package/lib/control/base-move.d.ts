import type { ExecutionPolicy, ExecutionStore, ExecutionView } from '../contracts/index.ts';
/** Сдвиг ref: репозиторий, ref, новое и ожидаемое прежнее значение. */
export type RefMove = (repoPath: string, target: string, to: string, from: string) => void | Promise<void>;
/**
 * Сдвиг ref внутри транзакции проверки владения операцией: проверка и
 * `git update-ref` неразделимы — отмена или перехват операции либо видны
 * проверке, либо происходят уже после сдвига. Внутри транзакции не
 * исполняется чужой код: hook `reference-transaction`, ждущий ту же базу,
 * ждал бы её, а она — его; срок Git ограничен, зависший Git не держит базу.
 */
export declare function fencedRefMove(store: ExecutionStore, fence: (view: ExecutionView) => void, timeoutMs?: number): RefMove;
export declare namespace fencedRefMove {
    var timeoutMs: number;
}
export interface BaseMoved {
    repositoryId: string;
    targetRef: string;
    from: string;
    to: string;
    commits: number;
    kind: 'fast-forward' | 'merge';
}
/**
 * Перенос базы: target ref каждого репозитория сводится с рабочей линией
 * (HEAD checkout или переданный точный SHA). Цель — предок рабочей линии:
 * fast-forward; обе линии несут работу — слияние без hooks в отдельном
 * worktree. Прежнее значение ref проверяется CAS. `only` — переносить только
 * эти репозитории и ровно на эти SHA: операция, проверившая одну редакцию,
 * не переносит ту, что появилась позже. Очередь при этом должна стоять —
 * это решает операция, а не перенос.
 */
export declare function moveBase(input: {
    policy: ExecutionPolicy;
    baseDir: string;
    stateDir: string;
    only?: Record<string, string>;
    move?: RefMove;
}): Promise<{
    workingBehind?: {
        repositoryId: string;
        commits: number;
    }[] | undefined;
    updated: BaseMoved[];
}>;
