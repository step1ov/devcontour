import { type Author, type ContextSnapshot, type ContractDocument, type ExecutionPolicy, type ReviewRecord, type RuntimeAdapter, type RuntimeName } from '../contracts/index.ts';
import type { CallMeta } from '../engine/budget.ts';
import type { Engine } from '../engine/engine.ts';
/**
 * Раунд технического ревью плана или контракта — одна реализация для
 * standalone `Harness.review` и для хоста, который ведёт движок поверх своего
 * хранилища. Хост задаёт предмет (ID, digest, автор), свои разделы запроса и
 * рабочий каталог reviewer; harness выбирает reviewer по правилу вендора
 * политики (отказ до вызова), вызывает его под учётом бюджета, требует
 * состояние каждой прежней открытой находки и записывает раунд в историю.
 * Тот же digest и назначение, уже одобренные последним раундом, — тот же
 * раунд без вызова модели.
 */
export interface TechnicalReviewInput {
    kind: 'plan' | 'contract';
    /** ID предмета: граф или контракт. */
    subject: string;
    /** Digest предмета, к которому относится одобрение. */
    digest: string;
    author: Author;
    /** Разделы запроса хоста: что проверять и сам документ. */
    instructions: string[];
    /** Закреплённый контекст плана: его digest — часть основания раунда. */
    context?: ContextSnapshot;
    /** Контракт, закрепляемый одобренным раундом по digest. */
    contract?: ContractDocument;
    /** Репозиторий, окружение которого получает reviewer (по умолчанию — первый). */
    repositoryId?: string;
    /** Рабочий каталог reviewer (только чтение). */
    cwd: string;
    /** Каталог артефактов раунда. */
    artifactDir: string;
    /** Пути, закрытые reviewer (состояние controller). */
    denied: string[];
    /** Дополнительно читаемые пути. */
    readable?: string[];
    /** Учёт вызова: предмет и группа. */
    meta: Omit<CallMeta, 'stage'> & {
        stage?: string;
    };
    /** Предел раундов предмета; нет — без предела. */
    maxRounds?: number;
    /**
     * Раунды предмета, которые хост провёл до harness и хранит сам. Учитываются,
     * только пока у предмета нет раундов в движке: нумерация продолжается после
     * них, а находки последнего из них — прежние открытые находки, состояние
     * которых reviewer обязан назвать. Это история, а не одобрение: у прежних
     * раундов нет digest, назначения и PASS, и ничего из этого не выводится.
     */
    history?: {
        rounds: number;
        findings: {
            severity: 'blocking' | 'note';
            message: string;
            rule?: string;
        }[];
    };
    /** Источник значений окружения (по умолчанию `process.env`). */
    environment?: NodeJS.ProcessEnv;
    signal?: AbortSignal;
}
export declare function technicalReview(engine: Engine, policy: ExecutionPolicy, adapters: Partial<Record<RuntimeName, RuntimeAdapter>>, input: TechnicalReviewInput): Promise<ReviewRecord>;
