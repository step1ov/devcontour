import { type ExecutionPolicy, type RuntimeAdapter, type RuntimeName } from '../contracts/index.ts';
import type { ToolchainReport } from '../toolchains/inspect.ts';
/** Диагностика toolchain политики (см. `inspectPolicy` в `./toolchains`). */
export type ToolchainInspect = (policy: ExecutionPolicy, baseDir: string) => Promise<ToolchainReport[]>;
/**
 * Проверка среды без live-вызова модели: версия пакета и Node, наличие
 * runtime (по `--version`) и их возможности, OS-sandbox, совместимость
 * каталога состояния. Каталог состояния открывается только если он есть;
 * для совместимого состояния называются версии движка, встреченные в нём
 * (роль controller и попытки), — перед обновлением и откатом видно, какая
 * версия последней писала состояние.
 */
export declare function doctor(policy: ExecutionPolicy | undefined, adapters: Partial<Record<RuntimeName, RuntimeAdapter>>, stateDir?: string, 
/**
 * Диагностика toolchain репозиториев (инструменты и версии, lockfiles,
 * scripts/tasks, cwd, отчёты) — только чтением и ограниченными пробами
 * версий. Передаётся явно (CLI — `inspectPolicy` из `./toolchains`): корень
 * пакета не тянет модуль toolchains сам.
 */
toolchain?: {
    baseDir: string;
    inspect: ToolchainInspect;
}): Promise<{
    problems: string[];
    toolchains?: ToolchainReport[] | undefined;
    state?: {
        stateVersion: number;
        compatible: boolean;
        engineVersions?: {
            controller?: string;
            attempts: string[];
        };
    } | undefined;
    harness: string;
    apiVersion: "devcontour-harness/v1alpha1";
    node: string;
    platform: string;
    runtimes: {
        reason?: string | undefined;
        structuredOutput: boolean;
        cancellation: boolean;
        version?: string | undefined;
        runtime: "codex" | "claude";
        available: boolean;
    }[];
    sandbox: {
        reason?: string | undefined;
        os: boolean;
    };
}>;
