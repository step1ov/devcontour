import type { z } from 'zod';
import { type ContextSnapshot, type ContractDocument, type ExecutionPolicy } from '../contracts/index.ts';
import { type planCheckDataSchema, type planRequestDataSchema } from '../contracts/planning.ts';
export type PlanRequestData = z.infer<typeof planRequestDataSchema>;
export type PlanCheckData = z.infer<typeof planCheckDataSchema>;
export interface PlanInputs {
    policy: ExecutionPolicy;
    baseDir: string;
    context?: ContextSnapshot;
    contracts?: ContractDocument[];
}
/** `harness plan-request`: prompt, basis и факты; ничего не пишет. */
export declare function planRequestOf(input: PlanInputs & {
    brief: string;
    requirementSources?: {
        repositoryId: string;
        source: string;
    }[];
}): PlanRequestData;
/** `harness plan-check`: issues и план подготовки проверок либо граф. */
export declare function planCheck(input: PlanInputs & {
    draft: unknown;
    graphId: string;
    brief?: string;
    basis?: string;
}): PlanCheckData;
