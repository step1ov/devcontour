import type { CodedIssue } from '../contracts/errors.ts';
import { type SourceRef, type WorkGraph } from '../contracts/index.ts';
import type { PlanningFacts, StandalonePlanDraft } from '../contracts/planning.ts';
/**
 * Draft → WorkGraph (OP-PLAN-04): digests контрактов из фактов, не выдумываются.
 * Вызывается после пустого `draftIssues`. Пределы исполняемого поручения
 * (ID ≤ 80, acceptance ≤ 30 по 3–1500, текст без пробелов по краям,
 * contracts ≤ 30) проверяет `workGraphSchema`; его нарушения — issues с
 * путями `['graph', 'orders', i, …]`, где `orders[i]` — это `tasks[i]`.
 * При любых issues графа нет.
 */
export declare function draftToGraph(draft: StandalonePlanDraft, options: {
    graphId: string;
    source: SourceRef;
    facts: PlanningFacts;
    idOf?: (key: string) => string;
}): {
    graph?: WorkGraph;
    issues: CodedIssue[];
};
