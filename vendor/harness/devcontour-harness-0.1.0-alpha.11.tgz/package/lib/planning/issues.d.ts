import type { CodedIssue } from '../contracts/errors.ts';
import type { CheckGap, PlanDraft, PlanningFacts } from '../contracts/planning.ts';
/**
 * Структурные проблемы draft (OP-PLAN-03); с `facts` — и ссылки на факты проекта.
 * Порядок: повтор ключа; зависимости по задачам (на себя, неизвестная); циклы;
 * затем по задачам — факты. Без `facts` — только структура: хост проверяет
 * контекст задач сам. Ничего не бросает и draft не меняет.
 */
export declare function draftIssues(draft: PlanDraft, options?: {
    known?: readonly string[];
    facts?: PlanningFacts;
}): CodedIssue[];
/**
 * Недостающие проверки: план их подготовки, а не удаление из draft.
 * Неизвестный gate или группа — объявить gate; область задачи из известных
 * ссылок без test gate — добавить test gate. Задачи репозитория, которого нет
 * в фактах, сюда не входят: это ошибка draft, а не недостающая проверка.
 */
export declare function checkGaps(draft: PlanDraft, facts: PlanningFacts): CheckGap[];
