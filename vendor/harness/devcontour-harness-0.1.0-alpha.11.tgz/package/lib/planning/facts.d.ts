import { type ContextSnapshot, type ContractDocument, type ExecutionPolicy } from '../contracts/index.ts';
import type { PlanningFacts } from '../contracts/planning.ts';
/**
 * Факты планирования из политики самостоятельного проекта. Роли репозитория —
 * роли политики, затем роли, объявленные только репозиторием; привязка каждой
 * берётся через `roleBinding` (роль репозитория заменяет роль политики).
 * Встроенных ролей нет: планировать можно только объявленными.
 */
export declare function planningFactsOf(policy: ExecutionPolicy, options: {
    baseDir: string;
    context?: ContextSnapshot;
    contracts?: readonly ContractDocument[];
}): PlanningFacts;
