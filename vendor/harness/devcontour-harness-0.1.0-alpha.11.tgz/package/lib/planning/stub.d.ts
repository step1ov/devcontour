/** Заглушка L0: сигнатура договора уже действует, тело приходит в рабочем пакете. */
export declare const notImplemented: (what: string) => never;
