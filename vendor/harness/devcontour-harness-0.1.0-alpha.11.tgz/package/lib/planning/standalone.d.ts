export interface RequirementFact {
    repositoryId: string;
    source: string;
    requirements: {
        id: string;
        text: string;
        digest: string;
    }[];
}
/**
 * Host-инструкции самостоятельного CLI (T1–T6): ведущий агент сам пишет draft,
 * отдельная модель планирования не вызывается.
 */
export declare function standaloneInstructions(input: {
    requirements: RequirementFact[];
}): string[];
