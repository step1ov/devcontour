import type { ExecutionView, FailureKind, WorkState } from '../contracts/index.ts';
export type RepairDecision = {
    action: 'retry';
    workId: string;
    kind: FailureKind;
    fingerprint: string;
    /** Класс держит выдачу: починив его, нужно снять его блокировку. */
    blocksQueue: boolean;
    reason: string;
} | {
    action: 'stop';
    workId?: string;
    kind?: FailureKind;
    reason: string;
};
/**
 * Что делать с упавшим поручением группы.
 *
 * Решение принимается только по записанному состоянию: класс отказа,
 * сохранённый в момент падения, число одинаковых отпечатков среди прошлых
 * попыток, бюджет попыток поручения и бюджет восстановлений группы. Ни одного
 * обращения к сети, git или runtime — поэтому вся таблица решений проверяется
 * тестами, а перезапуск процесса ничего не меняет: те же данные дают тот же
 * ответ.
 *
 * Повтор здесь — обычный повтор в пределах бюджета попыток поручения. Сброс
 * бюджета остаётся действием человека: он означает «причина устранена
 * снаружи», и утверждать это за человека контур не вправе.
 */
export declare function repairDecision(view: ExecutionView, works: WorkState[], options: {
    budgetLeft: number;
    maxAttempts: number;
}): RepairDecision | undefined;
