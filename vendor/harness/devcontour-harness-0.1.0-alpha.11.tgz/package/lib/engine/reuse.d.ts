import { type AttemptState, type ExecutionView, type FailureKind, type WorkState } from '../contracts/index.ts';
/** Отказы, которые ничего не говорят о коде кандидата. */
export declare const reusableFailures: readonly FailureKind[];
/**
 * Основания фазы реализации: всё, от чего зависел написанный код. Знания
 * хоста (у DevContour — память) приходят закреплённым контекстом и входят
 * сюда его digest, отдельного поля у движка нет.
 */
export interface ImplementationBasis {
    /** Согласованная постановка поручения. */
    spec: string;
    /** Контракты, на которые поручение ссылается, по их digest. */
    contracts: Record<string, string>;
    /** Договор исполнения: проверки, окружение, роли, изоляция. */
    policyDigest: string;
    runtime: string;
    model?: string;
    /** Целевая ветка, от которой ответвлён кандидат. */
    baseSha: string;
    /** Digest закреплённого снимка контекста. */
    context: string | null;
    dependencies: unknown;
    /** Версия движка: правила области и сборки запроса. */
    engineVersion: string;
    /** Принятая версия корпуса: новый подтверждённый случай — новое основание. */
    corpus?: string;
}
export declare function implementationBasis(work: WorkState, attempt: AttemptState, baseSha: string, engineVersion: string): string;
export type ReuseDecision = {
    reuse: true;
    from: AttemptState;
    candidateSha: string;
} | {
    reuse: false;
    reason: string;
};
/**
 * Можно ли вместо новой реализации взять кандидата предыдущей попытки.
 *
 * Только непосредственно предыдущая попытка того же поручения: пропустить
 * более позднее отклонение ревью и вернуться к старому коду значило бы
 * проигнорировать замечание. Только кандидат, прошедший реализацию (записан
 * его SHA), и только после отказа, не относящегося к коду. Основания должны
 * совпасть целиком.
 */
export declare function reusableImplementation(view: ExecutionView, work: WorkState, currentRunId: string, basis: string): ReuseDecision;
/**
 * Черновик предыдущей попытки, с которого стоит продолжить.
 *
 * Время реализации кончилось раньше работы — или ревью отклонило готового
 * кандидата за конкретные находки. Повтор с пустого дерева тратит предел
 * попытки на уже сделанное и нередко упирается в него снова. Черновик берётся
 * только у последней содержательной попытки. Проверки и ревью он не заменяет —
 * это отправная точка.
 */
export type Draft = ({
    kind: 'unfinished';
    runId: string;
    /** Чем кончилась попытка до кандидата: время, «не закончил», обрыв. */
    reason: FailureKind;
    patch: string;
    digest: string;
    files: string[];
} | {
    kind: 'candidate';
    runId: string;
    /** Чем кончилась попытка с готовым кандидатом: ревью, проверка, время ревью. */
    reason: FailureKind;
    error?: string;
    baseSha: string;
    candidateSha: string;
}) & {
    /**
     * Постановка или контракты менялись после попытки-источника. Черновик всё
     * равно берётся: переутверждение ради уточнения контракта выбрасывало
     * почти готовую работу. Исполнитель узнаёт, что сверять его нужно с новой.
     */
    respecified: boolean;
};
export declare function continuableDraft(view: ExecutionView, work: WorkState, currentRunId: string): Draft | undefined;
