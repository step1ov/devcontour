import { BlockedError, type FailureKind } from '../contracts/index.ts';
export { BlockedError };
/**
 * Отказ провайдера, а не работы: он повторится на любой следующей выдаче.
 * Список узкий намеренно — временные ошибки сети сюда не входят.
 */
export declare const providerRefusal: (message: string) => boolean;
export declare function classifyFailure(error: unknown, message: string): FailureKind;
