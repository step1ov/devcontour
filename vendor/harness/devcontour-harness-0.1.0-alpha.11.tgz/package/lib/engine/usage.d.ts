import { type CallRecord, type ExecutionPolicy, type ExecutionView, type Usage } from '../contracts/index.ts';
export type Price = ExecutionPolicy['prices'][number];
/**
 * Стоимость вызова. Сообщённая провайдером — как есть, и при ошибке вызова.
 * Оценка по тарифу — только по полным счётчикам: у оборванного вызова они
 * частичные, и оценка выдала бы нижнюю границу за стоимость.
 */
export declare function priceUsage(usage: Usage, price?: Price): {
    costUsd: number;
    costSource: "provider-reported";
} | {
    costUsd: null;
    costSource: "unknown";
} | {
    costUsd: number;
    costSource: "tariff-estimate";
};
export declare const activeStart: (id: string) => number | undefined;
export declare const startActive: (id: string) => Map<string, number>;
export declare const endActive: (id: string) => boolean;
export declare const registerMonotonic: (now: () => bigint, boot: string | undefined) => void;
/**
 * Время вызова: монотонное, если записано; иначе по меткам до завершения, а у
 * идущего — до `at`. `null` — время неизвестно: метки противоречат друг другу
 * (часы переведены назад), и ноль выдал бы потраченное время за непотраченное.
 */
export declare const callDurationMs: (r: CallRecord, at?: number) => number | null;
/**
 * Стоимость вызова известна, когда она сообщена провайдером (в том числе 0 и
 * при ошибке или прерывании) или оценена по полным счётчикам завершённого
 * вызова. Идущий вызов ещё может стоить больше записанного; у прерванного
 * оценка — лишь нижняя граница: после неё он мог продолжать тратить.
 */
export declare const knownCost: (r: CallRecord) => boolean;
export declare function usageTotals(records: CallRecord[], uncovered?: boolean, at?: number): {
    calls: number;
    costUsd: number | null;
    knownCostUsd: number;
    /** Сообщено провайдером. */
    reportedUsd: number;
    /** Оценено по тарифу. */
    estimatedUsd: number;
    complete: boolean;
    unknownCalls: number;
    estimatedCalls: number;
    reportedCalls: number;
    /** Идущие вызовы и прерванные падением процесса. */
    unfinishedCalls: number;
    abandonedCalls: number;
    errorCalls: number;
    durationMs: number;
    /** Вызовы с неизвестным временем: их время в `durationMs` не вошло. */
    unknownDurationCalls: number;
};
/**
 * Процесс, который ведёт вызов. Процессы и ОС — дело слоя окружения: он
 * регистрирует свой процесс и проверку чужого владельца. Без регистрации
 * чужой владелец живым не считается (консервативно).
 */
export type CallOwner = NonNullable<CallRecord['process']>;
export declare function registerProcess(owner: CallOwner, alive: (owner: CallOwner) => boolean, gone: (owner: CallOwner) => boolean): void;
/** Процесс, от имени которого записываются вызовы; `undefined` — не зарегистрирован. */
export declare const currentProcess: () => {
    id: string;
    pid: number;
    startedAt?: number | undefined;
} | undefined;
export declare const currentBootId: () => string | undefined;
/**
 * Вызов идёт на самом деле. Свой — ещё не завершён в этом процессе. Чужой —
 * его процесс существует и это тот же процесс (pid этого процесса у чужой
 * записи значит, что pid достался нам; момент старта сверяет слой окружения),
 * и вызов не старше `maxMs`. Владелец, которого подтвердить нельзя, живым не
 * считается.
 */
export declare function liveCall(r: CallRecord, at: number, maxMs: number): boolean;
/**
 * Владелец записи точно не ведёт вызов: процесса нет, или pid достался
 * другому процессу. Владелец, которого нельзя ни подтвердить, ни
 * опровергнуть, ушедшим не считается: восстановление не закрывает, возможно,
 * идущий вызов.
 */
export declare function ownerGone(r: CallRecord): boolean;
/** Все записи вызовов всех владельцев (workspace и репозиториев). */
export declare function callRecords(view: ExecutionView): CallRecord[];
/** Владелец локальной записи вызова: репозиторий или workspace. */
export declare const callOwner: (r: Pick<CallRecord, "repositoryId">) => string;
