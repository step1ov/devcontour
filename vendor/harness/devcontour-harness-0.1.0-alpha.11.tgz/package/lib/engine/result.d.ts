import { type AttemptState, type RunResult } from '../contracts/index.ts';
/**
 * Машинный результат завершённой попытки. Строится только из записей самой
 * попытки и оснований, закреплённых за ней при выдаче (`pinned`): новая
 * редакция графа, изменение или удаление поручения не переписывают
 * завершённую историю. `accepted` — только успешная попытка: её integration
 * SHA — result SHA. Недостающие сведения не выдумываются.
 */
export declare function runResult(attempt: AttemptState, harnessVersion: string): RunResult;
