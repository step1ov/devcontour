import { type ExecutionHost, type ExecutionPolicy, type ExecutionStore } from '../contracts/index.ts';
/**
 * Хост самостоятельного harness: основания — digest нейтральных структур,
 * дополнительных условий нет, группа бюджета — граф.
 */
export declare function standaloneHost(store: ExecutionStore, policy: ExecutionPolicy): ExecutionHost;
