import type { AttemptState, CodeReviewHistory, ContextSnapshot, ProtocolIssue, WorkState } from '../contracts/index.ts';
/** Предыдущие попытки поручения с находками ревью: исполнитель адресует каждую открытую. */
export declare function previousAttempts(attempts: AttemptState[], current: string): {
    attempt: number;
    error: string | undefined;
    evidence: {
        gate: string;
        phase: "candidate" | "integration";
        passed: boolean;
        summary: string;
        findings: {
            severity: string;
            message: string;
            path?: string | null | undefined;
            line?: number | null | undefined;
            id?: string | undefined;
            status?: "open" | "closed" | "withdrawn" | undefined;
        }[] | undefined;
    }[];
}[];
/** Строка-заголовок раздела открытых находок; JSON — следующей строкой (её читают fixtures). */
export declare const OPEN_FINDINGS_HEADER = "Open review findings issued by the controller";
export declare const CLOSED_FINDINGS_HEADER = "Closed or withdrawn review findings (history)";
/**
 * История находок ревью кода в запросе. Reviewer получает открытые находки с
 * выданными ID, severity, origin и основанием, а закрытые — как историю;
 * writer — открытые находки, которые нужно устранить.
 */
export declare function findingsText(history: CodeReviewHistory | undefined, review: boolean): string;
/**
 * Повтор reviewer после ошибки протокола: только структурированная
 * диагностика прошлого ответа и требование полного валидного вердикта.
 */
export declare function protocolRetryText(retry: {
    call: number;
    calls: number;
    issues: ProtocolIssue[];
}): string;
/** Закреплённый контекст: вложенные файлы — содержимым, справки — названием. */
export declare function contextText(snapshot: ContextSnapshot | undefined): string;
/** Запрос исполнителю или reviewer: исходные критерии, область, прежние находки, контекст. */
export declare function prompt(input: {
    work: WorkState;
    attempt: AttemptState;
    history: AttemptState[];
    context?: ContextSnapshot;
    gates: {
        id: string;
        command: string[];
    }[];
    review?: {
        sha: string;
        phase: string;
        diff: string;
    };
    /** Обязательный корпус и решение разбора, под которым выдан повтор. */
    notes?: string[];
    /** История находок ревью кода поручения (docs/review-protocol.md). */
    findings?: CodeReviewHistory;
    /** Повтор reviewer после ошибки протокола того же логического ревью. */
    retry?: {
        call: number;
        calls: number;
        issues: ProtocolIssue[];
    };
}): string;
