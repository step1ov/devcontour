import type { Stats } from 'node:fs';
import type { fileConflicts } from '../contracts/project.ts';
/**
 * Безопасная подготовка файлов: план → create-only применение. Ничего
 * существующего не перезаписывается, через symlink и вне корня не пишется.
 */
export type FileConflict = (typeof fileConflicts)[number];
export interface FileIntent {
    /** Абсолютный путь. */
    path: string;
    content: string;
    /** По умолчанию `preserve`. */
    onExisting?: 'preserve' | 'require-identical';
}
export interface FileWriteInput {
    files: FileIntent[];
    root?: string;
}
export interface FilePlanEntry {
    path: string;
    action: 'create' | 'preserve' | 'conflict';
    conflict?: FileConflict;
    /** Путь, вызвавший конфликт (symlink-предок, предок-файл). */
    conflictPath?: string;
}
export interface FilePlan {
    entries: FilePlanEntry[];
    conflicts: number;
    root?: string;
}
/** `lstat`; отсутствующий путь — undefined, прочие ошибки — как есть. */
export declare function inspectPath(path: string): Promise<Stats | undefined>;
/** Отказ PATH_CONFLICT, если путь или предок — symlink, предок не каталог или путь вне root. */
export declare function checkDestination(path: string, options?: {
    root?: string;
}): Promise<void>;
/** Относительные пути обычных файлов каталога (рекурсивно). */
export declare function listRegularFiles(dir: string): Promise<string[]>;
/** План записей; конфликты не бросаются — агент видит их все сразу. */
export declare function planFileWrites(input: FileWriteInput): Promise<FilePlan>;
/** Применение плана: только создание, в порядке `files`. */
export declare function applyFileWrites(plan: FilePlan, files: FileIntent[]): Promise<{
    created: string[];
    preserved: string[];
}>;
