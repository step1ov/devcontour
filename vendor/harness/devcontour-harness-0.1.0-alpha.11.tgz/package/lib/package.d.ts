/** Версия пакета читается из его собственного package.json, а не из cwd. */
export declare const HARNESS_VERSION: string;
