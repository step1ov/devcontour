import type { z } from 'zod';
import { type ExecutionPolicy, type GatePolicy, type repositoryPolicySchema } from '../contracts/index.ts';
import { type ToolProbe } from './probe.ts';
type Repository = z.infer<typeof repositoryPolicySchema>;
type Field = (string | number)[];
/**
 * Коды проблем диагностики toolchain. Каждая проблема называет поле
 * конфигурации (`field`) и, когда причина в файле проекта, — путь (`path`).
 */
export declare const toolchainProblemCodes: readonly ["REPOSITORY_MISSING", "CWD_MISSING", "TOOL_MISSING", "TOOL_VERSION", "TOOL_VERSION_UNKNOWN", "TOOL_NOT_LOCKED", "MANIFEST_MISSING", "LOCKFILE_MISSING", "LOCKFILE_AMBIGUOUS", "SCRIPT_UNKNOWN", "TASK_UNKNOWN", "FILTER_UNKNOWN", "INSTALL_UNLOCKED", "UNPINNED", "IF_PRESENT", "CACHE_REPLAY", "REPORT_MISMATCH", "COMPOSITION_CONFLICT", "PROJECT_FILE_MISSING", "SCRIPT_UNRESOLVED", "TOOL_IN_PROJECT"];
export type ToolchainProblemCode = (typeof toolchainProblemCodes)[number];
export interface ToolchainProblem {
    code: ToolchainProblemCode;
    field: Field;
    path?: string;
    message: string;
}
export interface PlanEntry {
    phase: 'prepare' | 'dependencyBuild' | 'preflight' | 'setup' | 'ready' | 'teardown' | 'gate';
    id: string;
    kind?: 'check' | 'test';
    /** Каталог запуска относительно корня репозитория (`.` — корень). */
    cwd: string;
    argv: string[];
    report?: string;
    field: Field;
}
export interface ToolEntry {
    name: string;
    /** `path` — из PATH окружения harness; `project` — даёт установленная среда проекта. */
    provider: 'path' | 'project';
    found: boolean;
    version?: string;
    required: {
        version: string;
        source: string;
    }[];
    usedBy: string[];
}
export interface ToolchainReport {
    repositoryId: string;
    root: string;
    configSource?: string;
    plan: PlanEntry[];
    tools: ToolEntry[];
    lockfiles: {
        dir: string;
        files: string[];
        manager?: string;
        selectedBy?: string;
    }[];
    reports: {
        gate: string;
        path: string;
        cwd: string;
    }[];
    ambiguities: {
        field: Field;
        path?: string;
        message: string;
        resolvedBy?: string;
    }[];
    /** Замечания, которые не останавливают запуск (совместимость прежних профилей). */
    warnings: ToolchainProblem[];
    problems: ToolchainProblem[];
}
export interface InspectOptions {
    /** Чем запускаются пробы версий; тест подменяет и считает вызовы. */
    probe?: ToolProbe;
    probeTimeoutMs?: number;
    /** Окружение поиска инструментов; по умолчанию — окружение процесса. */
    env?: NodeJS.ProcessEnv;
    /** Откуда загружена конфигурация (файл политики, binding, профиль). */
    configSource?: string;
    /**
     * Каталоги, исполняемые файлы из которых не запускаются никогда: корни
     * репозиториев политики, каталог состояния с worktrees попыток.
     */
    protectedRoots?: string[];
}
/**
 * Диагностика toolchain одного репозитория политики: какие команды и где
 * исполнятся, какие внешние инструменты и версии им нужны, есть ли lockfiles
 * и не противоречат ли они выбору, существуют ли scripts/tasks/фильтры,
 * каталоги и отчёты. Только чтение файлов и ограниченные по времени пробы
 * версий: ни установки, ни кода проекта, ни новых файлов.
 */
export declare function inspectRepository(repo: Repository, root: string, field: Field, options?: InspectOptions & {
    lifecycle?: ExecutionPolicy['lifecycle'];
    environment?: ExecutionPolicy['environment'];
    workspaceGates?: {
        gate: GatePolicy;
        field: Field;
    }[];
}): Promise<ToolchainReport>;
/** Диагностика всех репозиториев политики; пути — от каталога политики. */
export declare function inspectPolicy(policy: ExecutionPolicy, baseDir: string, options?: InspectOptions): Promise<ToolchainReport[]>;
/** Проблемы диагностики строками для `doctor.problems`. */
export declare const problemLines: (reports: ToolchainReport[]) => string[];
/**
 * Обязательный preflight запуска: та же диагностика, что у `doctor`, но
 * проблема — отказ `NOT_READY` до любой записи состояния и вызова runtime.
 */
export declare function assertToolchainReady(policy: ExecutionPolicy, baseDir: string, options?: InspectOptions): Promise<ToolchainReport[]>;
export {};
