/** Lockfile → менеджер пакетов, которому он принадлежит. */
export declare const lockfiles: {
    readonly 'package-lock.json': "npm";
    readonly 'npm-shrinkwrap.json': "npm";
    readonly 'pnpm-lock.yaml': "pnpm";
    readonly 'yarn.lock': "yarn";
    readonly 'bun.lock': "bun";
    readonly 'bun.lockb': "bun";
};
export type LockManager = (typeof lockfiles)[keyof typeof lockfiles];
export declare class Manifests {
    readonly root: string;
    private cache;
    constructor(root: string);
    /** Путь `rel` относительно корня; `.` — корень. */
    abs(rel: string): string;
    /** Относительный путь каталога; вне корня — undefined. */
    rel(abs: string): string | undefined;
    /** Каталог внутри корня без symlink на пути. */
    isDir(rel: string): boolean;
    isFile(rel: string): boolean;
    private stat;
    /** Текст файла внутри корня (до 4 MiB) или undefined. */
    text(rel: string): string | undefined;
    json(rel: string): Record<string, unknown> | undefined;
    /** Каталог и его предки до корня включительно, от ближнего. */
    ancestors(dir: string): string[];
    /** Ближайший к `dir` каталог (до корня), где есть файл `name`. */
    nearest(dir: string, name: string): string | undefined;
    lockfilesIn(dir: string): string[];
    list(rel: string): string[];
}
export declare const join2: (dir: string, name: string) => string;
/** Скрипты package.json каталога. */
export declare function scriptsOf(m: Manifests, dir: string): Record<string, string> | undefined;
/** `packageManager` из package.json: `pnpm@10.12.3+sha512…` → { name, version }. */
export declare function packageManagerField(m: Manifests, dir: string): {
    name: string;
    version: string;
    raw: string;
} | {
    name: string;
    raw: string;
    version?: undefined;
} | undefined;
/** Пакеты workspace pnpm: `packages:` из pnpm-workspace.yaml (простые шаблоны `dir/*`). */
export declare function workspacePackages(m: Manifests, workspaceRoot: string): {
    dir: string;
    name: string | undefined;
    scripts: Record<string, string>;
}[];
/** Задачи turbo.json (`tasks` v2 либо `pipeline` v1). */
export declare function turboTasks(m: Manifests, dir: string): string[] | undefined;
/** go.mod: директивы `go`, `toolchain` и наличие require. */
export declare function goModule(m: Manifests, dir: string): {
    go: string | undefined;
    toolchain: string | undefined;
    requires: boolean;
} | undefined;
/** Пакеты, закреплённые uv.lock (`name = "…"` записей `[[package]]`). */
export declare function uvLocked(m: Manifests, dir: string): Map<string, string> | undefined;
/**
 * Точная версия зависимости `name` корневого пакета каталога, закреплённая
 * lockfile: `importers['.']` pnpm-lock.yaml либо `packages['node_modules/<name>']`
 * package-lock.json. Нет закрепления — undefined.
 */
export declare function lockedVersion(m: Manifests, dir: string, name: string): string | undefined;
