import type { z } from 'zod';
import type { gateSchema, repositoryPolicySchema } from '../contracts/index.ts';
type Gate = z.input<typeof gateSchema>;
type RepositoryInput = z.input<typeof repositoryPolicySchema>;
/**
 * Рецепты установки зависимостей: точные locked-команды менеджера, каталог —
 * собственным флагом инструмента (шаг `prepare` исполняется в корне
 * worktree). Рецепт не меняет lockfile: несовместимый lockfile — отказ шага.
 */
export declare const installRecipes: {
    readonly npm: (dir: string) => string[];
    readonly pnpm: (dir: string) => string[];
    readonly uv: (dir: string) => string[];
    readonly go: (dir: string) => string[];
};
export type InstallRecipe = keyof typeof installRecipes;
export interface ToolchainComponent {
    /** Каталог компонента в репозитории (`.` — корень); gates исполняются в нём. */
    dir: string;
    install?: InstallRecipe;
    installTimeoutMs?: number;
    /** Gates компонента; `cwd` по умолчанию — каталог компонента. */
    gates: Gate[];
}
/**
 * Описание репозитория политики из компонентов: у каждого свой рецепт
 * установки, каталог и gates; один Git root — одна запись репозитория.
 * Никакого «типа проекта»: Node-компонент на pnpm и Go-компонент — просто два
 * компонента с разными рецептами. Для node-компонента выбор менеджера
 * записывается явно (`toolchain.packageManagers`).
 */
export declare function composeRepository(own: Pick<RepositoryInput, 'id' | 'path' | 'targetRef'> & Partial<RepositoryInput>, components: ToolchainComponent[], tools?: Record<string, string>): RepositoryInput;
export {};
