/** UTF-8 байты строки (сырой текст запроса до разбора JSON). */
export declare const utf8Bytes: (text: string) => number;
/** UTF-8 байты `JSON.stringify(value)`; значение без JSON-представления — 0. */
export declare function jsonBytes(value: unknown): number;
/** Размер JSON и помещается ли он в предел (`bytes <= limit`). */
export declare function checkJsonBytes(value: unknown, limit: number): {
    bytes: number;
    within: boolean;
};
