import { z } from 'zod';
import type { OperationCatalog } from '../contracts/catalog.ts';
/** Операция каталога: описание, признак только чтения, схема входа (и ответа). */
export interface CatalogOperation {
    description: string;
    readOnly: boolean;
    input: z.ZodType;
    output?: z.ZodType;
}
export interface CatalogInput {
    name: string;
    version: string;
    protocolVersion: number;
    maxInputBytes: number;
    maxResultBytes: number;
    /** Порядок ключей — порядок `tools`. */
    operations: Readonly<Record<string, CatalogOperation>>;
}
/**
 * Каталог операций для агента. `inputSchema` — `z.toJSONSchema(input, { io: 'input' })`
 * той копии zod, что у пакета; `outputSchema` — только у операции с `output`.
 * Хост строит свой каталог этой же функцией отдельно от каталога harness.
 */
export declare function operationCatalog(input: CatalogInput): OperationCatalog;
