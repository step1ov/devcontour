import type { OperationCatalog } from '../contracts/catalog.ts';
/** Каталог общих операций установленного harness (CLI `capabilities`). */
export declare const harnessCapabilities: () => OperationCatalog;
