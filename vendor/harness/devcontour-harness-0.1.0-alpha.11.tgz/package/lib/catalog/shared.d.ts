import { z } from 'zod';
import { cliDataSchemas, type CliArgument } from '../contracts/cli.ts';
import type { OperationLimits } from '../contracts/catalog.ts';
/** Версия протокола каталога операций harness. */
export declare const CATALOG_PROTOCOL_VERSION = 1;
/**
 * Пределы транспорта общих операций CLI: UTF-8 байты значений аргументов и
 * конверта ответа. Ответ сверх предела — отказ `RESPONSE_TOO_LARGE`, данные
 * не усекаются.
 */
export declare const cliTransportLimits: {
    readonly maxInputBytes: 100000;
    readonly maxResultBytes: 1048576;
};
/** Общие операции агентского слоя; остальные команды CLI в каталог не входят. */
export declare const sharedOperationNames: readonly ["init", "explain", "plan-request", "plan-check", "capabilities"];
export type SharedOperationName = (typeof sharedOperationNames)[number];
export interface SharedOperation<C extends SharedOperationName = SharedOperationName> {
    /** Экспорт корня пакета с той же операцией. */
    api: string;
    description: string;
    readOnly: boolean;
    input: z.ZodObject;
    output: (typeof cliDataSchemas)[C];
    limits: OperationLimits;
}
/** Схема входа CLI-операции по её аргументам: ключ — имя без `--`. */
export declare function cliInputSchema(args: readonly CliArgument[]): z.ZodObject;
/**
 * Одна декларация общих операций: описание, `readOnly` (= `!writes`), вход и
 * ответ берутся из договора CLI (`cliCommands`, `cliDataSchemas`) — второй
 * копии текста нет. Из неё строятся каталог `capabilities` и граница CLI.
 */
export declare const sharedOperations: {
    readonly [C in SharedOperationName]: SharedOperation<C>;
};
export declare const isSharedOperation: (command: string) => command is SharedOperationName;
