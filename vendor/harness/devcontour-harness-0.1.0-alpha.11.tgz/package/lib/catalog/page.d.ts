/**
 * Формат cursor: `json-base64url` — base64url JSON `{revision, binding, offset}`
 * (страница привязана к ревизии данных и к запросу); `digest-offset` —
 * `<sha256 ревизии>:<offset>` (только ревизия).
 */
export type CursorFormat = 'json-base64url' | 'digest-offset';
/** Мера бюджета: `page` — JSON всей страницы с заголовком; `items` — сумма JSON элементов. */
export type PageMeasure = 'page' | 'items';
interface PageBudget {
    cursor?: string;
    /** Не больше стольких элементов на странице. */
    limit: number;
    /** Предел байт страницы; по умолчанию 65536. */
    maxBytes?: number;
    /** Запас под конверт транспорта; по умолчанию 2048. */
    reserveBytes?: number;
    measure?: PageMeasure;
}
export type PageOptions = PageBudget & ({
    cursorFormat?: 'json-base64url';
    revision: string;
    binding: string;
} | {
    cursorFormat: 'digest-offset';
    revision: string;
    binding?: never;
});
export type Page<T, H extends Record<string, unknown> = Record<never, never>> = Omit<H, 'revision' | 'items' | 'total' | 'hasMore' | 'nextCursor'> & {
    revision: string;
    items: T[];
    total: number;
    hasMore: boolean;
    nextCursor: string | null;
};
/**
 * Страница элементов с cursor. Элементы набираются по порядку, пока страница
 * (или сумма элементов) помещается в `maxBytes − reserveBytes` и их меньше
 * `limit`. Чистая функция: тот же cursor на тех же данных — та же страница.
 *
 * Отказы: нечитаемый cursor — `INVALID_INPUT ['cursor']`; offset вне
 * `[0, items.length]` — `INVALID_INPUT ['cursor','offset']`; cursor другой
 * ревизии/запроса — `REVISION_CONFLICT`; первый элемент страницы не
 * помещается — `RESPONSE_TOO_LARGE` (данные не усекаются).
 */
export declare function pageItems<T, H extends Record<string, unknown> = Record<never, never>>(items: readonly T[], header: H, options: PageOptions): Page<T, H>;
export {};
