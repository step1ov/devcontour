import { z } from 'zod';
/**
 * Самостоятельный проект harness в репозитории пользователя. Каталог
 * `.harness/` хранит политику и рабочие файлы агента; manifest — локальные
 * решения подготовки (абсолютные пути), поэтому он не под Git. Состояние
 * исполнения живёт вне репозитория: worktrees попыток не вкладываются в checkout.
 */
export declare const HARNESS_PROJECT_DIR = ".harness";
export declare const PROJECT_MANIFEST_PATH = ".harness/project.json";
export declare const PROJECT_POLICY_PATH = ".harness/policy.json";
export declare const PROJECT_WORK_DIR = ".harness/work";
export declare const PROJECT_NOTES_DIR = ".harness/work/context/notes";
export declare const projectManifestSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    kind: z.ZodLiteral<"harness-project">;
    manifestVersion: z.ZodLiteral<1>;
    projectId: z.ZodString;
    root: z.ZodString;
    repository: z.ZodObject<{
        id: z.ZodString;
        targetRef: z.ZodString;
    }, z.core.$strict>;
    profile: z.ZodObject<{
        ref: z.ZodString;
        pin: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            source: z.ZodOptional<z.ZodObject<{
                repositoryId: z.ZodString;
                path: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    runtimes: z.ZodObject<{
        writer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
    }, z.core.$strict>;
    paths: z.ZodObject<{
        policy: z.ZodLiteral<".harness/policy.json">;
        work: z.ZodLiteral<".harness/work">;
        notes: z.ZodLiteral<".harness/work/context/notes">;
        state: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export type ProjectManifest = z.infer<typeof projectManifestSchema>;
export declare const fileConflicts: readonly ["symlink", "ancestor-not-directory", "not-regular-file", "content-differs", "outside-root"];
export declare const filePlanEntrySchema: z.ZodObject<{
    path: z.ZodString;
    action: z.ZodEnum<{
        conflict: "conflict";
        create: "create";
        preserve: "preserve";
    }>;
    conflict: z.ZodOptional<z.ZodEnum<{
        symlink: "symlink";
        "ancestor-not-directory": "ancestor-not-directory";
        "not-regular-file": "not-regular-file";
        "content-differs": "content-differs";
        "outside-root": "outside-root";
    }>>;
    conflictPath: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
