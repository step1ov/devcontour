import type { FailureKind } from './execution.ts';
/** Отказ окружения до начала работы: попытка не засчитывается. */
export declare class BlockedError extends Error {
    name: string;
}
/** Отказ с известным классом. Класс ставит тот, кто отказ обнаружил. */
export declare class TaskFailure extends Error {
    readonly kind: FailureKind;
    /**
     * Свойства, с которыми связан отказ: `bound` — объявленные задачей
     * property ID, `unbound` — названные проверкой или ревьюером, но не
     * объявленные (только для разбора, счётчик эпизода они не выбирают).
     */
    readonly properties?: {
        bound: string[];
        unbound: string[];
    } | undefined;
    constructor(kind: FailureKind, message: string, 
    /**
     * Свойства, с которыми связан отказ: `bound` — объявленные задачей
     * property ID, `unbound` — названные проверкой или ревьюером, но не
     * объявленные (только для разбора, счётчик эпизода они не выбирают).
     */
    properties?: {
        bound: string[];
        unbound: string[];
    } | undefined);
}
/**
 * Отпечаток отказа: одинаковые сбои должны совпадать, разные — расходиться.
 *
 * Из сообщения убирается всё, что меняется от попытки к попытке, — SHA, id
 * прогонов, пути с временными каталогами, числа, время. Иначе два одинаковых
 * провала одной проверки выглядели бы как два разных, и предел одинаковых
 * повторов не сработал бы ни разу.
 */
export declare function failureFingerprint(kind: FailureKind, message: string): string;
export { repairPolicy, type RepairRule } from './repair-policy.ts';
