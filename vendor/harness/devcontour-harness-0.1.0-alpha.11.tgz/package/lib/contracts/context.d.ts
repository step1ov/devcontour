import { z } from 'zod';
/**
 * Закреплённый файл контекста вместе с содержимым. Содержимое передаётся
 * в снимке, а не восстанавливается по пути: источник может не быть Git
 * (память, внешний сервис), и движок обязан получить ровно те байты, на
 * которые выдан digest. `digest` — SHA-256 байтов содержимого; движок
 * сверяет его при приёме снимка и при каждом использовании.
 */
export declare const pinnedFileSchema: z.ZodObject<{
    path: z.ZodString;
    digest: z.ZodString;
    bytes: z.ZodNumber;
    content: z.ZodDiscriminatedUnion<[z.ZodObject<{
        encoding: z.ZodLiteral<"utf8">;
        data: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        encoding: z.ZodLiteral<"base64">;
        data: z.ZodString;
    }, z.core.$strict>], "encoding">;
}, z.core.$strict>;
export type PinnedFile = z.infer<typeof pinnedFileSchema>;
/**
 * Источник контекста попытки. `files` вкладываются в запрос исполнителю,
 * `references` только называются, но их содержимое тоже закреплено и входит
 * в digest: изменилась справка — закрепление недействительно.
 *
 * `required: true` — без источника попытка не начинается (отказ окружения,
 * попытка не засчитывается); `false` — дополнительный, его отсутствие
 * записывается в ограничения результата.
 */
export declare const contextSourceEntrySchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodString;
    version: z.ZodString;
    repositoryId: z.ZodOptional<z.ZodString>;
    revision: z.ZodOptional<z.ZodString>;
    required: z.ZodBoolean;
    files: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        digest: z.ZodString;
        bytes: z.ZodNumber;
        content: z.ZodDiscriminatedUnion<[z.ZodObject<{
            encoding: z.ZodLiteral<"utf8">;
            data: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            encoding: z.ZodLiteral<"base64">;
            data: z.ZodString;
        }, z.core.$strict>], "encoding">;
    }, z.core.$strict>>;
    references: z.ZodDefault<z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        digest: z.ZodString;
        bytes: z.ZodNumber;
        content: z.ZodDiscriminatedUnion<[z.ZodObject<{
            encoding: z.ZodLiteral<"utf8">;
            data: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            encoding: z.ZodLiteral<"base64">;
            data: z.ZodString;
        }, z.core.$strict>], "encoding">;
    }, z.core.$strict>>>;
    digest: z.ZodString;
    hostDigest: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ContextSourceEntry = z.infer<typeof contextSourceEntrySchema>;
/** Пределы снимка: файл и сумма содержимого, байт. */
export declare const CONTEXT_LIMITS: {
    readonly fileBytes: number;
    readonly totalBytes: number;
};
export declare const contextSnapshotSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    sources: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodString;
        version: z.ZodString;
        repositoryId: z.ZodOptional<z.ZodString>;
        revision: z.ZodOptional<z.ZodString>;
        required: z.ZodBoolean;
        files: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
            bytes: z.ZodNumber;
            content: z.ZodDiscriminatedUnion<[z.ZodObject<{
                encoding: z.ZodLiteral<"utf8">;
                data: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                encoding: z.ZodLiteral<"base64">;
                data: z.ZodString;
            }, z.core.$strict>], "encoding">;
        }, z.core.$strict>>;
        references: z.ZodDefault<z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            digest: z.ZodString;
            bytes: z.ZodNumber;
            content: z.ZodDiscriminatedUnion<[z.ZodObject<{
                encoding: z.ZodLiteral<"utf8">;
                data: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                encoding: z.ZodLiteral<"base64">;
                data: z.ZodString;
            }, z.core.$strict>], "encoding">;
        }, z.core.$strict>>>;
        digest: z.ZodString;
        hostDigest: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    missing: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        reason: z.ZodString;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type ContextSnapshot = z.infer<typeof contextSnapshotSchema>;
/**
 * Краткая ссылка попытки на закреплённый источник — форма `Run.context`
 * DevContour. Полный снимок хранится отдельно по digest.
 */
export declare const contextPinSchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodString;
    repositoryId: z.ZodString;
    revision: z.ZodString;
    digest: z.ZodString;
}, z.core.$strict>;
export type ContextPin = z.infer<typeof contextPinSchema>;
/** Digest источника: id, версия, ревизия и digests всех файлов и справок по порядку. */
export declare const sourceDigest: (entry: Omit<ContextSourceEntry, "digest">) => string;
export declare const contextDigest: (snapshot: ContextSnapshot) => string;
/**
 * Проверка снимка: digest каждого файла равен SHA-256 его байтов, `bytes`
 * совпадает, digest источника пересчитывается, пределы соблюдены, ID
 * источников и пути внутри источника не повторяются. Возвращает нарушения.
 */
export declare function contextIssues(snapshot: ContextSnapshot): string[];
/** Байты закреплённого файла после проверки digest; несовпадение — исключение. */
export declare function pinnedBytes(file: PinnedFile): Buffer;
