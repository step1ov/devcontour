/**
 * Каноническая сериализация: ключи объектов по порядку, без пробелов,
 * `undefined` опускается. Один и тот же смысл даёт один digest независимо
 * от порядка полей в файле поручения.
 */
export declare function canonicalJson(value: unknown): string;
export declare const sha256: (text: string | Uint8Array) => string;
/** Digest значения: SHA-256 его канонического JSON. */
export declare const digestOf: (value: unknown) => string;
