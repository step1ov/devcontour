/**
 * Версии договоров. Они независимы: смена формата состояния не обязана
 * менять API, а новая версия пакета не меняет формат молча.
 *
 * - `apiVersion` — формат публичных входов/выходов (WorkOrder, RunResult...).
 * - `stateVersion` — формат сохранённого состояния исполнения.
 * - `policyVersion` — формат ExecutionPolicy; входит в digest политики.
 *
 * Пакет читает только перечисленные версии. Неизвестная версия отклоняется
 * до любой мутации состояния и до выдачи claim.
 */
export declare const API_VERSION: "devcontour-harness/v1alpha1";
export declare const SUPPORTED_API_VERSIONS: readonly ["devcontour-harness/v1alpha1"];
export declare const STATE_VERSION: 1;
export declare const SUPPORTED_STATE_VERSIONS: readonly [1];
export declare const POLICY_VERSION: 1;
export declare const SUPPORTED_POLICY_VERSIONS: readonly [1];
