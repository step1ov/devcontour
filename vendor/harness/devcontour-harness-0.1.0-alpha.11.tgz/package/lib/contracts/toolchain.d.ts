import { z } from 'zod';
/**
 * Требования toolchain репозитория — не «тип проекта». Установка зависимостей,
 * команды задач, каталоги и окружение уже выражены шагами `prepare`, gates и
 * `environment`; здесь только то, чего из команд не вывести: какие версии
 * внешних исполняемых файлов проверены и какой менеджер пакетов явно выбран
 * для каталога, где лежат lockfiles нескольких менеджеров. Поле необязательное:
 * политика и профиль без него сохраняют прежний digest.
 */
export declare const toolNameSchema: z.ZodString;
/** `1.12.3` — совпадают названные компоненты версии; `>=1.24` — не ниже. */
export declare const toolVersionSchema: z.ZodString;
/** Каталог репозитория: `.` — корень. */
export declare const toolchainDirSchema: z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>;
export declare const packageManagerSchema: z.ZodEnum<{
    npm: "npm";
    pnpm: "pnpm";
}>;
export type PackageManager = z.infer<typeof packageManagerSchema>;
export declare const toolchainSchema: z.ZodObject<{
    tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
        npm: "npm";
        pnpm: "pnpm";
    }>>>;
}, z.core.$strict>;
export type Toolchain = z.infer<typeof toolchainSchema>;
/** Диагностика toolchain репозитория в ответе `doctor` (см. `src/toolchains`). */
export declare const toolchainReportSchema: z.ZodObject<{
    repositoryId: z.ZodString;
    root: z.ZodString;
    configSource: z.ZodOptional<z.ZodString>;
    plan: z.ZodArray<z.ZodObject<{
        phase: z.ZodEnum<{
            gate: "gate";
            prepare: "prepare";
            dependencyBuild: "dependencyBuild";
            preflight: "preflight";
            setup: "setup";
            ready: "ready";
            teardown: "teardown";
        }>;
        id: z.ZodString;
        kind: z.ZodOptional<z.ZodEnum<{
            check: "check";
            test: "test";
        }>>;
        cwd: z.ZodString;
        argv: z.ZodArray<z.ZodString>;
        report: z.ZodOptional<z.ZodString>;
        field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
    }, z.core.$strict>>;
    tools: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        provider: z.ZodEnum<{
            path: "path";
            project: "project";
        }>;
        found: z.ZodBoolean;
        version: z.ZodOptional<z.ZodString>;
        required: z.ZodArray<z.ZodObject<{
            version: z.ZodString;
            source: z.ZodString;
        }, z.core.$strict>>;
        usedBy: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    lockfiles: z.ZodArray<z.ZodObject<{
        dir: z.ZodString;
        files: z.ZodArray<z.ZodString>;
        manager: z.ZodOptional<z.ZodString>;
        selectedBy: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    reports: z.ZodArray<z.ZodObject<{
        gate: z.ZodString;
        path: z.ZodString;
        cwd: z.ZodString;
    }, z.core.$strict>>;
    ambiguities: z.ZodArray<z.ZodObject<{
        field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        path: z.ZodOptional<z.ZodString>;
        message: z.ZodString;
        resolvedBy: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    problems: z.ZodArray<z.ZodObject<{
        code: z.ZodString;
        field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        path: z.ZodOptional<z.ZodString>;
        message: z.ZodString;
    }, z.core.$strict>>;
    warnings: z.ZodArray<z.ZodObject<{
        code: z.ZodString;
        field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        path: z.ZodOptional<z.ZodString>;
        message: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
