import { z } from 'zod';
/** Пределы транспорта операции: UTF-8 байты JSON входа и ответа. */
export interface OperationLimits {
    maxInputBytes: number;
    maxResultBytes: number;
}
/** Запись каталога: операция, признак только чтения и JSON Schema входа (и ответа). */
export declare const catalogToolSchema: z.ZodObject<{
    name: z.ZodString;
    description: z.ZodString;
    readOnly: z.ZodBoolean;
    inputSchema: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    outputSchema: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strict>;
/** Каталог операций агенту; порядок ключей нормативен (байты ответа хоста). */
export declare const operationCatalogSchema: z.ZodObject<{
    name: z.ZodString;
    version: z.ZodString;
    protocolVersion: z.ZodNumber;
    maxInputBytes: z.ZodNumber;
    maxResultBytes: z.ZodNumber;
    tools: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        description: z.ZodString;
        readOnly: z.ZodBoolean;
        inputSchema: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        outputSchema: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CatalogTool = z.infer<typeof catalogToolSchema>;
export type OperationCatalog = z.infer<typeof operationCatalogSchema>;
