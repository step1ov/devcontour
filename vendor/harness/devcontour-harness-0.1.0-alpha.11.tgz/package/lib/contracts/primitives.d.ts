import { z } from 'zod';
/** Идентификатор сущности harness: поручения, роли, gate, репозитория. */
export declare const idSchema: z.ZodString;
/** Ссылка на gate или на именованную группу gates (`@имя`). */
export declare const gateRefSchema: z.ZodString;
export declare const roleIdSchema: z.ZodString;
/** Полный SHA объекта Git (SHA-1 или SHA-256). */
export declare const gitShaSchema: z.ZodString;
/** SHA-256 содержимого в hex. */
export declare const digestSchema: z.ZodString;
export declare const isoTimeSchema: z.ZodISODateTime;
/**
 * Полное имя ветки `refs/heads/<имя>` по правилам `git check-ref-format`:
 * компоненты без ведущей точки и суффикса `.lock`, без `..`, `//`, `@{`,
 * управляющих символов, пробела и `~^:?*[\`, имя не кончается `/` или `.`.
 * Правило выражено одним регулярным выражением, чтобы JSON Schema
 * проверяла то же, что Zod.
 */
export declare const targetRefPattern = "^refs/heads/(?!.*(?:\\.\\.|//|@\\{|\\.lock(?:/|$)|/\\.|[.]$|/$))(?!\\.)[^\\x00-\\x20\\x7f~^:?*\\[\\\\]{1,200}$";
export declare const targetRefSchema: z.ZodString;
/**
 * Относительный путь внутри репозитория: без glob, `.`/`..`, абсолютных
 * префиксов, обратных слешей, `:` и NUL. Та же форма, что у области записи
 * DevContour: сохранённые поручения читаются без преобразования. Правило —
 * регулярное выражение, поэтому JSON Schema его не теряет.
 */
export declare const relativePathPattern = "^(?!/)(?!.*[\\\\:*?\\[\\]\\x00])(?!(?:.*/)?\\.{1,2}(?:/|$))(?=.{1,500}$).+$";
export declare const relativePathSchema: z.ZodString;
/** Встроенные runtime. `fixture` — управляемые ответы для тестов и демо, не живая модель. */
export declare const runtimeNames: readonly ["codex", "claude", "fixture"];
export declare const runtimeNameSchema: z.ZodEnum<{
    codex: "codex";
    claude: "claude";
    fixture: "fixture";
}>;
export type RuntimeName = (typeof runtimeNames)[number];
/**
 * Автор проверяемого предложения (плана, контракта, кода). Кроме runtime
 * harness, автором может быть `external` — человек или инструмент вне
 * harness; его вендор не совпадает ни с одним runtime.
 */
export declare const authorSchema: z.ZodEnum<{
    codex: "codex";
    claude: "claude";
    fixture: "fixture";
    external: "external";
}>;
export type Author = z.infer<typeof authorSchema>;
/**
 * Вендор runtime. Политика ревью сравнивает вендоров, а не имена runtime:
 * одинаковый вендор у автора и reviewer допустим только явным разрешением.
 */
export declare const vendorOf: (runtime: Author) => "fixture" | "external" | "openai" | "anthropic";
export type Vendor = ReturnType<typeof vendorOf>;
/**
 * Текст без пробельных символов по краям. Zod `.trim()` нормализует значение,
 * а JSON Schema нормализовать не умеет — и тогда «   » проходило бы одну схему
 * и не проходило другую. Поэтому harness не нормализует, а требует уже
 * обрезанный текст: правило выражено регулярным выражением в обеих схемах.
 * Адаптер хоста передаёт обрезанные значения.
 */
export declare const trimmedTextPattern = "^\\S(?:[\\s\\S]*\\S)?$";
export declare const trimmedText: (min: number, max: number) => z.ZodString;
