import { type ExecutionStore } from '../contracts/index.ts';
/**
 * Общий набор проверок договора `ExecutionStore`. Его проходят standalone
 * SQLite и адаптер любого хоста: `open` открывает хранилище в каталоге,
 * повторный вызов с тем же каталогом — то же хранилище другим экземпляром.
 * Регистрация тестов — через переданную `test` (node:test).
 */
export declare function executionStoreContract(name: string, test: (title: string, fn: () => void | Promise<void>) => unknown, open: (dir: string) => ExecutionStore, tempDir: () => string): void;
