import type { z } from 'zod';
import { type ExecutionPolicy, type initDataSchema, type ProfilePin, type ProjectManifest } from '../contracts/index.ts';
import { type ToolchainReport } from '../toolchains/inspect.ts';
import type { ToolProbe } from '../toolchains/probe.ts';
import { type FileIntent, type FilePlan, type FilePlanEntry } from '../setup/files.ts';
export type InitData = z.infer<typeof initDataSchema>;
/** `p-` + первые 16 hex sha256 от realpath корня: тот же проект — тот же id. */
export declare function projectIdOf(root: string): string;
/**
 * Каталог состояния по умолчанию — вне репозитория:
 * `<HARNESS_STATE_HOME | $XDG_STATE_HOME/devcontour-harness | ~/.local/state/devcontour-harness>/projects/<projectId>`.
 */
export declare function defaultStateDir(projectId: string, env?: NodeJS.ProcessEnv): string;
/** Manifest проекта; отсутствует — undefined, невалиден — INVALID_INPUT. */
export declare function readProjectManifest(repository: string): Promise<ProjectManifest | undefined>;
export interface InitOptions {
    repository: string;
    profile?: string;
    writer?: 'claude' | 'codex';
    state?: string;
    plan?: boolean;
    env?: NodeJS.ProcessEnv;
    probe?: ToolProbe;
}
export interface InitPlanned {
    root: string;
    status: 'new' | 'partial' | 'complete';
    manifest: ProjectManifest;
    intents: FileIntent[];
    plan: FilePlan;
    /**
     * Конфликты рабочих каталогов `.harness/work…`, куда агент пишет графы и
     * заметки: init их не создаёт, но не выдаёт агенту путь через symlink.
     */
    workConflicts: FilePlanEntry[];
    policy: ExecutionPolicy;
    profile: ProfilePin;
    shadowed: string[];
    toolchain: ToolchainReport[];
}
/**
 * План подготовки: все отказы по существу (1–7) до записи; конфликты плана
 * и проблемы toolchain — данными, их превращает в отказ `initProject`.
 */
export declare function planProject(options: InitOptions): Promise<InitPlanned>;
/**
 * `harness init`: план или create-only запись `.harness/`: manifest решений до
 * политики, политика последней.
 * Без `plan` конфликты (8) и проблемы toolchain (9) — отказ до любой записи.
 */
export declare function initProject(options: InitOptions): Promise<InitData>;
export declare function initText(data: InitData): string;
