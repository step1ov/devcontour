import type { z } from 'zod';
import { executionPolicySchema, type ResolvedProfile } from '../contracts/index.ts';
export type DetectedProfile = {
    id: 'npm-ci' | 'pnpm-frozen';
    lockfile: string;
} | {
    problem: 'stack-ambiguous' | 'stack-unsupported';
    files: string[];
};
/** ID репозитория и target ref проекта: одинаковы у каждого standalone-проекта. */
export declare const PROJECT_REPOSITORY_ID = "app";
export declare const PROJECT_TARGET_REF = "refs/heads/harness/accepted";
/**
 * Профиль стека по lockfile корня: только `package-lock.json` — `npm-ci`,
 * только `pnpm-lock.yaml` — `pnpm-frozen`; оба — неоднозначно, ни одного —
 * стек не поддерживается. Угадывания нет: без lockfile нужен явный `--profile`.
 */
export declare function detectProfile(root: string): DetectedProfile;
export interface GeneratedPolicy {
    input: z.input<typeof executionPolicySchema>;
    text: string;
    shadowed: string[];
}
/**
 * Политика проекта из профиля: пользователь JSON не пишет. Репозиторий —
 * корень над `.harness/` (`path: '..'`), target ref — `harness/accepted`,
 * `.harness/` защищён от записи исполнителем. Версия менеджера пакетов из
 * `package.json#packageManager` (того же менеджера, что выбирает профиль)
 * заменяет pin профиля — это явное значение проекта, оно видно в `shadowed`.
 * Роли — профиля, иначе одна `developer` с выбранным writer; reviewer —
 * другой вендор. Approval, isolation и бюджеты — умолчания схемы.
 */
export declare function generatePolicy(input: {
    profile: ResolvedProfile;
    writer: 'claude' | 'codex';
    packageManager?: {
        name: string;
        version?: string;
    };
}): GeneratedPolicy;
