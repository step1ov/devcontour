import { type Actor, type FailureKind, type NextAction, type WorkStatus } from './enums.ts';
export interface ChainWork {
    id: string;
    status: WorkStatus;
    dependsOn: readonly string[];
    attempt: number;
    activeRunId?: string;
    hold?: {
        operation: string;
        reason: string;
    };
    budgetBlock?: {
        reason: string;
    };
    failureKind?: FailureKind;
}
export declare const chainRootCodes: readonly ["failed", "failed-exhausted", "draft", "cancelled", "held", "budget-blocked", "attempts-exhausted"];
export type ChainRootCode = (typeof chainRootCodes)[number];
export interface ChainRoot {
    workId: string;
    code: ChainRootCode;
    waiting: number;
    actor: Actor;
    action: NextAction;
    detail?: string;
    failureKind?: FailureKind;
}
/**
 * Корневые причины, из-за которых ждут готовые работы (OP-DIAG-01).
 * Корень — незавершённая предшественница, которая сама не выполняется:
 * упала, не утверждена, удержана, отменена или упёрлась в бюджет. Каждый
 * ждущий считается у корня один раз, даже если доходит до него по ромбу.
 * Порядок результата — порядок первого обнаружения корня.
 */
export declare function chainRoots(works: ChainWork[], maxAttempts?: number): ChainRoot[];
