export type { FailureKind, PauseReason, WorkStatus } from '../contracts/execution.ts';
/** Кто действует: ведущий агент, человек, штатный исполнитель; null — никто. */
export declare const actors: readonly ["controller", "lead", "user"];
export type Actor = (typeof actors)[number] | null;
export declare const nextActions: readonly ["none", "wait", "review-plan", "retry", "diagnose-failure", "reset-attempts", "raise-budget", "replan-dependents", "recovery-decision", "user-decision", "resume-queue", "fix-environment", "fix-access"];
export type NextAction = (typeof nextActions)[number];
export declare const activeStatuses: readonly ["running", "verifying", "reviewing", "integrating"];
