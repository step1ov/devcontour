import type { PropertyRecovery } from '../contracts/execution.ts';
import { type Actor, type NextAction, type WorkStatus } from './enums.ts';
export declare const nextSteps: readonly ["accepted", "cancelled", "recovery-awaiting-lead", "recovery-analyzing", "recovery-applying", "recovery-retry-allowed", "recovery-retrying", "recovery-awaiting-user", "recovery-stopped", "corpus-adoption", "held", "plan-review", "attempt-running", "retry-within-budget", "attempts-exhausted", "awaiting-claim"];
export type NextStep = (typeof nextSteps)[number];
export interface NextInput {
    status: WorkStatus;
    attempt: number;
    maxAttempts: number;
    hold?: {
        operation: string;
    };
    recovery?: Pick<PropertyRecovery, 'status' | 'property' | 'reason' | 'decision'>;
    waitingAdoption?: boolean;
}
export interface NextView {
    actor: Actor;
    action: NextAction;
    step: NextStep;
    property?: string;
    detail?: string;
}
/**
 * Следующий шаг по работе и кто его делает (OP-DIAG-03). Порядок веток —
 * прежний: итог, эпизод восстановления, смена корпуса, удержание, план,
 * идущая попытка, сбой, ожидание выдачи. Закрытый эпизод (`closed`) идёт
 * дальше по веткам.
 */
export declare function nextAction(input: NextInput): NextView;
