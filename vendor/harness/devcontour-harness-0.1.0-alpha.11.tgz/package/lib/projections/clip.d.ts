export declare const CLIP_SHORT = 300;
export declare const CLIP_DIAGNOSTIC = 2000;
/** Строка длиннее `n` code units обрезается до `n` и получает «…». */
export declare function clipText(text: string | undefined, n?: number): string | undefined;
/** Каждая строка на любой глубине — через clipText; ключи `omitKeys` удаляются. */
export declare function clipDeep<T>(value: T, n?: number, omitKeys?: readonly string[]): T;
