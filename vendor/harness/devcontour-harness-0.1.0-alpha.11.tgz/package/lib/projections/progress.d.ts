import type { WorkStatus } from './enums.ts';
export declare const progressReasons: readonly ["plan-review-required", "attempts-exhausted", "failure-requires-diagnosis", "dependencies-incomplete", "queue-paused", "workers-busy"];
export type ProgressReason = (typeof progressReasons)[number];
export interface ProgressInput {
    work: {
        status: WorkStatus;
        attempt: number;
        dependsOn: readonly string[];
    };
    statusOf: (id: string) => WorkStatus | undefined;
    maxAttempts: number;
    paused: boolean;
    activeRuns: number;
    concurrency: number;
    hostReasons?: readonly string[];
}
export interface ProgressView {
    dependencies: string[];
    reasons: ProgressReason[];
    eligible: boolean;
}
/**
 * Почему работа сейчас не выдаётся (OP-DIAG-02): общие ветви. Продуктовые
 * причины хоста приходят в `hostReasons` и влияют только на `eligible`;
 * их место в итоговом перечне определяет хост.
 */
export declare function workProgress(input: ProgressInput): ProgressView;
