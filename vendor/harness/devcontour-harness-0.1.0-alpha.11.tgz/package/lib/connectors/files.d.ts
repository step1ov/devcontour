import { type ContextSnapshot, type ContextSource, type DeliveryOutcome, type Prerequisite, type ResultSink, type RunResult, type WorkGraph, type WorkSource } from '../contracts/index.ts';
/**
 * Источник поручений из файла `WorkGraph`. Редакция — `source.revision`
 * графа; повторное чтение той же редакции даёт тот же граф. Внешним
 * receipts файловый источник не доверяет.
 */
export declare class FileWorkSource implements WorkSource {
    readonly id = "files";
    fetch(path: string): Promise<{
        graph: {
            apiVersion: "devcontour-harness/v1alpha1";
            id: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            orders: {
                apiVersion: "devcontour-harness/v1alpha1";
                id: string;
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                title: string;
                goal: string;
                acceptance: string[];
                role: string;
                repositoryId: string;
                relatedRepositories: string[];
                writeScope: string[];
                dependsOn: string[];
                requirements: {
                    id: string;
                    source: string;
                    digest: string;
                    text: string;
                    gate: string;
                    scenario: string;
                    testId?: string | undefined;
                }[];
                contracts: {
                    id: string;
                    digest: string;
                }[];
                context: string[];
                gates?: string[] | undefined;
                consumers?: {
                    repositoryId: string;
                    gates: string[];
                }[] | undefined;
                properties?: string[] | undefined;
                resources?: string[] | undefined;
            }[];
            prerequisites: {
                id: string;
                repositoryId: string;
                resultSha: string;
                receipt: {
                    kind: "engine";
                    runId: string;
                } | {
                    kind: "trusted";
                    issuer: string;
                    digest: string;
                };
            }[];
        };
        source: {
            connector: string;
            ref: string;
            revision: string;
        };
    }>;
    revision(path: string): Promise<string | undefined>;
    trusts(prerequisite: Prerequisite): Promise<boolean>;
}
/**
 * Контекст из каталога: источник `<id>` — каталог `<dir>/<id>`, его файлы
 * вкладываются содержимым и закрепляются SHA-256. Каталог `references/`
 * внутри источника — справки: закреплены, но не вкладываются в запрос.
 * Отсутствующий каталог обязательного источника — отказ, а не пустой
 * контекст.
 */
export declare class FileContextSource implements ContextSource {
    readonly dir: string;
    readonly id = "files";
    constructor(dir: string);
    snapshot(ids: string[]): Promise<ContextSnapshot>;
}
/**
 * Получатель результата — каталог: `<dir>/<workId>.json`. Доставка
 * идемпотентна по ключу: тот же ключ — та же запись, без второй. Если
 * источник уже в другой редакции, чем та, к которой относится результат,
 * результат не закрывает её: `conflict`.
 */
export declare class FileResultSink implements ResultSink {
    readonly dir: string;
    readonly currentRevision: (result: RunResult) => Promise<string | undefined>;
    readonly id = "files";
    constructor(dir: string, currentRevision: (result: RunResult) => Promise<string | undefined>);
    deliver({ key, result }: {
        key: string;
        result: RunResult;
    }): Promise<DeliveryOutcome>;
}
export type { WorkGraph };
