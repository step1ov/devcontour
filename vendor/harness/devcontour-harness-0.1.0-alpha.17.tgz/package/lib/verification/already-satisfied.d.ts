import type { AlreadySatisfied, ContractDocument, EvidenceRecord, GatePolicy } from '../contracts/index.ts';
/** Gates договоров проверки поручения. */
export declare const contractCheckGates: (contracts: ContractDocument[]) => string[];
/**
 * Механическое основание считать работу поручения уже сделанной без изменений.
 * `contract` — договор проверки поручения: его gates в области задачи, и
 * reviewer на них сослался. `dependency` — зависимость поручения своим
 * кандидатом (`sha`) изменила файлы его области записи (`paths`): работу
 * сделала она. Записывает controller, а не reviewer.
 */
export type AlreadySatisfiedBasis = NonNullable<NonNullable<EvidenceRecord['alreadySatisfied']>['basis']>;
declare const within: (path: string, prefixes: string[]) => boolean;
export interface AlreadySatisfiedInput {
    /** Gates области задачи (исполненные попыткой). */
    scope: Pick<GatePolicy, 'id' | 'kind'>[];
    /** Gates договоров проверки поручения (все, а не только в области). */
    contractGates: string[];
    writeScope: string[];
    dependsOn: string[];
    claim: AlreadySatisfied | undefined;
    /** Основание по зависимости, найденное controller (или записанное им). */
    dependency?: Extract<AlreadySatisfiedBasis, {
        kind: 'dependency';
    }>;
}
export type AlreadySatisfiedVerdict = {
    ok: true;
    basis: AlreadySatisfiedBasis;
} | {
    ok: false;
    kind: 'empty-result' | 'needs-lead';
    problem: string;
};
/**
 * Правило «приёмка уже выполнена» — одно для ревью попытки и для
 * `engine.finish`. Подтверждение reviewer необходимо, но не достаточно:
 * зелёный общий gate на базе не доказывает, что новая работа есть (её тестов
 * ещё нет). Достаточно одного из механических оснований: договор проверки
 * поручения, все gates которого в области задачи и названы reviewer, или
 * зависимость, изменившая область записи поручения. Без основания — решение
 * ведущего (`needs-lead`), а не `done`.
 */
export declare function alreadySatisfiedVerdict(input: AlreadySatisfiedInput): AlreadySatisfiedVerdict;
export { within as withinWriteScope };
