import { type ReproductionRecord, type AttemptState, type Author, type CallRecord, type ContractDocument, type EvidenceRecord, type ExecutionHost, type ExecutionPolicy, type ExecutionTransaction, type ExecutionView, type FailureKind, type GraphState, type JointVerification, type JointVerificationState, type NotPromise, type Prerequisite, type PropertyRecovery, type ReviewRecord, type TechnicalApproval, type TransactionKind, type WorkGraph, type WorkState } from '../contracts/index.ts';
import { type BudgetContext, type CallMeta } from './budget.ts';
/** Префикс причины неудавшегося продления: первая причина не затирается следствиями. */
export declare const HEARTBEAT_FAILED = "\u041F\u0440\u043E\u0434\u043B\u0435\u043D\u0438\u0435 \u0432\u043B\u0430\u0434\u0435\u043D\u0438\u044F \u043D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C";
export interface EngineOptions {
    host: ExecutionHost;
    policy: ExecutionPolicy;
    /** Версия движка в попытках; по умолчанию — версия пакета. */
    version?: string;
    now?: () => number;
    id?: () => string;
    /**
     * Источник политики не менялся с её загрузки: `undefined` — да, иначе
     * причина. Без источника (политика передана объектом) право записать свою
     * политику как применённую ограничено остальными условиями.
     */
    provenance?: () => string | undefined;
    /**
     * Тождество применённой политики по формуле хоста — digest (64 hex),
     * например, файла конфигурации, из которого хост строит политику. По умолчанию —
     * `policyDigest(policy)`. Им сравниваются применённая и загруженная
     * политика в барьере и reconfigure; изменение политики в памяти после
     * создания движка проверяется по-прежнему по её содержимому.
     */
    policyIdentity?: string;
    /**
     * Записывать политику процесса применённой при получении роли controller
     * (по умолчанию — да). Хост, который записывает применённую политику сам
     * при запуске своего планировщика, выключает это: прямая выдача попытки
     * без запуска очереди тогда не меняет применённую политику.
     */
    recordPolicyOnLead?: boolean;
}
export type Phase = 'running' | 'verifying' | 'reviewing' | 'integrating';
/** Поручение исчерпало предел незасчитанных отказов: повтор — только со сбросом. */
export declare const neutralExhausted: (w: Pick<WorkState, "neutralFailures">) => boolean;
export declare class Engine {
    readonly host: ExecutionHost;
    readonly policy: ExecutionPolicy;
    readonly version: string;
    private readonly now;
    private readonly id;
    /** Digest политики процесса на момент создания движка. */
    readonly loadedPolicy: string;
    /** Содержимое политики при создании движка: изменение в памяти — отказ применения. */
    private readonly loadedContent;
    /** Поколение применённой политики, которое процесс застал при запуске. */
    private readonly observedGeneration;
    private readonly provenance;
    /** Владелец роли controller, под которым этот процесс её получил. */
    private ownLeader?;
    private readonly recordOnLead;
    constructor(options: EngineOptions);
    /** Часы движка: по ним считаются сроки владения. */
    clock(): number;
    /** Версия проверок поручения: формула хоста, если он её задал, иначе harness. */
    private checksOf;
    /**
     * Основание эпизода разбора по свойству: формула хоста, если он её задал,
     * иначе harness. Хост с принятой историей держит свою — ею подписаны его
     * прежние эпизоды и попытки, и они не закрываются как «новое основание».
     */
    episodeOf(work: WorkState, view: ExecutionView): string;
    private tx;
    private repository;
    read<T>(fn: (view: ExecutionView) => NotPromise<T>): T;
    /**
     * Регистрация графа. Повтор той же редакции источника с тем же digest —
     * продолжение прежней работы; другой digest той же редакции или того же
     * ID графа — `REVISION_CONFLICT`. Предпосылки должны быть подтверждены:
     * `engine` — успешной попыткой этого хранилища с тем же result SHA,
     * `trusted` — решением источника (`trusted`), переданным вызывающим вместе
     * с проверкой доступности SHA в target ref (`reachable`).
     */
    register(graph: WorkGraph, prerequisites: {
        trusted: (p: Prerequisite) => boolean;
        reachable: (p: Prerequisite) => boolean;
    }): {
        graph: GraphState;
        resumed: boolean;
        replaced?: boolean;
    };
    /** Раунд технического ревью плана или контракта сохраняется в истории предмета. */
    /**
     * `document` — документ контракта, который ревью рассматривало: он
     * сохраняется по своему digest, и из него движок берёт договор проверки.
     */
    /**
     * `historyRounds` — раунды предмета, проведённые хостом до harness
     * (`TechnicalReviewInput.history`): первый раунд движка следует за ними, и
     * дальше нумерация идёт подряд от него.
     */
    recordReview(record: ReviewRecord, document?: ContractDocument, historyRounds?: number): {
        id: string;
        kind: "plan" | "contract";
        subject: string;
        digest: string;
        round: number;
        at: string;
        approved: boolean;
        summary: string;
        authorRuntime: "codex" | "claude" | "fixture" | "external";
        reviewerRuntime: "codex" | "claude" | "fixture";
        sameVendor: boolean;
        findings: {
            id: string;
            severity: "blocking" | "note";
            message: string;
            status: "open" | "closed" | "withdrawn";
            openedIn: number;
            changedIn: number;
            rule?: string | undefined;
            path?: string | null | undefined;
            line?: number | null | undefined;
            basis?: string | undefined;
        }[];
        artifact: string;
        reviewerModel?: string | undefined;
        reviewerBinding?: string | undefined;
        contextDigest?: string | undefined;
    };
    reviews(kind: 'plan' | 'contract', subject: string): ReviewRecord[];
    /**
     * Digest назначения reviewer вида `kind` для автора по текущей политике:
     * runtime, модель, effort, содержимое профиля и правило вендора. Раунд ревью
     * подтверждает предмет только при том же назначении.
     */
    reviewerBinding(kind: 'plan' | 'contract' | 'code', author: Author): string | undefined;
    /**
     * Контракты поручения: последний раунд ревью каждого контракта — его digest,
     * одобрен, при текущем назначении reviewer; у хоста с портом `contracts` —
     * редакция этого digest согласована хостом. Иначе поручение не выдаётся и не
     * принимается.
     */
    contractBlocker(work: WorkState, view: ExecutionView): string | undefined;
    /**
     * Согласование графа. Привязано к digest проверенного предложения: в
     * режиме `agent` нужен одобренный последний раунд ревью этого digest, в
     * режиме `operator` — проведённое ревью этого digest и решение оператора.
     * Другого способа сделать поручения готовыми к выдаче нет.
     */
    approve(graphId: string, actor: TechnicalApproval['actor'], options?: {
        /**
         * Связать согласование со снимком контекста последнего раунда ревью
         * плана: другой снимок при том же графе — новое согласование.
         */
        bindContext?: boolean;
    }): {
        graph: {
            id: string;
            digest: string;
            graph: {
                apiVersion: "devcontour-harness/v1alpha1";
                id: string;
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                orders: {
                    apiVersion: "devcontour-harness/v1alpha1";
                    id: string;
                    source: {
                        connector: string;
                        ref: string;
                        revision: string;
                    };
                    title: string;
                    goal: string;
                    acceptance: string[];
                    role: string;
                    repositoryId: string;
                    relatedRepositories: string[];
                    writeScope: string[];
                    dependsOn: string[];
                    requirements: {
                        id: string;
                        source: string;
                        digest: string;
                        text: string;
                        gate: string;
                        scenario: string;
                        testId?: string | undefined;
                    }[];
                    contracts: {
                        id: string;
                        digest: string;
                    }[];
                    context: string[];
                    gates?: string[] | undefined;
                    consumers?: {
                        repositoryId: string;
                        gates: string[];
                    }[] | undefined;
                    properties?: string[] | undefined;
                    resources?: string[] | undefined;
                }[];
                prerequisites: {
                    id: string;
                    repositoryId: string;
                    resultSha: string;
                    receipt: {
                        kind: "engine";
                        runId: string;
                    } | {
                        kind: "trusted";
                        issuer: string;
                        digest: string;
                    };
                }[];
            };
            policyDigest: string;
            registeredAt: string;
            approval?: {
                actor: "agent" | "operator";
                at: string;
                authorRuntime?: "codex" | "claude" | "fixture" | undefined;
                reviewerRuntime?: "codex" | "claude" | "fixture" | undefined;
                artifact?: string | undefined;
                digest?: string | undefined;
                context?: {
                    digest: string | null;
                } | undefined;
            } | undefined;
        };
        changed: boolean;
    };
    /**
     * Роль принадлежит этому процессу: тот же владелец и та же версия движка
     * (роль прежней версии под тем же именем держит другой процесс); живая,
     * если не `expired`.
     */
    private mine;
    /** Захват или продление роли единственного controller. */
    lead(owner: string): boolean;
    release(owner: string): boolean;
    /**
     * Пауза оператора или штатной остановки: новые claims запрещены (семантика
     * DevContour `pause`). Штатная остановка поверх существующей паузы её не
     * подменяет, кроме паузы операции reconfigure. Пауза оператора — решение
     * человека: она заменяет любую паузу, и классы отказов прежней паузы с ней
     * не переживают.
     */
    pause(reason: 'operator' | 'shutdown'): {
        control: {
            paused: boolean;
            pauseReason?: "runtime" | "operator" | "shutdown" | "base-check" | "reconfigure" | undefined;
            pausedAt?: string | undefined;
            pauseOperation?: string | undefined;
            pauseFailures?: ("gate" | "unknown" | "review" | "environment" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead")[] | undefined;
            waits?: {
                kind: "base-check" | "context-lock";
                detail: string;
                at: string;
                operation?: string | undefined;
            }[] | undefined;
            appliedPolicy?: {
                digest: string;
                at: string;
                by: string;
                generation?: number | undefined;
            } | undefined;
            reconfigure?: {
                operation: string;
                digest: string;
                requestedAt: string;
                appliedAt?: string | undefined;
                appliedBy?: string | undefined;
                error?: string | undefined;
            } | undefined;
        };
        changed: boolean;
    };
    /**
     * Снять паузу — решение человека (семантика DevContour `pause(false)`):
     * снимает паузу оператора, штатной остановки и отказа runtime вместе с её
     * классами отказов. Паузу операции reconfigure снимает только сама
     * операция: `PAUSED`.
     */
    resume(): {
        control: {
            paused: boolean;
            pauseReason?: "runtime" | "operator" | "shutdown" | "base-check" | "reconfigure" | undefined;
            pausedAt?: string | undefined;
            pauseOperation?: string | undefined;
            pauseFailures?: ("gate" | "unknown" | "review" | "environment" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead")[] | undefined;
            waits?: {
                kind: "base-check" | "context-lock";
                detail: string;
                at: string;
                operation?: string | undefined;
            }[] | undefined;
            appliedPolicy?: {
                digest: string;
                at: string;
                by: string;
                generation?: number | undefined;
            } | undefined;
            reconfigure?: {
                operation: string;
                digest: string;
                requestedAt: string;
                appliedAt?: string | undefined;
                appliedBy?: string | undefined;
                error?: string | undefined;
            } | undefined;
        };
        changed: boolean;
    };
    /** Снять паузу отказа после устранения причины: только названные классы. */
    clearFailure(kinds: FailureKind[]): {
        paused: boolean;
        pauseReason?: "runtime" | "operator" | "shutdown" | "base-check" | "reconfigure" | undefined;
        pausedAt?: string | undefined;
        pauseOperation?: string | undefined;
        pauseFailures?: ("gate" | "unknown" | "review" | "environment" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead")[] | undefined;
        waits?: {
            kind: "base-check" | "context-lock";
            detail: string;
            at: string;
            operation?: string | undefined;
        }[] | undefined;
        appliedPolicy?: {
            digest: string;
            at: string;
            by: string;
            generation?: number | undefined;
        } | undefined;
        reconfigure?: {
            operation: string;
            digest: string;
            requestedAt: string;
            appliedAt?: string | undefined;
            appliedBy?: string | undefined;
            error?: string | undefined;
        } | undefined;
    };
    /** Правила и области бюджетов: политика движка и группы хоста. */
    budgetContext(): BudgetContext;
    /**
     * Бюджетное удержание готовых поручений. Бюджеты считаются по сохранённым
     * записям вызовов: сброс попыток и перезапуск их не уменьшают. Удержанное
     * поручение несёт причину, пока бюджет не позволит снова; выключенные
     * бюджеты удержание снимают.
     */
    private budgetBlocks;
    /**
     * Начало вызова модели: атрибуция на момент вызова и проверка бюджетов — в
     * одной транзакции с регистрацией идущего вызова. Превышенный или
     * неопределённый бюджет — отказ `budget` до вызова, без записи; два процесса
     * не проходят проверку оба, не видя друг друга. Процесс не с применённой
     * политикой — отказ `APPROVAL_STALE` до вызова.
     */
    beginCall(record: CallRecord, meta: CallMeta): CallRecord;
    /** Ход или итог вызова: запись заменяется целиком. */
    saveCall(record: CallRecord): void;
    /**
     * Закрывает записи вызовов, чей процесс умер, исходом `abandoned`. Запись
     * без процесса закрывается, когда её попытка уже не активна, а без попытки —
     * спустя два предела времени вызова. Под транзакцией запись перечитывается:
     * вызов мог завершиться между сканированием и закрытием, и его исход и
     * стоимость не затираются устаревшим снимком.
     */
    abandonCalls(at?: number): string[];
    /**
     * Закрепляет атрибуцию прежних записей вызовов (без закреплённых поручения и
     * группы) по текущему составу — до того, как новая редакция графа его
     * изменит: иначе перенос поручения снял бы или разделил учтённый расход
     * группы. Уже закреплённое не меняется; запись перечитывается под
     * транзакцией.
     */
    pinLegacyCalls(): number;
    /** Обзор бюджетов для статуса; `undefined` — бюджеты не заданы. */
    budgets(): {
        onUnknown: "stop" | "continue";
        budgets: {
            reason?: string | undefined;
            scope: import("./budget.ts").BudgetScope;
            state: "exceeded" | "undetermined" | "within";
            limit: {
                usd?: number;
                timeMs?: number;
            };
            reportedUsd: number;
            estimatedUsd: number;
            unknownCalls: number;
            unfinishedCalls: number;
            abandonedCalls: number;
            errorCalls: number;
            uncoveredRuns: number;
            durationMs: number;
            remainingUsd: number | null;
            remainingMs: number | null;
        }[];
    } | undefined;
    /**
     * Причина, по которой бюджет не даст выдать поручение при следующем claim, —
     * тот же расчёт, которым claim ставит `budgetBlock` (и до того, как поле
     * записано). Только чтение; бюджеты выключены — `undefined`.
     */
    budgetBlockOf(workId: string, view: ExecutionView): string | undefined;
    /** Почему поручение сейчас не выдаётся; пусто — может быть выдано. */
    blockers(work: WorkState, view: ExecutionView): {
        code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT";
        message: string;
    }[];
    /**
     * Назначение ревью кода для роли поручения недопустимо политикой (reviewer
     * того же вендора без явного разрешения, нет reviewer или роли). Такое
     * поручение не выдаётся и видно блокером; остальная очередь идёт дальше.
     */
    private reviewerBlocker;
    /**
     * Выдать следующую готовую работу. Только действующий controller; не на
     * паузе; не сверх `concurrency`; первое готовое поручение в порядке
     * регистрации. Поручение с согласованием, не совпадающим с текущим
     * основанием, — отказ `APPROVAL_STALE`, а не выдача.
     */
    claim(owner: string): AttemptState | undefined;
    /**
     * Единственная точка fencing: операция попытки выполняется, только если
     * попытка активна, токен её, срок владения не истёк, она — текущая попытка
     * поручения, политика не сменилась и хост не возражает.
     */
    withAttempt<T>(id: string, token: string, kind: TransactionKind, fn: (attempt: AttemptState, work: WorkState, tx: ExecutionTransaction) => NotPromise<T>): T;
    heartbeat(id: string, token: string): void;
    /** Причина неудавшегося продления: записывается первой и не затирается. Истёкший срок допустим, чужой токен — нет. */
    heartbeatFailed(id: string, token: string, reason: string): boolean;
    phase(id: string, token: string, phase: Phase, data?: Partial<Pick<AttemptState, 'baseSha' | 'candidateSha' | 'integrationSha' | 'worktree'>>): void;
    /** Дополнить попытку сведениями её хода (контекст, ресурсы, замеры) под тем же fencing. */
    update(id: string, token: string, kind: TransactionKind, patch: Partial<Pick<AttemptState, 'context' | 'contextSnapshot' | 'resources' | 'model' | 'timings'>>): void;
    /** Снимок зависимостей, против которого идёт попытка; закрепляется до реализации. */
    dependencies(id: string, token: string, snapshots: NonNullable<AttemptState['dependencies']>): void;
    /** Свежесть снимка зависимостей на момент окончания: записывается, не отклоняет. */
    dependencyFreshness(id: string, token: string, freshness: NonNullable<AttemptState['dependencyFreshness']>): void;
    /** Что проверено у потребителя: его голова и снимок всех его зависимостей. */
    consumerChecked(id: string, token: string, repositoryId: string, checked: NonNullable<NonNullable<AttemptState['consumers']>[number]['checked']>): void;
    /**
     * Gates репозиториев, не пройденные на integration ни одним из принятых
     * поручений: покрытие — по фактическому собственному evidence на принятом
     * SHA попытки под текущим основанием политики, для любой области. Evidence потребителя — проверка другого
     * компонента и не в счёт; запись ревью не закрывает одноимённый test gate.
     * Решение о приёмке набора поручений — за хостом.
     */
    uncoveredGates(workIds: string[]): {
        repositoryId: string;
        gates: string[];
    }[];
    /**
     * Основания реализации записываются до неё: по ним следующая попытка решит,
     * можно ли взять этого кандидата. В той же транзакции решается, берётся ли
     * кандидат предыдущей попытки вместо новой реализации.
     */
    implementationBasis(id: string, token: string, basis: string): {
        reusedFrom: {
            runId: string;
            candidateSha: string;
        };
        reason?: undefined;
    } | {
        reason: string;
        reusedFrom?: undefined;
    };
    /** Черновик реализации, оборванной до кандидата (см. `AttemptState.partial`). */
    recordPartial(id: string, token: string, partial: NonNullable<AttemptState['partial']>): void;
    /** Попытка начала с черновика предыдущей (см. `AttemptState.continuedFrom`). */
    continuation(id: string, token: string, from: NonNullable<AttemptState['continuedFrom']>): void;
    /** Начало стадии попытки; `timingFinished` закрывает её исходом. */
    timingStarted(id: string, token: string, stage: string): string;
    timingFinished(id: string, token: string, timingId: string, outcome: 'passed' | 'failed'): void;
    /**
     * Записать воспроизведения из находок ревью попытки. Одно свойство на одном
     * входе — одна запись поручения: повтор добавляет прогон, а не запись;
     * подтверждение запуском не отменяется последующим неподтверждённым.
     * Реестр ограничен: старые записи вытесняются, а не копятся без предела.
     */
    recordReproductions(id: string, token: string, sha: string, items: Omit<ReproductionRecord, 'key' | 'inputHash' | 'runs'>[]): number;
    /** Воспроизведения поручения, от старых к новым. */
    reproductions(workId: string): ReproductionRecord[];
    evidence(id: string, token: string, evidence: Omit<EvidenceRecord, 'id' | 'runId' | 'createdAt'>): {
        id: string;
        runId: string;
        kind: "test" | "review";
        phase: "candidate" | "integration";
        sha: string;
        gate: string;
        passed: boolean;
        createdAt: string;
        command: string[];
        exitCode: number;
        log: string;
        digest: string;
        summary: string;
        consumer?: string | undefined;
        inspection?: {
            mode: "commands" | "diff-only";
            source: "codex-events" | "unavailable" | "controller-probes" | "runtime-and-controller";
            commands: {
                command: string;
                exitCode: number | null;
                output: string;
                origins?: ({
                    type: "runtime";
                    runtime: string;
                    item: string | null;
                } | {
                    type: "controller";
                    runId: string;
                })[] | undefined;
                status?: "error" | "passed" | "failed" | "cancelled" | "completed" | "timeout" | undefined;
                failure?: "report" | "environment" | undefined;
                gate?: string | undefined;
                note?: string | undefined;
            }[];
            reason: string | null;
            context?: {
                attempt: string;
                phase: "candidate" | "integration";
                sha: string;
                call: number;
            } | undefined;
            total?: number | undefined;
            excluded?: {
                runId: string;
                status: string | null;
                reason: "unfinished" | "not-started" | "legacy-unconfirmed" | "foreign-scope" | "unknown-status" | "abandoned";
            }[] | undefined;
            excludedTotal?: number | undefined;
            invalid?: number | undefined;
        } | undefined;
        findings?: {
            severity: string;
            message: string;
            path?: string | null | undefined;
            line?: number | null | undefined;
            id?: string | undefined;
            status?: "open" | "closed" | "withdrawn" | undefined;
        }[] | undefined;
        reviewRound?: {
            version: 1;
            scope: string;
            round: number;
            call: number;
            calls: number;
            protocol: "valid" | "invalid" | "unsafe";
            expected: string[];
            issues?: {
                path: string;
                reason: "unknown" | "missing" | "schema" | "duplicate" | "not-open" | "approved-with-blocking";
                message: string;
            }[] | undefined;
            transitions?: {
                id: string;
                from: "open" | "closed" | "withdrawn";
                to: "open" | "closed" | "withdrawn";
                basis: string;
            }[] | undefined;
            spec?: string | undefined;
            mode?: "legacy" | "strict" | undefined;
        } | undefined;
        tests?: {
            id: string;
            status: "passed" | "failed" | "skipped";
            opaque?: true | undefined;
        }[] | undefined;
        testsTruncated?: boolean | undefined;
        property?: {
            seed: number;
            reproduce: string;
            contracts: Record<string, string>;
            artifacts: {
                path: string;
                blob: string;
            }[];
            report?: {
                version: 1;
                properties: {
                    testId: string;
                    status: "passed" | "failed" | "running";
                    cases: number;
                    families?: Record<string, number> | undefined;
                    error?: string | undefined;
                    current?: unknown;
                    counterexample?: {
                        original: unknown;
                        reduced?: unknown;
                        expected?: unknown;
                        actual?: unknown;
                        reductionTimedOut?: boolean | undefined;
                        case?: string | undefined;
                    } | undefined;
                }[];
                seed?: number | undefined;
                corpus?: {
                    digest: string;
                    executed: number;
                    passed: number;
                    witness: string;
                    failed: {
                        id: string;
                        property: string;
                        expected?: unknown;
                        actual?: unknown;
                    }[];
                } | undefined;
            } | undefined;
            problem?: string | undefined;
            level?: "manifest" | "legacy" | undefined;
            manifest?: {
                digest: string;
                properties: string[];
                corpus?: {
                    digest: string;
                    cases: number;
                } | undefined;
            } | undefined;
            coverage?: string[] | undefined;
        } | undefined;
        checks?: string | undefined;
        alreadySatisfied?: {
            gates: string[];
            evidence: string;
            basis?: {
                kind: "contract";
                gates: string[];
            } | {
                kind: "dependency";
                workId: string;
                sha: string;
                paths: string[];
            } | undefined;
        } | undefined;
    };
    /**
     * Техническая приёмка. Требует фазу интеграции и integration SHA, PASS
     * каждого обязательного gate в обеих фазах на точных SHA, PASS
     * независимого ревью в обеих фазах; затем условие хоста `beforeAccept`.
     * `publish` — CAS продвижения target ref — выполняется внутри той же
     * транзакции до фиксации: его отказ откатывает приёмку целиком.
     */
    finish(id: string, token: string, sha: string, publish?: () => void): {
        workId: string;
        runId: string;
        sha: string;
    };
    /**
     * Отказ попытки. Класс и отпечаток записываются вместе с отказом. Отказ
     * окружения до кандидата (`blocked`) попытку не засчитывает. Отказ,
     * который повторится на любой работе (`repairPolicy.blocksQueue`), ставит
     * паузу `runtime` с классом отказа — снимает её устранение причины.
     */
    fail(id: string, token: string, error: string, options?: {
        kind?: FailureKind;
        blocked?: boolean;
        heartbeatCause?: string;
        /**
         * Свойства отказа: `bound` — объявленные поручением, `unbound` — прочие
         * названные; `classes` — классы входов, названные ревьюером.
         */
        properties?: {
            bound: string[];
            unbound: string[];
            classes?: string[];
            pairs?: {
                property: string;
                inputClass: string;
            }[];
        };
        /**
         * Попытку прервала штатная остановка controller: отказ окружения без
         * паузы по классу; поручение возвращается в очередь (`ready`), а не
         * ждёт восстановления. Интегрированная попытка так не возвращается.
         */
        interrupted?: boolean;
    }): {
        recovery?: {
            id: string;
            status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
        } | undefined;
        properties?: string[] | undefined;
        workId: string;
        runId: string;
        kind: "gate" | "unknown" | "review" | "environment" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead";
        blocked: boolean;
        /** Работа возвращена в очередь (штатная остановка); иначе — обычный отказ. */
        interrupted: boolean;
    };
    private recoveryEvent;
    /** Принятие корпуса, ждущее оператора, удерживает выдачу поручения. */
    private awaitsOperator;
    private episode;
    /**
     * Учесть разбор ведущего до вызова модели. Один автоматический разбор на
     * эпизод: повторная регистрация, рестарт или дубликат бесплатного вызова
     * не получают. Исчерпанные попытки — решение человека.
     */
    recoveryReserve(workId: string, recoveryId: string): {
        id: string;
        property: string;
        basis: string;
        runs: string[];
        openedAt: string;
        status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
        calls: number;
        history: {
            at: string;
            event: string;
            detail?: string | undefined;
        }[];
        version: number;
        decision?: {
            action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
            reason: string;
            evidence: string[];
            source: {
                kind: "operator" | "lead";
                runtime?: string | undefined;
                model?: string | undefined;
            };
            decidedAt: string;
            hypothesis?: string | undefined;
            plan?: string | undefined;
            cases?: {
                input: string;
                expected?: string | null | undefined;
            }[] | undefined;
            proposal?: string | undefined;
            conflict?: string | undefined;
        } | undefined;
        retryRun?: string | undefined;
        reason?: string | undefined;
    };
    /**
     * Записать решение разбора — ведущего или ручное — и перевести эпизод в
     * состояние разрешённого действия. Ручное решение сверяет версию записи:
     * устаревшее не применяется.
     */
    recoveryDecide(workId: string, recoveryId: string, decision: NonNullable<PropertyRecovery['decision']>, expectedVersion?: number): {
        id: string;
        property: string;
        basis: string;
        runs: string[];
        openedAt: string;
        status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
        calls: number;
        history: {
            at: string;
            event: string;
            detail?: string | undefined;
        }[];
        version: number;
        decision?: {
            action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
            reason: string;
            evidence: string[];
            source: {
                kind: "operator" | "lead";
                runtime?: string | undefined;
                model?: string | undefined;
            };
            decidedAt: string;
            hypothesis?: string | undefined;
            plan?: string | undefined;
            cases?: {
                input: string;
                expected?: string | null | undefined;
            }[] | undefined;
            proposal?: string | undefined;
            conflict?: string | undefined;
        } | undefined;
        retryRun?: string | undefined;
        reason?: string | undefined;
    };
    /** Итог добавления случаев: подтверждённый случай разрешает один повтор. */
    recoveryApplied(workId: string, recoveryId: string, outcomes: {
        outcome: string;
        reason: string;
    }[]): {
        id: string;
        property: string;
        basis: string;
        runs: string[];
        openedAt: string;
        status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
        calls: number;
        history: {
            at: string;
            event: string;
            detail?: string | undefined;
        }[];
        version: number;
        decision?: {
            action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
            reason: string;
            evidence: string[];
            source: {
                kind: "operator" | "lead";
                runtime?: string | undefined;
                model?: string | undefined;
            };
            decidedAt: string;
            hypothesis?: string | undefined;
            plan?: string | undefined;
            cases?: {
                input: string;
                expected?: string | null | undefined;
            }[] | undefined;
            proposal?: string | undefined;
            conflict?: string | undefined;
        } | undefined;
        retryRun?: string | undefined;
        reason?: string | undefined;
    };
    /** Разбор прервался без решения: вызов учтён, повтор не бесплатен. */
    recoveryInterrupted(workId: string, recoveryId: string, reason: string): {
        id: string;
        property: string;
        basis: string;
        runs: string[];
        openedAt: string;
        status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
        calls: number;
        history: {
            at: string;
            event: string;
            detail?: string | undefined;
        }[];
        version: number;
        decision?: {
            action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
            reason: string;
            evidence: string[];
            source: {
                kind: "operator" | "lead";
                runtime?: string | undefined;
                model?: string | undefined;
            };
            decidedAt: string;
            hypothesis?: string | undefined;
            plan?: string | undefined;
            cases?: {
                input: string;
                expected?: string | null | undefined;
            }[] | undefined;
            proposal?: string | undefined;
            conflict?: string | undefined;
        } | undefined;
        retryRun?: string | undefined;
        reason?: string | undefined;
    };
    /**
     * Применённая политика в хранилище — единственный источник правды; у
     * процесса нет своего «поколения», которое мог бы рассинхронизировать
     * откат транзакции. Процесс текущий, только если его политика совпадает с
     * применённой. Записать свою вместо применённой (перезапуск с другой
     * политикой) он может, только если нет живого чужого controller, политика
     * не менялась в памяти после создания движка, её источник не менялся с
     * загрузки и после запуска процесса никто не применил другую: поколение
     * считается по записям, а не по часам.
     */
    private mayAdopt;
    private adoptPolicy;
    /** Почему процесс не вправе действовать под своей политикой; `undefined` — вправе. */
    private staleReason;
    private policyStale;
    /**
     * Общий барьер: в транзакциях выдачи, согласования, приёмки и совместной
     * проверки процесс сверяет свою политику с применённой. Первый процесс,
     * действующий после законной смены политики без живого controller,
     * записывает свою как применённую в той же транзакции — откат отменит и её.
     */
    assertCurrentPolicy(tx: ExecutionTransaction): void;
    /**
     * Запуск controller записывает его политику применённой, если её ещё нет
     * или процесс вправе её сменить. Неприменённый запрос операции остаётся.
     * Хост с `recordPolicyOnLead: false` вызывает это сам при запуске controller.
     */
    recordPolicy(owner: string): void;
    private reconfiguring;
    /** Сведения о политике процесса и применённой. */
    policyState(): {
        stale?: string | undefined;
        reconfigure?: {
            operation: string;
            digest: string;
            requestedAt: string;
            appliedAt?: string | undefined;
            appliedBy?: string | undefined;
            error?: string | undefined;
        } | undefined;
        applied?: {
            digest: string;
            at: string;
            by: string;
            generation?: number | undefined;
        } | undefined;
        loaded: string;
    };
    /**
     * Пауза операции: ставится, только если очередь не остановлена, и
     * помечается операцией. Пауза человека не перезаписывается.
     */
    operationPause(operation: string): boolean;
    /** Снять паузу операции — только свою; паузу человека она не трогает. */
    operationResume(operation: string): boolean;
    /**
     * Запросить применение политики с ожидаемым digest (`policyDigest`
     * загруженной политики). Идемпотентно; повтор той же операцией сбрасывает
     * прежний отказ — политику могли исправить. Пока запрос не применён, новые
     * попытки не выдаются.
     */
    requestReconfigure(operation: string, digest: string): {
        operation: string;
        digest: string;
        changed: boolean;
        retried?: undefined;
    } | {
        operation: string;
        digest: string;
        changed: boolean;
        retried: boolean;
    };
    /**
     * Работы, идущие под действующей политикой. Запись с истёкшим сроком не
     * держит применение: её результат и так не будет принят (владение
     * проверяется при каждой записи), а держать применение из-за неё значило
     * бы ждать вечно.
     */
    busyWork(view: ExecutionView): string[];
    /**
     * Применить запрос этим процессом: только если его политика — ровно
     * ожидаемая и работ под прежней не осталось. Политика другого digest —
     * отказ с обоими digest (повтор операции его сбросит). Применение и снятие
     * паузы операции — одна транзакция.
     */
    applyReconfigure(by: string): {
        status: 'none';
    } | {
        status: 'busy';
        busy: string[];
    } | {
        status: 'waiting';
        expected: string;
    } | {
        status: 'failed';
        error: string;
    } | {
        status: 'applied';
        generation: number;
    };
    /**
     * Процесс, работающий с прежней политикой, применить запрос не может: он
     * ждёт перезапуска с ожидаемой. Такой процесс применение не отклоняет.
     */
    /**
     * Применит ли этот процесс ожидающий запрос политики при следующем шаге —
     * те же условия, что у `serveReconfigure`/`applyReconfigure`. Только чтение.
     */
    reconfigureApplies(view: ExecutionView): boolean;
    serveReconfigure(by: string): {
        status: "none";
    } | {
        status: "busy";
        busy: string[];
    } | {
        status: "waiting";
        expected: string;
    } | {
        status: "failed";
        error: string;
    } | {
        status: "applied";
        generation: number;
    };
    /**
     * Записать отказ применения с причиной хоста (например, файл политики не
     * читается или не совпадает с ожидаемым). Только для неприменённого запроса
     * той же операции и digest; повтор операции сбрасывает отказ.
     */
    rejectReconfigure(operation: string, digest: string, error: string): boolean;
    /** Снять завершённый или отменённый запрос операции. */
    clearReconfigure(operation: string): boolean;
    /**
     * Удержать поручения от выдачи на время операции. Поручение, удерживаемое
     * другой операцией, — конфликт: две операции не меняют одно поручение
     * одновременно. Повтор той же операции ничего не меняет. `fence` —
     * проверка владения операцией в той же транзакции: утративший владение
     * ничего не пишет.
     */
    hold(ids: string[], operation: string, reason: string, fence?: (view: ExecutionView) => void): string[];
    /** Снять удержание операции — со всех или с перечисленных поручений; чужие не трогаются. */
    releaseHold(operation: string, ids?: string[], fence?: (view: ExecutionView) => void): string[];
    /** Передать удержание от одной операции другой без окна выдачи. */
    transferHold(from: string, to: string, reason: string, fence?: (view: ExecutionView) => void): string[];
    /** Попытки, ещё владеющие поручениями (живой срок): операция ждёт их окончания. */
    activeAttempts(workIds?: string[]): {
        id: string;
        workId: string;
        leaseUntil: number;
    }[];
    /** Digest политики совместной проверки: формула хоста, если он её задаёт. */
    private jointPolicy;
    /** Основание совместной проверки набора: формула хоста, если он её задаёт. */
    private jointSpec;
    private liveJoint;
    /**
     * Начать совместную проверку набора принятых поручений. Нужны gates уровня
     * workspace с JUnit, у каждого продуктового репозитория — свой; идущих
     * попыток и другой живой проверки быть не должно; истёкшая проверка
     * закрывается отказом. `baseline` — успешная проверка, которую хост принял
     * (для режима `affected`).
     */
    jointStart(input: {
        workIds: string[];
        baseline?: string;
    }): JointVerificationState;
    /**
     * Fencing совместной проверки: активна, токен её, срок не истёк, политика
     * и основание (поручения, их постановки и результаты) не изменились.
     */
    private jointUpdate;
    jointHeartbeat(id: string, token: string): void;
    /**
     * Закрепить manifest: SHA и tree каждого репозитория политики. Закрепляется
     * один раз; по нему же выбирается область проверки.
     */
    jointManifest(id: string, token: string, manifest: NonNullable<JointVerification['manifest']>): {
        manifest: Record<string, {
            sha: string;
            tree: string;
        }>;
        manifestDigest: string;
        impact: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        };
        status: "active";
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        token: string;
        leaseUntil: number;
        engineVersion?: string | undefined;
    } | {
        manifest: Record<string, {
            sha: string;
            tree: string;
        }>;
        manifestDigest: string;
        impact: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        };
        status: "failed";
        finishedAt: string;
        error: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        token: string;
        leaseUntil: number;
        engineVersion?: string | undefined;
    } | {
        manifest: Record<string, {
            sha: string;
            tree: string;
        }>;
        manifestDigest: string;
        impact: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        };
        status: "passed";
        finishedAt: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        token: string;
        leaseUntil: number;
        engineVersion?: string | undefined;
    };
    jointEvidence(id: string, token: string, evidence: JointVerification['evidence'][number]): void;
    private jointMissing;
    jointFinish(id: string, token: string): {
        status: "active";
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "failed";
        finishedAt: string;
        error: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "passed";
        finishedAt: string;
        manifest: Record<string, {
            sha: string;
            tree: string;
        }>;
        manifestDigest: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            durationMs?: number | undefined;
        }[];
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "all" | "affected";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    };
    /** Отказ проверки её владельцем; истёкший срок допустим, чужой токен — нет. */
    jointFail(id: string, token: string, error: string): boolean;
    /**
     * Актуальный результат совместной проверки набора: последняя проверка этого
     * набора, успешная, с целым manifest, под текущей политикой, на неизменном
     * основании, с PASS каждого gate своей области. Иначе — причина; прежний
     * результат как актуальный не выдаётся.
     */
    jointResult(workIds: string[], 
    /** Оценить эту проверку набора, а не последнюю (хост выбирает её сам). */
    verificationId?: string): {
        verification?: JointVerification;
        current: boolean;
        reason?: string;
    };
    /** Истёкшие попытки: отказ окружения, работа ждёт явного повтора. */
    /**
     * Истечение владения на момент `at` (по умолчанию — сейчас). Хост передаёт
     * момент в будущем, когда снимает всё владение восстановленной копии.
     */
    expire(at?: number): string[];
    /** Восстановление: новый владелец истёкшей активной попытки получает новый токен. Старый токен недействителен. */
    adopt(id: string, owner: string): AttemptState;
    /** Recovery отклонил продолжение: попытка истечёт на следующем `expire`. */
    rejectRecovery(id: string, reason: string): boolean;
    /** Отмена: активная попытка теряет владение, поручение — cancelled. Принятое не отменяется. */
    cancel(workId: string, reason?: string): {
        work: {
            id: string;
            graphId: string;
            order: {
                apiVersion: "devcontour-harness/v1alpha1";
                id: string;
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                title: string;
                goal: string;
                acceptance: string[];
                role: string;
                repositoryId: string;
                relatedRepositories: string[];
                writeScope: string[];
                dependsOn: string[];
                requirements: {
                    id: string;
                    source: string;
                    digest: string;
                    text: string;
                    gate: string;
                    scenario: string;
                    testId?: string | undefined;
                }[];
                contracts: {
                    id: string;
                    digest: string;
                }[];
                context: string[];
                gates?: string[] | undefined;
                consumers?: {
                    repositoryId: string;
                    gates: string[];
                }[] | undefined;
                properties?: string[] | undefined;
                resources?: string[] | undefined;
            };
            status: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
            attempt: number;
            activeRunId?: string | undefined;
            resultSha?: string | undefined;
            failure?: string | undefined;
            failureKind?: "gate" | "unknown" | "review" | "environment" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | undefined;
            failureFingerprint?: string | undefined;
            approvedAt?: string | undefined;
            approvedDigest?: string | undefined;
            approvedScope?: string | undefined;
            approval?: {
                actor: "agent" | "operator";
                authorRuntime?: "codex" | "claude" | "fixture" | undefined;
                reviewerRuntime?: "codex" | "claude" | "fixture" | undefined;
                artifact?: string | undefined;
                digest?: string | undefined;
                context?: {
                    digest: string | null;
                } | undefined;
            } | undefined;
            hold?: {
                operation: string;
                reason: string;
            } | undefined;
            budgetBlock?: {
                reason: string;
                at: string;
            } | undefined;
            checkVersion?: {
                suite: string;
                number: number;
                digest: string;
            } | undefined;
            recovery?: {
                id: string;
                property: string;
                basis: string;
                runs: string[];
                openedAt: string;
                status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
                calls: number;
                history: {
                    at: string;
                    event: string;
                    detail?: string | undefined;
                }[];
                version: number;
                decision?: {
                    action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                    reason: string;
                    evidence: string[];
                    source: {
                        kind: "operator" | "lead";
                        runtime?: string | undefined;
                        model?: string | undefined;
                    };
                    decidedAt: string;
                    hypothesis?: string | undefined;
                    plan?: string | undefined;
                    cases?: {
                        input: string;
                        expected?: string | null | undefined;
                    }[] | undefined;
                    proposal?: string | undefined;
                    conflict?: string | undefined;
                } | undefined;
                retryRun?: string | undefined;
                reason?: string | undefined;
            } | undefined;
            recoveryHistory?: {
                id: string;
                property: string;
                basis: string;
                runs: string[];
                openedAt: string;
                status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
                calls: number;
                history: {
                    at: string;
                    event: string;
                    detail?: string | undefined;
                }[];
                version: number;
                decision?: {
                    action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                    reason: string;
                    evidence: string[];
                    source: {
                        kind: "operator" | "lead";
                        runtime?: string | undefined;
                        model?: string | undefined;
                    };
                    decidedAt: string;
                    hypothesis?: string | undefined;
                    plan?: string | undefined;
                    cases?: {
                        input: string;
                        expected?: string | null | undefined;
                    }[] | undefined;
                    proposal?: string | undefined;
                    conflict?: string | undefined;
                } | undefined;
                retryRun?: string | undefined;
                reason?: string | undefined;
            }[] | undefined;
            neutralFailures?: number | undefined;
        };
        changed: boolean;
    };
    /**
     * Повтор неуспешного или отменённого поручения. Пока попытки не
     * исчерпаны — без сброса; исчерпаны — только явный сброс с причиной.
     * Класс и отпечаток прошлого отказа снимаются.
     */
    retry(workId: string, reset?: {
        reason: string;
    }): {
        work: {
            id: string;
            graphId: string;
            order: {
                apiVersion: "devcontour-harness/v1alpha1";
                id: string;
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                title: string;
                goal: string;
                acceptance: string[];
                role: string;
                repositoryId: string;
                relatedRepositories: string[];
                writeScope: string[];
                dependsOn: string[];
                requirements: {
                    id: string;
                    source: string;
                    digest: string;
                    text: string;
                    gate: string;
                    scenario: string;
                    testId?: string | undefined;
                }[];
                contracts: {
                    id: string;
                    digest: string;
                }[];
                context: string[];
                gates?: string[] | undefined;
                consumers?: {
                    repositoryId: string;
                    gates: string[];
                }[] | undefined;
                properties?: string[] | undefined;
                resources?: string[] | undefined;
            };
            status: "ready" | "failed" | "cancelled" | "draft" | "running" | "verifying" | "reviewing" | "integrating" | "done";
            attempt: number;
            activeRunId?: string | undefined;
            resultSha?: string | undefined;
            failure?: string | undefined;
            failureKind?: "gate" | "unknown" | "review" | "environment" | "cancelled" | "timeout" | "provider-auth" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | undefined;
            failureFingerprint?: string | undefined;
            approvedAt?: string | undefined;
            approvedDigest?: string | undefined;
            approvedScope?: string | undefined;
            approval?: {
                actor: "agent" | "operator";
                authorRuntime?: "codex" | "claude" | "fixture" | undefined;
                reviewerRuntime?: "codex" | "claude" | "fixture" | undefined;
                artifact?: string | undefined;
                digest?: string | undefined;
                context?: {
                    digest: string | null;
                } | undefined;
            } | undefined;
            hold?: {
                operation: string;
                reason: string;
            } | undefined;
            budgetBlock?: {
                reason: string;
                at: string;
            } | undefined;
            checkVersion?: {
                suite: string;
                number: number;
                digest: string;
            } | undefined;
            recovery?: {
                id: string;
                property: string;
                basis: string;
                runs: string[];
                openedAt: string;
                status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
                calls: number;
                history: {
                    at: string;
                    event: string;
                    detail?: string | undefined;
                }[];
                version: number;
                decision?: {
                    action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                    reason: string;
                    evidence: string[];
                    source: {
                        kind: "operator" | "lead";
                        runtime?: string | undefined;
                        model?: string | undefined;
                    };
                    decidedAt: string;
                    hypothesis?: string | undefined;
                    plan?: string | undefined;
                    cases?: {
                        input: string;
                        expected?: string | null | undefined;
                    }[] | undefined;
                    proposal?: string | undefined;
                    conflict?: string | undefined;
                } | undefined;
                retryRun?: string | undefined;
                reason?: string | undefined;
            } | undefined;
            recoveryHistory?: {
                id: string;
                property: string;
                basis: string;
                runs: string[];
                openedAt: string;
                status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
                calls: number;
                history: {
                    at: string;
                    event: string;
                    detail?: string | undefined;
                }[];
                version: number;
                decision?: {
                    action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                    reason: string;
                    evidence: string[];
                    source: {
                        kind: "operator" | "lead";
                        runtime?: string | undefined;
                        model?: string | undefined;
                    };
                    decidedAt: string;
                    hypothesis?: string | undefined;
                    plan?: string | undefined;
                    cases?: {
                        input: string;
                        expected?: string | null | undefined;
                    }[] | undefined;
                    proposal?: string | undefined;
                    conflict?: string | undefined;
                } | undefined;
                retryRun?: string | undefined;
                reason?: string | undefined;
            }[] | undefined;
            neutralFailures?: number | undefined;
        };
        changed: boolean;
    };
}
