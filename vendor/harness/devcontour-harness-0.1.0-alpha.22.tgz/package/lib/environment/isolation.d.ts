/**
 * Одна политика изоляции для исполнителя, ревьюера и проверок.
 *
 * Раньше граница зависела от того, кто исполняет: codex-исполнитель читал
 * любые файлы пользователя, claude-ревьюер без песочницы мог писать куда
 * угодно, а проверки шли обычным процессом хоста. Здесь граница описана один
 * раз, а применяет её механизм, родной для каждого: песочница codex (профиль
 * прав), песочница Claude Code (sandbox settings) и sandbox-runtime для
 * проверок. Все три — один класс механизма ОС (Seatbelt на macOS,
 * bubblewrap на Linux).
 *
 * - `write` — куда можно писать; всё остальное закрыто на запись.
 * - `hidden` — что закрыто на чтение: база и рабочие каталоги контура,
 *   каталоги учётных данных.
 * - `readable` — что внутри скрытого снова открыто: собственный worktree,
 *   закреплённые зависимости. Более конкретный путь побеждает.
 * - `domains` — внешние адреса; без них сеть закрыта. Проверкам остаётся
 *   localhost: тесты сервисов поднимают его сами.
 */
export interface Isolation {
    write: string[];
    hidden: string[];
    readable: string[];
    domains: string[];
    /**
     * Имена элементов каталога контура, которые хост создаёт по ходу работы
     * (конфигурация, журналы). Закрываются заранее вместе с известными harness.
     */
    entries?: string[];
}
/**
 * Каталоги учётных данных. Закрыть весь $HOME нельзя — там проверяемый
 * checkout и инструменты, — поэтому закрываются известные места ключей и
 * токенов. Пути абсолютные: не каждый механизм раскрывает `~`.
 */
export declare function credentialPaths(home?: string): string[];
export declare function isolation(options: {
    write: string[];
    controller: string[];
    readable?: string[];
    domains?: string[];
    /** Элементы каталога контура хоста, которые закрываются и до своего появления. */
    entries?: string[];
}): Isolation;
/** Sandbox Claude Code: применяется к Bash; без запасного выхода из песочницы. */
export declare function claudeSandbox(policy: Isolation, review: boolean, cwd: string): {
    permissions: {
        deny: string[];
    };
    sandbox: {
        enabled: boolean;
        failIfUnavailable: boolean;
        allowUnsandboxedCommands: boolean;
        autoAllowBashIfSandboxed: boolean;
        network: {
            allowedDomains: string[];
            allowLocalBinding: boolean;
        };
        filesystem: {
            denyRead: string[];
            allowRead: string[];
            denyWrite?: string[] | undefined;
            allowWrite: string[];
        };
    };
};
/**
 * Запреты для встроенных файловых инструментов claude (Read, Edit, Write…).
 *
 * Песочница Claude Code применяется только к Bash; файловые инструменты
 * подчиняются правилам прав. Скрытый путь закрывается правилом, если он не
 * предок рабочего каталога: иначе запрет закрыл бы и сам worktree. Такие
 * предки лежат вне рабочего каталога, а чтение вне него в неинтерактивном
 * режиме и так отклоняется. Главное здесь — скрытое внутри рабочего каталога:
 * база контура в embedded-режиме лежит прямо в проверяемом checkout.
 */
export declare function claudeFileDenies(policy: Isolation, cwd: string | undefined): string[];
/** Файловые инструменты claude: их заранее выданные разрешения при изоляции снимаются. */
export declare const claudeFileTools: string[];
/**
 * Профиль прав codex: карта путей с уровнем доступа. Более конкретный путь
 * побеждает, поэтому worktree внутри скрытого каталога контура остаётся
 * доступным. Временный каталог открыт на запись: проверкам ревьюера и
 * исполнителя нужна запись вне проверяемого кода.
 */
export declare function codexPermissions(policy: Isolation, network: boolean): string[];
/** Готов ли механизм изоляции проверок на этой машине. */
export declare function isolationSupport(): {
    ok: boolean;
    detail: string;
};
/**
 * Обязательные запреты записи sandbox-runtime для корней проверки — без
 * каталогов IDE внутри дерева зависимостей.
 *
 * srt всегда запрещает запись в конфигурацию shell, git, IDE и Claude
 * (README «Mandatory Deny Paths»), и отключить это можно только вместе со
 * всей файловой политикой. На macOS запрет `.idea`/`.vscode` действует на
 * любой глубине под текущим каталогом процесса srt, в том числе внутри
 * `node_modules`; на Linux тот же запрет `node_modules` пропускает. Пакеты
 * публикуют `.idea/` (так поставляются и распространённые транзитивные
 * зависимости), и установка зависимостей в чистом worktree падала с EPERM
 * при любом коде.
 *
 * Запрет защищает от конфигурации, которую песочница подложит, а человек
 * потом откроет в IDE или git исполнит на хосте. Дерево зависимостей IDE как
 * конфигурацию проекта не открывает, поэтому на macOS srt запускается из
 * собственного каталога проверки, а запреты для корней задаются здесь явно:
 *
 * - конфигурация shell и git, `.mcp.json`, `.claude/commands|agents`,
 *   `.git/hooks`, `.git/config` — в корне и на любой глубине, как у srt;
 * - `.idea` и `.vscode` — в корне и в каждом подкаталоге существующих
 *   каталогов до глубины `ideDepth`, кроме `node_modules`. Глоб srt не умеет
 *   «кроме node_modules», поэтому дерево перечисляется: новый каталог глубже
 *   существующего уровня не закрыт (у srt на Linux закрыты только уже
 *   существующие файлы до глубины 3).
 * - Регистр. Правила srt (`subpath`, `regex`) записаны в нижнем регистре, но
 *   Seatbelt на нечувствительном к регистру томе (APFS по умолчанию)
 *   сравнивает путь без регистра: проба под песочницей отказывает в записи в
 *   `.IDEA/x`, `.VSCode/x`, `.Bashrc`, `.Claude/commands/x` и `x/.GIT/hooks/x`
 *   так же, как в именах нижнего регистра. На Linux ФС обычно различает
 *   регистр, и `.Claude` хост не читает как `.claude`. Имена, которых в
 *   запретах нет (`.claude/settings.json` в любом регистре), и пути глубже
 *   перечисленных уровней ловит сверка снимков (`protectedSnapshot`) — она
 *   сравнивает имена без регистра везде.
 *
 * Путь с символами глоба нельзя записать шаблоном без риска не совпасть ни
 * с чем; тогда возвращается `undefined`, и srt остаётся в прежнем каталоге с
 * полным собственным запретом.
 */
export declare const ideDirectories: string[];
/**
 * Отказ собрать политику песочницы: проверка не запускается, а не идёт с
 * молча урезанными запретами.
 */
export declare class SandboxPolicyError extends Error {
    name: string;
}
export declare function protectedWriteDenies(roots: string[]): string[] | undefined;
/**
 * Явные запреты для Linux. srt там закрывает только уже существующие пути и
 * сам пропускает `node_modules`; файл `.git` рабочего дерева добавляется.
 */
export declare function linuxWriteDenies(roots: string[]): string[];
/**
 * Обязательный запрет записи, под который попадает `path` внутри открытых
 * проверке каталогов. `undefined` — путь вне таких запретов: отказ в нём —
 * не следствие обязательной политики песочницы.
 */
export declare function mandatoryDenyRule(policy: Isolation, path: string): string | undefined;
export interface SandboxViolation {
    operation: string;
    path: string;
}
/**
 * Отказы песочницы из журнала ядра macOS для одной проверки.
 *
 * srt помечает каждое правило запрета тегом с началом команды (base64) и
 * суффиксом сессии `_SBX`; команда проверки начинается с уникального
 * токена, и записи чужих песочниц на той же машине сюда не попадают. Текст
 * вывода проверки свидетельством не служит: его печатает сама проверка.
 */
export declare function parseSandboxLog(text: string, tag: string): SandboxViolation[];
/** Наблюдение за журналом песочницы на время проверки; без `log` — `undefined`. */
export declare function watchSandboxLog(tag: string): Promise<{
    /** Ждёт `drainMs`, пока ядро допишет записи, и возвращает отказы проверки. */
    stop(drainMs: number): Promise<SandboxViolation[]>;
} | undefined>;
/**
 * Отказы обязательной политики в открытых проверке каталогах, которые
 * подтвердило ядро. Запись вне открытых каталогов — ошибка кода проверки,
 * а не среды: её здесь нет.
 */
export declare function sandboxDenials(violations: SandboxViolation[], policy: Isolation): {
    path: string;
    rule: string;
}[];
/**
 * Защищённые элементы checkout вне `node_modules`: путь → подпись.
 *
 * Запреты песочницы проверяют только путь операции. Каталог, собранный
 * внутри `node_modules` (там каталоги IDE открыты) и затем перенесённый в
 * дерево проекта, или новый каталог глубже перечисленных уровней ими не
 * закрыты; сверка снимков до и после проверки находит такой результат.
 */
export declare function protectedSnapshot(root: string): Map<string, string>;
/**
 * Защищённые пути, которые появились или изменились после снимка `before`.
 *
 * Путь, который сверка не может прочитать (кроме ENOENT), — `SandboxPolicyError`
 * из снимка, а не пропуск: вызывающий решает, отказ ли это среды (снимок до
 * работы) или нарушение области (после).
 *
 * Пустые каталоги (только каталоги, рекурсивно, без записи всем)
 * нарушением не считаются, если до снимка пути не было или он тоже был без
 * файлов: исполняемой конфигурации в них нет, а CLI исполнителя создаёт
 * такие служебные каталоги (`.claude/.cc-writes`) рядом с каждым записанным
 * файлом. Путь, где раньше были файлы, по-прежнему нарушение при любом
 * изменении.
 */
export declare function protectedChanges(before: Map<string, string>, root: string): string[];
/**
 * Команда проверки внутри sandbox-runtime.
 *
 * Настройки пишутся в файл: srt отказывает, если файл пуст или невалиден, и
 * не откатывается к умолчаниям. Собственный служебный сокет srt кладёт во
 * временный каталог процесса, поэтому srt получает короткий системный
 * TMPDIR, а команде внутри передаётся свой scratch.
 *
 * `cwd` — каталог, из которого запускается srt (см. `protectedWriteDenies`):
 * на macOS это каталог метки старта, а в рабочий каталог проверки обёртка
 * переходит сама перед exec.
 */
export declare function isolatedCommand(policy: Isolation, argv: string[], settingsDir: string, scratch: string, 
/**
 * Файл, который обёртка создаёт внутри песочницы перед exec команды. Его
 * отсутствие — единственный достоверный признак, что команда не начиналась.
 */
started: string, 
/** Рабочий каталог команды. */
workdir: string, 
/** Корни, которым нужны обязательные запреты записи (checkout проверки). */
protect?: string[], platform?: NodeJS.Platform, 
/**
 * Токен в начале команды: srt кладёт начало команды в тег записей журнала
 * ядра, и по нему отказы этой проверки отличаются от чужих (`parseSandboxLog`).
 */
tag?: string): Promise<{
    argv: string[];
    env: {
        TMPDIR: string;
    };
    cwd: string;
}>;
