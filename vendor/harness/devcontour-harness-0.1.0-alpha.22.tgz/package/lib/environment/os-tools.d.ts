/**
 * Системные утилиты, которыми ядро наблюдает процессы (`ps`, `lsof`) и
 * владение вызовами (`sysctl`). Они ищутся по фиксированным абсолютным путям
 * ОС раньше PATH: урезанный PATH (только node и git) не лишает ядро
 * containment, а файл из проекта или worktree с тем же именем не
 * запускается. PATH — только запасной путь, когда ни одного штатного
 * расположения нет (нестандартная ОС); поведение тогда прежнее.
 */
export declare const OS_TOOL_CANDIDATES: {
    readonly ps: readonly ["/bin/ps", "/usr/bin/ps"];
    readonly lsof: readonly ["/usr/sbin/lsof", "/usr/bin/lsof", "/sbin/lsof", "/bin/lsof"];
    readonly sysctl: readonly ["/usr/sbin/sysctl", "/sbin/sysctl", "/usr/bin/sysctl"];
};
export type OsTool = keyof typeof OS_TOOL_CANDIDATES;
/** Исполняемый файл утилиты: первый существующий штатный путь, иначе имя для PATH. */
export declare function osTool(name: OsTool, candidates?: readonly string[]): string;
/**
 * Окружение утилиты, чей вывод ядро разбирает: даты, числа и сообщения — в
 * локали C при любой локали пользователя. В ru_RU `ps -o lstart=` печатает
 * «среда, 28 октября 2026 г. 16:42:10», и `Date.parse` его не читает. Только
 * LC_CTYPE остаётся пользовательским: в локали C `lsof` экранирует байты
 * не-ASCII путей (`\xd0\xbb…`), и каталог с кириллицей не узнаётся. Поэтому не
 * `LC_ALL=C`: LC_ALL перекрыл бы LC_CTYPE, и его значение переносится в LC_CTYPE.
 */
export declare function osToolEnv(env?: NodeJS.ProcessEnv): NodeJS.ProcessEnv;
/**
 * Имя файла из вывода `lsof`: в локали без UTF-8 он экранирует байты вне
 * ASCII как `\xNN`, обратную косую — как `\\`, управляющие — как `\t`, `\n` и
 * т. п. Здесь экранирование снимается, и путь сравним с настоящим.
 */
export declare function lsofName(name: string): string;
