import { z } from 'zod';
import { API_VERSION } from './version.ts';
import { type ErrorCode } from './errors.ts';
/**
 * Договор CLI `harness`.
 *
 * - Каждая команда получает явные пути; бинарник не хранит настроек проекта
 *   и не помнит «последний активный проект».
 * - `--state <каталог>` — каталог состояния исполнения (SQLite, артефакты
 *   попыток). Создаётся только командами, которые пишут (`run`,
 *   `review-*`, `approve`); читающие команды на отсутствующем каталоге
 *   отвечают `NOT_FOUND` и ничего не создают.
 * - stdout — ровно один JSON `CliEnvelope`; диагностика — stderr. Явный
 *   `--human` (init, explain) заменяет успешный ответ текстом; отказ — тот же
 *   JSON на stdout, exit code одинаков в обоих режимах.
 * - Exit: 0 — успех; 2 — неверный вход; 3 — отказ или блокировка по
 *   правилам; 4 — инфраструктура. Exit 1 не используется.
 *
 * Библиотека и CLI вызывают одни и те же доменные операции; у CLI нет
 * операции «передать PASS» или «принять без проверок».
 */
export interface CliArgument {
    name: string;
    value: 'path' | 'dir' | 'id' | 'digest' | 'number' | 'text' | 'flag' | 'sink';
    required: boolean;
    description: string;
}
export interface CliCommandContract {
    description: string;
    /** Пишет ли команда состояние. `false` — гарантированно без побочных эффектов. */
    writes: boolean;
    /** Что делает повтор той же команды с теми же аргументами. */
    idempotency: string;
    args: CliArgument[];
    /** Отказы по существу (exit 3), которые команда обязана различать кодом. */
    refusals: ErrorCode[];
}
export declare const cliCommands: {
    readonly validate: {
        readonly description: "Проверить граф, политику, их связь и (если задан) снимок контекста без вызова моделей и записи состояния";
        readonly writes: false;
        readonly idempotency: "Чистая функция входов";
        readonly args: [CliArgument, CliArgument, CliArgument];
        readonly refusals: [];
    };
    readonly 'review-plan': {
        readonly description: "Техническое ревью плана (графа) с конкретным digest; новый раунд сохраняет историю находок предмета";
        readonly writes: true;
        readonly idempotency: "Повтор с тем же digest и тем же автором, уже согласованный последним раундом, возвращает этот раунд без вызова модели; иначе — новый раунд в пределах maxAttempts. Автор, не допускаемый правилом вендора, — REVIEWER_SAME_VENDOR до вызова модели";
        readonly args: [CliArgument, CliArgument, CliArgument, CliArgument, CliArgument, {
            readonly name: "--source";
            readonly value: "path";
            readonly required: false;
            readonly description: "Конфигурация коннектора задач: внешние предпосылки графа допускаются по решению источника (trusts) и доступности SHA в target ref; без неё доверенных receipt нет";
        }];
        readonly refusals: ["REVIEW_REJECTED", "ATTEMPTS_EXHAUSTED", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN", "NOT_READY"];
    };
    readonly 'review-contract': {
        readonly description: "Техническое ревью контракта с конкретным digest";
        readonly writes: true;
        readonly idempotency: "Как review-plan, предмет — ID контракта";
        readonly args: [CliArgument, {
            readonly name: "--contract";
            readonly value: "path";
            readonly required: true;
            readonly description: "ContractDocument JSON";
        }, CliArgument, CliArgument];
        readonly refusals: ["REVIEW_REJECTED", "ATTEMPTS_EXHAUSTED", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN"];
    };
    readonly approve: {
        readonly description: "Согласование оператором (approvalMode: operator) конкретного digest графа или контракта, уже прошедшего ревью";
        readonly writes: true;
        readonly idempotency: "Повтор для того же digest ничего не меняет";
        readonly args: [CliArgument, {
            readonly name: "--digest";
            readonly value: "digest";
            readonly required: true;
            readonly description: "Digest из ReviewRecord последнего раунда";
        }, {
            readonly name: "--subject";
            readonly value: "id";
            readonly required: true;
            readonly description: "ID графа или контракта";
        }];
        readonly refusals: ["APPROVAL_STALE", "APPROVAL_REQUIRED", "REVIEW_REJECTED"];
    };
    readonly run: {
        readonly description: "Зарегистрировать согласованный граф (идемпотентно по connector, ref, revision, digest) и вести работу до простоя";
        readonly writes: true;
        readonly idempotency: "Тот же граф той же редакции продолжает прежнюю работу; другой digest для той же редакции источника — REVISION_CONFLICT";
        readonly args: [CliArgument, {
            readonly required: false;
            readonly description: "WorkGraph JSON; не нужен с --source";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
        }, CliArgument, CliArgument, {
            readonly name: "--source";
            readonly value: "path";
            readonly required: false;
            readonly description: "Конфигурация коннектора (relay-v1-http | relay-v2-cli): перед запуском задачи перечитываются, semantic digest сверяется с закреплённым снимком и eligibility — до любого вызова runtime; результат доставляется в исходную задачу";
        }, {
            readonly name: "--sink";
            readonly value: "sink";
            readonly required: false;
            readonly description: "Получатель результата, `file:<каталог>`";
        }, {
            readonly name: "--once";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Один шаг очереди вместо работы до простоя";
        }, {
            readonly name: "--author";
            readonly value: "id";
            readonly required: false;
            readonly description: "Автор графа для ревью плана; по умолчанию external";
        }];
        readonly refusals: ["APPROVAL_REQUIRED", "APPROVAL_STALE", "PAUSED", "CONTROLLER_BUSY", "REVISION_CONFLICT", "GATE_FAILED", "REVIEW_REJECTED", "SCOPE_VIOLATION", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN", "ATTEMPTS_EXHAUSTED"];
    };
    readonly status: {
        readonly description: "Состояние очереди, графов и поручений с причинами блокировки";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, {
            readonly name: "--graph";
            readonly value: "id";
            readonly required: false;
            readonly description: "Только этот граф";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly events: {
        readonly description: "События строго после номера, по возрастанию";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, {
            readonly name: "--after";
            readonly value: "number";
            readonly required: false;
            readonly description: "Номер, по умолчанию 0";
        }, {
            readonly name: "--limit";
            readonly value: "number";
            readonly required: false;
            readonly description: "1–500, по умолчанию 100";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly pause: {
        readonly description: "Пауза оператора: новые claims запрещены, активные попытки продолжаются";
        readonly writes: true;
        readonly idempotency: "Повтор ничего не меняет";
        readonly args: [CliArgument];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly resume: {
        readonly description: "Снять паузу — решение человека: паузу оператора, штатной остановки и отказа runtime (с её классами отказов); паузу операции reconfigure не снимает";
        readonly writes: true;
        readonly idempotency: "Повтор без паузы ничего не меняет";
        readonly args: [CliArgument];
        readonly refusals: ["NOT_FOUND", "PAUSED"];
    };
    readonly cancel: {
        readonly description: "Отменить поручение: активная попытка теряет владение, поручение становится cancelled; это не retry";
        readonly writes: true;
        readonly idempotency: "Повтор для отменённого ничего не меняет";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--reason";
            readonly value: "text";
            readonly required: false;
            readonly description: "Причина";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly retry: {
        readonly description: "Новая попытка неуспешного (failed) поручения в пределах maxAttempts и бюджета; --reset сбрасывает счётчик попыток с причиной, учёт расходов не сбрасывается";
        readonly writes: true;
        readonly idempotency: "Повтор для уже готового к выдаче поручения ничего не меняет";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--reset";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Сбросить счётчик попыток; требует --reason";
        }, {
            readonly name: "--reason";
            readonly value: "text";
            readonly required: false;
            readonly description: "Причина сброса";
        }];
        readonly refusals: ["NOT_FOUND", "ATTEMPTS_EXHAUSTED", "BUDGET_EXHAUSTED", "BUDGET_UNKNOWN"];
    };
    readonly result: {
        readonly description: "Машинный результат последней завершённой попытки поручения и состояние доставки";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, CliArgument];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly deliver: {
        readonly description: "Повторить доставку результата получателю с тем же ключом; модели, gates и интеграция не вызываются";
        readonly writes: true;
        readonly idempotency: "Доставленный результат повторно не доставляется";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--sink";
            readonly value: "sink";
            readonly required: true;
            readonly description: "Получатель, `file:<каталог>`";
        }];
        readonly refusals: ["NOT_FOUND", "REVISION_CONFLICT"];
    };
    readonly cleanup: {
        readonly description: "Довести незавершённую очистку закончившейся попытки: повторить teardown по сохранённым receipt окружений и убрать её рабочие деревья; модели, gates и Git-приёмка не вызываются";
        readonly writes: true;
        readonly idempotency: "Повтор после успешной очистки отвечает nothing-pending и ничего не меняет";
        readonly args: [CliArgument, {
            readonly name: "--run";
            readonly value: "id";
            readonly required: true;
            readonly description: "ID попытки (runId)";
        }];
        readonly refusals: ["NOT_FOUND", "NOT_READY"];
    };
    readonly profile: {
        readonly description: "Разрешить профиль стека (встроенный ID или ./file.json репозитория): слои, gates, закрепление; только чтение манифестов, без команд проекта";
        readonly writes: false;
        readonly idempotency: "Чистая функция файлов профиля";
        readonly args: [{
            readonly name: "--profile";
            readonly value: "text";
            readonly required: true;
            readonly description: "Встроенный ID профиля или относительный ./file.json";
        }, {
            readonly name: "--repository";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Корень репозитория для локального профиля";
        }];
        readonly refusals: [];
    };
    readonly doctor: {
        readonly description: "Версии, наличие runtime и их capabilities, OS-sandbox, совместимость каталога состояния; без live-вызова модели";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [{
            readonly required: false;
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly description: string;
        }, {
            readonly required: false;
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly description: string;
        }];
        readonly refusals: [];
    };
    readonly init: {
        readonly description: "Подготовить существующий Git npm/pnpm-репозиторий: план или create-only запись .harness/ (политика из профиля и toolchain inspection, manifest последним); чужие файлы не меняются";
        readonly writes: true;
        readonly idempotency: "Повтор с теми же решениями ничего не пишет (created пуст); после прерывания дописывает недостающее; иные решения при существующем manifest — PATH_CONFLICT content-differs";
        readonly args: [{
            readonly name: "--repository";
            readonly value: "dir";
            readonly required: true;
            readonly description: "Корень Git-репозитория проекта";
        }, {
            readonly name: "--profile";
            readonly value: "text";
            readonly required: false;
            readonly description: "Встроенный профиль или ./file.json репозитория; без него — из manifest, иначе по lockfile (npm-ci | pnpm-frozen)";
        }, {
            readonly name: "--writer";
            readonly value: "id";
            readonly required: false;
            readonly description: "Runtime writer: claude (по умолчанию) или codex; reviewer — другой вендор";
        }, {
            readonly name: "--state";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Каталог состояния вне репозитория; по умолчанию <state home>/projects/<projectId>";
        }, {
            readonly name: "--plan";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Только план, без записи";
        }, {
            readonly name: "--human";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Текст для человека вместо JSON";
        }];
        readonly refusals: ["PATH_CONFLICT", "CONTROLLER_BUSY", "NOT_READY"];
    };
    readonly explain: {
        readonly description: "Объяснить остановки: код, причина, фаза, кто действует, допустимый следующий шаг и evidence; без повторов, вызовов моделей и изменений состояния";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, {
            readonly required: true;
            readonly description: "ExecutionPolicy JSON: maxAttempts, repairBudget и runtime политики";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
        }, {
            readonly name: "--work";
            readonly value: "id";
            readonly required: false;
            readonly description: "ID поручения";
        }, {
            readonly name: "--human";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Текст для человека вместо JSON";
        }];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly 'plan-request': {
        readonly description: "Собрать read-only запрос планирования из постановки и фактов проекта (роли, gates, репозитории, контекст, ресурсы, контракты, требования) для ведущего агента; модель не вызывается, ничего не пишется";
        readonly writes: false;
        readonly idempotency: "Чистая функция входов: те же постановка и факты дают тот же prompt и basis";
        readonly args: [{
            readonly name: "--brief";
            readonly value: "path";
            readonly required: true;
            readonly description: "Постановка пользователя, UTF-8";
        }, CliArgument, {
            readonly description: "ContextSnapshot JSON; без него — каталоги <каталог политики>/work/context/<id>";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly required: boolean;
        }, {
            readonly name: "--contracts";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Каталог ContractDocument JSON, на которые может ссылаться план";
        }, {
            readonly name: "--requirements";
            readonly value: "path";
            readonly required: false;
            readonly description: "Закоммиченный файл с разделами ## REQ-*: [<repositoryId>:]<путь от корня репозитория>; можно повторять";
        }, {
            readonly name: "--human";
            readonly value: "flag";
            readonly required: false;
            readonly description: "Только текст prompt вместо JSON";
        }];
        readonly refusals: ["NOT_READY"];
    };
    readonly 'plan-check': {
        readonly description: "Проверить draft плана против фактов проекта и собрать WorkGraph без вызова моделей, ревью и записи; согласования не выдаёт";
        readonly writes: false;
        readonly idempotency: "Чистая функция входов и HEAD источников требований";
        readonly args: [{
            readonly name: "--draft";
            readonly value: "path";
            readonly required: true;
            readonly description: "Draft JSON (schemas/plan-draft.schema.json); ID графа — имя файла без .draft.json/.json";
        }, CliArgument, CliArgument, {
            readonly name: "--contracts";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Как у plan-request";
        }, {
            readonly name: "--brief";
            readonly value: "path";
            readonly required: false;
            readonly description: "Постановка: revision графа = basis";
        }, {
            readonly name: "--basis";
            readonly value: "digest";
            readonly required: false;
            readonly description: "basis из plan-request, по которому составлен draft; расхождение — APPROVAL_STALE";
        }];
        readonly refusals: ["APPROVAL_STALE", "NOT_READY"];
    };
    readonly 'source-check': {
        readonly description: "Коннектор задач: подключение, идентичность и capabilities backend, совпадение проекта, проверка mapping; без мутаций, записи истории и создания состояния";
        readonly writes: false;
        readonly idempotency: "Только чтение получателя";
        readonly args: [CliArgument, {
            readonly required: false;
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
            readonly description: string;
        }, {
            readonly required: false;
            readonly description: "ExecutionPolicy JSON для сверки gates/ролей mapping";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
        }];
        readonly refusals: ["NOT_READY"];
    };
    readonly 'source-snapshot': {
        readonly description: "Коннектор задач: согласованное чтение задач, предпросмотр и закрепление снимка (graph/context/manifest) для review-plan и approve";
        readonly writes: true;
        readonly idempotency: "Неизменная постановка — тот же semantic digest, тот же граф и контекст; новых записей у получателя нет";
        readonly args: [CliArgument, CliArgument, {
            readonly required: false;
            readonly description: "ExecutionPolicy JSON: её секреты маскируются в диагностике";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
        }, {
            readonly name: "--out";
            readonly value: "dir";
            readonly required: false;
            readonly description: "Каталог graph.json, context.json, manifest.json";
        }];
        readonly refusals: ["NOT_READY"];
    };
    readonly 'source-status': {
        readonly description: "Коннектор задач: локально принято / доставлено / конфликт / неизвестный исход и независимое чтение получателя";
        readonly writes: false;
        readonly idempotency: "Только чтение";
        readonly args: [CliArgument, CliArgument];
        readonly refusals: ["NOT_FOUND"];
    };
    readonly 'source-deliver': {
        readonly description: "Коннектор задач: доставить или продолжить доставку принятых результатов с тем же ключом операции; модели, gates и Git не вызываются";
        readonly writes: true;
        readonly idempotency: "Подтверждённая доставка не повторяется; неизвестный исход не отправляется повторно до source-reconcile";
        readonly args: [CliArgument, CliArgument, {
            readonly required: false;
            readonly description: "ID поручения; без него — все с результатом";
            readonly name: string;
            readonly value: "path" | "dir" | "id" | "digest" | "number" | "text" | "flag" | "sink";
        }];
        readonly refusals: ["NOT_FOUND", "CONTROLLER_BUSY", "REVISION_CONFLICT"];
    };
    readonly 'source-reconcile': {
        readonly description: "Коннектор задач: разобрать неизвестный исход или конфликт операции доставки по фактам получателя; неоднозначность — только явным решением";
        readonly writes: true;
        readonly idempotency: "Разобранная операция не меняется; мутаций без решения и фактов нет";
        readonly args: [CliArgument, CliArgument, {
            readonly name: "--operation";
            readonly value: "digest";
            readonly required: true;
            readonly description: "Ключ операции из source-status";
        }, {
            readonly name: "--decision";
            readonly value: "text";
            readonly required: false;
            readonly description: "resend (записи у получателя нет), adopt:<id> (одна из нескольких записей с маркером), recheck (CAS-конфликт без изменения постановки)";
        }];
        readonly refusals: ["NOT_FOUND", "CONTROLLER_BUSY"];
    };
};
export type CliCommand = keyof typeof cliCommands;
export declare const validateDataSchema: z.ZodObject<{
    graphId: z.ZodString;
    graphDigest: z.ZodString;
    policyDigest: z.ZodString;
    contextDigest: z.ZodOptional<z.ZodString>;
    orders: z.ZodNumber;
}, z.core.$strict>;
export declare const statusDataSchema: z.ZodObject<{
    stateVersion: z.ZodLiteral<1>;
    control: z.ZodObject<{
        paused: z.ZodBoolean;
        pauseReason: z.ZodOptional<z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>>;
        pausedAt: z.ZodOptional<z.ZodISODateTime>;
        pauseOperation: z.ZodOptional<z.ZodString>;
        pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            environment: "environment";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
        }>>>;
        waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                "base-check": "base-check";
                "context-lock": "context-lock";
            }>;
            detail: z.ZodString;
            at: z.ZodISODateTime;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        appliedPolicy: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodOptional<z.ZodNumber>;
            at: z.ZodISODateTime;
            by: z.ZodString;
        }, z.core.$strict>>;
        reconfigure: z.ZodOptional<z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            requestedAt: z.ZodISODateTime;
            appliedAt: z.ZodOptional<z.ZodISODateTime>;
            appliedBy: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    controller: z.ZodOptional<z.ZodObject<{
        owner: z.ZodString;
        leaseUntil: z.ZodNumber;
        engineVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    graphs: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        digest: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        approved: z.ZodBoolean;
    }, z.core.$strict>>;
    works: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        graphId: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        activeRunId: z.ZodOptional<z.ZodString>;
        resultSha: z.ZodOptional<z.ZodString>;
        blockers: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            message: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    budgets: z.ZodOptional<z.ZodObject<{
        onUnknown: z.ZodEnum<{
            stop: "stop";
            continue: "continue";
        }>;
        budgets: z.ZodArray<z.ZodObject<{
            scope: z.ZodObject<{
                kind: z.ZodEnum<{
                    work: "work";
                    group: "group";
                    total: "total";
                }>;
                id: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
                within: "within";
            }>;
            limit: z.ZodObject<{
                usd: z.ZodOptional<z.ZodNumber>;
                timeMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            reportedUsd: z.ZodNumber;
            estimatedUsd: z.ZodNumber;
            unknownCalls: z.ZodNumber;
            unfinishedCalls: z.ZodNumber;
            abandonedCalls: z.ZodNumber;
            errorCalls: z.ZodNumber;
            uncoveredRuns: z.ZodNumber;
            durationMs: z.ZodNumber;
            remainingUsd: z.ZodNullable<z.ZodNumber>;
            remainingMs: z.ZodNullable<z.ZodNumber>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const eventsDataSchema: z.ZodObject<{
    events: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        seq: z.ZodNumber;
        at: z.ZodISODateTime;
        graphId: z.ZodOptional<z.ZodString>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        attempt: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
        payload: z.ZodObject<{
            digest: z.ZodString;
            orders: z.ZodNumber;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodEnum<{
                plan: "plan";
                contract: "contract";
            }>;
            subject: z.ZodString;
            digest: z.ZodString;
            round: z.ZodNumber;
            approved: z.ZodBoolean;
            open: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            actor: z.ZodEnum<{
                agent: "agent";
                operator: "operator";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            orderDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            released: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            policyDigest: z.ZodString;
            engineVersion: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            sameVendor: z.ZodBoolean;
            blocking: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            failureKind: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
            }>;
            message: z.ZodString;
            blocked: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            leaseUntil: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            integrationSha: z.ZodString;
            accepted: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            resultSha: z.ZodString;
            integrationSha: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
            failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
            }>>>;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            scope: z.ZodEnum<{
                work: "work";
                group: "group";
                total: "total";
            }>;
            scopeId: z.ZodOptional<z.ZodString>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
            }>;
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            suite: z.ZodString;
            pending: z.ZodString;
            version: z.ZodNumber;
            digest: z.ZodString;
            status: z.ZodEnum<{
                completed: "completed";
                waiting: "waiting";
            }>;
            accepted: z.ZodArray<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            recoveryId: z.ZodString;
            property: z.ZodString;
            status: z.ZodEnum<{
                closed: "closed";
                stopped: "stopped";
                "awaiting-lead": "awaiting-lead";
                analyzing: "analyzing";
                applying: "applying";
                retry: "retry";
                retrying: "retrying";
                "awaiting-user": "awaiting-user";
            }>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            policyDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>;
            manifestDigest: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodNumber;
            by: z.ZodString;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                requested: "requested";
                cleared: "cleared";
            }>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            receipt: z.ZodOptional<z.ZodString>;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            error: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            currentRevision: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>, ...z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        seq: z.ZodNumber;
        at: z.ZodISODateTime;
        graphId: z.ZodOptional<z.ZodString>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        attempt: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
        payload: z.ZodObject<{
            digest: z.ZodString;
            orders: z.ZodNumber;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodEnum<{
                plan: "plan";
                contract: "contract";
            }>;
            subject: z.ZodString;
            digest: z.ZodString;
            round: z.ZodNumber;
            approved: z.ZodBoolean;
            open: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            actor: z.ZodEnum<{
                agent: "agent";
                operator: "operator";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            orderDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            released: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            policyDigest: z.ZodString;
            engineVersion: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            sameVendor: z.ZodBoolean;
            blocking: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            failureKind: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
            }>;
            message: z.ZodString;
            blocked: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            leaseUntil: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            integrationSha: z.ZodString;
            accepted: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            resultSha: z.ZodString;
            integrationSha: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
            failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
            }>>>;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            scope: z.ZodEnum<{
                work: "work";
                group: "group";
                total: "total";
            }>;
            scopeId: z.ZodOptional<z.ZodString>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
            }>;
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            suite: z.ZodString;
            pending: z.ZodString;
            version: z.ZodNumber;
            digest: z.ZodString;
            status: z.ZodEnum<{
                completed: "completed";
                waiting: "waiting";
            }>;
            accepted: z.ZodArray<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            recoveryId: z.ZodString;
            property: z.ZodString;
            status: z.ZodEnum<{
                closed: "closed";
                stopped: "stopped";
                "awaiting-lead": "awaiting-lead";
                analyzing: "analyzing";
                applying: "applying";
                retry: "retry";
                retrying: "retrying";
                "awaiting-user": "awaiting-user";
            }>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            policyDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>;
            manifestDigest: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodNumber;
            by: z.ZodString;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                requested: "requested";
                cleared: "cleared";
            }>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            receipt: z.ZodOptional<z.ZodString>;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            error: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            currentRevision: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>[]], "type">>;
    next: z.ZodNumber;
}, z.core.$strict>;
export declare const runDataSchema: z.ZodObject<{
    graphId: z.ZodString;
    digest: z.ZodString;
    resumed: z.ZodBoolean;
    works: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        runId: z.ZodOptional<z.ZodString>;
        resultSha: z.ZodOptional<z.ZodString>;
        blockers: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            message: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    workflow: z.ZodOptional<z.ZodObject<{
        key: z.ZodString;
        kind: z.ZodString;
        id: z.ZodString;
        stage: z.ZodNumber;
        status: z.ZodEnum<{
            failed: "failed";
            completed: "completed";
            running: "running";
            queued: "queued";
            stale: "stale";
        }>;
        attempts: z.ZodNumber;
        repairs: z.ZodNumber;
        repairBudget: z.ZodNumber;
        error: z.ZodOptional<z.ZodString>;
        history: z.ZodArray<z.ZodObject<{
            at: z.ZodISODateTime;
            stage: z.ZodNumber;
            event: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const controlDataSchema: z.ZodObject<{
    control: z.ZodObject<{
        paused: z.ZodBoolean;
        pauseReason: z.ZodOptional<z.ZodEnum<{
            runtime: "runtime";
            operator: "operator";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>>;
        pausedAt: z.ZodOptional<z.ZodISODateTime>;
        pauseOperation: z.ZodOptional<z.ZodString>;
        pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            environment: "environment";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
        }>>>;
        waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                "base-check": "base-check";
                "context-lock": "context-lock";
            }>;
            detail: z.ZodString;
            at: z.ZodISODateTime;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        appliedPolicy: z.ZodOptional<z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodOptional<z.ZodNumber>;
            at: z.ZodISODateTime;
            by: z.ZodString;
        }, z.core.$strict>>;
        reconfigure: z.ZodOptional<z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            requestedAt: z.ZodISODateTime;
            appliedAt: z.ZodOptional<z.ZodISODateTime>;
            appliedBy: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    changed: z.ZodBoolean;
}, z.core.$strict>;
export declare const workActionDataSchema: z.ZodObject<{
    workId: z.ZodString;
    status: z.ZodEnum<{
        ready: "ready";
        failed: "failed";
        cancelled: "cancelled";
        draft: "draft";
        running: "running";
        verifying: "verifying";
        reviewing: "reviewing";
        integrating: "integrating";
        done: "done";
    }>;
    attempt: z.ZodNumber;
    changed: z.ZodBoolean;
}, z.core.$strict>;
export declare const approveDataSchema: z.ZodObject<{
    subject: z.ZodString;
    digest: z.ZodString;
    at: z.ZodISODateTime;
    changed: z.ZodBoolean;
}, z.core.$strict>;
export declare const doctorDataSchema: z.ZodObject<{
    harness: z.ZodString;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    node: z.ZodString;
    platform: z.ZodString;
    runtimes: z.ZodArray<z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        available: z.ZodBoolean;
        version: z.ZodOptional<z.ZodString>;
        structuredOutput: z.ZodBoolean;
        cancellation: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    sandbox: z.ZodObject<{
        os: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    state: z.ZodOptional<z.ZodObject<{
        stateVersion: z.ZodNumber;
        compatible: z.ZodBoolean;
        writer: z.ZodOptional<z.ZodString>;
        engineVersions: z.ZodOptional<z.ZodObject<{
            controller: z.ZodOptional<z.ZodString>;
            attempts: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    toolchains: z.ZodOptional<z.ZodArray<z.ZodObject<{
        repositoryId: z.ZodString;
        root: z.ZodString;
        configSource: z.ZodOptional<z.ZodString>;
        plan: z.ZodArray<z.ZodObject<{
            phase: z.ZodEnum<{
                gate: "gate";
                prepare: "prepare";
                dependencyBuild: "dependencyBuild";
                preflight: "preflight";
                setup: "setup";
                ready: "ready";
                teardown: "teardown";
            }>;
            id: z.ZodString;
            kind: z.ZodOptional<z.ZodEnum<{
                check: "check";
                test: "test";
            }>>;
            cwd: z.ZodString;
            argv: z.ZodArray<z.ZodString>;
            report: z.ZodOptional<z.ZodString>;
            field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        }, z.core.$strict>>;
        tools: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            provider: z.ZodEnum<{
                path: "path";
                project: "project";
            }>;
            found: z.ZodBoolean;
            version: z.ZodOptional<z.ZodString>;
            required: z.ZodArray<z.ZodObject<{
                version: z.ZodString;
                source: z.ZodString;
            }, z.core.$strict>>;
            usedBy: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        lockfiles: z.ZodArray<z.ZodObject<{
            dir: z.ZodString;
            files: z.ZodArray<z.ZodString>;
            manager: z.ZodOptional<z.ZodString>;
            selectedBy: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        reports: z.ZodArray<z.ZodObject<{
            gate: z.ZodString;
            path: z.ZodString;
            cwd: z.ZodString;
        }, z.core.$strict>>;
        ambiguities: z.ZodArray<z.ZodObject<{
            field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            path: z.ZodOptional<z.ZodString>;
            message: z.ZodString;
            resolvedBy: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        problems: z.ZodArray<z.ZodObject<{
            code: z.ZodString;
            field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            path: z.ZodOptional<z.ZodString>;
            message: z.ZodString;
        }, z.core.$strict>>;
        warnings: z.ZodArray<z.ZodObject<{
            code: z.ZodString;
            field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            path: z.ZodOptional<z.ZodString>;
            message: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    problems: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const profileDataSchema: z.ZodObject<{
    pin: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        source: z.ZodOptional<z.ZodObject<{
            repositoryId: z.ZodString;
            path: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    profile: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        capabilities: z.ZodArray<z.ZodString>;
        gates: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"test">;
            report: z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>;
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"check">;
            report: z.ZodOptional<z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>>;
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>], "kind">>;
        prepare: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
        environment: z.ZodOptional<z.ZodObject<{
            inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
            values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        }, z.core.$strict>>;
        lifecycle: z.ZodOptional<z.ZodObject<{
            setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            teardown: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        toolchain: z.ZodOptional<z.ZodObject<{
            tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
                npm: "npm";
                pnpm: "pnpm";
            }>>>;
        }, z.core.$strict>>;
        protectedPaths: z.ZodArray<z.ZodString>;
        generatedPaths: z.ZodArray<z.ZodString>;
        concurrency: z.ZodOptional<z.ZodNumber>;
        runTimeoutMs: z.ZodOptional<z.ZodNumber>;
        roles: z.ZodRecord<z.ZodString, z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
            writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
            reviewer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            title: z.ZodOptional<z.ZodString>;
            requiresContract: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        contextPacks: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            repositoryId: z.ZodOptional<z.ZodString>;
            roles: z.ZodDefault<z.ZodArray<z.ZodString>>;
            files: z.ZodArray<z.ZodString>;
            references: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        source: z.ZodOptional<z.ZodObject<{
            repositoryId: z.ZodString;
            path: z.ZodString;
        }, z.core.$strict>>;
        closure: z.ZodArray<z.ZodObject<{
            ref: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const versionDataSchema: z.ZodObject<{
    harness: z.ZodString;
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
}, z.core.$strict>;
export declare const sourceCheckDataSchema: z.ZodObject<{
    provider: z.ZodEnum<{
        "relay-v1-http": "relay-v1-http";
        "relay-v2-cli": "relay-v2-cli";
    }>;
    projectId: z.ZodString;
    connector: z.ZodString;
    connected: z.ZodBoolean;
    projectMatches: z.ZodBoolean;
    identity: z.ZodOptional<z.ZodObject<{
        capabilities: z.ZodArray<z.ZodString>;
        build: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strict>>;
    history: z.ZodObject<{
        enabled: z.ZodBoolean;
        capability: z.ZodBoolean;
    }, z.core.$strict>;
    mapping: z.ZodArray<z.ZodObject<{
        ref: z.ZodString;
        key: z.ZodOptional<z.ZodString>;
        problems: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    ownership: z.ZodObject<{
        stateDir: z.ZodString;
        store: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    problems: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const sourceSnapshotDataSchema: z.ZodObject<{
    connector: z.ZodString;
    graphId: z.ZodString;
    graphDigest: z.ZodString;
    contextDigest: z.ZodString;
    revision: z.ZodString;
    created: z.ZodBoolean;
    eligible: z.ZodBoolean;
    problems: z.ZodArray<z.ZodString>;
    truncated: z.ZodArray<z.ZodString>;
    tasks: z.ZodArray<z.ZodObject<{
        identity: z.ZodString;
        key: z.ZodString;
        orderId: z.ZodString;
        semanticDigest: z.ZodString;
        casRevision: z.ZodNumber;
        column: z.ZodString;
    }, z.core.$strict>>;
    files: z.ZodObject<{
        graph: z.ZodString;
        context: z.ZodString;
        manifest: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const sourceStatusDataSchema: z.ZodObject<{
    connector: z.ZodString;
    provider: z.ZodEnum<{
        "relay-v1-http": "relay-v1-http";
        "relay-v2-cli": "relay-v2-cli";
    }>;
    projectId: z.ZodString;
    snapshot: z.ZodOptional<z.ZodObject<{
        revision: z.ZodString;
        graphId: z.ZodString;
    }, z.core.$strict>>;
    ownership: z.ZodObject<{
        stateDir: z.ZodString;
        store: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    tasks: z.ZodArray<z.ZodObject<{
        index: z.ZodNumber;
        ref: z.ZodString;
        key: z.ZodOptional<z.ZodString>;
        identity: z.ZodOptional<z.ZodString>;
        workId: z.ZodString;
        local: z.ZodObject<{
            status: z.ZodString;
            attempt: z.ZodOptional<z.ZodNumber>;
            resultSha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        deliveries: z.ZodArray<z.ZodObject<{
            status: z.ZodString;
            key: z.ZodString;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        operations: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            runId: z.ZodString;
            outcome: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
                intent: "intent";
                "in-progress": "in-progress";
            }>;
            reason: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            steps: z.ZodArray<z.ZodObject<{
                n: z.ZodNumber;
                kind: z.ZodString;
                status: z.ZodString;
                marker: z.ZodString;
            }, z.core.$strict>>;
            lease: z.ZodOptional<z.ZodObject<{
                owner: z.ZodString;
                expiresAt: z.ZodISODateTime;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        remote: z.ZodUnion<readonly [z.ZodObject<{
            reachable: z.ZodLiteral<true>;
            column: z.ZodString;
            casRevision: z.ZodNumber;
            semanticDigest: z.ZodString;
            matchesSnapshot: z.ZodBoolean;
            criteria: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                completed: z.ZodBoolean;
            }, z.core.$strict>>;
            markers: z.ZodRecord<z.ZodString, z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            reachable: z.ZodLiteral<false>;
            error: z.ZodString;
        }, z.core.$strict>]>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const sourceDeliverDataSchema: z.ZodObject<{
    connector: z.ZodString;
    deliveries: z.ZodArray<z.ZodObject<{
        workId: z.ZodString;
        outcome: z.ZodString;
        delivery: z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            operation: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const sourceReconcileDataSchema: z.ZodObject<{
    operation: z.ZodString;
    workId: z.ZodString;
    before: z.ZodString;
    after: z.ZodString;
    resolved: z.ZodBoolean;
    facts: z.ZodArray<z.ZodString>;
    delivery: z.ZodOptional<z.ZodArray<z.ZodObject<{
        sink: z.ZodString;
        key: z.ZodString;
        revision: z.ZodString;
        status: z.ZodEnum<{
            failed: "failed";
            pending: "pending";
            delivered: "delivered";
            conflict: "conflict";
            uncertain: "uncertain";
        }>;
        attempts: z.ZodNumber;
        lastError: z.ZodOptional<z.ZodString>;
        operation: z.ZodOptional<z.ZodString>;
        currentRevision: z.ZodOptional<z.ZodString>;
        receipt: z.ZodOptional<z.ZodString>;
        updatedAt: z.ZodISODateTime;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const cleanupDataSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    status: z.ZodLiteral<"nothing-pending">;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"cleaned">;
    receipts: z.ZodArray<z.ZodString>;
}, z.core.$strict>], "status">;
/** `init`: план или результат подготовки проекта. */
export declare const initDataSchema: z.ZodObject<{
    mode: z.ZodEnum<{
        plan: "plan";
        apply: "apply";
    }>;
    status: z.ZodEnum<{
        partial: "partial";
        complete: "complete";
        new: "new";
    }>;
    projectId: z.ZodString;
    root: z.ZodString;
    manifestPath: z.ZodString;
    manifest: z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        kind: z.ZodLiteral<"harness-project">;
        manifestVersion: z.ZodLiteral<1>;
        projectId: z.ZodString;
        root: z.ZodString;
        repository: z.ZodObject<{
            id: z.ZodString;
            targetRef: z.ZodString;
        }, z.core.$strict>;
        profile: z.ZodObject<{
            ref: z.ZodString;
            pin: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodString;
                digest: z.ZodString;
                source: z.ZodOptional<z.ZodObject<{
                    repositoryId: z.ZodString;
                    path: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        runtimes: z.ZodObject<{
            writer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
        }, z.core.$strict>;
        paths: z.ZodObject<{
            policy: z.ZodLiteral<".harness/policy.json">;
            work: z.ZodLiteral<".harness/work">;
            notes: z.ZodLiteral<".harness/work/context/notes">;
            state: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>;
    files: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        action: z.ZodEnum<{
            conflict: "conflict";
            create: "create";
            preserve: "preserve";
        }>;
        conflict: z.ZodOptional<z.ZodEnum<{
            symlink: "symlink";
            "ancestor-not-directory": "ancestor-not-directory";
            "not-regular-file": "not-regular-file";
            "content-differs": "content-differs";
            "outside-root": "outside-root";
        }>>;
        conflictPath: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    conflicts: z.ZodNumber;
    created: z.ZodArray<z.ZodString>;
    preserved: z.ZodArray<z.ZodString>;
    profile: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        source: z.ZodOptional<z.ZodObject<{
            repositoryId: z.ZodString;
            path: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    shadowed: z.ZodArray<z.ZodString>;
    facts: z.ZodObject<{
        repositoryId: z.ZodString;
        targetRef: z.ZodString;
        roles: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        gates: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                check: "check";
                test: "test";
            }>;
        }, z.core.$strict>>;
        workDir: z.ZodString;
        contextDir: z.ZodString;
        notesDir: z.ZodString;
    }, z.core.$strict>;
    toolchain: z.ZodObject<{
        ready: z.ZodBoolean;
        problems: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    next: z.ZodArray<z.ZodObject<{
        command: z.ZodString;
        args: z.ZodArray<z.ZodString>;
        why: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** `explain`: объяснения остановок. */
export declare const explainDataSchema: z.ZodObject<{
    diagnoses: z.ZodArray<z.ZodObject<{
        code: z.ZodEnum<{
            INVALID_INPUT: "INVALID_INPUT";
            UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
            UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
            GRAPH_CYCLE: "GRAPH_CYCLE";
            GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
            GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
            GATE_UNKNOWN: "GATE_UNKNOWN";
            GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
            REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
            REVIEWER_MISSING: "REVIEWER_MISSING";
            RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
            APPROVAL_STALE: "APPROVAL_STALE";
            APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
            LEASE_STALE: "LEASE_STALE";
            CONTROLLER_BUSY: "CONTROLLER_BUSY";
            PAUSED: "PAUSED";
            NOT_READY: "NOT_READY";
            SCOPE_VIOLATION: "SCOPE_VIOLATION";
            GATE_FAILED: "GATE_FAILED";
            REVIEW_REJECTED: "REVIEW_REJECTED";
            BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
            BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
            ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
            REVISION_CONFLICT: "REVISION_CONFLICT";
            CANCELLED: "CANCELLED";
            NOT_FOUND: "NOT_FOUND";
            PATH_CONFLICT: "PATH_CONFLICT";
            STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
            RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
            REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
            SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
            GIT_FAILED: "GIT_FAILED";
            STORAGE_FAILED: "STORAGE_FAILED";
            DELIVERY_FAILED: "DELIVERY_FAILED";
            INTERNAL: "INTERNAL";
        }>;
        cause: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            environment: "environment";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "runtime-missing": "runtime-missing";
            "controller-busy": "controller-busy";
            "operator-pause": "operator-pause";
            "approval-required": "approval-required";
            "not-ready": "not-ready";
        }>;
        phase: z.ZodEnum<{
            gates: "gates";
            preflight: "preflight";
            review: "review";
            integration: "integration";
            delivery: "delivery";
            claim: "claim";
            implementation: "implementation";
        }>;
        actor: z.ZodNullable<z.ZodEnum<{
            controller: "controller";
            lead: "lead";
            user: "user";
        }>>;
        action: z.ZodEnum<{
            none: "none";
            wait: "wait";
            retry: "retry";
            "review-plan": "review-plan";
            "diagnose-failure": "diagnose-failure";
            "reset-attempts": "reset-attempts";
            "raise-budget": "raise-budget";
            "replan-dependents": "replan-dependents";
            "recovery-decision": "recovery-decision";
            "user-decision": "user-decision";
            "resume-queue": "resume-queue";
            "fix-environment": "fix-environment";
            "fix-access": "fix-access";
        }>;
        retryPlanned: z.ZodBoolean;
        message: z.ZodString;
        evidence: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                attempt: "attempt";
                evidence: "evidence";
                event: "event";
                doctor: "doctor";
            }>;
            id: z.ZodString;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** Схема `data` каждой команды. */
export declare const cliDataSchemas: {
    readonly validate: z.ZodObject<{
        graphId: z.ZodString;
        graphDigest: z.ZodString;
        policyDigest: z.ZodString;
        contextDigest: z.ZodOptional<z.ZodString>;
        orders: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'review-plan': z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        at: z.ZodISODateTime;
        approved: z.ZodBoolean;
        summary: z.ZodString;
        authorRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
            external: "external";
        }>;
        reviewerRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewerModel: z.ZodOptional<z.ZodString>;
        sameVendor: z.ZodBoolean;
        reviewerBinding: z.ZodOptional<z.ZodString>;
        contextDigest: z.ZodOptional<z.ZodString>;
        findings: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            severity: z.ZodEnum<{
                blocking: "blocking";
                note: "note";
            }>;
            message: z.ZodString;
            rule: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            status: z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>;
            openedIn: z.ZodNumber;
            changedIn: z.ZodNumber;
            basis: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        artifact: z.ZodString;
    }, z.core.$strict>;
    readonly 'review-contract': z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        at: z.ZodISODateTime;
        approved: z.ZodBoolean;
        summary: z.ZodString;
        authorRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
            external: "external";
        }>;
        reviewerRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewerModel: z.ZodOptional<z.ZodString>;
        sameVendor: z.ZodBoolean;
        reviewerBinding: z.ZodOptional<z.ZodString>;
        contextDigest: z.ZodOptional<z.ZodString>;
        findings: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            severity: z.ZodEnum<{
                blocking: "blocking";
                note: "note";
            }>;
            message: z.ZodString;
            rule: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            status: z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>;
            openedIn: z.ZodNumber;
            changedIn: z.ZodNumber;
            basis: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        artifact: z.ZodString;
    }, z.core.$strict>;
    readonly approve: z.ZodObject<{
        subject: z.ZodString;
        digest: z.ZodString;
        at: z.ZodISODateTime;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly run: z.ZodObject<{
        graphId: z.ZodString;
        digest: z.ZodString;
        resumed: z.ZodBoolean;
        works: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            status: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            runId: z.ZodOptional<z.ZodString>;
            resultSha: z.ZodOptional<z.ZodString>;
            blockers: z.ZodArray<z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workflow: z.ZodOptional<z.ZodObject<{
            key: z.ZodString;
            kind: z.ZodString;
            id: z.ZodString;
            stage: z.ZodNumber;
            status: z.ZodEnum<{
                failed: "failed";
                completed: "completed";
                running: "running";
                queued: "queued";
                stale: "stale";
            }>;
            attempts: z.ZodNumber;
            repairs: z.ZodNumber;
            repairBudget: z.ZodNumber;
            error: z.ZodOptional<z.ZodString>;
            history: z.ZodArray<z.ZodObject<{
                at: z.ZodISODateTime;
                stage: z.ZodNumber;
                event: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly status: z.ZodObject<{
        stateVersion: z.ZodLiteral<1>;
        control: z.ZodObject<{
            paused: z.ZodBoolean;
            pauseReason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            pausedAt: z.ZodOptional<z.ZodISODateTime>;
            pauseOperation: z.ZodOptional<z.ZodString>;
            pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
            }>>>;
            waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    "base-check": "base-check";
                    "context-lock": "context-lock";
                }>;
                detail: z.ZodString;
                at: z.ZodISODateTime;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            appliedPolicy: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodOptional<z.ZodNumber>;
                at: z.ZodISODateTime;
                by: z.ZodString;
            }, z.core.$strict>>;
            reconfigure: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                requestedAt: z.ZodISODateTime;
                appliedAt: z.ZodOptional<z.ZodISODateTime>;
                appliedBy: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        controller: z.ZodOptional<z.ZodObject<{
            owner: z.ZodString;
            leaseUntil: z.ZodNumber;
            engineVersion: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        graphs: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            digest: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            approved: z.ZodBoolean;
        }, z.core.$strict>>;
        works: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            graphId: z.ZodString;
            status: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            attempt: z.ZodNumber;
            activeRunId: z.ZodOptional<z.ZodString>;
            resultSha: z.ZodOptional<z.ZodString>;
            blockers: z.ZodArray<z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        budgets: z.ZodOptional<z.ZodObject<{
            onUnknown: z.ZodEnum<{
                stop: "stop";
                continue: "continue";
            }>;
            budgets: z.ZodArray<z.ZodObject<{
                scope: z.ZodObject<{
                    kind: z.ZodEnum<{
                        work: "work";
                        group: "group";
                        total: "total";
                    }>;
                    id: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                state: z.ZodEnum<{
                    exceeded: "exceeded";
                    undetermined: "undetermined";
                    within: "within";
                }>;
                limit: z.ZodObject<{
                    usd: z.ZodOptional<z.ZodNumber>;
                    timeMs: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>;
                reportedUsd: z.ZodNumber;
                estimatedUsd: z.ZodNumber;
                unknownCalls: z.ZodNumber;
                unfinishedCalls: z.ZodNumber;
                abandonedCalls: z.ZodNumber;
                errorCalls: z.ZodNumber;
                uncoveredRuns: z.ZodNumber;
                durationMs: z.ZodNumber;
                remainingUsd: z.ZodNullable<z.ZodNumber>;
                remainingMs: z.ZodNullable<z.ZodNumber>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly events: z.ZodObject<{
        events: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            seq: z.ZodNumber;
            at: z.ZodISODateTime;
            graphId: z.ZodOptional<z.ZodString>;
            workId: z.ZodOptional<z.ZodString>;
            runId: z.ZodOptional<z.ZodString>;
            attempt: z.ZodOptional<z.ZodNumber>;
            type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
            payload: z.ZodObject<{
                digest: z.ZodString;
                orders: z.ZodNumber;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
            }, z.core.$strict> | z.ZodObject<{
                kind: z.ZodEnum<{
                    plan: "plan";
                    contract: "contract";
                }>;
                subject: z.ZodString;
                digest: z.ZodString;
                round: z.ZodNumber;
                approved: z.ZodBoolean;
                open: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                actor: z.ZodEnum<{
                    agent: "agent";
                    operator: "operator";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                orderDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
                released: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                policyDigest: z.ZodString;
                engineVersion: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    ready: "ready";
                    failed: "failed";
                    cancelled: "cancelled";
                    draft: "draft";
                    running: "running";
                    verifying: "verifying";
                    reviewing: "reviewing";
                    integrating: "integrating";
                    done: "done";
                }>;
                sha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                sameVendor: z.ZodBoolean;
                blocking: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                failureKind: z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    environment: "environment";
                    cancelled: "cancelled";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                }>;
                message: z.ZodString;
                blocked: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                leaseUntil: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                integrationSha: z.ZodString;
                accepted: z.ZodBoolean;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                resultSha: z.ZodString;
                integrationSha: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                code: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
                failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    environment: "environment";
                    cancelled: "cancelled";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                }>>>;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                scope: z.ZodEnum<{
                    work: "work";
                    group: "group";
                    total: "total";
                }>;
                scopeId: z.ZodOptional<z.ZodString>;
                state: z.ZodEnum<{
                    exceeded: "exceeded";
                    undetermined: "undetermined";
                }>;
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                suite: z.ZodString;
                pending: z.ZodString;
                version: z.ZodNumber;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    completed: "completed";
                    waiting: "waiting";
                }>;
                accepted: z.ZodArray<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                recoveryId: z.ZodString;
                property: z.ZodString;
                status: z.ZodEnum<{
                    closed: "closed";
                    stopped: "stopped";
                    "awaiting-lead": "awaiting-lead";
                    analyzing: "analyzing";
                    applying: "applying";
                    retry: "retry";
                    retrying: "retrying";
                    "awaiting-user": "awaiting-user";
                }>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                workIds: z.ZodArray<z.ZodString>;
                policyDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                }>;
                manifestDigest: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodNumber;
                by: z.ZodString;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    failed: "failed";
                    requested: "requested";
                    cleared: "cleared";
                }>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                receipt: z.ZodOptional<z.ZodString>;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                error: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                currentRevision: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict>;
        }, z.core.$strict>, ...z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            seq: z.ZodNumber;
            at: z.ZodISODateTime;
            graphId: z.ZodOptional<z.ZodString>;
            workId: z.ZodOptional<z.ZodString>;
            runId: z.ZodOptional<z.ZodString>;
            attempt: z.ZodOptional<z.ZodNumber>;
            type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
            payload: z.ZodObject<{
                digest: z.ZodString;
                orders: z.ZodNumber;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
            }, z.core.$strict> | z.ZodObject<{
                kind: z.ZodEnum<{
                    plan: "plan";
                    contract: "contract";
                }>;
                subject: z.ZodString;
                digest: z.ZodString;
                round: z.ZodNumber;
                approved: z.ZodBoolean;
                open: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                actor: z.ZodEnum<{
                    agent: "agent";
                    operator: "operator";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                orderDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
                released: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                policyDigest: z.ZodString;
                engineVersion: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    ready: "ready";
                    failed: "failed";
                    cancelled: "cancelled";
                    draft: "draft";
                    running: "running";
                    verifying: "verifying";
                    reviewing: "reviewing";
                    integrating: "integrating";
                    done: "done";
                }>;
                sha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                evidenceId: z.ZodString;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                sameVendor: z.ZodBoolean;
                blocking: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                failureKind: z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    environment: "environment";
                    cancelled: "cancelled";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                }>;
                message: z.ZodString;
                blocked: z.ZodBoolean;
            }, z.core.$strict> | z.ZodObject<{
                leaseUntil: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                integrationSha: z.ZodString;
                accepted: z.ZodBoolean;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                resultSha: z.ZodString;
                integrationSha: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                code: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
                failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    environment: "environment";
                    cancelled: "cancelled";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                }>>>;
            }, z.core.$strict> | z.ZodObject<{
                reason: z.ZodEnum<{
                    runtime: "runtime";
                    operator: "operator";
                    shutdown: "shutdown";
                    "base-check": "base-check";
                    reconfigure: "reconfigure";
                }>;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                owner: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                scope: z.ZodEnum<{
                    work: "work";
                    group: "group";
                    total: "total";
                }>;
                scopeId: z.ZodOptional<z.ZodString>;
                state: z.ZodEnum<{
                    exceeded: "exceeded";
                    undetermined: "undetermined";
                }>;
                reason: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                suite: z.ZodString;
                pending: z.ZodString;
                version: z.ZodNumber;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    completed: "completed";
                    waiting: "waiting";
                }>;
                accepted: z.ZodArray<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                recoveryId: z.ZodString;
                property: z.ZodString;
                status: z.ZodEnum<{
                    closed: "closed";
                    stopped: "stopped";
                    "awaiting-lead": "awaiting-lead";
                    analyzing: "analyzing";
                    applying: "applying";
                    retry: "retry";
                    retrying: "retrying";
                    "awaiting-user": "awaiting-user";
                }>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                workIds: z.ZodArray<z.ZodString>;
                policyDigest: z.ZodString;
            }, z.core.$strict> | z.ZodObject<{
                verificationId: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                }>;
                manifestDigest: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodNumber;
                by: z.ZodString;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                status: z.ZodEnum<{
                    failed: "failed";
                    requested: "requested";
                    cleared: "cleared";
                }>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict> | z.ZodObject<{
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                receipt: z.ZodOptional<z.ZodString>;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                error: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                currentRevision: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict> | z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                attempts: z.ZodNumber;
            }, z.core.$strict>;
        }, z.core.$strict>[]], "type">>;
        next: z.ZodNumber;
    }, z.core.$strict>;
    readonly pause: z.ZodObject<{
        control: z.ZodObject<{
            paused: z.ZodBoolean;
            pauseReason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            pausedAt: z.ZodOptional<z.ZodISODateTime>;
            pauseOperation: z.ZodOptional<z.ZodString>;
            pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
            }>>>;
            waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    "base-check": "base-check";
                    "context-lock": "context-lock";
                }>;
                detail: z.ZodString;
                at: z.ZodISODateTime;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            appliedPolicy: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodOptional<z.ZodNumber>;
                at: z.ZodISODateTime;
                by: z.ZodString;
            }, z.core.$strict>>;
            reconfigure: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                requestedAt: z.ZodISODateTime;
                appliedAt: z.ZodOptional<z.ZodISODateTime>;
                appliedBy: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly resume: z.ZodObject<{
        control: z.ZodObject<{
            paused: z.ZodBoolean;
            pauseReason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            pausedAt: z.ZodOptional<z.ZodISODateTime>;
            pauseOperation: z.ZodOptional<z.ZodString>;
            pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
            }>>>;
            waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    "base-check": "base-check";
                    "context-lock": "context-lock";
                }>;
                detail: z.ZodString;
                at: z.ZodISODateTime;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            appliedPolicy: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodOptional<z.ZodNumber>;
                at: z.ZodISODateTime;
                by: z.ZodString;
            }, z.core.$strict>>;
            reconfigure: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                requestedAt: z.ZodISODateTime;
                appliedAt: z.ZodOptional<z.ZodISODateTime>;
                appliedBy: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly cancel: z.ZodObject<{
        workId: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly retry: z.ZodObject<{
        workId: z.ZodString;
        status: z.ZodEnum<{
            ready: "ready";
            failed: "failed";
            cancelled: "cancelled";
            draft: "draft";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        changed: z.ZodBoolean;
    }, z.core.$strict>;
    readonly result: z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        result: z.ZodDiscriminatedUnion<[z.ZodObject<{
            outcome: z.ZodLiteral<"accepted">;
            shas: z.ZodObject<{
                base: z.ZodString;
                candidate: z.ZodString;
                integration: z.ZodString;
                result: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    property: "property";
                    review: "review";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodString;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            outcome: z.ZodEnum<{
                rejected: "rejected";
                blocked: "blocked";
                cancelled: "cancelled";
                stopped: "stopped";
            }>;
            shas: z.ZodObject<{
                base: z.ZodOptional<z.ZodString>;
                candidate: z.ZodOptional<z.ZodString>;
                integration: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            stopReason: z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    property: "property";
                    review: "review";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodString;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>], "outcome">;
        delivery: z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            operation: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly deliver: z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        result: z.ZodDiscriminatedUnion<[z.ZodObject<{
            outcome: z.ZodLiteral<"accepted">;
            shas: z.ZodObject<{
                base: z.ZodString;
                candidate: z.ZodString;
                integration: z.ZodString;
                result: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    property: "property";
                    review: "review";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodString;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            outcome: z.ZodEnum<{
                rejected: "rejected";
                blocked: "blocked";
                cancelled: "cancelled";
                stopped: "stopped";
            }>;
            shas: z.ZodObject<{
                base: z.ZodOptional<z.ZodString>;
                candidate: z.ZodOptional<z.ZodString>;
                integration: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            stopReason: z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    property: "property";
                    review: "review";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodString;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>], "outcome">;
        delivery: z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            operation: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly cleanup: z.ZodDiscriminatedUnion<[z.ZodObject<{
        status: z.ZodLiteral<"nothing-pending">;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodLiteral<"cleaned">;
        receipts: z.ZodArray<z.ZodString>;
    }, z.core.$strict>], "status">;
    readonly profile: z.ZodObject<{
        pin: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            source: z.ZodOptional<z.ZodObject<{
                repositoryId: z.ZodString;
                path: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        profile: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            capabilities: z.ZodArray<z.ZodString>;
            gates: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"test">;
                report: z.ZodObject<{
                    type: z.ZodLiteral<"junit">;
                    path: z.ZodString;
                }, z.core.$strict>;
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
                property: z.ZodOptional<z.ZodObject<{
                    path: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
                cwd: z.ZodOptional<z.ZodString>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"check">;
                report: z.ZodOptional<z.ZodObject<{
                    type: z.ZodLiteral<"junit">;
                    path: z.ZodString;
                }, z.core.$strict>>;
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
                property: z.ZodOptional<z.ZodObject<{
                    path: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
                cwd: z.ZodOptional<z.ZodString>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>], "kind">>;
            prepare: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
            environment: z.ZodOptional<z.ZodObject<{
                inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
                values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
                secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            }, z.core.$strict>>;
            lifecycle: z.ZodOptional<z.ZodObject<{
                setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>>;
                ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>>;
                teardown: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            toolchain: z.ZodOptional<z.ZodObject<{
                tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
                packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
                    npm: "npm";
                    pnpm: "pnpm";
                }>>>;
            }, z.core.$strict>>;
            protectedPaths: z.ZodArray<z.ZodString>;
            generatedPaths: z.ZodArray<z.ZodString>;
            concurrency: z.ZodOptional<z.ZodNumber>;
            runTimeoutMs: z.ZodOptional<z.ZodNumber>;
            roles: z.ZodRecord<z.ZodString, z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
                writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                title: z.ZodOptional<z.ZodString>;
                requiresContract: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strict>>;
            contextPacks: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                version: z.ZodString;
                repositoryId: z.ZodOptional<z.ZodString>;
                roles: z.ZodDefault<z.ZodArray<z.ZodString>>;
                files: z.ZodArray<z.ZodString>;
                references: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            source: z.ZodOptional<z.ZodObject<{
                repositoryId: z.ZodString;
                path: z.ZodString;
            }, z.core.$strict>>;
            closure: z.ZodArray<z.ZodObject<{
                ref: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    readonly doctor: z.ZodObject<{
        harness: z.ZodString;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        node: z.ZodString;
        platform: z.ZodString;
        runtimes: z.ZodArray<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            available: z.ZodBoolean;
            version: z.ZodOptional<z.ZodString>;
            structuredOutput: z.ZodBoolean;
            cancellation: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        sandbox: z.ZodObject<{
            os: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        state: z.ZodOptional<z.ZodObject<{
            stateVersion: z.ZodNumber;
            compatible: z.ZodBoolean;
            writer: z.ZodOptional<z.ZodString>;
            engineVersions: z.ZodOptional<z.ZodObject<{
                controller: z.ZodOptional<z.ZodString>;
                attempts: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        toolchains: z.ZodOptional<z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            root: z.ZodString;
            configSource: z.ZodOptional<z.ZodString>;
            plan: z.ZodArray<z.ZodObject<{
                phase: z.ZodEnum<{
                    gate: "gate";
                    prepare: "prepare";
                    dependencyBuild: "dependencyBuild";
                    preflight: "preflight";
                    setup: "setup";
                    ready: "ready";
                    teardown: "teardown";
                }>;
                id: z.ZodString;
                kind: z.ZodOptional<z.ZodEnum<{
                    check: "check";
                    test: "test";
                }>>;
                cwd: z.ZodString;
                argv: z.ZodArray<z.ZodString>;
                report: z.ZodOptional<z.ZodString>;
                field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            }, z.core.$strict>>;
            tools: z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                provider: z.ZodEnum<{
                    path: "path";
                    project: "project";
                }>;
                found: z.ZodBoolean;
                version: z.ZodOptional<z.ZodString>;
                required: z.ZodArray<z.ZodObject<{
                    version: z.ZodString;
                    source: z.ZodString;
                }, z.core.$strict>>;
                usedBy: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
            lockfiles: z.ZodArray<z.ZodObject<{
                dir: z.ZodString;
                files: z.ZodArray<z.ZodString>;
                manager: z.ZodOptional<z.ZodString>;
                selectedBy: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            reports: z.ZodArray<z.ZodObject<{
                gate: z.ZodString;
                path: z.ZodString;
                cwd: z.ZodString;
            }, z.core.$strict>>;
            ambiguities: z.ZodArray<z.ZodObject<{
                field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                path: z.ZodOptional<z.ZodString>;
                message: z.ZodString;
                resolvedBy: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            problems: z.ZodArray<z.ZodObject<{
                code: z.ZodString;
                field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                path: z.ZodOptional<z.ZodString>;
                message: z.ZodString;
            }, z.core.$strict>>;
            warnings: z.ZodArray<z.ZodObject<{
                code: z.ZodString;
                field: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                path: z.ZodOptional<z.ZodString>;
                message: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        problems: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    readonly init: z.ZodObject<{
        mode: z.ZodEnum<{
            plan: "plan";
            apply: "apply";
        }>;
        status: z.ZodEnum<{
            partial: "partial";
            complete: "complete";
            new: "new";
        }>;
        projectId: z.ZodString;
        root: z.ZodString;
        manifestPath: z.ZodString;
        manifest: z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            kind: z.ZodLiteral<"harness-project">;
            manifestVersion: z.ZodLiteral<1>;
            projectId: z.ZodString;
            root: z.ZodString;
            repository: z.ZodObject<{
                id: z.ZodString;
                targetRef: z.ZodString;
            }, z.core.$strict>;
            profile: z.ZodObject<{
                ref: z.ZodString;
                pin: z.ZodObject<{
                    id: z.ZodString;
                    version: z.ZodString;
                    digest: z.ZodString;
                    source: z.ZodOptional<z.ZodObject<{
                        repositoryId: z.ZodString;
                        path: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            runtimes: z.ZodObject<{
                writer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                reviewer: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
            }, z.core.$strict>;
            paths: z.ZodObject<{
                policy: z.ZodLiteral<".harness/policy.json">;
                work: z.ZodLiteral<".harness/work">;
                notes: z.ZodLiteral<".harness/work/context/notes">;
                state: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict>;
        files: z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            action: z.ZodEnum<{
                conflict: "conflict";
                create: "create";
                preserve: "preserve";
            }>;
            conflict: z.ZodOptional<z.ZodEnum<{
                symlink: "symlink";
                "ancestor-not-directory": "ancestor-not-directory";
                "not-regular-file": "not-regular-file";
                "content-differs": "content-differs";
                "outside-root": "outside-root";
            }>>;
            conflictPath: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        conflicts: z.ZodNumber;
        created: z.ZodArray<z.ZodString>;
        preserved: z.ZodArray<z.ZodString>;
        profile: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            source: z.ZodOptional<z.ZodObject<{
                repositoryId: z.ZodString;
                path: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        shadowed: z.ZodArray<z.ZodString>;
        facts: z.ZodObject<{
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            roles: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            gates: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                }>;
            }, z.core.$strict>>;
            workDir: z.ZodString;
            contextDir: z.ZodString;
            notesDir: z.ZodString;
        }, z.core.$strict>;
        toolchain: z.ZodObject<{
            ready: z.ZodBoolean;
            problems: z.ZodArray<z.ZodString>;
        }, z.core.$strict>;
        next: z.ZodArray<z.ZodObject<{
            command: z.ZodString;
            args: z.ZodArray<z.ZodString>;
            why: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly explain: z.ZodObject<{
        diagnoses: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            cause: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "runtime-missing": "runtime-missing";
                "controller-busy": "controller-busy";
                "operator-pause": "operator-pause";
                "approval-required": "approval-required";
                "not-ready": "not-ready";
            }>;
            phase: z.ZodEnum<{
                gates: "gates";
                preflight: "preflight";
                review: "review";
                integration: "integration";
                delivery: "delivery";
                claim: "claim";
                implementation: "implementation";
            }>;
            actor: z.ZodNullable<z.ZodEnum<{
                controller: "controller";
                lead: "lead";
                user: "user";
            }>>;
            action: z.ZodEnum<{
                none: "none";
                wait: "wait";
                retry: "retry";
                "review-plan": "review-plan";
                "diagnose-failure": "diagnose-failure";
                "reset-attempts": "reset-attempts";
                "raise-budget": "raise-budget";
                "replan-dependents": "replan-dependents";
                "recovery-decision": "recovery-decision";
                "user-decision": "user-decision";
                "resume-queue": "resume-queue";
                "fix-environment": "fix-environment";
                "fix-access": "fix-access";
            }>;
            retryPlanned: z.ZodBoolean;
            message: z.ZodString;
            evidence: z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    attempt: "attempt";
                    evidence: "evidence";
                    event: "event";
                    doctor: "doctor";
                }>;
                id: z.ZodString;
                sha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            workId: z.ZodOptional<z.ZodString>;
            runId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'plan-request': z.ZodObject<{
        prompt: z.ZodString;
        readOnly: z.ZodLiteral<true>;
        recommendedTasks: z.ZodNumber;
        maxTasks: z.ZodLiteral<30>;
        basis: z.ZodString;
        facts: z.ZodObject<{
            repositories: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodOptional<z.ZodString>;
                kind: z.ZodOptional<z.ZodString>;
                path: z.ZodString;
            }, z.core.$strict>>;
            roles: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                roles: z.ZodArray<z.ZodObject<{
                    role: z.ZodString;
                    title: z.ZodOptional<z.ZodString>;
                    writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    requiresContract: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            gates: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodString;
                }, z.core.$strict>>;
                groups: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
            }, z.core.$strict>>;
            contextPacks: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                version: z.ZodOptional<z.ZodString>;
                repositoryId: z.ZodOptional<z.ZodString>;
                roles: z.ZodOptional<z.ZodArray<z.ZodString>>;
                files: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            resources: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodString;
            }, z.core.$strict>>;
            contracts: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                digest: z.ZodString;
            }, z.core.$loose>>;
        }, z.core.$strict>;
        draftSchema: z.ZodLiteral<"plan-draft">;
    }, z.core.$strict>;
    readonly 'plan-check': z.ZodObject<{
        issues: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            message: z.ZodString;
        }, z.core.$strict>>;
        checkPlan: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                "gate-undeclared": "gate-undeclared";
                "test-gate-missing": "test-gate-missing";
            }>;
            taskKey: z.ZodString;
            repositoryId: z.ZodString;
            ref: z.ZodOptional<z.ZodString>;
            testGates: z.ZodArray<z.ZodString>;
            action: z.ZodEnum<{
                "declare-gate": "declare-gate";
                "add-test-gate": "add-test-gate";
            }>;
        }, z.core.$strict>>;
        graph: z.ZodOptional<z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            id: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            orders: z.ZodArray<z.ZodObject<{
                apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
                id: z.ZodString;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
                title: z.ZodString;
                goal: z.ZodString;
                acceptance: z.ZodArray<z.ZodString>;
                role: z.ZodString;
                repositoryId: z.ZodString;
                relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
                writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
                dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
                gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>>;
                properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
                requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    source: z.ZodString;
                    digest: z.ZodString;
                    text: z.ZodString;
                    gate: z.ZodString;
                    scenario: z.ZodString;
                    testId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>>;
                context: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            prerequisites: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                repositoryId: z.ZodString;
                resultSha: z.ZodString;
                receipt: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"engine">;
                    runId: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"trusted">;
                    issuer: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>], "kind">;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
        graphDigest: z.ZodOptional<z.ZodString>;
        basis: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    readonly 'source-check': z.ZodObject<{
        provider: z.ZodEnum<{
            "relay-v1-http": "relay-v1-http";
            "relay-v2-cli": "relay-v2-cli";
        }>;
        projectId: z.ZodString;
        connector: z.ZodString;
        connected: z.ZodBoolean;
        projectMatches: z.ZodBoolean;
        identity: z.ZodOptional<z.ZodObject<{
            capabilities: z.ZodArray<z.ZodString>;
            build: z.ZodRecord<z.ZodString, z.ZodString>;
        }, z.core.$strict>>;
        history: z.ZodObject<{
            enabled: z.ZodBoolean;
            capability: z.ZodBoolean;
        }, z.core.$strict>;
        mapping: z.ZodArray<z.ZodObject<{
            ref: z.ZodString;
            key: z.ZodOptional<z.ZodString>;
            problems: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        ownership: z.ZodObject<{
            stateDir: z.ZodString;
            store: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        problems: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    readonly 'source-snapshot': z.ZodObject<{
        connector: z.ZodString;
        graphId: z.ZodString;
        graphDigest: z.ZodString;
        contextDigest: z.ZodString;
        revision: z.ZodString;
        created: z.ZodBoolean;
        eligible: z.ZodBoolean;
        problems: z.ZodArray<z.ZodString>;
        truncated: z.ZodArray<z.ZodString>;
        tasks: z.ZodArray<z.ZodObject<{
            identity: z.ZodString;
            key: z.ZodString;
            orderId: z.ZodString;
            semanticDigest: z.ZodString;
            casRevision: z.ZodNumber;
            column: z.ZodString;
        }, z.core.$strict>>;
        files: z.ZodObject<{
            graph: z.ZodString;
            context: z.ZodString;
            manifest: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>;
    readonly 'source-status': z.ZodObject<{
        connector: z.ZodString;
        provider: z.ZodEnum<{
            "relay-v1-http": "relay-v1-http";
            "relay-v2-cli": "relay-v2-cli";
        }>;
        projectId: z.ZodString;
        snapshot: z.ZodOptional<z.ZodObject<{
            revision: z.ZodString;
            graphId: z.ZodString;
        }, z.core.$strict>>;
        ownership: z.ZodObject<{
            stateDir: z.ZodString;
            store: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        tasks: z.ZodArray<z.ZodObject<{
            index: z.ZodNumber;
            ref: z.ZodString;
            key: z.ZodOptional<z.ZodString>;
            identity: z.ZodOptional<z.ZodString>;
            workId: z.ZodString;
            local: z.ZodObject<{
                status: z.ZodString;
                attempt: z.ZodOptional<z.ZodNumber>;
                resultSha: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            deliveries: z.ZodArray<z.ZodObject<{
                status: z.ZodString;
                key: z.ZodString;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            operations: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                runId: z.ZodString;
                outcome: z.ZodString;
                status: z.ZodEnum<{
                    failed: "failed";
                    delivered: "delivered";
                    conflict: "conflict";
                    uncertain: "uncertain";
                    intent: "intent";
                    "in-progress": "in-progress";
                }>;
                reason: z.ZodOptional<z.ZodString>;
                currentRevision: z.ZodOptional<z.ZodString>;
                steps: z.ZodArray<z.ZodObject<{
                    n: z.ZodNumber;
                    kind: z.ZodString;
                    status: z.ZodString;
                    marker: z.ZodString;
                }, z.core.$strict>>;
                lease: z.ZodOptional<z.ZodObject<{
                    owner: z.ZodString;
                    expiresAt: z.ZodISODateTime;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            remote: z.ZodUnion<readonly [z.ZodObject<{
                reachable: z.ZodLiteral<true>;
                column: z.ZodString;
                casRevision: z.ZodNumber;
                semanticDigest: z.ZodString;
                matchesSnapshot: z.ZodBoolean;
                criteria: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    title: z.ZodString;
                    completed: z.ZodBoolean;
                }, z.core.$strict>>;
                markers: z.ZodRecord<z.ZodString, z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                reachable: z.ZodLiteral<false>;
                error: z.ZodString;
            }, z.core.$strict>]>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'source-deliver': z.ZodObject<{
        connector: z.ZodString;
        deliveries: z.ZodArray<z.ZodObject<{
            workId: z.ZodString;
            outcome: z.ZodString;
            delivery: z.ZodArray<z.ZodObject<{
                sink: z.ZodString;
                key: z.ZodString;
                revision: z.ZodString;
                status: z.ZodEnum<{
                    failed: "failed";
                    pending: "pending";
                    delivered: "delivered";
                    conflict: "conflict";
                    uncertain: "uncertain";
                }>;
                attempts: z.ZodNumber;
                lastError: z.ZodOptional<z.ZodString>;
                operation: z.ZodOptional<z.ZodString>;
                currentRevision: z.ZodOptional<z.ZodString>;
                receipt: z.ZodOptional<z.ZodString>;
                updatedAt: z.ZodISODateTime;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'source-reconcile': z.ZodObject<{
        operation: z.ZodString;
        workId: z.ZodString;
        before: z.ZodString;
        after: z.ZodString;
        resolved: z.ZodBoolean;
        facts: z.ZodArray<z.ZodString>;
        delivery: z.ZodOptional<z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            operation: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    readonly version: z.ZodObject<{
        harness: z.ZodString;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    }, z.core.$strict>;
};
export declare const cliErrorSchema: z.ZodObject<{
    code: z.ZodEnum<{
        INVALID_INPUT: "INVALID_INPUT";
        UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
        UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
        GRAPH_CYCLE: "GRAPH_CYCLE";
        GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
        GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
        GATE_UNKNOWN: "GATE_UNKNOWN";
        GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
        REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
        REVIEWER_MISSING: "REVIEWER_MISSING";
        RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
        APPROVAL_STALE: "APPROVAL_STALE";
        APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
        LEASE_STALE: "LEASE_STALE";
        CONTROLLER_BUSY: "CONTROLLER_BUSY";
        PAUSED: "PAUSED";
        NOT_READY: "NOT_READY";
        SCOPE_VIOLATION: "SCOPE_VIOLATION";
        GATE_FAILED: "GATE_FAILED";
        REVIEW_REJECTED: "REVIEW_REJECTED";
        BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
        BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
        ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
        REVISION_CONFLICT: "REVISION_CONFLICT";
        CANCELLED: "CANCELLED";
        NOT_FOUND: "NOT_FOUND";
        PATH_CONFLICT: "PATH_CONFLICT";
        STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
        RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
        REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
        SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
        GIT_FAILED: "GIT_FAILED";
        STORAGE_FAILED: "STORAGE_FAILED";
        DELIVERY_FAILED: "DELIVERY_FAILED";
        INTERNAL: "INTERNAL";
    }>;
    class: z.ZodEnum<{
        input: "input";
        refused: "refused";
        infrastructure: "infrastructure";
    }>;
    message: z.ZodString;
    issues: z.ZodArray<z.ZodObject<{
        path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        message: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CliEnvelope<C extends CliCommand | 'version' = CliCommand | 'version'> = {
    apiVersion: typeof API_VERSION;
    command: C;
    ok: true;
    data: z.infer<(typeof cliDataSchemas)[C]>;
} | {
    apiVersion: typeof API_VERSION;
    command: C | null;
    ok: false;
    error: z.infer<typeof cliErrorSchema>;
};
/** Входной документ контракта для `review-contract` — см. `checks.ts`. */
export { contractDocumentSchema, type ContractDocument } from './checks.ts';
