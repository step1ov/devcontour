import type { z } from 'zod';
/**
 * Схемы, публикуемые как JSON Schema (`schemas/<имя>.schema.json`).
 *
 * JSON Schema выражает всё, что относится к одному значению: типы,
 * обязательность, закрытость объектов, пределы, регулярные выражения путей
 * и refs, варианты исходов. Связи *между* значениями — граф без циклов и
 * неизвестных зависимостей, согласованность политики, связь поручений с
 * политикой, совпадение содержимого контекста с digests — проверяют
 * `graphIssues`, `policyIssues`, `crossIssues`, `contextIssues` и CLI
 * `harness validate`; JSON Schema их не заменяет.
 */
export declare const publishedSchemas: {
    readonly 'work-order': z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        title: z.ZodString;
        goal: z.ZodString;
        acceptance: z.ZodArray<z.ZodString>;
        role: z.ZodString;
        repositoryId: z.ZodString;
        relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
        writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
        dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
        gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
            repositoryId: z.ZodString;
            gates: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>>;
        properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            source: z.ZodString;
            digest: z.ZodString;
            text: z.ZodString;
            gate: z.ZodString;
            scenario: z.ZodString;
            testId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            digest: z.ZodString;
        }, z.core.$strict>>>;
        context: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>;
    readonly 'work-graph': z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        orders: z.ZodArray<z.ZodObject<{
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            id: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            title: z.ZodString;
            goal: z.ZodString;
            acceptance: z.ZodArray<z.ZodString>;
            role: z.ZodString;
            repositoryId: z.ZodString;
            relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
            writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
            dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
            gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>>;
            properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                source: z.ZodString;
                digest: z.ZodString;
                text: z.ZodString;
                gate: z.ZodString;
                scenario: z.ZodString;
                testId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>>;
            context: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        prerequisites: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            repositoryId: z.ZodString;
            resultSha: z.ZodString;
            receipt: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"engine">;
                runId: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"trusted">;
                issuer: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>], "kind">;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    readonly 'execution-policy': z.ZodObject<{
        policyVersion: z.ZodLiteral<1>;
        repositories: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            roles: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
                writer: z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
                review: z.ZodOptional<z.ZodObject<{
                    reviewer: z.ZodObject<{
                        runtime: z.ZodEnum<{
                            codex: "codex";
                            claude: "claude";
                            fixture: "fixture";
                        }>;
                        model: z.ZodOptional<z.ZodString>;
                        effort: z.ZodOptional<z.ZodEnum<{
                            low: "low";
                            medium: "medium";
                            high: "high";
                            xhigh: "xhigh";
                        }>>;
                        toolProfile: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>;
                    alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        runtime: z.ZodEnum<{
                            codex: "codex";
                            claude: "claude";
                            fixture: "fixture";
                        }>;
                        model: z.ZodOptional<z.ZodString>;
                        effort: z.ZodOptional<z.ZodEnum<{
                            low: "low";
                            medium: "medium";
                            high: "high";
                            xhigh: "xhigh";
                        }>>;
                        toolProfile: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>>;
                    vendor: z.ZodDefault<z.ZodEnum<{
                        "different-vendor": "different-vendor";
                        "same-vendor-allowed": "same-vendor-allowed";
                    }>>;
                }, z.core.$strict>>;
                requiresContract: z.ZodDefault<z.ZodBoolean>;
            }, z.core.$strict>>>;
            review: z.ZodOptional<z.ZodObject<{
                reviewer: z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                vendor: z.ZodDefault<z.ZodEnum<{
                    "different-vendor": "different-vendor";
                    "same-vendor-allowed": "same-vendor-allowed";
                }>>;
            }, z.core.$strict>>;
            path: z.ZodString;
            kind: z.ZodDefault<z.ZodEnum<{
                product: "product";
                library: "library";
            }>>;
            targetRef: z.ZodString;
            dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
            gates: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"test">;
                report: z.ZodObject<{
                    type: z.ZodLiteral<"junit">;
                    path: z.ZodString;
                }, z.core.$strict>;
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
                property: z.ZodOptional<z.ZodObject<{
                    path: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
                cwd: z.ZodOptional<z.ZodString>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"check">;
                report: z.ZodOptional<z.ZodObject<{
                    type: z.ZodLiteral<"junit">;
                    path: z.ZodString;
                }, z.core.$strict>>;
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
                property: z.ZodOptional<z.ZodObject<{
                    path: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
                cwd: z.ZodOptional<z.ZodString>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>], "kind">>;
            gateGroups: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
            protectedPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
            generatedPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
            environment: z.ZodOptional<z.ZodObject<{
                inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
                values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
                secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            }, z.core.$strict>>;
            lifecycle: z.ZodOptional<z.ZodObject<{
                setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>>;
                ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>>;
                teardown: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    command: z.ZodArray<z.ZodString>;
                    timeoutMs: z.ZodDefault<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            prepare: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            dependencyStore: z.ZodOptional<z.ZodObject<{
                manager: z.ZodEnum<{
                    pnpm: "pnpm";
                }>;
                lockfile: z.ZodDefault<z.ZodString>;
                maxBytes: z.ZodDefault<z.ZodNumber>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
            dependencyBuild: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            dependencyArtifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
            preflight: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            toolchain: z.ZodOptional<z.ZodObject<{
                tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
                packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
                    npm: "npm";
                    pnpm: "pnpm";
                }>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        roles: z.ZodRecord<z.ZodString, z.ZodObject<{
            writer: z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
            review: z.ZodOptional<z.ZodObject<{
                reviewer: z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                vendor: z.ZodDefault<z.ZodEnum<{
                    "different-vendor": "different-vendor";
                    "same-vendor-allowed": "same-vendor-allowed";
                }>>;
            }, z.core.$strict>>;
            requiresContract: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>>;
        review: z.ZodObject<{
            code: z.ZodObject<{
                reviewer: z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                vendor: z.ZodDefault<z.ZodEnum<{
                    "different-vendor": "different-vendor";
                    "same-vendor-allowed": "same-vendor-allowed";
                }>>;
            }, z.core.$strict>;
            plan: z.ZodObject<{
                reviewer: z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                vendor: z.ZodDefault<z.ZodEnum<{
                    "different-vendor": "different-vendor";
                    "same-vendor-allowed": "same-vendor-allowed";
                }>>;
            }, z.core.$strict>;
            contract: z.ZodObject<{
                reviewer: z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                alternates: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    effort: z.ZodOptional<z.ZodEnum<{
                        low: "low";
                        medium: "medium";
                        high: "high";
                        xhigh: "xhigh";
                    }>>;
                    toolProfile: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                vendor: z.ZodDefault<z.ZodEnum<{
                    "different-vendor": "different-vendor";
                    "same-vendor-allowed": "same-vendor-allowed";
                }>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        mode: z.ZodDefault<z.ZodEnum<{
            fixture: "fixture";
            live: "live";
        }>>;
        workspaceGates: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"test">;
            report: z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>;
            repositoryId: z.ZodString;
            artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"check">;
            report: z.ZodOptional<z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>>;
            repositoryId: z.ZodString;
            artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>], "kind">>>;
        workspaceLifecycle: z.ZodOptional<z.ZodObject<{
            setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            teardown: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        verificationMode: z.ZodDefault<z.ZodEnum<{
            all: "all";
            affected: "affected";
        }>>;
        approvalMode: z.ZodDefault<z.ZodEnum<{
            agent: "agent";
            operator: "operator";
        }>>;
        isolation: z.ZodDefault<z.ZodObject<{
            mode: z.ZodDefault<z.ZodEnum<{
                os: "os";
                none: "none";
            }>>;
            domains: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        toolProfiles: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            environment: z.ZodOptional<z.ZodObject<{
                inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
                values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
                secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            }, z.core.$strict>>;
            mcp: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
                transport: z.ZodEnum<{
                    stdio: "stdio";
                    http: "http";
                }>;
                command: z.ZodOptional<z.ZodString>;
                args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                env: z.ZodDefault<z.ZodArray<z.ZodString>>;
                url: z.ZodOptional<z.ZodURL>;
                bearerTokenEnv: z.ZodOptional<z.ZodString>;
                tools: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>>;
            claudeTools: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                Read: "Read";
                Glob: "Glob";
                Grep: "Grep";
                Edit: "Edit";
                Write: "Write";
                Bash: "Bash";
            }>>>;
            claudeAllowedTools: z.ZodDefault<z.ZodArray<z.ZodString>>;
            codexShell: z.ZodDefault<z.ZodBoolean>;
            codexNetwork: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>>>;
        environment: z.ZodOptional<z.ZodObject<{
            inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
            values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        }, z.core.$strict>>;
        lifecycle: z.ZodOptional<z.ZodObject<{
            setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            teardown: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        resources: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                device: "device";
                port: "port";
                account: "account";
                service: "service";
            }>;
            value: z.ZodString;
        }, z.core.$strict>>>;
        concurrency: z.ZodDefault<z.ZodNumber>;
        leaseMs: z.ZodDefault<z.ZodNumber>;
        runTimeoutMs: z.ZodDefault<z.ZodNumber>;
        reviewProbes: z.ZodDefault<z.ZodObject<{
            commandTimeoutMs: z.ZodDefault<z.ZodNumber>;
            budgetMs: z.ZodDefault<z.ZodNumber>;
            reserveMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
        reviewProtocolRetries: z.ZodOptional<z.ZodNumber>;
        maxAttempts: z.ZodDefault<z.ZodNumber>;
        repairBudget: z.ZodDefault<z.ZodNumber>;
        reuseImplementation: z.ZodDefault<z.ZodBoolean>;
        budgets: z.ZodOptional<z.ZodObject<{
            work: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                usd: z.ZodNumber;
                timeMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                usd: z.ZodOptional<z.ZodNumber>;
                timeMs: z.ZodNumber;
            }, z.core.$strict>]>>;
            group: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                usd: z.ZodNumber;
                timeMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                usd: z.ZodOptional<z.ZodNumber>;
                timeMs: z.ZodNumber;
            }, z.core.$strict>]>>;
            total: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                usd: z.ZodNumber;
                timeMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                usd: z.ZodOptional<z.ZodNumber>;
                timeMs: z.ZodNumber;
            }, z.core.$strict>]>>;
            onUnknown: z.ZodDefault<z.ZodEnum<{
                continue: "continue";
                stop: "stop";
            }>>;
        }, z.core.$strict>>;
        prices: z.ZodDefault<z.ZodArray<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            model: z.ZodString;
            effectiveAt: z.ZodISODateTime;
            input: z.ZodNumber;
            output: z.ZodNumber;
            cacheRead: z.ZodNumber;
            cacheWrite: z.ZodNumber;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    readonly 'context-snapshot': z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        sources: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodString;
            version: z.ZodString;
            repositoryId: z.ZodOptional<z.ZodString>;
            revision: z.ZodOptional<z.ZodString>;
            required: z.ZodBoolean;
            files: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
                bytes: z.ZodNumber;
                content: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    encoding: z.ZodLiteral<"utf8">;
                    data: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    encoding: z.ZodLiteral<"base64">;
                    data: z.ZodString;
                }, z.core.$strict>], "encoding">;
            }, z.core.$strict>>;
            references: z.ZodDefault<z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
                bytes: z.ZodNumber;
                content: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    encoding: z.ZodLiteral<"utf8">;
                    data: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    encoding: z.ZodLiteral<"base64">;
                    data: z.ZodString;
                }, z.core.$strict>], "encoding">;
            }, z.core.$strict>>>;
            digest: z.ZodString;
            hostDigest: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        missing: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            reason: z.ZodString;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    readonly 'contract-document': z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        repositoryId: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        content: z.ZodString;
        artifacts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            blob: z.ZodString;
        }, z.core.$strict>>>;
        checks: z.ZodOptional<z.ZodObject<{
            version: z.ZodLiteral<1>;
            gate: z.ZodString;
            obligations: z.ZodArray<z.ZodObject<{
                property: z.ZodString;
                requirements: z.ZodArray<z.ZodString>;
                promise: z.ZodEnum<{
                    functional: "functional";
                    accuracy: "accuracy";
                    optimality: "optimality";
                    completeness: "completeness";
                    performance: "performance";
                    invariant: "invariant";
                    other: "other";
                }>;
                explanation: z.ZodOptional<z.ZodString>;
                domain: z.ZodObject<{
                    inputs: z.ZodString;
                    bounds: z.ZodString;
                    units: z.ZodOptional<z.ZodString>;
                    invalid: z.ZodString;
                }, z.core.$strict>;
                answer: z.ZodObject<{
                    rules: z.ZodString;
                    ties: z.ZodOptional<z.ZodString>;
                    rounding: z.ZodOptional<z.ZodString>;
                    tolerance: z.ZodOptional<z.ZodString>;
                    refusals: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                method: z.ZodObject<{
                    kind: z.ZodEnum<{
                        scenario: "scenario";
                        invariant: "invariant";
                        other: "other";
                        oracle: "oracle";
                        certificate: "certificate";
                        analytic: "analytic";
                    }>;
                    description: z.ZodString;
                    applicability: z.ZodString;
                    artifacts: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                coverage: z.ZodObject<{
                    families: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            typical: "typical";
                            boundary: "boundary";
                            adversarial: "adversarial";
                        }>;
                        description: z.ZodString;
                        minCases: z.ZodNumber;
                    }, z.core.$strict>>;
                    minCases: z.ZodNumber;
                    corpus: z.ZodDefault<z.ZodBoolean>;
                }, z.core.$strict>;
                resources: z.ZodObject<{
                    subject: z.ZodString;
                    oracle: z.ZodString;
                    benchmark: z.ZodOptional<z.ZodObject<{
                        method: z.ZodString;
                        environment: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                verification: z.ZodOptional<z.ZodEnum<{
                    property: "property";
                    reference: "reference";
                }>>;
                reference: z.ZodOptional<z.ZodObject<{
                    oracle: z.ZodObject<{
                        description: z.ZodString;
                        limits: z.ZodString;
                    }, z.core.$strict>;
                    crossChecks: z.ZodArray<z.ZodObject<{
                        family: z.ZodString;
                        against: z.ZodString;
                        matches: z.ZodNumber;
                        total: z.ZodNumber;
                        artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    sets: z.ZodArray<z.ZodObject<{
                        gate: z.ZodString;
                        artifacts: z.ZodArray<z.ZodString>;
                        minCases: z.ZodNumber;
                        families: z.ZodDefault<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            minCases: z.ZodNumber;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                    gaps: z.ZodString;
                }, z.core.$strict>>;
                hard: z.ZodDefault<z.ZodBoolean>;
                feasibility: z.ZodOptional<z.ZodObject<{
                    spike: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            corpus: z.ZodOptional<z.ZodObject<{
                format: z.ZodString;
                extensible: z.ZodBoolean;
                maxCases: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'run-result': z.ZodDiscriminatedUnion<[z.ZodObject<{
        outcome: z.ZodLiteral<"accepted">;
        shas: z.ZodObject<{
            base: z.ZodString;
            candidate: z.ZodString;
            integration: z.ZodString;
            result: z.ZodString;
        }, z.core.$strict>;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        workOrderId: z.ZodString;
        graphId: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        runId: z.ZodString;
        attempt: z.ZodNumber;
        repositoryId: z.ZodString;
        targetRef: z.ZodString;
        inputs: z.ZodObject<{
            harnessVersion: z.ZodString;
            consumerVersion: z.ZodOptional<z.ZodString>;
            stateVersion: z.ZodLiteral<1>;
            workOrderDigest: z.ZodString;
            graphDigest: z.ZodString;
            policyDigest: z.ZodString;
            contextDigest: z.ZodOptional<z.ZodString>;
            checks: z.ZodOptional<z.ZodString>;
            corpus: z.ZodOptional<z.ZodObject<{
                suite: z.ZodString;
                number: z.ZodNumber;
                digest: z.ZodString;
            }, z.core.$strict>>;
            requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            writer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        checked: z.ZodObject<{
            dependencies: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                sha: z.ZodString;
                tree: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            freshness: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                snapshot: z.ZodString;
                head: z.ZodString;
                fresh: z.ZodBoolean;
            }, z.core.$strict>>;
            consumers: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodString>;
                sha: z.ZodString;
                tree: z.ZodString;
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        evidence: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                check: "check";
                test: "test";
                property: "property";
                review: "review";
                consumer: "consumer";
            }>;
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            digest: z.ZodString;
            summary: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
            checks: z.ZodOptional<z.ZodString>;
            tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                    skipped: "skipped";
                }>;
                opaque: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>>;
            testsTruncated: z.ZodOptional<z.ZodBoolean>;
            property: z.ZodOptional<z.ZodObject<{
                level: z.ZodOptional<z.ZodEnum<{
                    manifest: "manifest";
                    legacy: "legacy";
                }>>;
                manifest: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodString;
                    properties: z.ZodArray<z.ZodString>;
                    corpus: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        cases: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            reviewer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                sameVendor: z.ZodBoolean;
            }, z.core.$strict>>;
            review: z.ZodOptional<z.ZodObject<{
                round: z.ZodNumber;
                call: z.ZodNumber;
                protocol: z.ZodEnum<{
                    valid: "valid";
                    invalid: "invalid";
                    unsafe: "unsafe";
                }>;
                issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    reason: z.ZodString;
                    message: z.ZodString;
                }, z.core.$strict>>>;
                transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    from: z.ZodEnum<{
                        open: "open";
                        closed: "closed";
                        withdrawn: "withdrawn";
                    }>;
                    to: z.ZodEnum<{
                        open: "open";
                        closed: "closed";
                        withdrawn: "withdrawn";
                    }>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
            severity: z.ZodString;
            message: z.ZodString;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            rule: z.ZodOptional<z.ZodString>;
            id: z.ZodOptional<z.ZodString>;
            status: z.ZodOptional<z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>>;
        }, z.core.$strict>>>;
        limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
        finishedAt: z.ZodISODateTime;
    }, z.core.$strict>, z.ZodObject<{
        outcome: z.ZodEnum<{
            rejected: "rejected";
            blocked: "blocked";
            cancelled: "cancelled";
            stopped: "stopped";
        }>;
        shas: z.ZodObject<{
            base: z.ZodOptional<z.ZodString>;
            candidate: z.ZodOptional<z.ZodString>;
            integration: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        stopReason: z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            message: z.ZodString;
        }, z.core.$strict>;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        workOrderId: z.ZodString;
        graphId: z.ZodString;
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        runId: z.ZodString;
        attempt: z.ZodNumber;
        repositoryId: z.ZodString;
        targetRef: z.ZodString;
        inputs: z.ZodObject<{
            harnessVersion: z.ZodString;
            consumerVersion: z.ZodOptional<z.ZodString>;
            stateVersion: z.ZodLiteral<1>;
            workOrderDigest: z.ZodString;
            graphDigest: z.ZodString;
            policyDigest: z.ZodString;
            contextDigest: z.ZodOptional<z.ZodString>;
            checks: z.ZodOptional<z.ZodString>;
            corpus: z.ZodOptional<z.ZodObject<{
                suite: z.ZodString;
                number: z.ZodNumber;
                digest: z.ZodString;
            }, z.core.$strict>>;
            requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            writer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        checked: z.ZodObject<{
            dependencies: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                sha: z.ZodString;
                tree: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            freshness: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                snapshot: z.ZodString;
                head: z.ZodString;
                fresh: z.ZodBoolean;
            }, z.core.$strict>>;
            consumers: z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodString>;
                sha: z.ZodString;
                tree: z.ZodString;
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        evidence: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                check: "check";
                test: "test";
                property: "property";
                review: "review";
                consumer: "consumer";
            }>;
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            digest: z.ZodString;
            summary: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
            checks: z.ZodOptional<z.ZodString>;
            tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                status: z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                    skipped: "skipped";
                }>;
                opaque: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>>>;
            testsTruncated: z.ZodOptional<z.ZodBoolean>;
            property: z.ZodOptional<z.ZodObject<{
                level: z.ZodOptional<z.ZodEnum<{
                    manifest: "manifest";
                    legacy: "legacy";
                }>>;
                manifest: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodString;
                    properties: z.ZodArray<z.ZodString>;
                    corpus: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        cases: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            reviewer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>;
                model: z.ZodOptional<z.ZodString>;
                sameVendor: z.ZodBoolean;
            }, z.core.$strict>>;
            review: z.ZodOptional<z.ZodObject<{
                round: z.ZodNumber;
                call: z.ZodNumber;
                protocol: z.ZodEnum<{
                    valid: "valid";
                    invalid: "invalid";
                    unsafe: "unsafe";
                }>;
                issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    reason: z.ZodString;
                    message: z.ZodString;
                }, z.core.$strict>>>;
                transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    from: z.ZodEnum<{
                        open: "open";
                        closed: "closed";
                        withdrawn: "withdrawn";
                    }>;
                    to: z.ZodEnum<{
                        open: "open";
                        closed: "closed";
                        withdrawn: "withdrawn";
                    }>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
            severity: z.ZodString;
            message: z.ZodString;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            rule: z.ZodOptional<z.ZodString>;
            id: z.ZodOptional<z.ZodString>;
            status: z.ZodOptional<z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>>;
        }, z.core.$strict>>>;
        limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
        finishedAt: z.ZodISODateTime;
    }, z.core.$strict>], "outcome">;
    readonly 'result-envelope': z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        result: z.ZodDiscriminatedUnion<[z.ZodObject<{
            outcome: z.ZodLiteral<"accepted">;
            shas: z.ZodObject<{
                base: z.ZodString;
                candidate: z.ZodString;
                integration: z.ZodString;
                result: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    property: "property";
                    review: "review";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodString;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            outcome: z.ZodEnum<{
                rejected: "rejected";
                blocked: "blocked";
                cancelled: "cancelled";
                stopped: "stopped";
            }>;
            shas: z.ZodObject<{
                base: z.ZodOptional<z.ZodString>;
                candidate: z.ZodOptional<z.ZodString>;
                integration: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            stopReason: z.ZodObject<{
                code: z.ZodEnum<{
                    INVALID_INPUT: "INVALID_INPUT";
                    UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                    UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                    GRAPH_CYCLE: "GRAPH_CYCLE";
                    GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                    GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                    GATE_UNKNOWN: "GATE_UNKNOWN";
                    GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                    REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                    REVIEWER_MISSING: "REVIEWER_MISSING";
                    RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                    APPROVAL_STALE: "APPROVAL_STALE";
                    APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                    LEASE_STALE: "LEASE_STALE";
                    CONTROLLER_BUSY: "CONTROLLER_BUSY";
                    PAUSED: "PAUSED";
                    NOT_READY: "NOT_READY";
                    SCOPE_VIOLATION: "SCOPE_VIOLATION";
                    GATE_FAILED: "GATE_FAILED";
                    REVIEW_REJECTED: "REVIEW_REJECTED";
                    BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                    BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                    ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                    REVISION_CONFLICT: "REVISION_CONFLICT";
                    CANCELLED: "CANCELLED";
                    NOT_FOUND: "NOT_FOUND";
                    PATH_CONFLICT: "PATH_CONFLICT";
                    STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                    RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                    REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                    SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                    GIT_FAILED: "GIT_FAILED";
                    STORAGE_FAILED: "STORAGE_FAILED";
                    DELIVERY_FAILED: "DELIVERY_FAILED";
                    INTERNAL: "INTERNAL";
                }>;
                message: z.ZodString;
            }, z.core.$strict>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            workOrderId: z.ZodString;
            graphId: z.ZodString;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
            runId: z.ZodString;
            attempt: z.ZodNumber;
            repositoryId: z.ZodString;
            targetRef: z.ZodString;
            inputs: z.ZodObject<{
                harnessVersion: z.ZodString;
                consumerVersion: z.ZodOptional<z.ZodString>;
                stateVersion: z.ZodLiteral<1>;
                workOrderDigest: z.ZodString;
                graphDigest: z.ZodString;
                policyDigest: z.ZodString;
                contextDigest: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                writer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            checked: z.ZodObject<{
                dependencies: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                freshness: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    snapshot: z.ZodString;
                    head: z.ZodString;
                    fresh: z.ZodBoolean;
                }, z.core.$strict>>;
                consumers: z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    check: "check";
                    test: "test";
                    property: "property";
                    review: "review";
                    consumer: "consumer";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                gate: z.ZodString;
                sha: z.ZodString;
                passed: z.ZodBoolean;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                checks: z.ZodOptional<z.ZodString>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                reviewer: z.ZodOptional<z.ZodObject<{
                    runtime: z.ZodEnum<{
                        codex: "codex";
                        claude: "claude";
                        fixture: "fixture";
                    }>;
                    model: z.ZodOptional<z.ZodString>;
                    sameVendor: z.ZodBoolean;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodString;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            findings: z.ZodDefault<z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                message: z.ZodString;
                path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                rule: z.ZodOptional<z.ZodString>;
                id: z.ZodOptional<z.ZodString>;
                status: z.ZodOptional<z.ZodEnum<{
                    open: "open";
                    closed: "closed";
                    withdrawn: "withdrawn";
                }>>;
            }, z.core.$strict>>>;
            limitations: z.ZodDefault<z.ZodArray<z.ZodString>>;
            finishedAt: z.ZodISODateTime;
        }, z.core.$strict>], "outcome">;
        delivery: z.ZodArray<z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                pending: "pending";
                delivered: "delivered";
                conflict: "conflict";
                uncertain: "uncertain";
            }>;
            attempts: z.ZodNumber;
            lastError: z.ZodOptional<z.ZodString>;
            operation: z.ZodOptional<z.ZodString>;
            currentRevision: z.ZodOptional<z.ZodString>;
            receipt: z.ZodOptional<z.ZodString>;
            updatedAt: z.ZodISODateTime;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    readonly 'run-event': z.ZodDiscriminatedUnion<[z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        seq: z.ZodNumber;
        at: z.ZodISODateTime;
        graphId: z.ZodOptional<z.ZodString>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        attempt: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
        payload: z.ZodObject<{
            digest: z.ZodString;
            orders: z.ZodNumber;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodEnum<{
                plan: "plan";
                contract: "contract";
            }>;
            subject: z.ZodString;
            digest: z.ZodString;
            round: z.ZodNumber;
            approved: z.ZodBoolean;
            open: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            actor: z.ZodEnum<{
                agent: "agent";
                operator: "operator";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            orderDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            released: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            policyDigest: z.ZodString;
            engineVersion: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
            recheck: z.ZodOptional<z.ZodObject<{
                of: z.ZodString;
                outcome: z.ZodEnum<{
                    flaky: "flaky";
                    confirmed: "confirmed";
                }>;
            }, z.core.$strict>>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            sameVendor: z.ZodBoolean;
            blocking: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            failureKind: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>;
            message: z.ZodString;
            blocked: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            leaseUntil: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            integrationSha: z.ZodString;
            accepted: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            resultSha: z.ZodString;
            integrationSha: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
            failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>>;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            scope: z.ZodEnum<{
                work: "work";
                group: "group";
                total: "total";
            }>;
            scopeId: z.ZodOptional<z.ZodString>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
            }>;
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            suite: z.ZodString;
            pending: z.ZodString;
            version: z.ZodNumber;
            digest: z.ZodString;
            status: z.ZodEnum<{
                completed: "completed";
                waiting: "waiting";
            }>;
            accepted: z.ZodArray<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            recoveryId: z.ZodString;
            property: z.ZodString;
            status: z.ZodEnum<{
                closed: "closed";
                stopped: "stopped";
                "awaiting-lead": "awaiting-lead";
                analyzing: "analyzing";
                applying: "applying";
                retry: "retry";
                retrying: "retrying";
                "awaiting-user": "awaiting-user";
            }>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            policyDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>;
            manifestDigest: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodNumber;
            by: z.ZodString;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                requested: "requested";
                cleared: "cleared";
            }>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            receipt: z.ZodOptional<z.ZodString>;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            error: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            currentRevision: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>, ...z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        seq: z.ZodNumber;
        at: z.ZodISODateTime;
        graphId: z.ZodOptional<z.ZodString>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        attempt: z.ZodOptional<z.ZodNumber>;
        type: z.ZodLiteral<"graph.registered" | "graph.reviewed" | "graph.approved" | "work.ready" | "work.held" | "attempt.claimed" | "attempt.phase" | "attempt.gate" | "attempt.review" | "attempt.failed" | "attempt.expired" | "attempt.cancelled" | "attempt.recovered" | "work.accepted" | "work.blocked" | "control.paused" | "control.resumed" | "controller.acquired" | "controller.released" | "budget.blocked" | "corpus.adopted" | "work.recovery" | "joint.started" | "joint.finished" | "policy.applied" | "policy.reconfigure" | "delivery.pending" | "delivery.delivered" | "delivery.failed" | "delivery.conflict" | "delivery.uncertain">;
        payload: z.ZodObject<{
            digest: z.ZodString;
            orders: z.ZodNumber;
            source: z.ZodObject<{
                connector: z.ZodString;
                ref: z.ZodString;
                revision: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodEnum<{
                plan: "plan";
                contract: "contract";
            }>;
            subject: z.ZodString;
            digest: z.ZodString;
            round: z.ZodNumber;
            approved: z.ZodBoolean;
            open: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            actor: z.ZodEnum<{
                agent: "agent";
                operator: "operator";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            orderDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            released: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            policyDigest: z.ZodString;
            engineVersion: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            gate: z.ZodString;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            consumer: z.ZodOptional<z.ZodString>;
            recheck: z.ZodOptional<z.ZodObject<{
                of: z.ZodString;
                outcome: z.ZodEnum<{
                    flaky: "flaky";
                    confirmed: "confirmed";
                }>;
            }, z.core.$strict>>;
        }, z.core.$strict> | z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            sha: z.ZodString;
            passed: z.ZodBoolean;
            evidenceId: z.ZodString;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            sameVendor: z.ZodBoolean;
            blocking: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            failureKind: z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>;
            message: z.ZodString;
            blocked: z.ZodBoolean;
        }, z.core.$strict> | z.ZodObject<{
            leaseUntil: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            integrationSha: z.ZodString;
            accepted: z.ZodBoolean;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            resultSha: z.ZodString;
            integrationSha: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
            failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>>;
        }, z.core.$strict> | z.ZodObject<{
            reason: z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            owner: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            scope: z.ZodEnum<{
                work: "work";
                group: "group";
                total: "total";
            }>;
            scopeId: z.ZodOptional<z.ZodString>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
            }>;
            reason: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            suite: z.ZodString;
            pending: z.ZodString;
            version: z.ZodNumber;
            digest: z.ZodString;
            status: z.ZodEnum<{
                completed: "completed";
                waiting: "waiting";
            }>;
            accepted: z.ZodArray<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            recoveryId: z.ZodString;
            property: z.ZodString;
            status: z.ZodEnum<{
                closed: "closed";
                stopped: "stopped";
                "awaiting-lead": "awaiting-lead";
                analyzing: "analyzing";
                applying: "applying";
                retry: "retry";
                retrying: "retrying";
                "awaiting-user": "awaiting-user";
            }>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            policyDigest: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            verificationId: z.ZodString;
            status: z.ZodEnum<{
                passed: "passed";
                failed: "failed";
            }>;
            manifestDigest: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            digest: z.ZodString;
            generation: z.ZodNumber;
            by: z.ZodString;
            operation: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            digest: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                requested: "requested";
                cleared: "cleared";
            }>;
            error: z.ZodOptional<z.ZodString>;
        }, z.core.$strict> | z.ZodObject<{
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            receipt: z.ZodOptional<z.ZodString>;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            error: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            currentRevision: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict> | z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
            sink: z.ZodString;
            key: z.ZodString;
            revision: z.ZodString;
            attempts: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>[]], "type">;
    readonly 'review-record': z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            plan: "plan";
            contract: "contract";
        }>;
        subject: z.ZodString;
        digest: z.ZodString;
        round: z.ZodNumber;
        at: z.ZodISODateTime;
        approved: z.ZodBoolean;
        summary: z.ZodString;
        authorRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
            external: "external";
        }>;
        reviewerRuntime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
            fixture: "fixture";
        }>;
        reviewerModel: z.ZodOptional<z.ZodString>;
        sameVendor: z.ZodBoolean;
        reviewerBinding: z.ZodOptional<z.ZodString>;
        contextDigest: z.ZodOptional<z.ZodString>;
        findings: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            severity: z.ZodEnum<{
                blocking: "blocking";
                note: "note";
            }>;
            message: z.ZodString;
            rule: z.ZodOptional<z.ZodString>;
            path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            status: z.ZodEnum<{
                open: "open";
                closed: "closed";
                withdrawn: "withdrawn";
            }>;
            openedIn: z.ZodNumber;
            changedIn: z.ZodNumber;
            basis: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        artifact: z.ZodString;
    }, z.core.$strict>;
    readonly 'joint-verification': z.ZodDiscriminatedUnion<[z.ZodObject<{
        status: z.ZodLiteral<"active">;
        manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            sha: z.ZodString;
            tree: z.ZodString;
        }, z.core.$strict>>>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        startedAt: z.ZodISODateTime;
        policyDigest: z.ZodString;
        specDigest: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        impact: z.ZodOptional<z.ZodObject<{
            changed: z.ZodArray<z.ZodString>;
            affected: z.ZodArray<z.ZodString>;
            gateIds: z.ZodArray<z.ZodString>;
            mode: z.ZodEnum<{
                all: "all";
                affected: "affected";
            }>;
            reason: z.ZodString;
            baseline: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        evidence: z.ZodArray<z.ZodObject<{
            gate: z.ZodString;
            passed: z.ZodBoolean;
            command: z.ZodArray<z.ZodString>;
            exitCode: z.ZodNumber;
            log: z.ZodString;
            digest: z.ZodString;
            summary: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodLiteral<"failed">;
        finishedAt: z.ZodISODateTime;
        manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            sha: z.ZodString;
            tree: z.ZodString;
        }, z.core.$strict>>>;
        manifestDigest: z.ZodOptional<z.ZodString>;
        error: z.ZodString;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        startedAt: z.ZodISODateTime;
        policyDigest: z.ZodString;
        specDigest: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        impact: z.ZodOptional<z.ZodObject<{
            changed: z.ZodArray<z.ZodString>;
            affected: z.ZodArray<z.ZodString>;
            gateIds: z.ZodArray<z.ZodString>;
            mode: z.ZodEnum<{
                all: "all";
                affected: "affected";
            }>;
            reason: z.ZodString;
            baseline: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        evidence: z.ZodArray<z.ZodObject<{
            gate: z.ZodString;
            passed: z.ZodBoolean;
            command: z.ZodArray<z.ZodString>;
            exitCode: z.ZodNumber;
            log: z.ZodString;
            digest: z.ZodString;
            summary: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodLiteral<"passed">;
        finishedAt: z.ZodISODateTime;
        manifest: z.ZodRecord<z.ZodString, z.ZodObject<{
            sha: z.ZodString;
            tree: z.ZodString;
        }, z.core.$strict>>;
        manifestDigest: z.ZodString;
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        id: z.ZodString;
        startedAt: z.ZodISODateTime;
        policyDigest: z.ZodString;
        specDigest: z.ZodString;
        workIds: z.ZodArray<z.ZodString>;
        impact: z.ZodOptional<z.ZodObject<{
            changed: z.ZodArray<z.ZodString>;
            affected: z.ZodArray<z.ZodString>;
            gateIds: z.ZodArray<z.ZodString>;
            mode: z.ZodEnum<{
                all: "all";
                affected: "affected";
            }>;
            reason: z.ZodString;
            baseline: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        evidence: z.ZodArray<z.ZodObject<{
            gate: z.ZodString;
            passed: z.ZodBoolean;
            command: z.ZodArray<z.ZodString>;
            exitCode: z.ZodNumber;
            log: z.ZodString;
            digest: z.ZodString;
            summary: z.ZodString;
            artifacts: z.ZodArray<z.ZodObject<{
                path: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>], "status">;
    readonly 'execution-document': z.ZodObject<{
        stateVersion: z.ZodLiteral<1>;
        graphs: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            digest: z.ZodString;
            graph: z.ZodObject<{
                apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
                id: z.ZodString;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
                orders: z.ZodArray<z.ZodObject<{
                    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
                    id: z.ZodString;
                    source: z.ZodObject<{
                        connector: z.ZodString;
                        ref: z.ZodString;
                        revision: z.ZodString;
                    }, z.core.$strict>;
                    title: z.ZodString;
                    goal: z.ZodString;
                    acceptance: z.ZodArray<z.ZodString>;
                    role: z.ZodString;
                    repositoryId: z.ZodString;
                    relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
                    dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        gates: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>>>;
                    properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        source: z.ZodString;
                        digest: z.ZodString;
                        text: z.ZodString;
                        gate: z.ZodString;
                        scenario: z.ZodString;
                        testId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>>;
                    contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>>>;
                    context: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                prerequisites: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    repositoryId: z.ZodString;
                    resultSha: z.ZodString;
                    receipt: z.ZodDiscriminatedUnion<[z.ZodObject<{
                        kind: z.ZodLiteral<"engine">;
                        runId: z.ZodString;
                    }, z.core.$strict>, z.ZodObject<{
                        kind: z.ZodLiteral<"trusted">;
                        issuer: z.ZodString;
                        digest: z.ZodString;
                    }, z.core.$strict>], "kind">;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            policyDigest: z.ZodString;
            approval: z.ZodOptional<z.ZodObject<{
                actor: z.ZodEnum<{
                    agent: "agent";
                    operator: "operator";
                }>;
                authorRuntime: z.ZodOptional<z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>>;
                reviewerRuntime: z.ZodOptional<z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>>;
                artifact: z.ZodOptional<z.ZodString>;
                digest: z.ZodOptional<z.ZodString>;
                context: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodNullable<z.ZodString>;
                }, z.core.$strict>>;
                at: z.ZodISODateTime;
            }, z.core.$strict>>;
            registeredAt: z.ZodISODateTime;
        }, z.core.$strict>>;
        works: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            graphId: z.ZodString;
            order: z.ZodObject<{
                apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
                id: z.ZodString;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
                title: z.ZodString;
                goal: z.ZodString;
                acceptance: z.ZodArray<z.ZodString>;
                role: z.ZodString;
                repositoryId: z.ZodString;
                relatedRepositories: z.ZodDefault<z.ZodArray<z.ZodString>>;
                writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
                dependsOn: z.ZodDefault<z.ZodArray<z.ZodString>>;
                gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
                consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    repositoryId: z.ZodString;
                    gates: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>>;
                properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
                resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
                requirements: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    source: z.ZodString;
                    digest: z.ZodString;
                    text: z.ZodString;
                    gate: z.ZodString;
                    scenario: z.ZodString;
                    testId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                contracts: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>>;
                context: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>;
            status: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            attempt: z.ZodNumber;
            activeRunId: z.ZodOptional<z.ZodString>;
            resultSha: z.ZodOptional<z.ZodString>;
            failure: z.ZodOptional<z.ZodString>;
            failureKind: z.ZodOptional<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>;
            failureFingerprint: z.ZodOptional<z.ZodString>;
            approvedAt: z.ZodOptional<z.ZodISODateTime>;
            approvedDigest: z.ZodOptional<z.ZodString>;
            approvedScope: z.ZodOptional<z.ZodString>;
            approval: z.ZodOptional<z.ZodObject<{
                actor: z.ZodEnum<{
                    agent: "agent";
                    operator: "operator";
                }>;
                authorRuntime: z.ZodOptional<z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>>;
                reviewerRuntime: z.ZodOptional<z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                    fixture: "fixture";
                }>>;
                artifact: z.ZodOptional<z.ZodString>;
                digest: z.ZodOptional<z.ZodString>;
                context: z.ZodOptional<z.ZodObject<{
                    digest: z.ZodNullable<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            hold: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                reason: z.ZodString;
            }, z.core.$strict>>;
            budgetBlock: z.ZodOptional<z.ZodObject<{
                reason: z.ZodString;
                at: z.ZodISODateTime;
            }, z.core.$strict>>;
            checkVersion: z.ZodOptional<z.ZodObject<{
                suite: z.ZodString;
                number: z.ZodNumber;
                digest: z.ZodString;
            }, z.core.$strict>>;
            recovery: z.ZodOptional<z.ZodObject<{
                id: z.ZodString;
                property: z.ZodString;
                basis: z.ZodString;
                runs: z.ZodArray<z.ZodString>;
                openedAt: z.ZodISODateTime;
                status: z.ZodEnum<{
                    closed: "closed";
                    stopped: "stopped";
                    "awaiting-lead": "awaiting-lead";
                    analyzing: "analyzing";
                    applying: "applying";
                    retry: "retry";
                    retrying: "retrying";
                    "awaiting-user": "awaiting-user";
                }>;
                calls: z.ZodNumber;
                decision: z.ZodOptional<z.ZodObject<{
                    action: z.ZodEnum<{
                        environment: "environment";
                        "add-cases": "add-cases";
                        "new-approach": "new-approach";
                        "strengthen-checker": "strengthen-checker";
                        "split-task": "split-task";
                        "clarify-obligation": "clarify-obligation";
                    }>;
                    reason: z.ZodString;
                    evidence: z.ZodArray<z.ZodString>;
                    hypothesis: z.ZodOptional<z.ZodString>;
                    plan: z.ZodOptional<z.ZodString>;
                    cases: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        input: z.ZodString;
                        expected: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>>;
                    proposal: z.ZodOptional<z.ZodString>;
                    conflict: z.ZodOptional<z.ZodString>;
                    source: z.ZodObject<{
                        kind: z.ZodEnum<{
                            operator: "operator";
                            lead: "lead";
                        }>;
                        runtime: z.ZodOptional<z.ZodString>;
                        model: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>;
                    decidedAt: z.ZodISODateTime;
                }, z.core.$strict>>;
                retryRun: z.ZodOptional<z.ZodString>;
                reason: z.ZodOptional<z.ZodString>;
                history: z.ZodArray<z.ZodObject<{
                    at: z.ZodISODateTime;
                    event: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                version: z.ZodNumber;
            }, z.core.$strict>>;
            recoveryHistory: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                property: z.ZodString;
                basis: z.ZodString;
                runs: z.ZodArray<z.ZodString>;
                openedAt: z.ZodISODateTime;
                status: z.ZodEnum<{
                    closed: "closed";
                    stopped: "stopped";
                    "awaiting-lead": "awaiting-lead";
                    analyzing: "analyzing";
                    applying: "applying";
                    retry: "retry";
                    retrying: "retrying";
                    "awaiting-user": "awaiting-user";
                }>;
                calls: z.ZodNumber;
                decision: z.ZodOptional<z.ZodObject<{
                    action: z.ZodEnum<{
                        environment: "environment";
                        "add-cases": "add-cases";
                        "new-approach": "new-approach";
                        "strengthen-checker": "strengthen-checker";
                        "split-task": "split-task";
                        "clarify-obligation": "clarify-obligation";
                    }>;
                    reason: z.ZodString;
                    evidence: z.ZodArray<z.ZodString>;
                    hypothesis: z.ZodOptional<z.ZodString>;
                    plan: z.ZodOptional<z.ZodString>;
                    cases: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        input: z.ZodString;
                        expected: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strict>>>;
                    proposal: z.ZodOptional<z.ZodString>;
                    conflict: z.ZodOptional<z.ZodString>;
                    source: z.ZodObject<{
                        kind: z.ZodEnum<{
                            operator: "operator";
                            lead: "lead";
                        }>;
                        runtime: z.ZodOptional<z.ZodString>;
                        model: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>;
                    decidedAt: z.ZodISODateTime;
                }, z.core.$strict>>;
                retryRun: z.ZodOptional<z.ZodString>;
                reason: z.ZodOptional<z.ZodString>;
                history: z.ZodArray<z.ZodObject<{
                    at: z.ZodISODateTime;
                    event: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                version: z.ZodNumber;
            }, z.core.$strict>>>;
            neutralFailures: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        attempts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            workId: z.ZodString;
            repositoryId: z.ZodString;
            attempt: z.ZodNumber;
            token: z.ZodString;
            owner: z.ZodString;
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
                fixture: "fixture";
            }>;
            model: z.ZodOptional<z.ZodString>;
            reviewerModel: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodString>;
            reviewerEffort: z.ZodOptional<z.ZodString>;
            policyDigest: z.ZodString;
            status: z.ZodEnum<{
                failed: "failed";
                cancelled: "cancelled";
                active: "active";
                expired: "expired";
                succeeded: "succeeded";
            }>;
            phase: z.ZodEnum<{
                ready: "ready";
                failed: "failed";
                cancelled: "cancelled";
                draft: "draft";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            startedAt: z.ZodISODateTime;
            finishedAt: z.ZodOptional<z.ZodISODateTime>;
            leaseUntil: z.ZodNumber;
            worktree: z.ZodOptional<z.ZodString>;
            baseSha: z.ZodOptional<z.ZodString>;
            candidateSha: z.ZodOptional<z.ZodString>;
            integrationSha: z.ZodOptional<z.ZodString>;
            error: z.ZodOptional<z.ZodString>;
            blocked: z.ZodOptional<z.ZodBoolean>;
            failureKind: z.ZodOptional<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>;
            failureFingerprint: z.ZodOptional<z.ZodString>;
            requiredGates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodString>;
                checked: z.ZodOptional<z.ZodObject<{
                    sha: z.ZodString;
                    tree: z.ZodString;
                    dependencies: z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        sha: z.ZodString;
                        tree: z.ZodString;
                        artifacts: z.ZodArray<z.ZodObject<{
                            path: z.ZodString;
                            digest: z.ZodString;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    freshness: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        repositoryId: z.ZodString;
                        snapshot: z.ZodString;
                        head: z.ZodString;
                        fresh: z.ZodBoolean;
                    }, z.core.$strict>>>;
                    observedAt: z.ZodOptional<z.ZodISODateTime>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            checks: z.ZodOptional<z.ZodObject<{
                effective: z.ZodString;
                corpus: z.ZodOptional<z.ZodObject<{
                    suite: z.ZodString;
                    number: z.ZodNumber;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                version: z.ZodString;
                repositoryId: z.ZodString;
                revision: z.ZodString;
                digest: z.ZodString;
            }, z.core.$strict>>>;
            contextSnapshot: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    device: "device";
                    port: "port";
                    account: "account";
                    service: "service";
                }>;
                value: z.ZodString;
            }, z.core.$strict>>>;
            dependencies: z.ZodOptional<z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                sha: z.ZodString;
                tree: z.ZodString;
                path: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            dependencyFreshness: z.ZodOptional<z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                snapshot: z.ZodString;
                head: z.ZodString;
                fresh: z.ZodBoolean;
            }, z.core.$strict>>>;
            properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
            unboundProperties: z.ZodOptional<z.ZodArray<z.ZodString>>;
            interrupted: z.ZodOptional<z.ZodLiteral<"shutdown">>;
            inputClasses: z.ZodOptional<z.ZodArray<z.ZodString>>;
            classified: z.ZodOptional<z.ZodArray<z.ZodObject<{
                property: z.ZodString;
                inputClass: z.ZodString;
            }, z.core.$strict>>>;
            episodeBasis: z.ZodOptional<z.ZodString>;
            implementationBasis: z.ZodOptional<z.ZodString>;
            reusedFrom: z.ZodOptional<z.ZodObject<{
                runId: z.ZodString;
                candidateSha: z.ZodString;
            }, z.core.$strict>>;
            partial: z.ZodOptional<z.ZodObject<{
                patch: z.ZodString;
                digest: z.ZodString;
                files: z.ZodArray<z.ZodString>;
                spec: z.ZodString;
                contracts: z.ZodRecord<z.ZodString, z.ZodString>;
            }, z.core.$strict>>;
            continuedFrom: z.ZodOptional<z.ZodObject<{
                runId: z.ZodString;
                kind: z.ZodEnum<{
                    candidate: "candidate";
                    unfinished: "unfinished";
                }>;
                reason: z.ZodOptional<z.ZodEnum<{
                    gate: "gate";
                    unknown: "unknown";
                    review: "review";
                    environment: "environment";
                    cancelled: "cancelled";
                    timeout: "timeout";
                    "provider-auth": "provider-auth";
                    "stale-base": "stale-base";
                    "empty-result": "empty-result";
                    unfinished: "unfinished";
                    "scope-violation": "scope-violation";
                    "review-protocol": "review-protocol";
                    merge: "merge";
                    budget: "budget";
                    "needs-lead": "needs-lead";
                }>>;
                respecified: z.ZodOptional<z.ZodBoolean>;
                applied: z.ZodBoolean;
                files: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
            callsRecorded: z.ZodOptional<z.ZodLiteral<true>>;
            dispatch: z.ZodOptional<z.ZodObject<{
                policy: z.ZodLiteral<"fifo-ready-v1">;
                at: z.ZodISODateTime;
                eligible: z.ZodArray<z.ZodObject<{
                    taskId: z.ZodString;
                    repositoryId: z.ZodOptional<z.ZodString>;
                    attempt: z.ZodNumber;
                }, z.core.$strict>>;
                activeCount: z.ZodNumber;
                concurrency: z.ZodNumber;
                inputDigest: z.ZodString;
            }, z.core.$strict>>;
            wait: z.ZodOptional<z.ZodObject<{
                approvedAt: z.ZodOptional<z.ZodISODateTime>;
                readyAt: z.ZodOptional<z.ZodISODateTime>;
            }, z.core.$strict>>;
            timings: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                stage: z.ZodString;
                startedAt: z.ZodISODateTime;
                finishedAt: z.ZodOptional<z.ZodISODateTime>;
                outcome: z.ZodOptional<z.ZodEnum<{
                    passed: "passed";
                    failed: "failed";
                }>>;
            }, z.core.$strict>>>;
            pinned: z.ZodOptional<z.ZodObject<{
                graphId: z.ZodString;
                graphDigest: z.ZodString;
                orderDigest: z.ZodString;
                targetRef: z.ZodString;
                source: z.ZodObject<{
                    connector: z.ZodString;
                    ref: z.ZodString;
                    revision: z.ZodString;
                }, z.core.$strict>;
            }, z.core.$strict>>;
            engineVersion: z.ZodOptional<z.ZodString>;
            consumerVersion: z.ZodOptional<z.ZodString>;
            evidence: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                runId: z.ZodString;
                kind: z.ZodEnum<{
                    test: "test";
                    review: "review";
                }>;
                phase: z.ZodEnum<{
                    candidate: "candidate";
                    integration: "integration";
                }>;
                sha: z.ZodString;
                gate: z.ZodString;
                passed: z.ZodBoolean;
                createdAt: z.ZodISODateTime;
                command: z.ZodArray<z.ZodString>;
                exitCode: z.ZodNumber;
                log: z.ZodString;
                digest: z.ZodString;
                summary: z.ZodString;
                consumer: z.ZodOptional<z.ZodString>;
                recheck: z.ZodOptional<z.ZodObject<{
                    of: z.ZodString;
                    outcome: z.ZodEnum<{
                        flaky: "flaky";
                        confirmed: "confirmed";
                    }>;
                }, z.core.$strict>>;
                inspection: z.ZodOptional<z.ZodObject<{
                    mode: z.ZodEnum<{
                        commands: "commands";
                        "diff-only": "diff-only";
                    }>;
                    source: z.ZodEnum<{
                        "codex-events": "codex-events";
                        unavailable: "unavailable";
                        "controller-probes": "controller-probes";
                        "runtime-and-controller": "runtime-and-controller";
                    }>;
                    commands: z.ZodArray<z.ZodObject<{
                        command: z.ZodString;
                        exitCode: z.ZodNullable<z.ZodNumber>;
                        output: z.ZodString;
                        origins: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                            type: z.ZodLiteral<"runtime">;
                            runtime: z.ZodString;
                            item: z.ZodNullable<z.ZodString>;
                        }, z.core.$strict>, z.ZodObject<{
                            type: z.ZodLiteral<"controller">;
                            runId: z.ZodString;
                        }, z.core.$strict>], "type">>>;
                        status: z.ZodOptional<z.ZodEnum<{
                            error: "error";
                            passed: "passed";
                            failed: "failed";
                            cancelled: "cancelled";
                            completed: "completed";
                            timeout: "timeout";
                        }>>;
                        failure: z.ZodOptional<z.ZodEnum<{
                            report: "report";
                            environment: "environment";
                        }>>;
                        gate: z.ZodOptional<z.ZodString>;
                        note: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                    reason: z.ZodNullable<z.ZodString>;
                    context: z.ZodOptional<z.ZodObject<{
                        attempt: z.ZodString;
                        phase: z.ZodEnum<{
                            candidate: "candidate";
                            integration: "integration";
                        }>;
                        sha: z.ZodString;
                        call: z.ZodNumber;
                    }, z.core.$strict>>;
                    total: z.ZodOptional<z.ZodNumber>;
                    excluded: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        runId: z.ZodString;
                        status: z.ZodNullable<z.ZodString>;
                        reason: z.ZodEnum<{
                            unfinished: "unfinished";
                            "not-started": "not-started";
                            "legacy-unconfirmed": "legacy-unconfirmed";
                            "foreign-scope": "foreign-scope";
                            "unknown-status": "unknown-status";
                            abandoned: "abandoned";
                        }>;
                    }, z.core.$strict>>>;
                    excludedTotal: z.ZodOptional<z.ZodNumber>;
                    invalid: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                findings: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    severity: z.ZodString;
                    message: z.ZodString;
                    path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                    id: z.ZodOptional<z.ZodString>;
                    status: z.ZodOptional<z.ZodEnum<{
                        open: "open";
                        closed: "closed";
                        withdrawn: "withdrawn";
                    }>>;
                }, z.core.$strict>>>;
                reviewRound: z.ZodOptional<z.ZodObject<{
                    version: z.ZodLiteral<1>;
                    scope: z.ZodString;
                    round: z.ZodNumber;
                    call: z.ZodNumber;
                    calls: z.ZodNumber;
                    protocol: z.ZodEnum<{
                        valid: "valid";
                        invalid: "invalid";
                        unsafe: "unsafe";
                    }>;
                    expected: z.ZodArray<z.ZodString>;
                    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        reason: z.ZodEnum<{
                            schema: "schema";
                            unknown: "unknown";
                            missing: "missing";
                            duplicate: "duplicate";
                            "not-open": "not-open";
                            "approved-with-blocking": "approved-with-blocking";
                        }>;
                        message: z.ZodString;
                    }, z.core.$strict>>>;
                    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        from: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        to: z.ZodEnum<{
                            open: "open";
                            closed: "closed";
                            withdrawn: "withdrawn";
                        }>;
                        basis: z.ZodString;
                    }, z.core.$strict>>>;
                    spec: z.ZodOptional<z.ZodString>;
                    mode: z.ZodOptional<z.ZodEnum<{
                        legacy: "legacy";
                        strict: "strict";
                    }>>;
                }, z.core.$strict>>;
                tests: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    status: z.ZodEnum<{
                        passed: "passed";
                        failed: "failed";
                        skipped: "skipped";
                    }>;
                    opaque: z.ZodOptional<z.ZodLiteral<true>>;
                }, z.core.$strict>>>;
                testsTruncated: z.ZodOptional<z.ZodBoolean>;
                property: z.ZodOptional<z.ZodObject<{
                    seed: z.ZodNumber;
                    reproduce: z.ZodString;
                    report: z.ZodOptional<z.ZodObject<{
                        version: z.ZodLiteral<1>;
                        seed: z.ZodOptional<z.ZodNumber>;
                        properties: z.ZodArray<z.ZodObject<{
                            testId: z.ZodString;
                            status: z.ZodEnum<{
                                passed: "passed";
                                failed: "failed";
                                running: "running";
                            }>;
                            cases: z.ZodNumber;
                            families: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodNumber>>;
                            error: z.ZodOptional<z.ZodString>;
                            current: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                            counterexample: z.ZodOptional<z.ZodObject<{
                                original: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
                                reduced: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                                expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                                actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                                reductionTimedOut: z.ZodOptional<z.ZodBoolean>;
                                case: z.ZodOptional<z.ZodString>;
                            }, z.core.$strip>>;
                        }, z.core.$strip>>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            executed: z.ZodNumber;
                            passed: z.ZodNumber;
                            witness: z.ZodString;
                            failed: z.ZodArray<z.ZodObject<{
                                id: z.ZodString;
                                property: z.ZodString;
                                expected: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                                actual: z.ZodOptional<z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>>;
                            }, z.core.$strip>>;
                        }, z.core.$strip>>;
                    }, z.core.$strip>>;
                    problem: z.ZodOptional<z.ZodString>;
                    contracts: z.ZodRecord<z.ZodString, z.ZodString>;
                    artifacts: z.ZodArray<z.ZodObject<{
                        path: z.ZodString;
                        blob: z.ZodString;
                    }, z.core.$strict>>;
                    level: z.ZodOptional<z.ZodEnum<{
                        manifest: "manifest";
                        legacy: "legacy";
                    }>>;
                    manifest: z.ZodOptional<z.ZodObject<{
                        digest: z.ZodString;
                        properties: z.ZodArray<z.ZodString>;
                        corpus: z.ZodOptional<z.ZodObject<{
                            digest: z.ZodString;
                            cases: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    coverage: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                checks: z.ZodOptional<z.ZodString>;
                alreadySatisfied: z.ZodOptional<z.ZodObject<{
                    gates: z.ZodArray<z.ZodString>;
                    evidence: z.ZodString;
                    basis: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                        kind: z.ZodLiteral<"contract">;
                        gates: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>, z.ZodObject<{
                        kind: z.ZodLiteral<"dependency">;
                        workId: z.ZodString;
                        sha: z.ZodString;
                        paths: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>], "kind">>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        verifications: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            status: z.ZodLiteral<"active">;
            manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
                sha: z.ZodString;
                tree: z.ZodString;
            }, z.core.$strict>>>;
            manifestDigest: z.ZodOptional<z.ZodString>;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            id: z.ZodString;
            startedAt: z.ZodISODateTime;
            policyDigest: z.ZodString;
            specDigest: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            impact: z.ZodOptional<z.ZodObject<{
                changed: z.ZodArray<z.ZodString>;
                affected: z.ZodArray<z.ZodString>;
                gateIds: z.ZodArray<z.ZodString>;
                mode: z.ZodEnum<{
                    all: "all";
                    affected: "affected";
                }>;
                reason: z.ZodString;
                baseline: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            evidence: z.ZodArray<z.ZodObject<{
                gate: z.ZodString;
                passed: z.ZodBoolean;
                command: z.ZodArray<z.ZodString>;
                exitCode: z.ZodNumber;
                log: z.ZodString;
                digest: z.ZodString;
                summary: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                durationMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            token: z.ZodString;
            leaseUntil: z.ZodNumber;
            engineVersion: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            status: z.ZodLiteral<"failed">;
            finishedAt: z.ZodISODateTime;
            manifest: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
                sha: z.ZodString;
                tree: z.ZodString;
            }, z.core.$strict>>>;
            manifestDigest: z.ZodOptional<z.ZodString>;
            error: z.ZodString;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            id: z.ZodString;
            startedAt: z.ZodISODateTime;
            policyDigest: z.ZodString;
            specDigest: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            impact: z.ZodOptional<z.ZodObject<{
                changed: z.ZodArray<z.ZodString>;
                affected: z.ZodArray<z.ZodString>;
                gateIds: z.ZodArray<z.ZodString>;
                mode: z.ZodEnum<{
                    all: "all";
                    affected: "affected";
                }>;
                reason: z.ZodString;
                baseline: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            evidence: z.ZodArray<z.ZodObject<{
                gate: z.ZodString;
                passed: z.ZodBoolean;
                command: z.ZodArray<z.ZodString>;
                exitCode: z.ZodNumber;
                log: z.ZodString;
                digest: z.ZodString;
                summary: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                durationMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            token: z.ZodString;
            leaseUntil: z.ZodNumber;
            engineVersion: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            status: z.ZodLiteral<"passed">;
            finishedAt: z.ZodISODateTime;
            manifest: z.ZodRecord<z.ZodString, z.ZodObject<{
                sha: z.ZodString;
                tree: z.ZodString;
            }, z.core.$strict>>;
            manifestDigest: z.ZodString;
            apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
            id: z.ZodString;
            startedAt: z.ZodISODateTime;
            policyDigest: z.ZodString;
            specDigest: z.ZodString;
            workIds: z.ZodArray<z.ZodString>;
            impact: z.ZodOptional<z.ZodObject<{
                changed: z.ZodArray<z.ZodString>;
                affected: z.ZodArray<z.ZodString>;
                gateIds: z.ZodArray<z.ZodString>;
                mode: z.ZodEnum<{
                    all: "all";
                    affected: "affected";
                }>;
                reason: z.ZodString;
                baseline: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            evidence: z.ZodArray<z.ZodObject<{
                gate: z.ZodString;
                passed: z.ZodBoolean;
                command: z.ZodArray<z.ZodString>;
                exitCode: z.ZodNumber;
                log: z.ZodString;
                digest: z.ZodString;
                summary: z.ZodString;
                artifacts: z.ZodArray<z.ZodObject<{
                    path: z.ZodString;
                    digest: z.ZodString;
                }, z.core.$strict>>;
                durationMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            token: z.ZodString;
            leaseUntil: z.ZodNumber;
            engineVersion: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>], "status">>>;
        control: z.ZodObject<{
            paused: z.ZodBoolean;
            pauseReason: z.ZodOptional<z.ZodEnum<{
                runtime: "runtime";
                operator: "operator";
                shutdown: "shutdown";
                "base-check": "base-check";
                reconfigure: "reconfigure";
            }>>;
            pausedAt: z.ZodOptional<z.ZodISODateTime>;
            pauseOperation: z.ZodOptional<z.ZodString>;
            pauseFailures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                gate: "gate";
                unknown: "unknown";
                review: "review";
                environment: "environment";
                cancelled: "cancelled";
                timeout: "timeout";
                "provider-auth": "provider-auth";
                "stale-base": "stale-base";
                "empty-result": "empty-result";
                unfinished: "unfinished";
                "scope-violation": "scope-violation";
                "review-protocol": "review-protocol";
                merge: "merge";
                budget: "budget";
                "needs-lead": "needs-lead";
            }>>>;
            waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    "base-check": "base-check";
                    "context-lock": "context-lock";
                }>;
                detail: z.ZodString;
                at: z.ZodISODateTime;
                operation: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            appliedPolicy: z.ZodOptional<z.ZodObject<{
                digest: z.ZodString;
                generation: z.ZodOptional<z.ZodNumber>;
                at: z.ZodISODateTime;
                by: z.ZodString;
            }, z.core.$strict>>;
            reconfigure: z.ZodOptional<z.ZodObject<{
                operation: z.ZodString;
                digest: z.ZodString;
                requestedAt: z.ZodISODateTime;
                appliedAt: z.ZodOptional<z.ZodISODateTime>;
                appliedBy: z.ZodOptional<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        controller: z.ZodOptional<z.ZodObject<{
            owner: z.ZodString;
            leaseUntil: z.ZodNumber;
            engineVersion: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        sequence: z.ZodNumber;
    }, z.core.$strict>;
    readonly 'stack-profile': z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        extends: z.ZodDefault<z.ZodArray<z.ZodString>>;
        capabilities: z.ZodDefault<z.ZodArray<z.ZodString>>;
        gates: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                check: "check";
                test: "test";
            }>;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
            report: z.ZodOptional<z.ZodObject<{
                type: z.ZodLiteral<"junit">;
                path: z.ZodString;
            }, z.core.$strict>>;
            property: z.ZodOptional<z.ZodObject<{
                path: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
            cwd: z.ZodOptional<z.ZodString>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>>;
        prepare: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        environment: z.ZodOptional<z.ZodObject<{
            inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
            values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        }, z.core.$strict>>;
        lifecycle: z.ZodOptional<z.ZodObject<{
            setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>>;
            teardown: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                command: z.ZodArray<z.ZodString>;
                timeoutMs: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        toolchain: z.ZodOptional<z.ZodObject<{
            tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
            packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
                npm: "npm";
                pnpm: "pnpm";
            }>>>;
        }, z.core.$strict>>;
        protectedPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
        generatedPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
        concurrency: z.ZodOptional<z.ZodNumber>;
        runTimeoutMs: z.ZodOptional<z.ZodNumber>;
        roles: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
            writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
            reviewer: z.ZodOptional<z.ZodObject<{
                runtime: z.ZodEnum<{
                    codex: "codex";
                    claude: "claude";
                }>;
                model: z.ZodOptional<z.ZodString>;
                effort: z.ZodOptional<z.ZodEnum<{
                    low: "low";
                    medium: "medium";
                    high: "high";
                    xhigh: "xhigh";
                }>>;
                toolProfile: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            title: z.ZodOptional<z.ZodString>;
            requiresContract: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>>;
        contextPacks: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            repositoryId: z.ZodOptional<z.ZodString>;
            roles: z.ZodDefault<z.ZodArray<z.ZodString>>;
            files: z.ZodArray<z.ZodString>;
            references: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>;
    readonly 'project-manifest': z.ZodObject<{
        apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
        kind: z.ZodLiteral<"harness-project">;
        manifestVersion: z.ZodLiteral<1>;
        projectId: z.ZodString;
        root: z.ZodString;
        repository: z.ZodObject<{
            id: z.ZodString;
            targetRef: z.ZodString;
        }, z.core.$strict>;
        profile: z.ZodObject<{
            ref: z.ZodString;
            pin: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodString;
                digest: z.ZodString;
                source: z.ZodOptional<z.ZodObject<{
                    repositoryId: z.ZodString;
                    path: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        runtimes: z.ZodObject<{
            writer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            reviewer: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
        }, z.core.$strict>;
        paths: z.ZodObject<{
            policy: z.ZodLiteral<".harness/policy.json">;
            work: z.ZodLiteral<".harness/work">;
            notes: z.ZodLiteral<".harness/work/context/notes">;
            state: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>;
    readonly 'stop-diagnosis': z.ZodObject<{
        code: z.ZodEnum<{
            INVALID_INPUT: "INVALID_INPUT";
            UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
            UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
            GRAPH_CYCLE: "GRAPH_CYCLE";
            GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
            GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
            GATE_UNKNOWN: "GATE_UNKNOWN";
            GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
            REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
            REVIEWER_MISSING: "REVIEWER_MISSING";
            RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
            APPROVAL_STALE: "APPROVAL_STALE";
            APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
            LEASE_STALE: "LEASE_STALE";
            CONTROLLER_BUSY: "CONTROLLER_BUSY";
            PAUSED: "PAUSED";
            NOT_READY: "NOT_READY";
            SCOPE_VIOLATION: "SCOPE_VIOLATION";
            GATE_FAILED: "GATE_FAILED";
            REVIEW_REJECTED: "REVIEW_REJECTED";
            BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
            BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
            ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
            REVISION_CONFLICT: "REVISION_CONFLICT";
            CANCELLED: "CANCELLED";
            NOT_FOUND: "NOT_FOUND";
            PATH_CONFLICT: "PATH_CONFLICT";
            STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
            RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
            REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
            SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
            GIT_FAILED: "GIT_FAILED";
            STORAGE_FAILED: "STORAGE_FAILED";
            DELIVERY_FAILED: "DELIVERY_FAILED";
            INTERNAL: "INTERNAL";
        }>;
        cause: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            environment: "environment";
            cancelled: "cancelled";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
            "runtime-missing": "runtime-missing";
            "controller-busy": "controller-busy";
            "operator-pause": "operator-pause";
            "approval-required": "approval-required";
            "not-ready": "not-ready";
        }>;
        phase: z.ZodEnum<{
            gates: "gates";
            preflight: "preflight";
            review: "review";
            integration: "integration";
            delivery: "delivery";
            claim: "claim";
            implementation: "implementation";
        }>;
        actor: z.ZodNullable<z.ZodEnum<{
            controller: "controller";
            lead: "lead";
            user: "user";
        }>>;
        action: z.ZodEnum<{
            none: "none";
            wait: "wait";
            retry: "retry";
            "review-plan": "review-plan";
            "diagnose-failure": "diagnose-failure";
            "reset-attempts": "reset-attempts";
            "raise-budget": "raise-budget";
            "replan-dependents": "replan-dependents";
            "recovery-decision": "recovery-decision";
            "user-decision": "user-decision";
            "resume-queue": "resume-queue";
            "fix-environment": "fix-environment";
            "fix-access": "fix-access";
        }>;
        retryPlanned: z.ZodBoolean;
        message: z.ZodString;
        evidence: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                attempt: "attempt";
                evidence: "evidence";
                event: "event";
                doctor: "doctor";
            }>;
            id: z.ZodString;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    readonly 'plan-draft': z.ZodObject<{
        title: z.ZodString;
        description: z.ZodString;
        tasks: z.ZodArray<z.ZodObject<{
            requirements: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                source: z.ZodString;
                digest: z.ZodString;
                text: z.ZodString;
                gate: z.ZodString;
                scenario: z.ZodString;
                testId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            scope: z.ZodDefault<z.ZodEnum<{
                component: "component";
                workspace: "workspace";
            }>>;
            relatedRepositories: z.ZodOptional<z.ZodArray<z.ZodString>>;
            contextPacks: z.ZodOptional<z.ZodArray<z.ZodString>>;
            writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
            gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
            properties: z.ZodOptional<z.ZodArray<z.ZodString>>;
            resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            repositoryId: z.ZodDefault<z.ZodString>;
            key: z.ZodString;
            title: z.ZodString;
            description: z.ZodString;
            role: z.ZodString;
            dependsOn: z.ZodArray<z.ZodString>;
            acceptance: z.ZodArray<z.ZodString>;
            contracts: z.ZodArray<z.ZodString>;
            consumers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                repositoryId: z.ZodString;
                gates: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
};
