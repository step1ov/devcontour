import { type DependencyStorePolicy, type ExecutionPolicy } from '../contracts/index.ts';
import { type CheckoutRoot } from '../environment/checkout-root.ts';
import type { executionEnvironment } from '../environment/lifecycle.ts';
import { runCheck, type Boundary } from './gates.ts';
/**
 * Хранилище зависимостей: один seed на lockfile целевой ветки и его копия в
 * каждом checkout. Проект ничего не пишет сам: установка остаётся обычным
 * `pnpm install --frozen-lockfile` в его gate, только хранилище уже заполнено.
 *
 * Граница доверия:
 *
 * - Seed собирается только из lockfile целевой ветки — принятой истории.
 *   Сам harness не даёт кандидату запустить сборку или выбрать её содержимое:
 *   его lockfile только сравнивается с seed (частичное попадание).
 * - Сборка идёт в песочнице проверок с её `isolation.domains`, в каталоге из
 *   одного lockfile: `.npmrc`, `.pnpmfile.cjs` и `pnpm-workspace.yaml` проекта
 *   туда не попадают, и его хуки не исполняются.
 * - Seed лежит под корнем рабочих деревьев или в каталоге состояния: оба
 *   закрыты песочницей на чтение и запись. Копия в checkout принадлежит этому
 *   checkout: обратно в seed ничего не возвращается, а integration и следующая
 *   попытка получают новую копию.
 * - Проверяются байты копии, а не источника: те, что прочитает менеджер, и без
 *   окна между сверкой и копированием. Манифест закреплён в базе ресурсов, вне
 *   дерева seed. Несовпадение — отказ от seed с причиной в квитанции.
 * - Байты, докачанные менеджером при частичном попадании, защищены не seed, а
 *   lockfile: в дереве кандидата они доверены не больше, чем `node_modules`.
 *
 * Условие границы: шаги `prepare` и `lifecycle` идут на хосте вне песочницы, а на
 * integration — над слитым деревом. Если они исполняют код кандидата (скрипт из
 * репозитория), он работает с правами controller и может изменить seed и базу
 * закреплений: граница seed держится только там, где эти шаги кода кандидата не
 * исполняют. `doctor` предупреждает о хранилище рядом с непустым `prepare`.
 *
 * Отсутствие seed, отказ сборки и частичное попадание сводятся к обычной
 * установке: хранилище — ускорение, и проверка из-за него не падает.
 */
type Repo = ExecutionPolicy['repositories'][number];
type Execution = ReturnType<typeof executionEnvironment>;
export interface StoreContext {
    policy: Pick<ExecutionPolicy, 'isolation'>;
    /** Каталог seeds репозитория (`dependencyStoreRoot`). */
    root(repositoryId: string): string;
    repoPath(repo: Repo): string;
    /** Граница сборки seed — та же, что у проверок этого контура. */
    boundary: Pick<Boundary, 'hidden' | 'checkouts'>;
    resourceDatabase: string;
    /** Момент (ms), когда истекает время фазы; от остатка считается бюджет хранилища. */
    deadline: number;
    /** Полная длина этого предела фазы: так видно, что фаза пришла с остатком. */
    phaseMs: number;
}
export interface StoreReceipt {
    outcome: 'hit' | 'partial' | 'miss';
    manager: DependencyStorePolicy['manager'];
    /** Ключ использованного seed. */
    seed?: string;
    mode?: 'clone' | 'copy';
    /** Seed собран этим вызовом. */
    built?: boolean;
    files?: number;
    bytes?: number;
    durationMs: number;
    /** Причина промаха. */
    reason?: string;
    /** Seeds, от которых отказались: причина отказа. */
    refused?: string[];
    /** Переменные окружения процессов этого checkout. */
    env: NodeJS.ProcessEnv;
}
/** Каталог seeds: том рабочих деревьев и уже закрытое песочницей место. */
export declare function dependencyStoreRoot(placement: CheckoutRoot, stateDir: string, repositoryId: string): string;
/** Способы размещения дерева; тест подменяет `cloneable`, чтобы проверить обычную копию. */
export declare const storeTree: {
    /**
     * Предел файлов seed: копия лежит в checkout и входит в сверку защищённых
     * путей. Seed больше неё превратил бы ускорение в отказ каждой проверки.
     */
    maxFiles: number;
    /**
     * Предел элементов checkout вместе с копией seed. Запас — на то, что проверки
     * допишут в дерево после развёртывания.
     */
    maxEntries: number;
    /**
     * Меньше этого остатка сборка не начинается и ничего не отмечает: за такое время
     * она не успеет, а опоздавшая фаза не должна закрывать сборку остальным.
     */
    minBuildMs: number;
    /** Запуск сборки; тест подменяет его: исход гонки с отменой иначе не воспроизвести. */
    run: typeof runCheck;
    /** Запись `.gitignore` хранилища; тест подменяет её, чтобы проверить отказ. */
    ignore: (dest: string) => Promise<void>;
    /**
     * Том клонирует файлы. `cp -c` на другом томе молча копирует, поэтому способ
     * выясняется заранее: от него зависит проверка свободного места.
     */
    cloneable(from: string, to: string, sample: string, signal: AbortSignal): Promise<boolean>;
    freeBytes(path: string): Promise<number>;
    /** Копия-при-записи порциями: один `cp` на всё дерево вдвое медленнее. */
    clone(from: string, to: string, signal: AbortSignal): Promise<void>;
    copy(from: string, to: string): Promise<void>;
};
/**
 * Подготовить хранилище checkout до `prepare` и gates. Промах — обычный исход:
 * исключение бывает только при отмене, а сводка пишется в `dir`.
 * Окружение менеджера дописывается в `execution` (как `withEnvironment` дописывает
 * каталог окружения) и повторяется в квитанции для хостов с окружением на gate.
 */
export declare function materializeStore(ctx: StoreContext, input: {
    repo: Repo;
    cwd: string;
    execution: Execution;
    signal: AbortSignal;
    /** Каталог артефактов фазы: квитанция и журнал сборки. */
    dir: string;
}): Promise<StoreReceipt | undefined>;
export {};
