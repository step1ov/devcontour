# Самостоятельный проект

Как подготовить существующий Git-репозиторий npm или pnpm к работе с harness
без внешнего хоста: пользователь называет репозиторий, цель и ограничения,
остальное агент получает от `harness init`, а план составляет сам через
`harness plan-request` и `harness plan-check`. Пошаговый маршрут для агента —
skill [`skills/harness/SKILL.md`](../skills/harness/SKILL.md); установку,
первую настройку и обновление версии ведёт skill
[`skills/harness-setup/SKILL.md`](../skills/harness-setup/SKILL.md).

## Установка

Пакет ставится в отдельный каталог инструментов, а не в зависимости проекта:
`package.json` и lockfile проекта не меняются. Каталог — снаружи
репозитория или внутри него, в `.harness-tools/`.

```sh
npm install --prefix <tooldir> --save-exact --omit=dev --ignore-scripts devcontour-harness@<version>
# или из архива: npm install --prefix <tooldir> --omit=dev --ignore-scripts ./devcontour-harness-<version>.tgz
H=<tooldir>/node_modules/.bin/harness
$H --version
$H doctor
```

Внутри проекта (`<tooldir>` = `<repo>/.harness-tools`) версию закрепляют
`.harness-tools/package.json` и `package-lock.json`: их коммитят вместе с
`.harness/`, а `node_modules/` исключает `.harness-tools/.gitignore`. Чтобы
поручение не могло изменить инструмент, которым его проверяют, каталог
добавляют в `protectedPaths` политики. Установка из архива записывает в
`package.json` локальный путь `file:` — такой каталог целиком исключают через
`.git/info/exclude`. Worktrees попыток создаются из Git, поэтому
неотслеживаемый каталог инструментов в них не попадает. Состояние исполнения
в любом случае остаётся вне репозитория.

Обновление — смена закреплённой версии в том же каталоге по процедуре
[upgrade](upgrade.md): остановка writers, копия state, проверка копии новой
версией, установка, `doctor --state`, `init --plan`, `validate` графов,
`resume`. Новая версия не перегенерирует политику: если изменился встроенный
профиль, `init --plan` сообщает `content-differs` на `project.json`, и решение
принимает человек.

## `harness init`

```sh
$H init --repository <repo> --plan   # только план, ничего не пишет
$H init --repository <repo>          # create-only запись .harness/
```

Профиль: `--profile`, иначе сохранённый в manifest, иначе по lockfile — только
`package-lock.json` даёт `npm-ci`, только `pnpm-lock.yaml` — `pnpm-frozen`;
оба lockfile или ни одного — `NOT_READY` (`stack-ambiguous` /
`stack-unsupported`). Версия менеджера пакетов берётся из
`package.json#packageManager`, без него — из закрепления профиля. Writer —
`--writer claude` (по умолчанию) или `codex`; reviewer всегда другого вендора.
Политика генерируется из профиля и проверяется toolchain inspection: нет
script или подходящей версии инструмента — точная диагностика `NOT_READY`, а
не ослабленная политика.

| Путь                               | Что                                            | Запись                                        | Под Git         |
| ---------------------------------- | ---------------------------------------------- | --------------------------------------------- | --------------- |
| `.harness/.gitignore`              | исключает `project.json`                       | create, существующий сохраняется              | да              |
| `.harness/README.md`               | что лежит в каталоге и как продолжить работу   | create, существующий сохраняется              | да              |
| `.harness/project.json`            | manifest: решения init и абсолютный путь state | до политики; повтор — только байтово тот же   | нет (локальный) |
| `.harness/policy.json`             | `ExecutionPolicy` из решений manifest          | последней; настройку агента не перезаписывает | да              |
| `.harness/work/*.json`             | графы поручений                                | пишет агент                                   | по выбору       |
| `.harness/work/context/notes/*.md` | заметки, только при необходимости              | пишет агент                                   | по выбору       |
| state                              | состояние исполнения                           | создаёт `run`                                 | вне репозитория |

State по умолчанию — `<state home>/projects/<projectId>`, где state home —
`HARNESS_STATE_HOME`, иначе `$XDG_STATE_HOME/devcontour-harness`, иначе
`~/.local/state/devcontour-harness`; `projectId` — `p-` и 16 hex sha256 от
realpath корня, поэтому повтор и новая сессия находят тот же state.
`--state` внутри репозитория отклоняется: worktrees попыток не должны
вкладываться в checkout.

`init` не трогает `AGENTS.md`, `CLAUDE.md`, корневой `.gitignore`, lockfile и
`package.json` и не делает коммитов. Ответ `data` (`cliDataSchemas.init`):
`mode`, `status` до вызова (`new`, `partial`, `complete`), `files` с действием
по каждому файлу, `conflicts`, `created`, `preserved`, `manifest`, `profile`,
`facts` (репозиторий, target ref, роли, gates, каталоги работы, контекста и
заметок), `toolchain` и `next` — готовые вызовы `doctor`,
`validate`, `run`, `status`, `explain`.

Отказы, все до записи, в этом порядке:

1. Не каталог или не верхний уровень Git — `INVALID_INPUT` (`not-git-root`).
2. Нет коммитов — `NOT_READY` (`no-commits`).
3. Репозиторием уже владеет другой controller — `CONTROLLER_BUSY`; второй
   controller и state не создаются.
4. Невалидный существующий manifest — `INVALID_INPUT` с путём.
5. Профиль не определён — `NOT_READY` (`stack-ambiguous`, `stack-unsupported`).
6. `--state` внутри репозитория — `INVALID_INPUT` (`state-inside-repository`).
7. Невалидный существующий `.harness/policy.json` (в том числе обрыв посреди
   записи) — `INVALID_INPUT` с путём; файл не перезаписывается.
8. Конфликты плана — `PATH_CONFLICT`, все конфликты в `issues` с абсолютными
   путями: `symlink`, `ancestor-not-directory`, `not-regular-file`,
   `content-differs`, `outside-root`.
9. Проблемы toolchain — `NOT_READY`.

С `--plan` пункты 8–9 не бросаются: ответ `ok: true` с данными, exit 3 при
конфликтах или неготовом toolchain. Иное решение при существующем manifest
(другой `--writer`, профиль с другим digest) — `content-differs` на
`project.json`: решение меняется явно, файл не перезаписывается. Writer
сохранённой политики (выводится из reviewer ревью плана — другой вендор),
расходящийся с writer manifest или явного `--writer`, — `content-differs` на
`policy.json`, в том числе после ручной правки политики. Повтор с теми же
решениями даёт `created: []`. Manifest записывается до политики: после
прерывания подготовка продолжается по его решениям (профиль, writer, state) и
дописывает недостающее; `status: complete` — только при валидных manifest и
политике.

## Факты репозитория без записи

`inspectProject({ repository })` из корня пакета — библиотечная инспекция до
любой подготовки (схема `project-facts`): Git-корень, вид worktree, base SHA,
ветка, незакоммиченные изменения и первые 50 изменённых путей; lockfiles корня и менеджер пакетов
(`detected`, `ambiguous`, `none`) с полем `packageManager`; подходящие
встроенные профили с digest; scripts корневого `package.json` и похожие на
проверки (`checks`); версии git, node и менеджера с требуемой версией и её
источником; наличие CLI `claude`/`codex` — `available`, `missing` или
`version-error`, авторизация всегда `unknown`. `diagnostics` — коды с
`severity` (`blocker`, `warning`, `info`), текстом и следующим действием;
`ready` — нет блокирующих.

Инспекция ничего не создаёт (`.harness`, state, refs, индекс Git), не
исполняет scripts манифестов и не вызывает модели: единственные процессы —
Git без optional locks и пробы `--version` во временном каталоге. Маркеры
DevContour и готовый `.harness/` — факты (`info`), а не отказ. `init`
определяет корень и профиль тем же алгоритмом; хост применяет к фактам свои
правила размещения.

## Планирование

План составляет сам ведущий агент: отдельная модель-планировщик не
вызывается, ни `plan-request`, ни `plan-check` не запускают runtime, не
открывают state и ничего не пишут. Draft ничего не согласовывает:
согласование — только `review-plan` / `approve` / `run`.

```sh
$H plan-request --brief .harness/work/<id>.brief.md --policy .harness/policy.json \
  [--requirements [<repositoryId>:]docs/spec.md] [--contracts <dir>] [--context F] [--human]
$H plan-check --draft .harness/work/<id>.draft.json --policy .harness/policy.json \
  [--brief .harness/work/<id>.brief.md --basis <basis>] [--contracts <dir>] [--context F]
```

1. Постановка пользователя — файл `.harness/work/<id>.brief.md`.
   Неоднозначности цели разрешаются вопросами человеку, ответ входит в
   постановку.
2. `plan-request` (`cliDataSchemas['plan-request']`) возвращает `prompt`,
   `readOnly: true`, `recommendedTasks` (15), `maxTasks` (30), `facts`
   (`PlanningFacts`: репозитории, роли с `writePaths` и `requiresContract`,
   gates и группы, пакеты контекста, ресурсы, контракты с digest) и `basis` —
   digest постановки и фактов. `--requirements` называет закоммиченный файл
   с разделами `## REQ-*`: снимок требований на `HEAD` входит в prompt; файл
   вне Git — `NOT_READY`. Контекст по умолчанию — каталоги
   `<каталог политики>/work/context/<id>`. `--human` печатает только prompt.
3. Draft пишется по `schemas/plan-draft.schema.json`; пример —
   `templates/plan-draft.json` установленного пакета. Ключ задачи становится
   ID поручения, `description` — его целью, `writePaths` — областью записи
   (без них — весь репозиторий). Роли, gates, контракты, ресурсы и пакеты
   контекста берутся только из `facts`; требования копируются из снимка без
   изменений. Лишние ключи (например `approved`, `status`) отбрасываются.
4. `plan-check` (`cliDataSchemas['plan-check']`) проверяет draft против
   фактов и собирает `WorkGraph`: ответ `ok: true` с `issues`, `checkPlan`, а
   без проблем — `graph`, `graphDigest` и `basis`. ID графа — имя файла без
   `.draft.json`. Exit — 0 без проблем, иначе по классу первой проблемы.
5. Граф без изменений сохраняется в `.harness/work/<id>.json`; дальше —
   `validate`, `review-plan`, `run`. Digest записи ревью равен `graphDigest`.

| Проблема                                                                                  | Код                                              | Exit | Действие                                                          |
| ----------------------------------------------------------------------------------------- | ------------------------------------------------ | ---- | ----------------------------------------------------------------- |
| неизвестная роль, репозиторий, контракт, ресурс, пакет контекста; область записи вне роли | `INVALID_INPUT`                                  | 2    | исправить draft; ID и digest не подставляются                     |
| требование не найдено в источнике на `HEAD` или его digest выдуман                        | `INVALID_INPUT`                                  | 2    | скопировать требование из снимка `plan-request`                   |
| неизвестный gate или группа, цикл групп                                                   | `GATE_UNKNOWN`, `GATE_GROUP_CYCLE` + `checkPlan` | 2    | подготовить проверку (`declare-gate`), а не удалять gate из draft |
| в области задачи нет test gate                                                            | `INVALID_INPUT` + `checkPlan`                    | 2    | подготовить проверку (`add-test-gate`), а не снижать требования   |
| постановка или факты изменились после `plan-request` (`--basis`); требование изменилось   | `APPROVAL_STALE`                                 | 3    | повторить `plan-request` и составить draft заново                 |
| источник требований не обычный Git-файл                                                   | `NOT_READY`                                      | 3    | закоммитить источник                                              |

`checkPlan` — что подготовить, прежде чем согласовывать основную работу:
`gate-undeclared` / `declare-gate` (gate, как он написан в draft) или
`test-gate-missing` / `add-test-gate`, со списком объявленных test gates
репозитория. Gate объявляется в `.harness/policy.json` или локальном профиле
(проверка — `doctor --policy` или `init --plan`), либо отдельный bootstrap-граф,
доказанный уже объявленными gates. Смена политики меняет факты, а с ними
`basis`: draft составляется заново.

`plan-check` не запускает gates и не проверяет наличие `testId`: gates
исполняются только на кандидате и интеграции, никогда на base. Новый тест
пишется в той же задаче, что и поведение, которое он доказывает, и
связывается требованием (test gate, сценарий, `testId`): до реализации он
может падать, на принятом коммите обязан пройти. Задача, чьи gates заведомо
красные, не планируется; проект, падающий уже на base, — отдельная первая
задача.

Без `--basis` новая постановка даёт новый `source.revision` графа и, значит,
новый `graphDigest`: прежнее ревью к нему не относится.

## Граф, запуск, результат

Граф — `data.graph` из `plan-check`, сохранённый в `.harness/work/<id>.json`.
Граф можно написать и вручную по шаблону `templates/graph.json` установленного
пакета; `repositoryId`, роль, gates и область записи берутся только из `facts`.

```sh
$H validate --graph .harness/work/<id>.json --policy .harness/policy.json
$H run --graph .harness/work/<id>.json --policy .harness/policy.json \
  --state <manifest.paths.state> --author claude
$H result --state <manifest.paths.state> --work <order-id>
```

`result.outcome: accepted` и `result.shas.result`, равный
`git rev-parse refs/heads/harness/accepted`, — приёмка; зелёный exit сам по
себе ею не является.

## `harness explain`

```sh
$H explain --state <state> --policy .harness/policy.json [--work <id>] [--human]
```

Только чтение: без повторов, вызовов моделей и изменений попыток, бюджетов,
очереди, событий и refs. Отсутствующий state — `NOT_FOUND`, каталог не
создаётся. Пробу runtime выполняет так же, как `doctor` (`--version`, не вызов
модели). `data.diagnoses[]` (`cliDataSchemas.explain`,
`schemas/stop-diagnosis.schema.json`):

| Поле           | Значение                                                                                                                |
| -------------- | ----------------------------------------------------------------------------------------------------------------------- |
| `code`         | `ErrorCode` остановки                                                                                                   |
| `cause`        | класс сбоя (`FailureKind`) или `runtime-missing`, `controller-busy`, `operator-pause`, `approval-required`, `not-ready` |
| `phase`        | `preflight`, `claim`, `implementation`, `gates`, `review`, `integration`, `delivery`                                    |
| `actor`        | `controller`, `lead` (ведущий агент), `user` (человек) или `null`                                                       |
| `action`       | допустимый следующий шаг                                                                                                |
| `retryPlanned` | движок сам назначит повтор по политике восстановления                                                                   |
| `message`      | текст, не длиннее 2000 символов                                                                                         |
| `evidence`     | до 20 ссылок `{kind: attempt \| evidence \| event \| doctor, id, sha?}`                                                 |

Класс сбоя берётся из сохранённой попытки, текст повторно не разбирается.
Сначала идут диагнозы runtime, затем controller, затем поручения. Человеку
передаются только действия `user`: `fix-access`, `fix-environment`,
`raise-budget`, `reset-attempts`, `user-decision`, `resume-queue`.

`--human` (только `init`, `explain` и `plan-request`) печатает текст вместо успешного
конверта; отказ остаётся JSON-конвертом. Exit code одинаков в обоих режимах.

## Новая сессия

1. `$H init --repository <repo> --plan` — сохранённый manifest и
   `status: complete`, ничего не пишется.
2. `$H status --state <paths.state>` — `NOT_FOUND` значит «ещё не запускали».
3. `$H explain --state <paths.state> --policy <repo>/.harness/policy.json`.
4. Графы `.harness/work/*.json` и заметки.

## Заметки

Внешние сервисы заметок и сообщений не вызываются, модули `integrations/*` не
загружаются. Заметка — Markdown в `.harness/work/context/notes/`; в снимок
контекста она попадает, только если поручение указывает `"context":
["notes"]`, тогда снимок закрепляет её digest и отклоняет symlink.

## Общие проекции

`devcontour-harness/projections` — чистые функции без `node:*` (подходят для
браузерного бандла): `chainRoots`, `workProgress`, `nextAction`, `queueStop`,
`explainStop`, `stopCodeOf`, `clipText`, `clipDeep` и их перечни. Корень пакета
экспортирует те же функции — реализация одна. Безопасная запись файлов —
`inspectPath`, `checkDestination`, `listRegularFiles`, `planFileWrites`,
`applyFileWrites` из корня: план показывает все конфликты сразу, применение
только создаёт файлы и повторно проверяет назначение перед каждой записью.

## Каталог и пределы ответа

`harness capabilities` возвращает каталог общих операций (`init`, `explain`,
`plan-request`, `plan-check`, `capabilities`): для каждой — описание,
`readOnly`, JSON Schema входа и данных ответа, а также пределы UTF-8 байт
(`maxInputBytes` 100000, `maxResultBytes` 1048576). Каталог строится из договора
CLI — второй копии описаний нет. Ответ общей операции сверх предела — отказ
`RESPONSE_TOO_LARGE` (exit 2) без усечения данных: сузьте вход (`--work`,
постановка, файлы требований).

Для хостов: `operationCatalog` строит каталог из своих операций и схем (тем
же построителем, что `capabilities`, но отдельно от каталога harness);
`jsonBytes`, `checkJsonBytes` и `utf8Bytes` — байтовые проверки транспорта
(отказ формирует хост); `pageItems` — страницы с cursor (`json-base64url` с
привязкой к ревизии и запросу или `digest-offset` по ревизии; чужой или
устаревший cursor — `REVISION_CONFLICT`, элемент, не помещающийся в страницу,
— `RESPONSE_TOO_LARGE`). `resolveProfile(ref, { includeLeafContent: true })`
дополнительно возвращает текст файла листа (`leafContent`); digest не меняется.
`resolveProfile(ref, { layerSchema })` разбирает профили схемой файла хоста
(закреплённые у хоста профили своей формы) при прежних сложении, проверках
gates и digest.
