import { z } from 'zod';
import { repositoryPolicySchema, type ProfilePin, type ResolvedProfile, type ResolvedProfileWithLeaf, type StackProfile } from '../contracts/index.ts';
/** Встроенные профили пакета: `profiles/<id>.json` рядом с `lib/`. */
export declare const builtinProfilesRoot: string;
export interface ResolveProfileOptions {
    /** Корень репозитория, внутри которого лежат локальные профили (`./file.json`). */
    repository?: string;
    /** ID репозитория в политике; записывается в источник локального профиля. */
    repositoryId?: string;
    /** Каталог встроенных профилей; по умолчанию — профили пакета. */
    builtinRoot?: string;
    /** Вернуть текст файла листа (`leafContent`) — для хоста, который хранит его сам. */
    includeLeafContent?: boolean;
}
/**
 * Слой профиля, который складывает resolver: поля, от которых зависит
 * сложение и проверки gates. Схема файла хоста (`layerSchema`) обязана давать
 * их; прочие поля ролей, gates, шагов и инструкций — форма хоста, harness их
 * переносит как есть.
 */
export interface ProfileLayer {
    id: string;
    version: string;
    extends: string[];
    capabilities: string[];
    gates: {
        id: string;
        kind: 'check' | 'test';
        dependsOn?: string[];
        report?: unknown;
    }[];
    prepare: {
        id: string;
    }[];
    environment?: unknown;
    lifecycle?: {
        setup: {
            id: string;
        }[];
        ready: {
            id: string;
        }[];
        teardown: {
            id: string;
        }[];
    };
    toolchain?: StackProfile['toolchain'];
    protectedPaths: string[];
    generatedPaths: string[];
    concurrency?: number;
    runTimeoutMs?: number;
    roles: Record<string, unknown>;
    contextPacks: {
        id: string;
    }[];
}
/** Профиль, разрешённый по схеме файла хоста: поля слоёв — в форме хоста. */
export type ResolvedProfileOf<L extends ProfileLayer> = Omit<ResolvedProfile, 'gates' | 'prepare' | 'environment' | 'lifecycle' | 'toolchain' | 'roles' | 'contextPacks'> & {
    gates: L['gates'];
    prepare: L['prepare'];
    environment?: NonNullable<L['environment']>;
    lifecycle?: NonNullable<L['lifecycle']>;
    toolchain?: NonNullable<L['toolchain']>;
    roles: L['roles'];
    contextPacks: L['contextPacks'];
};
/**
 * Опции разрешения по схеме файла хоста. Профили, закреплённые у хоста, могут
 * иметь свою форму (другие runtime ролей, свои поля, нестрогие вложенные
 * объекты): `layerSchema` разбирает каждый файл вместо `stackProfileSchema`.
 * Безопасность файлов, обход `extends`, сложение слоёв, проверки gates и
 * digest — прежние.
 */
export interface ResolveProfileLayerOptions<L extends ProfileLayer> extends ResolveProfileOptions {
    layerSchema: z.ZodType<L>;
}
/** ID встроенных профилей пакета. */
export declare function builtinProfiles(root?: string): string[];
/**
 * Разрешение профиля: встроенный ID или относительный `./file.json` внутри
 * репозитория, слои `extends` в глубину, без циклов и не больше 32 файлов.
 * Только чтение манифестов — ни одна команда проекта не исполняется.
 *
 * Слои складываются: gates, подготовка, возможности, защищённые и
 * генерируемые пути — объединением; окружение и lifecycle — только из одного
 * слоя (иначе конфликт); параллельность — наименьшая, время попытки —
 * наибольшее; роли и инструкции стека — по ID, надстройка уточняет базу.
 * Итоговый профиль обязан иметь test gate с JUnit: зелёный выход без отчёта
 * ничего не доказывает. Файлы локальных слоёв становятся защищёнными путями.
 *
 * С `layerSchema` файлы разбирает схема хоста, а gates, роли, шаги и
 * инструкции остаются в её форме (см. `ResolveProfileLayerOptions`).
 */
export declare function resolveProfile<L extends ProfileLayer>(ref: string, options: ResolveProfileLayerOptions<L> & {
    includeLeafContent: true;
}): ResolvedProfileOf<L> & {
    leafContent: string;
};
export declare function resolveProfile<L extends ProfileLayer>(ref: string, options: ResolveProfileLayerOptions<L>): ResolvedProfileOf<L>;
export declare function resolveProfile(ref: string, options: ResolveProfileOptions & {
    includeLeafContent: true;
}): ResolvedProfileWithLeaf;
export declare function resolveProfile(ref: string, options?: ResolveProfileOptions): ResolvedProfile;
export declare const profilePin: (p: ResolvedProfile) => ProfilePin;
type RepositoryInput = z.input<typeof repositoryPolicySchema>;
/**
 * Описание репозитория политики из профиля. Явные значения `own` сильнее
 * профиля и ничего не дополняют молча: `shadowed` называет поля, которые
 * профиль задаёт иначе, а `own` переопределяет, — иначе обновлённый профиль с
 * новым gate «применялся бы», не доходя до политики.
 */
export declare function repositoryFromProfile(profile: ResolvedProfile, own: Pick<RepositoryInput, 'id' | 'path' | 'targetRef'> & Partial<RepositoryInput>): {
    repository: {
        id: string;
        path: string;
        kind: "product" | "library";
        targetRef: string;
        dependsOn: string[];
        gates: ({
            kind: "test";
            report: {
                type: "junit";
                path: string;
            };
            id: string;
            command: string[];
            timeoutMs: number;
            artifacts?: string[] | undefined;
            property?: {
                path?: string | undefined;
            } | undefined;
            dependsOn?: string[] | undefined;
            cwd?: string | undefined;
            resources?: string[] | undefined;
        } | {
            kind: "check";
            id: string;
            command: string[];
            timeoutMs: number;
            report?: {
                type: "junit";
                path: string;
            } | undefined;
            artifacts?: string[] | undefined;
            property?: {
                path?: string | undefined;
            } | undefined;
            dependsOn?: string[] | undefined;
            cwd?: string | undefined;
            resources?: string[] | undefined;
        })[];
        protectedPaths: string[];
        generatedPaths: string[];
        prepare: {
            id: string;
            command: string[];
            timeoutMs: number;
        }[];
        dependencyBuild: {
            id: string;
            command: string[];
            timeoutMs: number;
        }[];
        dependencyArtifacts: string[];
        preflight: {
            id: string;
            command: string[];
            timeoutMs: number;
        }[];
        roles?: Record<string, {
            writer: {
                runtime: "codex" | "claude" | "fixture";
                model?: string | undefined;
                effort?: "low" | "medium" | "high" | "xhigh" | undefined;
                toolProfile?: string | undefined;
            };
            requiresContract: boolean;
            writePaths?: string[] | undefined;
            review?: {
                reviewer: {
                    runtime: "codex" | "claude" | "fixture";
                    model?: string | undefined;
                    effort?: "low" | "medium" | "high" | "xhigh" | undefined;
                    toolProfile?: string | undefined;
                };
                vendor: "different-vendor" | "same-vendor-allowed";
                alternates?: {
                    runtime: "codex" | "claude" | "fixture";
                    model?: string | undefined;
                    effort?: "low" | "medium" | "high" | "xhigh" | undefined;
                    toolProfile?: string | undefined;
                }[] | undefined;
            } | undefined;
        }> | undefined;
        review?: {
            reviewer: {
                runtime: "codex" | "claude" | "fixture";
                model?: string | undefined;
                effort?: "low" | "medium" | "high" | "xhigh" | undefined;
                toolProfile?: string | undefined;
            };
            vendor: "different-vendor" | "same-vendor-allowed";
            alternates?: {
                runtime: "codex" | "claude" | "fixture";
                model?: string | undefined;
                effort?: "low" | "medium" | "high" | "xhigh" | undefined;
                toolProfile?: string | undefined;
            }[] | undefined;
        } | undefined;
        gateGroups?: Record<string, string[]> | undefined;
        environment?: {
            inherit: string[];
            values: Record<string, string>;
            secrets: Record<string, string>;
        } | undefined;
        lifecycle?: {
            setup: {
                id: string;
                command: string[];
                timeoutMs: number;
            }[];
            ready: {
                id: string;
                command: string[];
                timeoutMs: number;
            }[];
            teardown: {
                id: string;
                command: string[];
                timeoutMs: number;
            }[];
        } | undefined;
        dependencyStore?: {
            manager: "pnpm";
            lockfile: string;
            maxBytes: number;
            timeoutMs: number;
        } | undefined;
        writerDependencies?: boolean | undefined;
        toolchain?: {
            tools: Record<string, string>;
            packageManagers: Record<string, "npm" | "pnpm">;
        } | undefined;
    };
    shadowed: ("gates" | "prepare" | "protectedPaths" | "generatedPaths" | "environment" | "lifecycle" | "toolchain")[];
};
/** Роли профиля в форме политики: writer, область записи и правило ревью кода роли. */
export declare function profileRoles(profile: ResolvedProfile): {
    [k: string]: {
        writer: {
            runtime: "codex" | "claude" | "fixture";
            model?: string | undefined;
            effort?: "low" | "medium" | "high" | "xhigh" | undefined;
            toolProfile?: string | undefined;
        };
        requiresContract: boolean;
        writePaths?: string[] | undefined;
        review?: {
            reviewer: {
                runtime: "codex" | "claude" | "fixture";
                model?: string | undefined;
                effort?: "low" | "medium" | "high" | "xhigh" | undefined;
                toolProfile?: string | undefined;
            };
            vendor: "different-vendor" | "same-vendor-allowed";
            alternates?: {
                runtime: "codex" | "claude" | "fixture";
                model?: string | undefined;
                effort?: "low" | "medium" | "high" | "xhigh" | undefined;
                toolProfile?: string | undefined;
            }[] | undefined;
        } | undefined;
    };
};
export {};
