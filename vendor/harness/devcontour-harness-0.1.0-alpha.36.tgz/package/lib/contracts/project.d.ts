import { z } from 'zod';
/**
 * Самостоятельный проект harness в репозитории пользователя. Каталог
 * `.harness/` хранит политику и рабочие файлы агента; manifest — локальные
 * решения подготовки (абсолютные пути), поэтому он не под Git. Состояние
 * исполнения живёт вне репозитория: worktrees попыток не вкладываются в checkout.
 */
export declare const HARNESS_PROJECT_DIR = ".harness";
export declare const PROJECT_MANIFEST_PATH = ".harness/project.json";
export declare const PROJECT_POLICY_PATH = ".harness/policy.json";
export declare const PROJECT_WORK_DIR = ".harness/work";
export declare const PROJECT_NOTES_DIR = ".harness/work/context/notes";
export declare const projectManifestSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    kind: z.ZodLiteral<"harness-project">;
    manifestVersion: z.ZodLiteral<1>;
    projectId: z.ZodString;
    root: z.ZodString;
    repository: z.ZodObject<{
        id: z.ZodString;
        targetRef: z.ZodString;
    }, z.core.$strict>;
    profile: z.ZodObject<{
        ref: z.ZodString;
        pin: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            source: z.ZodOptional<z.ZodObject<{
                repositoryId: z.ZodString;
                path: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    runtimes: z.ZodObject<{
        writer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
        reviewer: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
    }, z.core.$strict>;
    paths: z.ZodObject<{
        policy: z.ZodLiteral<".harness/policy.json">;
        work: z.ZodLiteral<".harness/work">;
        notes: z.ZodLiteral<".harness/work/context/notes">;
        state: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export type ProjectManifest = z.infer<typeof projectManifestSchema>;
export declare const fileConflicts: readonly ["symlink", "ancestor-not-directory", "not-regular-file", "content-differs", "outside-root"];
export declare const filePlanEntrySchema: z.ZodObject<{
    path: z.ZodString;
    action: z.ZodEnum<{
        conflict: "conflict";
        create: "create";
        preserve: "preserve";
    }>;
    conflict: z.ZodOptional<z.ZodEnum<{
        symlink: "symlink";
        "ancestor-not-directory": "ancestor-not-directory";
        "not-regular-file": "not-regular-file";
        "content-differs": "content-differs";
        "outside-root": "outside-root";
    }>>;
    conflictPath: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
/**
 * Причины инспекции репозитория (`inspectProject`). `blocker` не даёт начать
 * подготовку, `warning` требует решения или внимания, `info` — факт.
 */
export declare const projectDiagnosticCodes: readonly ["path-missing", "not-directory", "not-git-repository", "inside-repository", "git-worktree", "no-commits", "dirty-checkout", "stack-ambiguous", "stack-unsupported", "package-json-missing", "package-json-invalid", "manager-mismatch", "no-check-scripts", "tool-missing", "tool-version-error", "tool-version-mismatch", "runtime-missing", "runtime-version-error", "devcontour-owned", "harness-project"];
export type ProjectDiagnosticCode = (typeof projectDiagnosticCodes)[number];
/**
 * Факты готовности репозитория к первому запуску: только чтение файлов, Git
 * без optional locks и пробы `--version` вне репозитория. Не создаёт
 * `.harness`, state и refs; не исполняет scripts манифестов и не вызывает
 * модели. Авторизация runtime неизвестна (`auth: 'unknown'`): наличие CLI её
 * не подтверждает. Правила размещения и владения применяет вызывающий.
 */
export declare const projectFactsSchema: z.ZodObject<{
    apiVersion: z.ZodLiteral<"devcontour-harness/v1alpha1">;
    kind: z.ZodLiteral<"project-facts">;
    path: z.ZodString;
    git: z.ZodObject<{
        root: z.ZodNullable<z.ZodString>;
        worktree: z.ZodNullable<z.ZodEnum<{
            main: "main";
            linked: "linked";
        }>>;
        baseSha: z.ZodNullable<z.ZodString>;
        branch: z.ZodNullable<z.ZodString>;
        dirty: z.ZodNullable<z.ZodBoolean>;
        changes: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    lockfiles: z.ZodArray<z.ZodString>;
    packageManager: z.ZodObject<{
        status: z.ZodEnum<{
            none: "none";
            detected: "detected";
            ambiguous: "ambiguous";
        }>;
        name: z.ZodOptional<z.ZodEnum<{
            npm: "npm";
            pnpm: "pnpm";
        }>>;
        lockfile: z.ZodOptional<z.ZodString>;
        declared: z.ZodOptional<z.ZodObject<{
            name: z.ZodString;
            version: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    profiles: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        source: z.ZodOptional<z.ZodObject<{
            repositoryId: z.ZodString;
            path: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    scripts: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        command: z.ZodString;
    }, z.core.$strict>>;
    checks: z.ZodArray<z.ZodString>;
    tools: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        status: z.ZodEnum<{
            missing: "missing";
            ok: "ok";
            "version-error": "version-error";
            mismatch: "mismatch";
        }>;
        version: z.ZodOptional<z.ZodString>;
        required: z.ZodOptional<z.ZodObject<{
            version: z.ZodString;
            source: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    runtimes: z.ZodArray<z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
        status: z.ZodEnum<{
            missing: "missing";
            available: "available";
            "version-error": "version-error";
        }>;
        version: z.ZodOptional<z.ZodString>;
        auth: z.ZodLiteral<"unknown">;
    }, z.core.$strict>>;
    markers: z.ZodObject<{
        devcontour: z.ZodArray<z.ZodString>;
        harnessProject: z.ZodBoolean;
    }, z.core.$strict>;
    diagnostics: z.ZodArray<z.ZodObject<{
        code: z.ZodEnum<{
            "harness-project": "harness-project";
            "path-missing": "path-missing";
            "not-directory": "not-directory";
            "not-git-repository": "not-git-repository";
            "inside-repository": "inside-repository";
            "git-worktree": "git-worktree";
            "no-commits": "no-commits";
            "dirty-checkout": "dirty-checkout";
            "stack-ambiguous": "stack-ambiguous";
            "stack-unsupported": "stack-unsupported";
            "package-json-missing": "package-json-missing";
            "package-json-invalid": "package-json-invalid";
            "manager-mismatch": "manager-mismatch";
            "no-check-scripts": "no-check-scripts";
            "tool-missing": "tool-missing";
            "tool-version-error": "tool-version-error";
            "tool-version-mismatch": "tool-version-mismatch";
            "runtime-missing": "runtime-missing";
            "runtime-version-error": "runtime-version-error";
            "devcontour-owned": "devcontour-owned";
        }>;
        severity: z.ZodEnum<{
            blocker: "blocker";
            warning: "warning";
            info: "info";
        }>;
        message: z.ZodString;
        action: z.ZodString;
        path: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    ready: z.ZodBoolean;
}, z.core.$strict>;
export type ProjectFacts = z.infer<typeof projectFactsSchema>;
