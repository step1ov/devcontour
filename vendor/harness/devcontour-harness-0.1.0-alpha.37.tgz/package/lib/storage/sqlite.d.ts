import { type ExecutionStore, type ExecutionTransaction, type ExecutionView, type NotPromise, type RunEvent, type TransactionKind } from '../contracts/index.ts';
/**
 * Standalone ExecutionStore: нейтральный документ, события и локальные
 * записи в одной SQLite. Транзакция — `BEGIN IMMEDIATE` (вложенная —
 * SAVEPOINT); документ читается один раз на внешнюю транзакцию, вложенные
 * работают с ним же и при отказе восстанавливают его снимок и свой буфер
 * событий. Документ проверяется схемой при каждой фиксации: состояние вне
 * договора не записывается.
 *
 * Версия: в `meta` записаны версия формата и версия писателя. Неизвестная
 * версия формата отклоняется при открытии, до любой записи.
 */
export declare class SqliteExecutionStore implements ExecutionStore {
    readonly file: string;
    readonly writer: string;
    readonly options: {
        readOnly?: boolean;
        /**
         * Только с `readOnly`: неизменяемое открытие без файлов и блокировок —
         * для однократного чтения через `SqliteExecutionStore.readOnce`.
         */
        immutable?: boolean;
    };
    readonly stateVersion: 1;
    private db;
    private frame?;
    /** Снимок внешнего `read`: вложенное чтение видит его же, без второго BEGIN. */
    private reading?;
    private savepoint;
    constructor(file: string, writer: string, options?: {
        readOnly?: boolean;
        /**
         * Только с `readOnly`: неизменяемое открытие без файлов и блокировок —
         * для однократного чтения через `SqliteExecutionStore.readOnce`.
         */
        immutable?: boolean;
    });
    /**
     * Однократное чтение без единого файла в каталоге состояния (`report`).
     * Если журнала (`-wal`, `-journal`) нет, база открывается неизменяемой;
     * после чтения проверяется, что журнал не появился, а размер и время
     * основного файла прежние. Иначе (писатель начал работу или журнал уже
     * был) чтение повторяется обычным открытием только для чтения — с его
     * служебными `-wal`/`-shm`, но согласованное.
     */
    static readOnce<T>(file: string, writer: string, fn: (store: SqliteExecutionStore) => T): T;
    /** Проверка существующего файла без единой записи; отказ — HarnessError. */
    private static preflight;
    private load;
    read<T>(fn: (view: ExecutionView) => NotPromise<T>): T;
    transact<T>(kind: TransactionKind, fn: (tx: ExecutionTransaction) => NotPromise<T>): T;
    private writeEvents;
    events(after?: number, limit?: number): RunEvent[];
    close(): void;
    private view;
}
