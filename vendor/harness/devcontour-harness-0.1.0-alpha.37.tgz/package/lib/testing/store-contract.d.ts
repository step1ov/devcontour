import { type ExecutionStore, type InputRequest } from '../contracts/index.ts';
/**
 * Запрос исполнителя (`input-requests`) для проверок адаптера: вопрос с
 * вариантами, основание исходной попытки, без ответов (`pending`).
 */
export declare function sampleInputRequest(runId?: string, workId?: string): InputRequest;
/** Тот же запрос с ответом: `answered`, следующая версия. */
export declare function answeredInputRequest(request: InputRequest, text?: string): InputRequest;
/**
 * Общий набор проверок договора `ExecutionStore`. Его проходят standalone
 * SQLite и адаптер любого хоста: `open` открывает хранилище в каталоге,
 * повторный вызов с тем же каталогом — то же хранилище другим экземпляром.
 * Регистрация тестов — через переданную `test` (node:test).
 */
export declare function executionStoreContract(name: string, test: (title: string, fn: () => void | Promise<void>) => unknown, open: (dir: string) => ExecutionStore, tempDir: () => string): void;
