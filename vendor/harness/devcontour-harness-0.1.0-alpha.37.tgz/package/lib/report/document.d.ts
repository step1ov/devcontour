import type { ValueReport } from '../contracts/report.ts';
export type Block = {
    kind: 'heading';
    level: 1 | 2 | 3;
    text: string;
} | {
    kind: 'paragraph';
    text: string;
    muted?: true;
} | {
    kind: 'list';
    items: string[];
} | {
    kind: 'table';
    head: string[];
    rows: string[][];
    /** Столбцы с числами выравниваются вправо. */
    numeric: number[];
} | {
    kind: 'summary';
    summary: ValueReport['summary'];
} | {
    kind: 'weeks';
    weeks: ValueReport['weeks'];
};
/** Блоки отчёта в порядке разделов (`docs/contracts.md`, «Отчёт»). */
export declare function reportBlocks(r: ValueReport): Block[];
