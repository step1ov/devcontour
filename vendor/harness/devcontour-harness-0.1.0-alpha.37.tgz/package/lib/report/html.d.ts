import type { ValueReport } from '../contracts/report.ts';
/**
 * Отчёт одним HTML-файлом: встроенный CSS, светлая и тёмная схема по
 * `prefers-color-scheme`, читается на ширине телефона; скриптов, шрифтов,
 * изображений и внешних ссылок нет.
 */
export declare function reportHtml(report: ValueReport): string;
