import type { ValueReport } from '../contracts/report.ts';
/** Строки недель (новые сверху) для таблицы. */
export declare function weekCells(weeks: ValueReport['weeks']): string[][];
export declare const weekColumns: string[];
export declare const weekNumeric: number[];
/** Отчёт в Markdown: те же разделы и числа, что в HTML. */
export declare function reportMarkdown(report: ValueReport): string;
