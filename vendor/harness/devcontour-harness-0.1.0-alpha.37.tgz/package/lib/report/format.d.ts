import type { ReportDist, ReportMeasure } from '../contracts/report.ts';
/** Длительность: «45 s», «58 min», «3.2 h», «20.6 d». */
export declare function formatDuration(ms: number): string;
/** Доллары с двумя знаками. */
export declare const formatUsd: (usd: number) => string;
/** «k of n»; процент — только при знаменателе от 20. */
export declare function formatRatio(k: number, n: number): string;
/** Знак границы: «≥ », «≤ » или ничего. */
export declare const boundPrefix: (m: Pick<ReportMeasure, "bound">) => "" | "≥ " | "≤ ";
/** Мера-доля: «≥ 3 of 19», «unknown». */
export declare function formatMeasureRatio(m: ReportMeasure): string;
/** Мера в долларах: «≥ $5.73», «= $5.73», «unknown». */
export declare function formatMeasureUsd(m: ReportMeasure): string;
/**
 * Распределение длительностей: «median 58 min, p75 11.0 h (n=19)»; при
 * n < 5 — перечень значений без медианы.
 */
export declare function formatDist(d: ReportDist, value?: (v: number) => string): string;
/** Окно отчёта простыми словами. */
export declare function formatWindow(w: {
    since: string | null;
    until: string | null;
}): string;
