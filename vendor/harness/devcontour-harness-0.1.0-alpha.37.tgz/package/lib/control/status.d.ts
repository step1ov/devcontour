import { type ExecutionPolicy } from '../contracts/index.ts';
import type { Engine } from '../engine/engine.ts';
/**
 * Что читает `statusOf`: движок над хранилищем и политика исполнения.
 * `Harness` удовлетворяет ему структурно; хост со своим `Engine` передаёт
 * `{ engine, policy }`.
 */
export interface StatusSource {
    readonly engine: Engine;
    readonly policy: ExecutionPolicy;
}
/**
 * Состояние очереди, графов и поручений (`Harness.status`, `harness status`)
 * над движком и политикой источника. С `detail` — ещё снимок наблюдателя:
 * почему стоит выдача (`queueStop` и `queuePause`) и активные попытки
 * (`attemptView`); без него ответ прежний. Только чтение, один `read`.
 */
export declare function statusOf(source: StatusSource, graphId?: string, options?: {
    detail?: boolean;
}): {
    detail?: {
        at: string;
        queue: {
            liftedByRun: true;
            code: "NOT_READY";
            cause: "not-ready";
            actor: "controller";
            action: "wait";
            operation?: string | undefined;
            since?: string | undefined;
            detail: string;
            reason?: "operator" | "runtime" | "shutdown" | "base-check" | "reconfigure" | undefined;
            paused: boolean;
        } | {
            code?: "INVALID_INPUT" | "UNSUPPORTED_COMMAND" | "UNSUPPORTED_VERSION" | "GRAPH_CYCLE" | "GRAPH_UNKNOWN_DEPENDENCY" | "GRAPH_DUPLICATE_ID" | "GATE_UNKNOWN" | "GATE_GROUP_CYCLE" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "RESPONSE_TOO_LARGE" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "LEASE_STALE" | "CONTROLLER_BUSY" | "PAUSED" | "NOT_READY" | "SCOPE_VIOLATION" | "GATE_FAILED" | "REVIEW_REJECTED" | "BUDGET_EXHAUSTED" | "BUDGET_UNKNOWN" | "ATTEMPTS_EXHAUSTED" | "CONTEXT_EXHAUSTED" | "INPUT_REQUIRED" | "REVISION_CONFLICT" | "CANCELLED" | "NOT_FOUND" | "PATH_CONFLICT" | "STATE_VERSION_UNSUPPORTED" | "RUNTIME_UNAVAILABLE" | "REVIEW_PROTOCOL_INVALID" | "SANDBOX_UNAVAILABLE" | "GIT_FAILED" | "STORAGE_FAILED" | "DELIVERY_FAILED" | "INTERNAL" | undefined;
            cause?: "gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input" | "runtime-missing" | "controller-busy" | "operator-pause" | "approval-required" | "not-ready" | undefined;
            actor?: import("../projections/enums.ts").Actor | undefined;
            action?: "none" | "wait" | "retry" | "review-plan" | "diagnose-failure" | "reset-attempts" | "raise-budget" | "replan-dependents" | "recovery-decision" | "user-decision" | "resume-queue" | "fix-environment" | "fix-access" | "answer-input" | "apply-input" | undefined;
            failures?: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input")[] | undefined;
            operation?: string | undefined;
            since?: string | undefined;
            detail?: string;
            paused: boolean;
            reason?: import("../contracts/execution.ts").PauseReason;
        };
        attempts: import("../projections/attempt.ts").AttemptView[];
    } | undefined;
    budgets: {
        onUnknown: "continue" | "stop";
        budgets: {
            reason?: string | undefined;
            scope: import("../engine/budget.ts").BudgetScope;
            state: "exceeded" | "undetermined" | "within";
            limit: {
                usd?: number;
                timeMs?: number;
            };
            reportedUsd: number;
            estimatedUsd: number;
            unknownCalls: number;
            unfinishedCalls: number;
            abandonedCalls: number;
            errorCalls: number;
            uncoveredRuns: number;
            durationMs: number;
            remainingUsd: number | null;
            remainingMs: number | null;
        }[];
    };
    graphs: {
        id: string;
        digest: string;
        source: {
            connector: string;
            ref: string;
            revision: string;
        };
        approved: boolean;
    }[];
    works: ({
        blockers: {
            code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT" | "INPUT_REQUIRED";
            message: string;
        }[];
        followUps?: number | undefined;
        input?: import("../projections/input.ts").WorkInputView | undefined;
        resultSha?: string | undefined;
        liveness: "stalled" | "quiet";
        activeRunId?: string | undefined;
        id: string;
        graphId: string;
        status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        attempt: number;
    } | {
        blockers: {
            code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT" | "INPUT_REQUIRED";
            message: string;
        }[];
        followUps?: number | undefined;
        input?: import("../projections/input.ts").WorkInputView | undefined;
        resultSha?: string | undefined;
        liveness?: undefined;
        activeRunId?: string | undefined;
        id: string;
        graphId: string;
        status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        attempt: number;
    })[];
    controller?: {
        owner: string;
        leaseUntil: number;
        engineVersion?: string | undefined;
    } | undefined;
    stateVersion: 1;
    control: {
        paused: boolean;
        pauseReason?: "operator" | "runtime" | "shutdown" | "base-check" | "reconfigure" | undefined;
        pausedAt?: string | undefined;
        pauseOperation?: string | undefined;
        pauseFailures?: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input")[] | undefined;
        waits?: {
            kind: "base-check" | "context-lock";
            detail: string;
            at: string;
            operation?: string | undefined;
        }[] | undefined;
        appliedPolicy?: {
            digest: string;
            at: string;
            by: string;
            generation?: number | undefined;
        } | undefined;
        reconfigure?: {
            operation: string;
            digest: string;
            requestedAt: string;
            appliedAt?: string | undefined;
            appliedBy?: string | undefined;
            error?: string | undefined;
        } | undefined;
    };
} | {
    detail?: {
        at: string;
        queue: {
            liftedByRun: true;
            code: "NOT_READY";
            cause: "not-ready";
            actor: "controller";
            action: "wait";
            operation?: string | undefined;
            since?: string | undefined;
            detail: string;
            reason?: "operator" | "runtime" | "shutdown" | "base-check" | "reconfigure" | undefined;
            paused: boolean;
        } | {
            code?: "INVALID_INPUT" | "UNSUPPORTED_COMMAND" | "UNSUPPORTED_VERSION" | "GRAPH_CYCLE" | "GRAPH_UNKNOWN_DEPENDENCY" | "GRAPH_DUPLICATE_ID" | "GATE_UNKNOWN" | "GATE_GROUP_CYCLE" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "RESPONSE_TOO_LARGE" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "LEASE_STALE" | "CONTROLLER_BUSY" | "PAUSED" | "NOT_READY" | "SCOPE_VIOLATION" | "GATE_FAILED" | "REVIEW_REJECTED" | "BUDGET_EXHAUSTED" | "BUDGET_UNKNOWN" | "ATTEMPTS_EXHAUSTED" | "CONTEXT_EXHAUSTED" | "INPUT_REQUIRED" | "REVISION_CONFLICT" | "CANCELLED" | "NOT_FOUND" | "PATH_CONFLICT" | "STATE_VERSION_UNSUPPORTED" | "RUNTIME_UNAVAILABLE" | "REVIEW_PROTOCOL_INVALID" | "SANDBOX_UNAVAILABLE" | "GIT_FAILED" | "STORAGE_FAILED" | "DELIVERY_FAILED" | "INTERNAL" | undefined;
            cause?: "gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input" | "runtime-missing" | "controller-busy" | "operator-pause" | "approval-required" | "not-ready" | undefined;
            actor?: import("../projections/enums.ts").Actor | undefined;
            action?: "none" | "wait" | "retry" | "review-plan" | "diagnose-failure" | "reset-attempts" | "raise-budget" | "replan-dependents" | "recovery-decision" | "user-decision" | "resume-queue" | "fix-environment" | "fix-access" | "answer-input" | "apply-input" | undefined;
            failures?: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input")[] | undefined;
            operation?: string | undefined;
            since?: string | undefined;
            detail?: string;
            paused: boolean;
            reason?: import("../contracts/execution.ts").PauseReason;
        };
        attempts: import("../projections/attempt.ts").AttemptView[];
    } | undefined;
    budgets?: undefined;
    graphs: {
        id: string;
        digest: string;
        source: {
            connector: string;
            ref: string;
            revision: string;
        };
        approved: boolean;
    }[];
    works: ({
        blockers: {
            code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT" | "INPUT_REQUIRED";
            message: string;
        }[];
        followUps?: number | undefined;
        input?: import("../projections/input.ts").WorkInputView | undefined;
        resultSha?: string | undefined;
        liveness: "stalled" | "quiet";
        activeRunId?: string | undefined;
        id: string;
        graphId: string;
        status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        attempt: number;
    } | {
        blockers: {
            code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT" | "INPUT_REQUIRED";
            message: string;
        }[];
        followUps?: number | undefined;
        input?: import("../projections/input.ts").WorkInputView | undefined;
        resultSha?: string | undefined;
        liveness?: undefined;
        activeRunId?: string | undefined;
        id: string;
        graphId: string;
        status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        attempt: number;
    })[];
    controller?: {
        owner: string;
        leaseUntil: number;
        engineVersion?: string | undefined;
    } | undefined;
    stateVersion: 1;
    control: {
        paused: boolean;
        pauseReason?: "operator" | "runtime" | "shutdown" | "base-check" | "reconfigure" | undefined;
        pausedAt?: string | undefined;
        pauseOperation?: string | undefined;
        pauseFailures?: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input")[] | undefined;
        waits?: {
            kind: "base-check" | "context-lock";
            detail: string;
            at: string;
            operation?: string | undefined;
        }[] | undefined;
        appliedPolicy?: {
            digest: string;
            at: string;
            by: string;
            generation?: number | undefined;
        } | undefined;
        reconfigure?: {
            operation: string;
            digest: string;
            requestedAt: string;
            appliedAt?: string | undefined;
            appliedBy?: string | undefined;
            error?: string | undefined;
        } | undefined;
    };
};
