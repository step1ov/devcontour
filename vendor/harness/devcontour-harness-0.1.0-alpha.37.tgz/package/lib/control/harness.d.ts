import { type Author, type ContextSnapshot, type ContractDocument, type PropertyRecovery, type ExecutionPolicy, type ResultEnvelope, type ResultSink, type WorkSource, type RuntimeAdapter, type RuntimeName, type WorkGraph } from '../contracts/index.ts';
import { type InputMessageRef } from '../engine/input-requests.ts';
import { Engine } from '../engine/engine.ts';
import { Runner, type RunnerHooks } from '../engine/runner.ts';
import { SqliteExecutionStore } from '../storage/sqlite.ts';
import { WorkflowQueue } from './workflow.ts';
import { type PolicySource } from './provenance.ts';
import { JointRunner } from '../engine/joint-runner.ts';
import { type ValueReportOptions } from '../report/compute.ts';
export interface HarnessOptions {
    /** Каталог состояния исполнения: база, worktrees, артефакты. */
    stateDir: string;
    policy: ExecutionPolicy;
    /** Каталог, от которого разрешаются относительные пути репозиториев политики. */
    baseDir: string;
    /** Подключённые runtime; по умолчанию — CLI codex и claude из PATH. */
    adapters?: Partial<Record<RuntimeName, RuntimeAdapter>>;
    /** Читающие операции не создают каталог состояния. */
    readOnly?: boolean;
    /**
     * Открыть базу состояния только для чтения (status, events, result): процесс
     * не записывает даже метку писателя. Любая запись — отказ.
     */
    readOnlyState?: boolean;
    environment?: NodeJS.ProcessEnv;
    /**
     * Файл, из которого загружена политика. С ним процесс может записать свою
     * политику применённой, только пока файл не менялся; без него политика —
     * объект вызывающего, и право ограничено остальными условиями.
     */
    policySource?: PolicySource;
    /** База блокировок ресурсов; по умолчанию — общая для машины. */
    resourceDatabase?: string;
    /**
     * Корень рабочих деревьев попыток и совместных проверок; без него —
     * `chooseCheckoutRoot` (кэш пользователя, если каталог состояния внутри
     * репозитория, иначе каталог состояния).
     */
    checkoutRoot?: string;
    /**
     * Дополнения хоста к попыткам (например, история работы внешнего
     * хранилища задач до исполнения). Приёмку не решают: отказ хука — отказ
     * попытки.
     */
    hooks?: RunnerHooks;
}
/**
 * Доменные операции harness — общие для библиотеки и CLI. Здесь нет
 * операции «передать PASS» или «принять без проверок»: приёмка возможна
 * только через движок после evidence обеих фаз.
 */
export declare class Harness {
    readonly options: HarnessOptions;
    readonly engine: Engine;
    readonly runner: Runner;
    readonly store: SqliteExecutionStore;
    readonly policy: ExecutionPolicy;
    /** Техническая очередь: сохранённые стадии и ограниченное восстановление графа. */
    readonly workflows: WorkflowQueue;
    /** Совместная проверка комбинации репозиториев. */
    readonly joint: JointRunner;
    private readonly adapters;
    static open(options: HarnessOptions): Harness;
    private constructor();
    close(): void;
    /**
     * Совместная проверка набора принятых поручений на текущих target ref.
     * Возвращает итог (`passed` или `failed` с причиной); продуктовое принятие
     * комбинации решает хост.
     */
    verifyJoint(workIds: string[], options?: {
        baseline?: string;
    }): Promise<{
        status: "active";
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            artifactFiles?: {
                dir: string;
                files: {
                    path: string;
                    sha256: string;
                    bytes: number;
                    redacted?: true | undefined;
                }[];
                skipped: {
                    path: string;
                    reason: "missing" | "symlink" | "outside" | "not-regular" | "hardlink" | "secret" | "extension" | "file-limit" | "total-limit" | "count-limit" | "scan-limit" | "copy-failed";
                    detail?: string | undefined;
                }[];
                skippedMore?: number | undefined;
            } | undefined;
            durationMs?: number | undefined;
        }[];
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "affected" | "all";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "failed";
        finishedAt: string;
        error: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            artifactFiles?: {
                dir: string;
                files: {
                    path: string;
                    sha256: string;
                    bytes: number;
                    redacted?: true | undefined;
                }[];
                skipped: {
                    path: string;
                    reason: "missing" | "symlink" | "outside" | "not-regular" | "hardlink" | "secret" | "extension" | "file-limit" | "total-limit" | "count-limit" | "scan-limit" | "copy-failed";
                    detail?: string | undefined;
                }[];
                skippedMore?: number | undefined;
            } | undefined;
            durationMs?: number | undefined;
        }[];
        manifest?: Record<string, {
            sha: string;
            tree: string;
        }> | undefined;
        manifestDigest?: string | undefined;
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "affected" | "all";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    } | {
        status: "passed";
        finishedAt: string;
        manifest: Record<string, {
            sha: string;
            tree: string;
        }>;
        manifestDigest: string;
        apiVersion: "devcontour-harness/v1alpha1";
        id: string;
        startedAt: string;
        policyDigest: string;
        specDigest: string;
        workIds: string[];
        evidence: {
            gate: string;
            passed: boolean;
            command: string[];
            exitCode: number;
            log: string;
            digest: string;
            summary: string;
            artifacts: {
                path: string;
                digest: string;
            }[];
            artifactFiles?: {
                dir: string;
                files: {
                    path: string;
                    sha256: string;
                    bytes: number;
                    redacted?: true | undefined;
                }[];
                skipped: {
                    path: string;
                    reason: "missing" | "symlink" | "outside" | "not-regular" | "hardlink" | "secret" | "extension" | "file-limit" | "total-limit" | "count-limit" | "scan-limit" | "copy-failed";
                    detail?: string | undefined;
                }[];
                skippedMore?: number | undefined;
            } | undefined;
            durationMs?: number | undefined;
        }[];
        impact?: {
            changed: string[];
            affected: string[];
            gateIds: string[];
            mode: "affected" | "all";
            reason: string;
            baseline?: string | undefined;
        } | undefined;
    }>;
    /**
     * Актуальность результата совместной проверки набора и свежесть его
     * manifest: SHA каждого репозитория сравнивается с текущим target ref.
     * Свежесть — наблюдение, а не запрет: решение о принятии — за хостом.
     */
    jointResult(workIds: string[]): Promise<{
        verification?: import("../contracts/result.ts").JointVerification;
        current: boolean;
        reason?: string;
    } | {
        freshness: {
            fresh: boolean;
            head?: string | undefined;
            repositoryId: string;
            sha: string;
        }[];
        verification?: import("../contracts/result.ts").JointVerification;
        current: boolean;
        reason?: string;
    }>;
    /** Запросить применение политики с digest `policyDigest(next)`; держит новые выдачи. */
    requestReconfigure(operation: string, digest: string): {
        operation: string;
        digest: string;
        changed: boolean;
        retried?: undefined;
    } | {
        operation: string;
        digest: string;
        changed: boolean;
        retried: boolean;
    };
    /** Применить запрос политикой этого процесса (после drain), см. `Engine.applyReconfigure`. */
    applyReconfigure(by?: string): {
        status: "none";
    } | {
        status: "busy";
        busy: string[];
    } | {
        status: "waiting";
        expected: string;
    } | {
        status: "failed";
        error: string;
    } | {
        status: "applied";
        generation: number;
    };
    policyState(): {
        stale?: string | undefined;
        reconfigure?: {
            operation: string;
            digest: string;
            requestedAt: string;
            appliedAt?: string | undefined;
            appliedBy?: string | undefined;
            error?: string | undefined;
        } | undefined;
        applied?: {
            digest: string;
            at: string;
            by: string;
            generation?: number | undefined;
        } | undefined;
        loaded: string;
    };
    /**
     * Довести незавершённую очистку закончившейся попытки: повторить teardown по
     * сохранённым receipt окружений и убрать её рабочие деревья и снимки.
     */
    cleanup(runId: string): Promise<{
        status: "nothing-pending";
        receipts?: undefined;
    } | {
        status: "cleaned";
        receipts: string[];
    }>;
    /** Убрать рабочие деревья закончившихся попыток; ветки и артефакты остаются. */
    cleanupWorktrees(options?: {
        dryRun?: boolean;
    }): Promise<{
        dryRun: boolean;
        removed: number;
        removable: number;
        refused: number;
        failed: number;
        reclaimedKb: number;
        worktrees: import("../engine/worktree-cleanup.ts").WorktreeCleanupEntry[];
    }>;
    private repoPath;
    /**
     * Снимок контекста для ревью плана: без нужного графу источника — отказ
     * `NOT_READY`, нарушения снимка (digest, размер) — `INVALID_INPUT`.
     * Поручения без контекста — снимок не нужен.
     */
    private planContext;
    /**
     * Раунд технического ревью предмета (граф или контракт) с конкретным
     * digest. Тот же digest и автор, уже согласованные последним раундом, —
     * тот же раунд без вызова модели. Reviewer — по правилу вендора политики;
     * недопустимый автор — `REVIEWER_SAME_VENDOR` до вызова. Reviewer называет
     * состояние каждой прежней открытой находки; история не переписывается.
     */
    review(input: {
        kind: 'plan';
        graph: WorkGraph;
        context?: ContextSnapshot;
        author: Author;
    } | {
        kind: 'contract';
        contract: ContractDocument;
        author: Author;
    }): Promise<{
        id: string;
        kind: "contract" | "plan";
        subject: string;
        digest: string;
        round: number;
        at: string;
        approved: boolean;
        summary: string;
        authorRuntime: "codex" | "claude" | "fixture" | "external";
        reviewerRuntime: "codex" | "claude" | "fixture";
        sameVendor: boolean;
        findings: {
            id: string;
            severity: "blocking" | "note";
            message: string;
            status: "closed" | "open" | "withdrawn";
            openedIn: number;
            changedIn: number;
            rule?: string | undefined;
            path?: string | null | undefined;
            line?: number | null | undefined;
            basis?: string | undefined;
        }[];
        artifact: string;
        reviewerModel?: string | undefined;
        reviewerBinding?: string | undefined;
        contextDigest?: string | undefined;
    }>;
    /**
     * Эксперименты, на которые ссылаются тяжёлые обязательства: reviewer читает
     * фактический результат, а не пересказ автора.
     */
    private spikeNote;
    private assertContract;
    /** Корпус: принятые версии, решения, отложенные принятия. */
    get corpus(): import("../index.ts").CorpusStore;
    /**
     * Ограниченный эксперимент выполнимости до реализации тяжёлого обязательства.
     * Таймаут — `inconclusive`: не доказательство невыполнимости и не основание
     * ослаблять обязательство.
     */
    spike(input: unknown): Promise<{
        id: string;
        repositoryId: string;
        sha: string;
        command: string[];
        seed: number;
        sizes: number[];
        timeoutMs: number;
        question: string;
        results: {
            size: number;
            ms: number;
            outcome: "error" | "ok" | "timeout";
            exitCode: number;
        }[];
        outcome: "failed" | "feasible" | "inconclusive";
        limits: string;
        environment: {
            platform: string;
            arch: string;
            node: string;
            cpus: number;
            isolation: string;
        };
        at: string;
        digest: string;
    }>;
    /** Эксперименты выполнимости репозитория (по умолчанию — всех). */
    spikes(repositoryId?: string): {
        id: string;
        repositoryId: string;
        sha: string;
        command: string[];
        seed: number;
        sizes: number[];
        timeoutMs: number;
        question: string;
        results: {
            size: number;
            ms: number;
            outcome: "error" | "ok" | "timeout";
            exitCode: number;
        }[];
        outcome: "failed" | "feasible" | "inconclusive";
        limits: string;
        environment: {
            platform: string;
            arch: string;
            node: string;
            cpus: number;
            isolation: string;
        };
        at: string;
        digest: string;
    }[];
    /** Подтвердить пример закреплённым эталоном; подтверждённый — новая версия корпуса. */
    submitCase(input: unknown): Promise<{
        suite: string;
        repeated: boolean;
        decision: {
            id: string;
            property: string;
            input: string;
            inputHash: string;
            outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
            reason: string;
            source: {
                sha: string;
                runId?: string | undefined;
                taskId?: string | undefined;
            };
            origin: {
                kind: "operator" | "lead" | "review" | "agent";
                runtime?: string | undefined;
            };
            at: string;
            key?: string | undefined;
            claimed?: {
                expected: string | null;
                actual: string | null;
                reproduction?: string | undefined;
            } | undefined;
            observed?: {
                repeats: number;
                durationsMs: number[];
                expected?: string | undefined;
                actual?: string | undefined;
                equal?: boolean | undefined;
            } | undefined;
            method?: {
                gate: string;
                artifacts: {
                    path: string;
                    blob: string;
                }[];
                contract: string;
                basis: string;
                command?: string[] | undefined;
            } | undefined;
            caseId?: string | undefined;
            version?: number | undefined;
        };
        version: {
            number: number;
            digest: string;
            cases: number;
        } | null;
        adoption: {
            awaitingOperator?: true | undefined;
            id: string;
            status: "completed" | "waiting";
            results: Record<string, string>;
        }[];
    }>;
    /** Ручное техническое подтверждение принятия версии корпуса (operator mode). */
    approveAdoption(suiteId: string, pendingId: string): {
        pending: {
            id: string;
            version: number;
            tasks: string[];
            status: "completed" | "waiting";
            results: Record<string, string>;
            actor: string;
            reason: string;
            requestedAt: string;
            digest?: string | undefined;
            awaitingOperator?: boolean | undefined;
            completedAt?: string | undefined;
        };
        suite: {
            id: string;
            repositoryId: string;
            contractId: string;
            contractDigest: string;
            gate: string;
            basis: string;
            cases: Record<string, {
                id: string;
                property: string;
                input: string;
                expected: string;
                source: {
                    kind: "oracle";
                    decision: string;
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                    reproduction?: string | undefined;
                };
                addedAt: string;
            }>;
            versions: {
                number: number;
                digest: string;
                previous: string | null;
                cases: string[];
                blob: string;
                createdAt: string;
                reason: string;
                decisions: string[];
            }[];
            decisions: {
                id: string;
                property: string;
                input: string;
                inputHash: string;
                outcome: "rejected" | "inconclusive" | "confirmed" | "refuted";
                reason: string;
                source: {
                    sha: string;
                    runId?: string | undefined;
                    taskId?: string | undefined;
                };
                origin: {
                    kind: "operator" | "lead" | "review" | "agent";
                    runtime?: string | undefined;
                };
                at: string;
                key?: string | undefined;
                claimed?: {
                    expected: string | null;
                    actual: string | null;
                    reproduction?: string | undefined;
                } | undefined;
                observed?: {
                    repeats: number;
                    durationsMs: number[];
                    expected?: string | undefined;
                    actual?: string | undefined;
                    equal?: boolean | undefined;
                } | undefined;
                method?: {
                    gate: string;
                    artifacts: {
                        path: string;
                        blob: string;
                    }[];
                    contract: string;
                    basis: string;
                    command?: string[] | undefined;
                } | undefined;
                caseId?: string | undefined;
                version?: number | undefined;
            }[];
            adoptions: {
                id: string;
                taskId: string;
                from: {
                    number: number;
                    digest: string;
                } | null;
                to: {
                    number: number;
                    digest: string;
                };
                actor: string;
                reason: string;
                operation: string;
                at: string;
            }[];
            pending: {
                id: string;
                version: number;
                tasks: string[];
                status: "completed" | "waiting";
                results: Record<string, string>;
                actor: string;
                reason: string;
                requestedAt: string;
                digest?: string | undefined;
                awaitingOperator?: boolean | undefined;
                completedAt?: string | undefined;
            }[];
            operations: Record<string, {
                key: string;
                status: "completed" | "running";
                startedAt: string;
                token?: string | undefined;
                leaseUntil?: number | undefined;
                decision?: string | undefined;
            }>;
            revision: number;
        };
    };
    /** Решение эпизода по свойству человеком: CAS по версии записи. */
    decideRecovery(workId: string, recoveryId: string, decision: Omit<NonNullable<PropertyRecovery['decision']>, 'source' | 'decidedAt'>, version: number): {
        id: string;
        property: string;
        basis: string;
        runs: string[];
        openedAt: string;
        status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
        calls: number;
        history: {
            at: string;
            event: string;
            detail?: string | undefined;
        }[];
        version: number;
        decision?: {
            action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
            reason: string;
            evidence: string[];
            source: {
                kind: "operator" | "lead";
                runtime?: string | undefined;
                model?: string | undefined;
            };
            decidedAt: string;
            hypothesis?: string | undefined;
            plan?: string | undefined;
            cases?: {
                input: string;
                expected?: string | null | undefined;
            }[] | undefined;
            proposal?: string | undefined;
            conflict?: string | undefined;
        } | undefined;
        retryRun?: string | undefined;
        reason?: string | undefined;
    };
    /** Согласование оператором (approvalMode: operator) графа, digest которого прошёл ревью. */
    approve(subject: string, digest: string): {
        subject: string;
        digest: string;
        at: string;
        changed: boolean;
    };
    /**
     * Действующий контекст графа — снимок, связанный с его согласованием, а не
     * последний переданный: отклонённый или ещё не согласованный снимок не
     * исполняется.
     */
    private contextOf;
    /** Запросы исполнителя: все или поручения. */
    inputRequests(filter?: {
        workId?: string;
    }): {
        id: string;
        kind: "question" | "follow-up";
        blocking: boolean;
        workId: string;
        graphId: string;
        runId: string;
        attempt: number;
        callId: string | null;
        question: {
            question: string;
            options: {
                id: string;
                label: string;
                consequence: string | null;
            }[];
            recommended: string | null;
            severity: number;
            rationale: string;
            affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
        };
        effectiveSeverity: number;
        floors: ("declared" | "critical-path")[];
        criticalHits: string[];
        draft: {
            digest: string;
            files: string[];
        } | null;
        createdAt: string;
        originBasis: {
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            graphId: string;
            graphDigest: string;
            orderDigest: string;
            policyDigest: string;
            contextDigest: string | null;
            baseSha: string | null;
            inputPolicy: {
                threshold: number;
                criticalPaths: string[];
            };
            contentDigest?: string | undefined;
        };
        lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
        answers: {
            revision: number;
            text: string;
            optionId: string | null;
            kind: "clarification" | "requirement-change";
            actor: {
                kind: "operator" | "lead" | "host";
                id?: string | undefined;
            };
            digest: string;
            at: string;
            messageRef?: string | undefined;
        }[];
        version: number;
        target?: {
            originDigest: string;
            answerDigest: string;
            graphDigest: string;
            orderDigest: string;
            policyDigest: string;
            contextDigest: string | null;
            review: {
                round: number;
                approved: boolean;
                reviewerBinding: string | null;
            } | null;
            actor: "operator" | "agent";
            digest: string;
            contentDigest?: string | undefined;
        } | undefined;
        delivered?: {
            runId: string;
            callId: string;
            at: string;
        } | undefined;
        closed?: {
            at: string;
            by: "operator" | "lead" | "host" | "controller";
            reason: string;
            successor?: string | undefined;
            carry?: boolean | undefined;
            previous?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
            } | undefined;
        } | undefined;
        stale?: {
            targetDigest: string;
            reason: "context" | "graph" | "order" | "policy";
            at: string;
        } | undefined;
        normalized?: string[] | undefined;
    }[];
    /** Запрос исполнителя по ID. */
    inputRequest(id: string): {
        id: string;
        kind: "question" | "follow-up";
        blocking: boolean;
        workId: string;
        graphId: string;
        runId: string;
        attempt: number;
        callId: string | null;
        question: {
            question: string;
            options: {
                id: string;
                label: string;
                consequence: string | null;
            }[];
            recommended: string | null;
            severity: number;
            rationale: string;
            affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
        };
        effectiveSeverity: number;
        floors: ("declared" | "critical-path")[];
        criticalHits: string[];
        draft: {
            digest: string;
            files: string[];
        } | null;
        createdAt: string;
        originBasis: {
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            graphId: string;
            graphDigest: string;
            orderDigest: string;
            policyDigest: string;
            contextDigest: string | null;
            baseSha: string | null;
            inputPolicy: {
                threshold: number;
                criticalPaths: string[];
            };
            contentDigest?: string | undefined;
        };
        lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
        answers: {
            revision: number;
            text: string;
            optionId: string | null;
            kind: "clarification" | "requirement-change";
            actor: {
                kind: "operator" | "lead" | "host";
                id?: string | undefined;
            };
            digest: string;
            at: string;
            messageRef?: string | undefined;
        }[];
        version: number;
        target?: {
            originDigest: string;
            answerDigest: string;
            graphDigest: string;
            orderDigest: string;
            policyDigest: string;
            contextDigest: string | null;
            review: {
                round: number;
                approved: boolean;
                reviewerBinding: string | null;
            } | null;
            actor: "operator" | "agent";
            digest: string;
            contentDigest?: string | undefined;
        } | undefined;
        delivered?: {
            runId: string;
            callId: string;
            at: string;
        } | undefined;
        closed?: {
            at: string;
            by: "operator" | "lead" | "host" | "controller";
            reason: string;
            successor?: string | undefined;
            carry?: boolean | undefined;
            previous?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
            } | undefined;
        } | undefined;
        stale?: {
            targetDigest: string;
            reason: "context" | "graph" | "order" | "policy";
            at: string;
        } | undefined;
        normalized?: string[] | undefined;
    };
    /** Записать ответ (новая версия); работу он не возобновляет. */
    answerInput(id: string, answer: Parameters<Engine['answerInput']>[1], expectedVersion: number): {
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        answer: {
            revision: number;
            text: string;
            optionId: string | null;
            kind: "clarification" | "requirement-change";
            actor: {
                kind: "operator" | "lead" | "host";
                id?: string | undefined;
            };
            digest: string;
            at: string;
            messageRef?: string | undefined;
        };
        changed: boolean;
    };
    /**
     * Снимок контекста с последним ответом на запрос: действующий снимок графа
     * плюс источник ответа (`input-answer`). Снимок сохраняется по digest, но
     * не активируется: дальше — review-plan с ним, `proposeTarget` и
     * `applyInput`. `messages` — сообщения обсуждения хоста, включённые в
     * manifest (ID, версия, digest).
     */
    inputContext(id: string, options?: {
        messages?: InputMessageRef[];
    }): {
        requestId: string;
        answerDigest: string;
        digest: string;
        snapshot: {
            apiVersion: "devcontour-harness/v1alpha1";
            sources: {
                id: string;
                kind: string;
                version: string;
                required: boolean;
                files: {
                    path: string;
                    digest: string;
                    bytes: number;
                    content: {
                        encoding: "utf8";
                        data: string;
                    } | {
                        encoding: "base64";
                        data: string;
                    };
                }[];
                references: {
                    path: string;
                    digest: string;
                    bytes: number;
                    content: {
                        encoding: "utf8";
                        data: string;
                    } | {
                        encoding: "base64";
                        data: string;
                    };
                }[];
                digest: string;
                repositoryId?: string | undefined;
                revision?: string | undefined;
                hostDigest?: string | undefined;
            }[];
            missing: {
                id: string;
                reason: string;
            }[];
        };
    };
    /** Основание продолжения для снимка с ответом (только чтение). */
    proposeTarget(id: string, contextDigest: string | null): {
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        problems: string[];
        target?: undefined;
    } | {
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        target: {
            digest: string;
            actor: "operator" | "agent";
            graphDigest: string;
            orderDigest: string;
            policyDigest: string;
            contextDigest: string | null;
            contentDigest?: string | undefined;
            originDigest: string;
            answerDigest: string;
            review: {
                round: number;
                approved: boolean;
                reviewerBinding: string | null;
            } | null;
        };
        problems: string[];
    };
    /** Применить ответ одной транзакцией (см. `Engine.applyInput`); модель не вызывается. */
    applyInput(id: string, options: Parameters<Engine['applyInput']>[1]): {
        applied: true;
        changed: boolean;
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        blocker?: undefined;
        work?: undefined;
    } | {
        joint?: boolean | undefined;
        applied: false;
        changed: boolean;
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        active: {
            id: string;
            workId: string;
        }[];
        blocker?: undefined;
        work?: undefined;
    } | {
        applied: false;
        changed: boolean;
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        blocker: {
            code: "ATTEMPTS_EXHAUSTED";
            message: string;
        };
        work?: undefined;
    } | {
        applied: false;
        changed: boolean;
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        blocker: {
            code: "BUDGET_EXHAUSTED";
            message: string;
        };
        work?: undefined;
    } | {
        applied: true;
        changed: boolean;
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        work: {
            id: string;
            graphId: string;
            order: {
                apiVersion: "devcontour-harness/v1alpha1";
                id: string;
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                title: string;
                goal: string;
                acceptance: string[];
                role: string;
                repositoryId: string;
                relatedRepositories: string[];
                writeScope: string[];
                dependsOn: string[];
                requirements: {
                    id: string;
                    source: string;
                    digest: string;
                    text: string;
                    gate: string;
                    scenario: string;
                    testId?: string | undefined;
                }[];
                contracts: {
                    id: string;
                    digest: string;
                }[];
                context: string[];
                gates?: string[] | undefined;
                consumers?: {
                    repositoryId: string;
                    gates: string[];
                }[] | undefined;
                properties?: string[] | undefined;
                resources?: string[] | undefined;
            };
            status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
            attempt: number;
            activeRunId?: string | undefined;
            resultSha?: string | undefined;
            failure?: string | undefined;
            failureKind?: "gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input" | undefined;
            failureFingerprint?: string | undefined;
            approvedAt?: string | undefined;
            approvedDigest?: string | undefined;
            approvedScope?: string | undefined;
            approval?: {
                actor: "operator" | "agent";
                authorRuntime?: "codex" | "claude" | "fixture" | undefined;
                reviewerRuntime?: "codex" | "claude" | "fixture" | undefined;
                artifact?: string | undefined;
                digest?: string | undefined;
                context?: {
                    digest: string | null;
                } | undefined;
            } | undefined;
            hold?: {
                operation: string;
                reason: string;
            } | undefined;
            budgetBlock?: {
                reason: string;
                at: string;
            } | undefined;
            checkVersion?: {
                suite: string;
                number: number;
                digest: string;
            } | undefined;
            recovery?: {
                id: string;
                property: string;
                basis: string;
                runs: string[];
                openedAt: string;
                status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
                calls: number;
                history: {
                    at: string;
                    event: string;
                    detail?: string | undefined;
                }[];
                version: number;
                decision?: {
                    action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                    reason: string;
                    evidence: string[];
                    source: {
                        kind: "operator" | "lead";
                        runtime?: string | undefined;
                        model?: string | undefined;
                    };
                    decidedAt: string;
                    hypothesis?: string | undefined;
                    plan?: string | undefined;
                    cases?: {
                        input: string;
                        expected?: string | null | undefined;
                    }[] | undefined;
                    proposal?: string | undefined;
                    conflict?: string | undefined;
                } | undefined;
                retryRun?: string | undefined;
                reason?: string | undefined;
            } | undefined;
            recoveryHistory?: {
                id: string;
                property: string;
                basis: string;
                runs: string[];
                openedAt: string;
                status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
                calls: number;
                history: {
                    at: string;
                    event: string;
                    detail?: string | undefined;
                }[];
                version: number;
                decision?: {
                    action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                    reason: string;
                    evidence: string[];
                    source: {
                        kind: "operator" | "lead";
                        runtime?: string | undefined;
                        model?: string | undefined;
                    };
                    decidedAt: string;
                    hypothesis?: string | undefined;
                    plan?: string | undefined;
                    cases?: {
                        input: string;
                        expected?: string | null | undefined;
                    }[] | undefined;
                    proposal?: string | undefined;
                    conflict?: string | undefined;
                } | undefined;
                retryRun?: string | undefined;
                reason?: string | undefined;
            }[] | undefined;
            neutralFailures?: number | undefined;
        };
        blocker?: undefined;
    };
    /** Основание переноса ответа заменённого вопроса (только чтение, см. `Engine.proposeCarry`). */
    proposeCarry(id: string, contextDigest: string): {
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        problems: string[];
        target?: undefined;
    } | {
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        target: {
            digest: string;
            actor: "operator" | "agent";
            graphDigest: string;
            orderDigest: string;
            policyDigest: string;
            contextDigest: string | null;
            contentDigest?: string | undefined;
            originDigest: string;
            answerDigest: string;
            review: {
                round: number;
                approved: boolean;
                reviewerBinding: string | null;
            } | null;
        };
        problems: string[];
    };
    /** Перенести ответ заменённого вопроса в согласование новой редакции (см. `Engine.carryInput`). */
    carryInput(id: string, options: Parameters<Engine['carryInput']>[1]): {
        carried: true;
        changed: boolean;
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        blocker?: undefined;
        work?: undefined;
    } | {
        joint?: boolean | undefined;
        carried: false;
        changed: boolean;
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        active: {
            id: string;
            workId: string;
        }[];
        blocker?: undefined;
        work?: undefined;
    } | {
        carried: false;
        changed: boolean;
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        blocker: {
            code: "ATTEMPTS_EXHAUSTED";
            message: string;
        };
        work?: undefined;
    } | {
        carried: false;
        changed: boolean;
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        blocker: {
            code: "BUDGET_EXHAUSTED";
            message: string;
        };
        work?: undefined;
    } | {
        carried: true;
        changed: boolean;
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        work: {
            id: string;
            graphId: string;
            order: {
                apiVersion: "devcontour-harness/v1alpha1";
                id: string;
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                title: string;
                goal: string;
                acceptance: string[];
                role: string;
                repositoryId: string;
                relatedRepositories: string[];
                writeScope: string[];
                dependsOn: string[];
                requirements: {
                    id: string;
                    source: string;
                    digest: string;
                    text: string;
                    gate: string;
                    scenario: string;
                    testId?: string | undefined;
                }[];
                contracts: {
                    id: string;
                    digest: string;
                }[];
                context: string[];
                gates?: string[] | undefined;
                consumers?: {
                    repositoryId: string;
                    gates: string[];
                }[] | undefined;
                properties?: string[] | undefined;
                resources?: string[] | undefined;
            };
            status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
            attempt: number;
            activeRunId?: string | undefined;
            resultSha?: string | undefined;
            failure?: string | undefined;
            failureKind?: "gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input" | undefined;
            failureFingerprint?: string | undefined;
            approvedAt?: string | undefined;
            approvedDigest?: string | undefined;
            approvedScope?: string | undefined;
            approval?: {
                actor: "operator" | "agent";
                authorRuntime?: "codex" | "claude" | "fixture" | undefined;
                reviewerRuntime?: "codex" | "claude" | "fixture" | undefined;
                artifact?: string | undefined;
                digest?: string | undefined;
                context?: {
                    digest: string | null;
                } | undefined;
            } | undefined;
            hold?: {
                operation: string;
                reason: string;
            } | undefined;
            budgetBlock?: {
                reason: string;
                at: string;
            } | undefined;
            checkVersion?: {
                suite: string;
                number: number;
                digest: string;
            } | undefined;
            recovery?: {
                id: string;
                property: string;
                basis: string;
                runs: string[];
                openedAt: string;
                status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
                calls: number;
                history: {
                    at: string;
                    event: string;
                    detail?: string | undefined;
                }[];
                version: number;
                decision?: {
                    action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                    reason: string;
                    evidence: string[];
                    source: {
                        kind: "operator" | "lead";
                        runtime?: string | undefined;
                        model?: string | undefined;
                    };
                    decidedAt: string;
                    hypothesis?: string | undefined;
                    plan?: string | undefined;
                    cases?: {
                        input: string;
                        expected?: string | null | undefined;
                    }[] | undefined;
                    proposal?: string | undefined;
                    conflict?: string | undefined;
                } | undefined;
                retryRun?: string | undefined;
                reason?: string | undefined;
            } | undefined;
            recoveryHistory?: {
                id: string;
                property: string;
                basis: string;
                runs: string[];
                openedAt: string;
                status: "closed" | "stopped" | "awaiting-lead" | "analyzing" | "applying" | "retry" | "retrying" | "awaiting-user";
                calls: number;
                history: {
                    at: string;
                    event: string;
                    detail?: string | undefined;
                }[];
                version: number;
                decision?: {
                    action: "environment" | "add-cases" | "new-approach" | "strengthen-checker" | "split-task" | "clarify-obligation";
                    reason: string;
                    evidence: string[];
                    source: {
                        kind: "operator" | "lead";
                        runtime?: string | undefined;
                        model?: string | undefined;
                    };
                    decidedAt: string;
                    hypothesis?: string | undefined;
                    plan?: string | undefined;
                    cases?: {
                        input: string;
                        expected?: string | null | undefined;
                    }[] | undefined;
                    proposal?: string | undefined;
                    conflict?: string | undefined;
                } | undefined;
                retryRun?: string | undefined;
                reason?: string | undefined;
            }[] | undefined;
            neutralFailures?: number | undefined;
        };
        blocker?: undefined;
    };
    /** Отменить вопрос: работа больше его не ждёт. */
    cancelInput(id: string, input: Parameters<Engine['cancelInput']>[1], expectedVersion: number): {
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        changed: boolean;
    };
    /** Заменить вопрос преемником (изменение требований — новая ревизия). */
    supersedeInput(id: string, input: Parameters<Engine['supersedeInput']>[1], expectedVersion: number): {
        request: {
            id: string;
            kind: "question" | "follow-up";
            blocking: boolean;
            workId: string;
            graphId: string;
            runId: string;
            attempt: number;
            callId: string | null;
            question: {
                question: string;
                options: {
                    id: string;
                    label: string;
                    consequence: string | null;
                }[];
                recommended: string | null;
                severity: number;
                rationale: string;
                affects: ("acceptance" | "contract" | "product" | "api" | "migration")[];
            };
            effectiveSeverity: number;
            floors: ("declared" | "critical-path")[];
            criticalHits: string[];
            draft: {
                digest: string;
                files: string[];
            } | null;
            createdAt: string;
            originBasis: {
                source: {
                    connector: string;
                    ref: string;
                    revision: string;
                };
                graphId: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                baseSha: string | null;
                inputPolicy: {
                    threshold: number;
                    criticalPaths: string[];
                };
                contentDigest?: string | undefined;
            };
            lifecycle: "pending" | "answered" | "applied" | "cancelled" | "superseded";
            answers: {
                revision: number;
                text: string;
                optionId: string | null;
                kind: "clarification" | "requirement-change";
                actor: {
                    kind: "operator" | "lead" | "host";
                    id?: string | undefined;
                };
                digest: string;
                at: string;
                messageRef?: string | undefined;
            }[];
            version: number;
            target?: {
                originDigest: string;
                answerDigest: string;
                graphDigest: string;
                orderDigest: string;
                policyDigest: string;
                contextDigest: string | null;
                review: {
                    round: number;
                    approved: boolean;
                    reviewerBinding: string | null;
                } | null;
                actor: "operator" | "agent";
                digest: string;
                contentDigest?: string | undefined;
            } | undefined;
            delivered?: {
                runId: string;
                callId: string;
                at: string;
            } | undefined;
            closed?: {
                at: string;
                by: "operator" | "lead" | "host" | "controller";
                reason: string;
                successor?: string | undefined;
                carry?: boolean | undefined;
                previous?: {
                    at: string;
                    by: "operator" | "lead" | "host" | "controller";
                    reason: string;
                    successor?: string | undefined;
                    carry?: boolean | undefined;
                } | undefined;
            } | undefined;
            stale?: {
                targetDigest: string;
                reason: "context" | "graph" | "order" | "policy";
                at: string;
            } | undefined;
            normalized?: string[] | undefined;
        };
        changed: boolean;
    };
    /**
     * Контекст запуска с применёнными ответами: переданный снимок (или
     * отсутствие снимка) вместе с источниками применённых ответов действующего
     * согласования — это тот же действующий снимок, а не изменение контекста.
     * Иначе — переданный снимок как есть.
     */
    private withAppliedInputs;
    /**
     * Зарегистрировать граф (идемпотентно по редакции), в режиме `agent`
     * провести ревью плана, если его нет, согласовать и вести очередь до
     * простоя. Результаты доставляются получателю с идемпотентным ключом.
     */
    run(input: {
        graph: WorkGraph;
        context?: ContextSnapshot;
        author: Author;
        sink?: ResultSink;
        once?: boolean;
        /**
         * Источник, из которого прочитан граф. Его решение `trusts` — единственное
         * основание принять внешнюю предпосылку с receipt `trusted`; доступность
         * result SHA в target ref проверяется в любом случае. Без источника
         * доверенных receipt нет.
         */
        source?: WorkSource;
    }): Promise<{
        works: {
            blockers: {
                code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT" | "INPUT_REQUIRED";
                message: string;
            }[];
            resultSha?: string | undefined;
            runId?: string | undefined;
            id: string;
            status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
        }[];
        workflow?: {
            history: {
                at: string;
                stage: number;
                event: string;
            }[];
            error?: string | undefined;
            key: string;
            kind: string;
            id: string;
            stage: number;
            status: "stale" | "failed" | "completed" | "running" | "queued";
            attempts: number;
            repairs: number;
            repairBudget: number;
        } | undefined;
        graphId: string;
        digest: string;
        resumed: boolean;
    }>;
    /**
     * Вести задание графа: стадия согласования уже пройдена синхронно; стадия
     * исполнения — очередь до простоя, затем решение о восстановлении по
     * записанному состоянию. Повтор назначается и списывается одной
     * транзакцией; остановка записывает причину в задание.
     */
    private advance;
    /**
     * Эпизоды повторяющихся отказов по свойству. Возвращает true, когда
     * разрешённое действие назначено и его результата нужно дождаться;
     * останавливается с причиной там, где автоматического действия нет.
     * Бюджет восстановлений и разбор эпизода учитываются одной транзакцией до
     * вызова модели: рестарт и повтор бесплатного вызова не получают.
     */
    private recoverProperties;
    private applyRecovery;
    private afterDecision;
    /**
     * Восстановление упавшего поручения группы. Решение и его исполнение — одна
     * транзакция: между чтением и записью никто не успеет отменить поручение.
     * Возвращает true, когда повтор назначен; остановка — исключение с причиной.
     */
    private repair;
    /**
     * Состояние очереди, графов и поручений. С `detail` — ещё снимок
     * наблюдателя: почему стоит выдача (`queueStop` и `queuePause`) и активные
     * попытки (`attemptView`); без него ответ прежний. Та же функция над
     * движком и политикой хоста — `statusOf`.
     */
    status(graphId?: string, options?: {
        detail?: boolean;
    }): {
        detail?: {
            at: string;
            queue: {
                liftedByRun: true;
                code: "NOT_READY";
                cause: "not-ready";
                actor: "controller";
                action: "wait";
                operation?: string | undefined;
                since?: string | undefined;
                detail: string;
                reason?: "operator" | "runtime" | "shutdown" | "base-check" | "reconfigure" | undefined;
                paused: boolean;
            } | {
                code?: "INVALID_INPUT" | "UNSUPPORTED_COMMAND" | "UNSUPPORTED_VERSION" | "GRAPH_CYCLE" | "GRAPH_UNKNOWN_DEPENDENCY" | "GRAPH_DUPLICATE_ID" | "GATE_UNKNOWN" | "GATE_GROUP_CYCLE" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "RESPONSE_TOO_LARGE" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "LEASE_STALE" | "CONTROLLER_BUSY" | "PAUSED" | "NOT_READY" | "SCOPE_VIOLATION" | "GATE_FAILED" | "REVIEW_REJECTED" | "BUDGET_EXHAUSTED" | "BUDGET_UNKNOWN" | "ATTEMPTS_EXHAUSTED" | "CONTEXT_EXHAUSTED" | "INPUT_REQUIRED" | "REVISION_CONFLICT" | "CANCELLED" | "NOT_FOUND" | "PATH_CONFLICT" | "STATE_VERSION_UNSUPPORTED" | "RUNTIME_UNAVAILABLE" | "REVIEW_PROTOCOL_INVALID" | "SANDBOX_UNAVAILABLE" | "GIT_FAILED" | "STORAGE_FAILED" | "DELIVERY_FAILED" | "INTERNAL" | undefined;
                cause?: "gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input" | "runtime-missing" | "controller-busy" | "operator-pause" | "approval-required" | "not-ready" | undefined;
                actor?: import("../index.ts").Actor | undefined;
                action?: "none" | "wait" | "retry" | "review-plan" | "diagnose-failure" | "reset-attempts" | "raise-budget" | "replan-dependents" | "recovery-decision" | "user-decision" | "resume-queue" | "fix-environment" | "fix-access" | "answer-input" | "apply-input" | undefined;
                failures?: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input")[] | undefined;
                operation?: string | undefined;
                since?: string | undefined;
                detail?: string;
                paused: boolean;
                reason?: import("../contracts/execution.ts").PauseReason;
            };
            attempts: import("../index.ts").AttemptView[];
        } | undefined;
        budgets: {
            onUnknown: "continue" | "stop";
            budgets: {
                reason?: string | undefined;
                scope: import("../index.ts").BudgetScope;
                state: "exceeded" | "undetermined" | "within";
                limit: {
                    usd?: number;
                    timeMs?: number;
                };
                reportedUsd: number;
                estimatedUsd: number;
                unknownCalls: number;
                unfinishedCalls: number;
                abandonedCalls: number;
                errorCalls: number;
                uncoveredRuns: number;
                durationMs: number;
                remainingUsd: number | null;
                remainingMs: number | null;
            }[];
        };
        graphs: {
            id: string;
            digest: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            approved: boolean;
        }[];
        works: ({
            blockers: {
                code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT" | "INPUT_REQUIRED";
                message: string;
            }[];
            followUps?: number | undefined;
            input?: import("../index.ts").WorkInputView | undefined;
            resultSha?: string | undefined;
            liveness: "stalled" | "quiet";
            activeRunId?: string | undefined;
            id: string;
            graphId: string;
            status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
            attempt: number;
        } | {
            blockers: {
                code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT" | "INPUT_REQUIRED";
                message: string;
            }[];
            followUps?: number | undefined;
            input?: import("../index.ts").WorkInputView | undefined;
            resultSha?: string | undefined;
            liveness?: undefined;
            activeRunId?: string | undefined;
            id: string;
            graphId: string;
            status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
            attempt: number;
        })[];
        controller?: {
            owner: string;
            leaseUntil: number;
            engineVersion?: string | undefined;
        } | undefined;
        stateVersion: 1;
        control: {
            paused: boolean;
            pauseReason?: "operator" | "runtime" | "shutdown" | "base-check" | "reconfigure" | undefined;
            pausedAt?: string | undefined;
            pauseOperation?: string | undefined;
            pauseFailures?: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input")[] | undefined;
            waits?: {
                kind: "base-check" | "context-lock";
                detail: string;
                at: string;
                operation?: string | undefined;
            }[] | undefined;
            appliedPolicy?: {
                digest: string;
                at: string;
                by: string;
                generation?: number | undefined;
            } | undefined;
            reconfigure?: {
                operation: string;
                digest: string;
                requestedAt: string;
                appliedAt?: string | undefined;
                appliedBy?: string | undefined;
                error?: string | undefined;
            } | undefined;
        };
    } | {
        detail?: {
            at: string;
            queue: {
                liftedByRun: true;
                code: "NOT_READY";
                cause: "not-ready";
                actor: "controller";
                action: "wait";
                operation?: string | undefined;
                since?: string | undefined;
                detail: string;
                reason?: "operator" | "runtime" | "shutdown" | "base-check" | "reconfigure" | undefined;
                paused: boolean;
            } | {
                code?: "INVALID_INPUT" | "UNSUPPORTED_COMMAND" | "UNSUPPORTED_VERSION" | "GRAPH_CYCLE" | "GRAPH_UNKNOWN_DEPENDENCY" | "GRAPH_DUPLICATE_ID" | "GATE_UNKNOWN" | "GATE_GROUP_CYCLE" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "RESPONSE_TOO_LARGE" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "LEASE_STALE" | "CONTROLLER_BUSY" | "PAUSED" | "NOT_READY" | "SCOPE_VIOLATION" | "GATE_FAILED" | "REVIEW_REJECTED" | "BUDGET_EXHAUSTED" | "BUDGET_UNKNOWN" | "ATTEMPTS_EXHAUSTED" | "CONTEXT_EXHAUSTED" | "INPUT_REQUIRED" | "REVISION_CONFLICT" | "CANCELLED" | "NOT_FOUND" | "PATH_CONFLICT" | "STATE_VERSION_UNSUPPORTED" | "RUNTIME_UNAVAILABLE" | "REVIEW_PROTOCOL_INVALID" | "SANDBOX_UNAVAILABLE" | "GIT_FAILED" | "STORAGE_FAILED" | "DELIVERY_FAILED" | "INTERNAL" | undefined;
                cause?: "gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input" | "runtime-missing" | "controller-busy" | "operator-pause" | "approval-required" | "not-ready" | undefined;
                actor?: import("../index.ts").Actor | undefined;
                action?: "none" | "wait" | "retry" | "review-plan" | "diagnose-failure" | "reset-attempts" | "raise-budget" | "replan-dependents" | "recovery-decision" | "user-decision" | "resume-queue" | "fix-environment" | "fix-access" | "answer-input" | "apply-input" | undefined;
                failures?: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input")[] | undefined;
                operation?: string | undefined;
                since?: string | undefined;
                detail?: string;
                paused: boolean;
                reason?: import("../contracts/execution.ts").PauseReason;
            };
            attempts: import("../index.ts").AttemptView[];
        } | undefined;
        budgets?: undefined;
        graphs: {
            id: string;
            digest: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            approved: boolean;
        }[];
        works: ({
            blockers: {
                code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT" | "INPUT_REQUIRED";
                message: string;
            }[];
            followUps?: number | undefined;
            input?: import("../index.ts").WorkInputView | undefined;
            resultSha?: string | undefined;
            liveness: "stalled" | "quiet";
            activeRunId?: string | undefined;
            id: string;
            graphId: string;
            status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
            attempt: number;
        } | {
            blockers: {
                code: "NOT_READY" | "PAUSED" | "ATTEMPTS_EXHAUSTED" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "BUDGET_EXHAUSTED" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "INVALID_INPUT" | "INPUT_REQUIRED";
                message: string;
            }[];
            followUps?: number | undefined;
            input?: import("../index.ts").WorkInputView | undefined;
            resultSha?: string | undefined;
            liveness?: undefined;
            activeRunId?: string | undefined;
            id: string;
            graphId: string;
            status: "cancelled" | "draft" | "ready" | "failed" | "running" | "verifying" | "reviewing" | "integrating" | "done";
            attempt: number;
        })[];
        controller?: {
            owner: string;
            leaseUntil: number;
            engineVersion?: string | undefined;
        } | undefined;
        stateVersion: 1;
        control: {
            paused: boolean;
            pauseReason?: "operator" | "runtime" | "shutdown" | "base-check" | "reconfigure" | undefined;
            pausedAt?: string | undefined;
            pauseOperation?: string | undefined;
            pauseFailures?: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input")[] | undefined;
            waits?: {
                kind: "base-check" | "context-lock";
                detail: string;
                at: string;
                operation?: string | undefined;
            }[] | undefined;
            appliedPolicy?: {
                digest: string;
                at: string;
                by: string;
                generation?: number | undefined;
            } | undefined;
            reconfigure?: {
                operation: string;
                digest: string;
                requestedAt: string;
                appliedAt?: string | undefined;
                appliedBy?: string | undefined;
                error?: string | undefined;
            } | undefined;
        };
    };
    /**
     * Отчёт об эффекте (`valueReport`) по состоянию этого каталога: только
     * чтение; пути evidence — относительно каталога состояния.
     */
    report(options?: Omit<ValueReportOptions, 'stateDir' | 'harnessVersion'>): {
        reportVersion: 1;
        harnessVersion: string;
        label: string | null;
        window: {
            since: string | null;
            until: string | null;
            asOf: string;
        };
        enoughData: boolean;
        coverage: {
            works: number;
            attempts: number;
            failed: number;
            withFailureKind: number;
            withTimings: number;
            withCalls: number;
            doneWithoutAttempt: number;
            withWait: number;
            withEngineVersion: number;
            engines: string[];
            enginesTruncated: boolean;
            calls: number;
            reviews: number;
            events: number;
            eventsFrom: string | null;
        };
        summary: {
            status: "ok";
            headlines: {
                id: "accepted" | "environment" | "sent-back" | "lead-time" | "spend";
                value: string;
                text: string;
                basis: string;
                measure: {
                    value: number | null;
                    n: number;
                    unknown: number;
                    bound: "exact" | "unknown" | "lower" | "upper";
                };
            }[];
        } | {
            status: "not-enough-data";
            text: string;
            accepted: number;
            attempts: number;
            failedAttempts: number;
            works: number;
        };
        defects: {
            rejected: number;
            byKind: {
                gate: number;
                review: number;
                'scope-violation': number;
            };
            byPhase: {
                candidate: number;
                integration: number;
                unknown: number;
            };
            sentBack: {
                value: number | null;
                n: number;
                unknown: number;
                bound: "exact" | "unknown" | "lower" | "upper";
            };
            sentBackSetupOnly: number;
            sentBackRange: {
                min: number;
                max: number;
            };
            byGate: {
                gate: string;
                phase: "candidate" | "integration";
                failed: number;
                setup: boolean;
            }[];
            byGateTruncated: boolean;
            reviews: {
                rejected: number;
                candidate: number;
                integration: number;
                blockingFindings: number;
                withoutFindings: number;
            };
            afterGreenGates: {
                value: number | null;
                n: number;
                unknown: number;
                bound: "exact" | "unknown" | "lower" | "upper";
            };
            integration: number;
            planContract: {
                rounds: number;
                rejected: number;
                plans: {
                    rounds: number;
                    rejected: number;
                };
                contracts: {
                    rounds: number;
                    rejected: number;
                };
                blockingClosed: number;
                blockingOpen: number;
                blockingWithdrawn: number;
            };
            withdrawn: {
                value: number | null;
                n: number;
                unknown: number;
                bound: "exact" | "unknown" | "lower" | "upper";
            };
            items: {
                workId: string;
                runId: string;
                attempt: number;
                kind: "review" | "test" | "scope";
                phase: "candidate" | "integration" | null;
                gate: string | null;
                at: string;
                sha: string | null;
                log: string | null;
                blocking: number | null;
            }[];
            itemsTotal: number;
            itemsTruncated: boolean;
        };
        autonomy: {
            withAction: {
                value: number | null;
                n: number;
                unknown: number;
                bound: "exact" | "unknown" | "lower" | "upper";
            };
            withoutAction: {
                value: number | null;
                n: number;
                unknown: number;
                bound: "exact" | "unknown" | "lower" | "upper";
            };
            actions: {
                operatorDecisions: number;
                holds: number;
                cancelledAttempts: number;
                retries: number | null;
                resets: number | null;
                baseMoves: number | null;
                recorded: {
                    from: string;
                    bound: "exact" | "lower";
                    retries: {
                        operator: number;
                        host: number;
                        recovery: number;
                    };
                    resets: {
                        operator: number;
                        host: number;
                        recovery: number;
                    };
                    cancellations: {
                        operator: number;
                        host: number;
                        graph: number;
                    };
                    cancelledWithoutAttempt: number;
                    baseMoves: {
                        operator: number;
                        host: number;
                        controller: number;
                    };
                    baseMovesBound: "lower";
                    gaps: number;
                } | null;
            };
            approvals: {
                operator: number;
                agent: number;
                source: "none" | "state" | "events" | "mixed";
            };
            pauses: {
                reason: "operator" | "runtime" | "shutdown" | "base-check" | "reconfigure";
                count: number;
                pausedMs: number;
                open: number;
                failures: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input")[];
            }[];
            escalations: number;
        };
        speed: {
            leadTime: {
                n: number;
                unknown: number;
                median: number | null;
                p75: number | null;
                max: number | null;
                values: number[];
            };
            leadTimeFallback: number;
            dependencyWait: {
                n: number;
                unknown: number;
                median: number | null;
                p75: number | null;
                max: number | null;
                values: number[];
            };
            queueWait: {
                n: number;
                unknown: number;
                median: number | null;
                p75: number | null;
                max: number | null;
                values: number[];
            };
            stages: {
                family: string;
                spans: number;
                totalMs: number;
                medianMs: number | null;
                acceptedMs: number;
                rejectedMs: number;
                incomplete: number;
            }[];
            stagesTruncated: boolean;
            firstPass: {
                value: number | null;
                n: number;
                unknown: number;
                bound: "exact" | "unknown" | "lower" | "upper";
            };
            firstPassRaw: {
                value: number | null;
                n: number;
                unknown: number;
                bound: "exact" | "unknown" | "lower" | "upper";
            };
            finished: {
                accepted: number;
                failed: number;
                cancelled: number;
            };
            attemptsPerAccepted: {
                n: number;
                buckets: {
                    '1': number;
                    '2': number;
                    '3': number;
                    '4-6': number;
                    '7+': number;
                };
                median: number | null;
                mean: number | null;
            };
            attemptsOnOther: number;
            machineTime: {
                n: number;
                unknown: number;
                median: number | null;
                p75: number | null;
                max: number | null;
                values: number[];
            };
        };
        cost: {
            calls: number;
            knownCalls: number;
            knownUsd: number;
            reportedUsd: number;
            estimatedUsd: number;
            unknown: {
                total: number;
                noPrice: number;
                incomplete: number;
                active: number;
                abandoned: number;
                byRuntime: {
                    runtime: string;
                    calls: number;
                }[];
            };
            attemptsWithoutCalls: number;
            attemptsPartialCalls: number;
            perAccepted: {
                value: number | null;
                n: number;
                unknown: number;
                bound: "exact" | "unknown" | "lower" | "upper";
            };
            perAttempt: {
                n: number;
                unknown: number;
                median: number | null;
                p75: number | null;
                max: number | null;
                values: number[];
            };
            rejected: {
                bound: "exact" | "unknown" | "lower" | "upper";
                usd: number;
                totalUsd: number;
                attempts: number;
                byBucket: {
                    bucket: "input" | "unknown" | "operator" | "integration" | "environment" | "budget" | "defect" | "incomplete" | "time-limit" | "tool" | "unclassified";
                    usd: number;
                }[];
            };
            byStage: {
                stage: string;
                calls: number;
                knownUsd: number;
                unknownCalls: number;
            }[];
            tokens: {
                input: number;
                output: number;
                cacheRead: number;
                cacheWrite: number;
                incompleteCalls: number;
            };
        };
        environment: {
            failed: number;
            classified: number;
            interrupted: number;
            buckets: {
                bucket: "input" | "unknown" | "operator" | "integration" | "environment" | "budget" | "defect" | "incomplete" | "time-limit" | "tool" | "unclassified";
                count: number;
            }[];
            share: {
                value: number | null;
                n: number;
                unknown: number;
                bound: "exact" | "unknown" | "lower" | "upper";
            };
            setupCheckFailures: number;
            timeLimit: number;
            causes: {
                rows: {
                    cause: "preflight" | "transport" | "none" | "other" | "provider-auth" | "stalled" | "shutdown" | "sandbox-launch" | "sandbox-network" | "sandbox-filesystem" | "sandbox-policy" | "dependency-network" | "provider-limit" | "lease-expired";
                    count: number;
                    counted: number;
                }[];
                diagnosed: number;
                undiagnosed: number;
                bound: "exact" | "lower";
            } | null;
            neutral: {
                costBound: "exact" | "unknown" | "lower" | "upper";
                attempts: number;
                blocked: number;
                machineMs: number;
                knownUsd: number;
                runtimePauses: number;
            };
            rechecks: {
                flaky: number;
                confirmed: number;
            };
        };
        weeks: {
            rows: ({
                kind: "week";
                week: string;
                attempts: number;
                accepted: number;
                firstPass: number;
                defects: number;
                environment: number;
                knownUsd: number;
                unknownCalls: number;
                leadMedianMs: number | null;
                engines: string[];
                engineChanged: boolean;
                enginesTruncated: boolean;
            } | {
                kind: "gap";
                from: string;
                to: string;
            })[];
            earlier: {
                kind: "earlier";
                from: string;
                to: string;
                weeks: number;
                attempts: number;
                accepted: number;
                firstPass: number;
                defects: number;
                environment: number;
                knownUsd: number;
                unknownCalls: number;
            } | null;
            active: number;
        };
        works: {
            rows: {
                id: string;
                outcome: "cancelled" | "failed" | "accepted";
                finishedAt: string | null;
                attempts: number;
                counted: number;
                leadMs: number | null;
                knownUsd: number;
                unknownCalls: number;
                costBound: "exact" | "unknown" | "lower" | "upper";
                rejections: {
                    key: "input" | "unknown" | "operator" | "integration" | "environment" | "budget" | "defect" | "incomplete" | "time-limit" | "tool" | "unclassified";
                    count: number;
                }[];
                title?: string | undefined;
            }[];
            total: number;
            truncated: boolean;
        };
        limitations: {
            id: string;
            text: string;
        }[];
        inputs?: {
            questions: number;
            awaitingAnswer: number;
            answeredNotApplied: number;
            appliedAwaitingClaim: number;
            delivered: number;
            closed: number;
            declined: number;
            followUps: number;
            assumptions: number;
            carryStale?: number | undefined;
        } | undefined;
    };
    events(after?: number, limit?: number): {
        events: import("../contracts/events.ts").RunEvent[];
        next: number;
    };
    /** Результат завершённой попытки поручения (последней или `runId`) и состояние его доставки. */
    result(workId: string, runId?: string): ResultEnvelope;
    /**
     * Доставка результата поручения получателю. Ключ — получатель, поручение и
     * попытка: повтор не создаёт второй записи и не вызывает моделей или
     * интеграции. Конфликт редакции записывается, результат её не закрывает.
     */
    deliver(workId: string, sink: ResultSink): Promise<{
        apiVersion: "devcontour-harness/v1alpha1";
        result: {
            outcome: "accepted";
            shas: {
                base: string;
                candidate: string;
                integration: string;
                result: string;
            };
            apiVersion: "devcontour-harness/v1alpha1";
            workOrderId: string;
            graphId: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            runId: string;
            attempt: number;
            repositoryId: string;
            targetRef: string;
            inputs: {
                harnessVersion: string;
                stateVersion: 1;
                workOrderDigest: string;
                graphDigest: string;
                policyDigest: string;
                consumerVersion?: string | undefined;
                contextDigest?: string | undefined;
                checks?: string | undefined;
                corpus?: {
                    suite: string;
                    number: number;
                    digest: string;
                } | undefined;
                requiredGates?: string[] | undefined;
                writer?: {
                    runtime: "codex" | "claude" | "fixture";
                    model?: string | undefined;
                } | undefined;
            };
            checked: {
                dependencies: {
                    repositoryId: string;
                    sha: string;
                    tree: string;
                    artifacts: {
                        path: string;
                        digest: string;
                    }[];
                }[];
                freshness: {
                    repositoryId: string;
                    snapshot: string;
                    head: string;
                    fresh: boolean;
                }[];
                consumers: {
                    repositoryId: string;
                    gates: string[];
                    sha: string;
                    tree: string;
                    dependencies: {
                        repositoryId: string;
                        sha: string;
                        tree: string;
                        artifacts: {
                            path: string;
                            digest: string;
                        }[];
                    }[];
                    freshness: {
                        repositoryId: string;
                        snapshot: string;
                        head: string;
                        fresh: boolean;
                    }[];
                }[];
            };
            evidence: {
                id: string;
                kind: "check" | "review" | "test" | "property" | "consumer";
                phase: "candidate" | "integration";
                gate: string;
                sha: string;
                passed: boolean;
                digest: string;
                summary: string;
                consumer?: string | undefined;
                checks?: string | undefined;
                tests?: {
                    id: string;
                    status: "passed" | "failed" | "skipped";
                    opaque?: true | undefined;
                }[] | undefined;
                testsTruncated?: boolean | undefined;
                property?: {
                    level?: "manifest" | "legacy" | undefined;
                    manifest?: {
                        digest: string;
                        properties: string[];
                        corpus?: {
                            digest: string;
                            cases: number;
                        } | undefined;
                    } | undefined;
                } | undefined;
                reviewer?: {
                    runtime: "codex" | "claude" | "fixture";
                    sameVendor: boolean;
                    model?: string | undefined;
                } | undefined;
                review?: {
                    round: number;
                    call: number;
                    protocol: "valid" | "invalid" | "unsafe";
                    issues?: {
                        path: string;
                        reason: string;
                        message: string;
                    }[] | undefined;
                    transitions?: {
                        id: string;
                        from: "closed" | "open" | "withdrawn";
                        to: "closed" | "open" | "withdrawn";
                    }[] | undefined;
                } | undefined;
            }[];
            findings: {
                severity: string;
                message: string;
                path?: string | null | undefined;
                line?: number | null | undefined;
                rule?: string | undefined;
                id?: string | undefined;
                status?: "closed" | "open" | "withdrawn" | undefined;
            }[];
            limitations: string[];
            finishedAt: string;
        } | {
            outcome: "cancelled" | "rejected" | "blocked" | "stopped";
            shas: {
                base?: string | undefined;
                candidate?: string | undefined;
                integration?: string | undefined;
            };
            stopReason: {
                code: "INVALID_INPUT" | "UNSUPPORTED_COMMAND" | "UNSUPPORTED_VERSION" | "GRAPH_CYCLE" | "GRAPH_UNKNOWN_DEPENDENCY" | "GRAPH_DUPLICATE_ID" | "GATE_UNKNOWN" | "GATE_GROUP_CYCLE" | "REVIEWER_SAME_VENDOR" | "REVIEWER_MISSING" | "RESPONSE_TOO_LARGE" | "APPROVAL_STALE" | "APPROVAL_REQUIRED" | "LEASE_STALE" | "CONTROLLER_BUSY" | "PAUSED" | "NOT_READY" | "SCOPE_VIOLATION" | "GATE_FAILED" | "REVIEW_REJECTED" | "BUDGET_EXHAUSTED" | "BUDGET_UNKNOWN" | "ATTEMPTS_EXHAUSTED" | "CONTEXT_EXHAUSTED" | "INPUT_REQUIRED" | "REVISION_CONFLICT" | "CANCELLED" | "NOT_FOUND" | "PATH_CONFLICT" | "STATE_VERSION_UNSUPPORTED" | "RUNTIME_UNAVAILABLE" | "REVIEW_PROTOCOL_INVALID" | "SANDBOX_UNAVAILABLE" | "GIT_FAILED" | "STORAGE_FAILED" | "DELIVERY_FAILED" | "INTERNAL";
                message: string;
            };
            apiVersion: "devcontour-harness/v1alpha1";
            workOrderId: string;
            graphId: string;
            source: {
                connector: string;
                ref: string;
                revision: string;
            };
            runId: string;
            attempt: number;
            repositoryId: string;
            targetRef: string;
            inputs: {
                harnessVersion: string;
                stateVersion: 1;
                workOrderDigest: string;
                graphDigest: string;
                policyDigest: string;
                consumerVersion?: string | undefined;
                contextDigest?: string | undefined;
                checks?: string | undefined;
                corpus?: {
                    suite: string;
                    number: number;
                    digest: string;
                } | undefined;
                requiredGates?: string[] | undefined;
                writer?: {
                    runtime: "codex" | "claude" | "fixture";
                    model?: string | undefined;
                } | undefined;
            };
            checked: {
                dependencies: {
                    repositoryId: string;
                    sha: string;
                    tree: string;
                    artifacts: {
                        path: string;
                        digest: string;
                    }[];
                }[];
                freshness: {
                    repositoryId: string;
                    snapshot: string;
                    head: string;
                    fresh: boolean;
                }[];
                consumers: {
                    repositoryId: string;
                    gates: string[];
                    sha: string;
                    tree: string;
                    dependencies: {
                        repositoryId: string;
                        sha: string;
                        tree: string;
                        artifacts: {
                            path: string;
                            digest: string;
                        }[];
                    }[];
                    freshness: {
                        repositoryId: string;
                        snapshot: string;
                        head: string;
                        fresh: boolean;
                    }[];
                }[];
            };
            evidence: {
                id: string;
                kind: "check" | "review" | "test" | "property" | "consumer";
                phase: "candidate" | "integration";
                gate: string;
                sha: string;
                passed: boolean;
                digest: string;
                summary: string;
                consumer?: string | undefined;
                checks?: string | undefined;
                tests?: {
                    id: string;
                    status: "passed" | "failed" | "skipped";
                    opaque?: true | undefined;
                }[] | undefined;
                testsTruncated?: boolean | undefined;
                property?: {
                    level?: "manifest" | "legacy" | undefined;
                    manifest?: {
                        digest: string;
                        properties: string[];
                        corpus?: {
                            digest: string;
                            cases: number;
                        } | undefined;
                    } | undefined;
                } | undefined;
                reviewer?: {
                    runtime: "codex" | "claude" | "fixture";
                    sameVendor: boolean;
                    model?: string | undefined;
                } | undefined;
                review?: {
                    round: number;
                    call: number;
                    protocol: "valid" | "invalid" | "unsafe";
                    issues?: {
                        path: string;
                        reason: string;
                        message: string;
                    }[] | undefined;
                    transitions?: {
                        id: string;
                        from: "closed" | "open" | "withdrawn";
                        to: "closed" | "open" | "withdrawn";
                    }[] | undefined;
                } | undefined;
            }[];
            findings: {
                severity: string;
                message: string;
                path?: string | null | undefined;
                line?: number | null | undefined;
                rule?: string | undefined;
                id?: string | undefined;
                status?: "closed" | "open" | "withdrawn" | undefined;
            }[];
            limitations: string[];
            finishedAt: string;
        };
        delivery: {
            sink: string;
            key: string;
            revision: string;
            status: "pending" | "delivered" | "failed" | "conflict" | "uncertain";
            attempts: number;
            updatedAt: string;
            lastError?: string | undefined;
            operation?: string | undefined;
            currentRevision?: string | undefined;
            receipt?: string | undefined;
        }[];
    }>;
    private deliverAll;
}
