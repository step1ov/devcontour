import type { ExecutionStore } from '../contracts/index.ts';
import type { ValueReportInput } from '../report/compute.ts';
/**
 * Вход отчёта (`valueReport`) из хранилища исполнения: графы, поручения,
 * попытки, записи учёта вызовов и ревью — одним снимком `read`; журнал
 * событий — страницами по 500 вне этого снимка (транзакция чтения между
 * страницами не держится). Ничего не пишет.
 */
export declare function collectReportInput(store: ExecutionStore): ValueReportInput;
