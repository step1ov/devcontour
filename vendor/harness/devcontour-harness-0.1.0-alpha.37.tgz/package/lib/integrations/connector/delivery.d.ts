import { type DeliveryOutcome, type ResultSink, type RunResult } from '../../contracts/index.ts';
import { type Redactor } from '../../environment/redaction.ts';
import { type ConnectorConfig } from './config.ts';
import type { HistoryRecorder } from './history.ts';
import type { ConnectorStore } from './store.ts';
import { type CriterionOutcome } from './summary.ts';
import type { RelayTransport } from './transport.ts';
/**
 * Получатель результата во внешнем хранилище задач с сохраняемым протоколом.
 *
 * Ключ операции — `hash(provider, projectId, workId, runId, resultDigest)`.
 * Intent записывается в состояние коннектора **до** внешнего вызова; без него
 * мутация не отправляется. Каждый шаг (комментарий с маркером, отметки
 * критериев с CAS, перемещение с CAS, история) записывается до и после
 * вызова; неизвестный исход разбирается read-back по маркеру или сравнением
 * состояния, а не повтором. Неоднозначность — `uncertain` и явный
 * `source-reconcile`.
 *
 * Владелец доставки один: lease с токеном, сроком и fencing в той же SQLite.
 * Гарантия действует для процессов с общим каталогом состояния коннектора;
 * независимые установки с разными каталогами вне её. Distributed
 * exactly-once не заявляется: у получателя нет идемпотентности по requestId.
 */
export declare const operationKey: (provider: string, projectId: string, workId: string, runId: string, resultDigest: string) => string;
export type CriterionPlan = CriterionOutcome;
export interface SinkOptions {
    config: ConnectorConfig;
    transport: RelayTransport;
    store: ConnectorStore;
    connectorId: string;
    history?: HistoryRecorder;
    /** Владелец lease (для диагностики); по умолчанию host:pid. */
    owner?: string;
    redact?: Redactor;
}
/** Решение оператора при reconcile неоднозначного шага. */
export type ReconcileDecision = 
/** Доказано вне harness, что записи нет: отправить шаг снова (маркер тот же). */
{
    kind: 'resend';
}
/** Несколько записей с маркером: явно выбрать одну как подтверждение. */
 | {
    kind: 'adopt';
    id: string;
}
/** Конфликт CAS из-за несемантического изменения: перепроверить постановку и продолжить. */
 | {
    kind: 'recheck';
};
export declare class RelaySink implements ResultSink {
    readonly options: SinkOptions;
    readonly id: string;
    private readonly owner;
    private readonly redact;
    private readonly t;
    constructor(options: SinkOptions);
    private get config();
    /** Задача и её mapping по результату; чужой provider/проект — отказ до записи. */
    private taskOf;
    private sameSnapshot;
    private mappingOf;
    keyOf(result: RunResult): string;
    private outcomeOf;
    deliver(input: {
        key: string;
        result: RunResult;
    }): Promise<DeliveryOutcome>;
    private deliverOnce;
    /** Предварительная сверка постановки и eligibility, затем план шагов — до первой мутации. */
    private plan;
    /** Критерий закрывается только явным mapping на прошедший gate/testcase принятого результата. */
    private criteriaPlan;
    private movePlan;
    /** Выполнить оставшиеся шаги по протоколу; итог — новое состояние операции. */
    private execute;
    /**
     * Сверка перед каждым неподтверждённым шагом (и при продолжении после
     * обрыва): постановка та же (semantic digest), задача не отменена и не
     * закрыта другим, а для нового CAS-шага текущая ревизия равна ревизии,
     * записанной после **нашего** предыдущего шага. Иначе — conflict: старый
     * результат не применяется к изменённой задаче.
     */
    private verifyBefore;
    /** Последняя подтверждённая CAS-ревизия задачи перед шагом `n`. */
    private revisionBefore;
    private handlers;
    /**
     * Разбор неизвестного исхода или конфликта операции. Сначала — факты
     * получателя (read-back); решение оператора требуется только там, где
     * факты неоднозначны. Сам reconcile мутаций не отправляет: продолжение —
     * обычной доставкой с тем же ключом.
     */
    reconcile(key: string, decision?: ReconcileDecision): Promise<{
        operation: string;
        before: "conflict";
        after: import("./store.ts").OperationStatus;
        resolved: boolean;
        facts: string[];
    } | {
        operation: string;
        before: "delivered" | "failed" | "uncertain" | "intent" | "in-progress";
        after: import("./store.ts").OperationStatus;
        resolved: boolean;
        facts: string[];
    }>;
}
