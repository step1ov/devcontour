import { HarnessError } from '../../contracts/index.ts';
import type { ProviderId } from './transport.ts';
export type StepStatus = 'planned' | 'sending' | 'done' | 'skipped' | 'conflict' | 'uncertain';
/** Шаг доставки или истории: внешний вызов с маркером и его подтверждённый итог. */
export interface StepRecord {
    n: number;
    kind: 'comment' | 'historical-comment' | 'criterion' | 'move' | 'history' | 'session.start' | 'session.intent' | 'session.fork' | 'session.attach' | 'session.checkpoint' | 'session.finish';
    status: StepStatus;
    marker: string;
    /** Параметры шага, закреплённые при планировании (критерий, колонка, выход истории). */
    input: Record<string, unknown>;
    /** Подтверждённый итог (ID комментария, новая ревизия, ID сессии). */
    result?: Record<string, unknown>;
    reason?: string;
    /** Сколько раз шаг отправлялся (вне `planned`); не повод для повтора. */
    sends: number;
    updatedAt: string;
}
export type OperationStatus = 'intent' | 'in-progress' | 'delivered' | 'conflict' | 'uncertain' | 'failed';
export interface OperationRecord {
    key: string;
    provider: ProviderId;
    projectId: string;
    workId: string;
    runId: string;
    taskId: string;
    resultDigest: string;
    /** Редакция (semantic digest) постановки, к которой относится результат. */
    revision: string;
    outcome: string;
    status: OperationStatus;
    steps: StepRecord[];
    /** Шаги спланированы (после предварительной сверки, до первой мутации). */
    planned: boolean;
    reason?: string;
    /** Текущая редакция источника при конфликте. */
    currentRevision?: string;
    receipt?: Record<string, unknown>;
    createdAt: string;
    updatedAt: string;
}
export interface LeaseRecord {
    key: string;
    token: string;
    owner: string;
    expiresAt: number;
    fence: number;
}
export interface SnapshotRecord {
    revision: string;
    graphId: string;
    graph: unknown;
    context: unknown;
    manifest: unknown;
    createdAt: string;
}
/** Доверенный receipt доставки принятого результата: основание предпосылки зависимой задачи. */
export interface ReceiptRecord {
    issuer: string;
    orderId: string;
    taskId: string;
    repositoryId: string;
    resultSha: string;
    workId: string;
    runId: string;
    operation: string;
}
export declare class LeaseLost extends HarnessError {
    constructor(key: string);
}
export declare class ConnectorStore {
    readonly file: string;
    readonly identity: {
        provider: ProviderId;
        projectId: string;
    };
    readonly options: {
        readOnly?: boolean;
        onWrite?: (what: string) => void;
    };
    private readonly db;
    /**
     * `onWrite` — точка отказа для тестов: вызывается перед каждой записью с её
     * названием и может бросить исключение (запись не выполняется).
     */
    constructor(file: string, identity: {
        provider: ProviderId;
        projectId: string;
    }, options?: {
        readOnly?: boolean;
        onWrite?: (what: string) => void;
    });
    private checkIdentity;
    close(): void;
    /** Синхронная транзакция записи; внутри нет сети, процессов и `await`. */
    private tx;
    putSnapshot(record: Omit<SnapshotRecord, 'createdAt'>): {
        record: SnapshotRecord;
        created: boolean;
    };
    snapshot(revision: string): SnapshotRecord | undefined;
    /** Последний закреплённый снимок графа: порядок записи, а не время создания редакции. */
    latestSnapshot(graphId: string): SnapshotRecord | undefined;
    /** Последний закреплённый снимок любого графа этого коннектора. */
    latestSnapshotAny(): SnapshotRecord | undefined;
    /**
     * Взять владение операцией. Действующий lease другого владельца — отказ
     * (`undefined` с текущим держателем); истёкший — перехват с новым токеном
     * и увеличенным fence. Intent операции при этом не теряется: он в
     * отдельной записи.
     */
    acquire(key: string, owner: string, ms: number): {
        lease?: LeaseRecord;
        holder?: LeaseRecord;
    };
    lease(key: string): LeaseRecord | undefined;
    private assertLease;
    /** Продлить владение; утраченное — `LeaseLost`. */
    renew(key: string, token: string, ms: number): void;
    release(key: string, token: string): void;
    operation(key: string): OperationRecord | undefined;
    operations(filter?: {
        workId?: string;
        taskId?: string;
    }): OperationRecord[];
    /** Записать intent до любого внешнего вызова; повтор существующего не меняет его. */
    putIntent(record: Omit<OperationRecord, 'createdAt' | 'updatedAt' | 'status' | 'steps' | 'planned'>, token: string): OperationRecord;
    /** Изменить операцию под владением `token` (fencing в той же транзакции). */
    updateOp(key: string, token: string, mutate: (op: OperationRecord) => OperationRecord, what?: string): OperationRecord;
    private writeOp;
    putReceipt(receipt: ReceiptRecord, token: string): void;
    receipts(orderId?: string): ReceiptRecord[];
    history<T>(key: string): T | undefined;
    histories<T>(prefix: string): {
        key: string;
        value: T;
    }[];
    /** Записать связь истории; `mutate` получает прежнее значение. */
    putHistory<T>(key: string, mutate: (prior: T | undefined) => T): T;
}
