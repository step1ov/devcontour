import { policySecrets, redactor, type Redactor } from '../../environment/redaction.ts';
import { type RelayTransport } from './transport.ts';
/** Значения настроек provider, по имени похожие на секрет (например, `relay.env.RELAY_TOKEN`). */
export declare function settingsSecrets(settings: unknown): string[];
export declare function maskError(error: unknown, redact: Redactor): unknown;
/** Транспорт, ошибки которого замаскированы `redact`. Повторная обёртка не создаётся. */
export declare function redactingTransport(inner: RelayTransport, redact: Redactor): RelayTransport;
export { policySecrets, redactor };
