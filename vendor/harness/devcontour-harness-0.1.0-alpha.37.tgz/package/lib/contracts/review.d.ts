import { z } from 'zod';
/**
 * Ответы исполнителей. Runtime возвращает сырой текст/JSON (`RuntimeResponse.output`
 * — вход парсера); движок разбирает его этими схемами. Ответ вне схемы —
 * отказ ревью или реализации, а не самооценка writer.
 */
/** Находка, которую исполнитель предлагает завести отдельной работой (bug/debt). */
export declare const discoverySchema: z.ZodObject<{
    kind: z.ZodEnum<{
        bug: "bug";
        debt: "debt";
    }>;
    title: z.ZodString;
    path: z.ZodString;
    line: z.ZodNumber;
    observation: z.ZodString;
    consequence: z.ZodString;
    reproduction: z.ZodString;
}, z.core.$strict>;
/**
 * Ответ writer. При `completed: false` он может вернуть вопрос
 * (`inputRequest`) — controller решит по закреплённой `inputPolicy`, остановка
 * это (`needs-input`) или незавершённость. `completed: true` вместе с вопросом
 * невалиден. Развилки, решённые самим исполнителем, — `assumptions`. Поля
 * необязательны: ответ прежнего формата читается как ответ без вопроса и
 * допущений.
 */
export declare const implementationResultSchema: z.ZodObject<{
    completed: z.ZodBoolean;
    summary: z.ZodString;
    discoveries: z.ZodDefault<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            bug: "bug";
            debt: "debt";
        }>;
        title: z.ZodString;
        path: z.ZodString;
        line: z.ZodNumber;
        observation: z.ZodString;
        consequence: z.ZodString;
        reproduction: z.ZodString;
    }, z.core.$strict>>>;
    inputRequest: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        question: z.ZodString;
        options: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            consequence: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
        recommended: z.ZodNullable<z.ZodString>;
        severity: z.ZodNumber;
        rationale: z.ZodString;
        affects: z.ZodArray<z.ZodEnum<{
            acceptance: "acceptance";
            contract: "contract";
            product: "product";
            api: "api";
            migration: "migration";
        }>>;
    }, z.core.$strict>>>;
    assumptions: z.ZodDefault<z.ZodArray<z.ZodObject<{
        question: z.ZodString;
        chosen: z.ZodString;
        rationale: z.ZodString;
        severity: z.ZodNumber;
        affects: z.ZodArray<z.ZodEnum<{
            acceptance: "acceptance";
            contract: "contract";
            product: "product";
            api: "api";
            migration: "migration";
        }>>;
    }, z.core.$strict>>>;
}, z.core.$strip>;
export type ImplementationResult = z.infer<typeof implementationResultSchema>;
export declare const reproductionSchema: z.ZodObject<{
    property: z.ZodNullable<z.ZodString>;
    input: z.ZodString;
    inputClass: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    expected: z.ZodNullable<z.ZodString>;
    actual: z.ZodNullable<z.ZodString>;
    command: z.ZodNullable<z.ZodArray<z.ZodString>>;
    executed: z.ZodBoolean;
    run: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
export declare const reviewExecutionSchema: z.ZodObject<{
    commands: z.ZodArray<z.ZodObject<{
        command: z.ZodString;
        exitCode: z.ZodNumber;
        summary: z.ZodString;
    }, z.core.$strict>>;
    noCommandsReason: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
/**
 * Основание перехода: не меньше трёх непробельных символов. Те же правила —
 * `pattern` wire-схемы CLI runtime (`agents/schemas.ts`): длину строки
 * structured output выразить нельзя, поэтому и Zod длину сверху не
 * ограничивает — сохраняемое основание обрезается до 4000 символов.
 */
export declare const FINDING_BASIS_PATTERN = "\\S[\\s\\S]*\\S[\\s\\S]*\\S";
export declare const FINDING_ID_PATTERN = "^[0-9a-f]{64}$";
export declare const findingStatuses: readonly ["open", "closed", "withdrawn"];
export type FindingStatus = (typeof findingStatuses)[number];
/** Состояние прежней находки в новом раунде ревью. */
export declare const findingTransitionSchema: z.ZodObject<{
    id: z.ZodString;
    status: z.ZodEnum<{
        closed: "closed";
        open: "open";
        withdrawn: "withdrawn";
    }>;
    basis: z.ZodString;
}, z.core.$strict>;
/**
 * Ответ reviewer. Принятие (`approved: true`) при любой блокирующей находке
 * — отказ; `previous` обязан назвать состояние каждой прежней открытой
 * находки этого предмета (см. `reviewIssues`).
 */
/** Основание «приёмка уже выполнена»: названные gates и что их evidence показывает. */
export declare const alreadySatisfiedSchema: z.ZodObject<{
    gates: z.ZodArray<z.ZodString>;
    evidence: z.ZodString;
}, z.core.$strict>;
export type AlreadySatisfied = z.infer<typeof alreadySatisfiedSchema>;
/**
 * Предел находок и переходов в одном ответе reviewer и в раунде истории. Без
 * предела каждый лишний элемент ответа давал отдельные ошибки разбора и
 * гигабайты кучи. Реальные ответы на порядки меньше.
 */
export declare const REVIEW_ITEMS_LIMIT = 500;
export declare const reviewResultSchema: z.ZodObject<{
    execution: z.ZodOptional<z.ZodObject<{
        commands: z.ZodArray<z.ZodObject<{
            command: z.ZodString;
            exitCode: z.ZodNumber;
            summary: z.ZodString;
        }, z.core.$strict>>;
        noCommandsReason: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    approved: z.ZodBoolean;
    summary: z.ZodString;
    discoveries: z.ZodDefault<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            bug: "bug";
            debt: "debt";
        }>;
        title: z.ZodString;
        path: z.ZodString;
        line: z.ZodNumber;
        observation: z.ZodString;
        consequence: z.ZodString;
        reproduction: z.ZodString;
    }, z.core.$strict>>>;
    findings: z.ZodArray<z.ZodObject<{
        severity: z.ZodEnum<{
            blocking: "blocking";
            note: "note";
        }>;
        message: z.ZodString;
        path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        rule: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        consequence: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        evidence: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        reproduction: z.ZodCatch<z.ZodOptional<z.ZodNullable<z.ZodObject<{
            property: z.ZodNullable<z.ZodString>;
            input: z.ZodString;
            inputClass: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            expected: z.ZodNullable<z.ZodString>;
            actual: z.ZodNullable<z.ZodString>;
            command: z.ZodNullable<z.ZodArray<z.ZodString>>;
            executed: z.ZodBoolean;
            run: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>>>>;
    }, z.core.$strip>>;
    previous: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        status: z.ZodEnum<{
            closed: "closed";
            open: "open";
            withdrawn: "withdrawn";
        }>;
        basis: z.ZodString;
    }, z.core.$strict>>>;
    alreadySatisfied: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        gates: z.ZodArray<z.ZodString>;
        evidence: z.ZodString;
    }, z.core.$strict>>>;
}, z.core.$strip>;
export type ReviewResult = z.infer<typeof reviewResultSchema>;
/**
 * Записанный ответ reviewer (`review.json`). Предел `reviewResultSchema` —
 * граница приёма: файлы прежних версий с длинными списками читаются и дальше.
 */
export declare const storedReviewResultSchema: z.ZodObject<{
    execution: z.ZodOptional<z.ZodObject<{
        commands: z.ZodArray<z.ZodObject<{
            command: z.ZodString;
            exitCode: z.ZodNumber;
            summary: z.ZodString;
        }, z.core.$strict>>;
        noCommandsReason: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    approved: z.ZodBoolean;
    summary: z.ZodString;
    discoveries: z.ZodDefault<z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            bug: "bug";
            debt: "debt";
        }>;
        title: z.ZodString;
        path: z.ZodString;
        line: z.ZodNumber;
        observation: z.ZodString;
        consequence: z.ZodString;
        reproduction: z.ZodString;
    }, z.core.$strict>>>;
    alreadySatisfied: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        gates: z.ZodArray<z.ZodString>;
        evidence: z.ZodString;
    }, z.core.$strict>>>;
    findings: z.ZodArray<z.ZodObject<{
        severity: z.ZodEnum<{
            blocking: "blocking";
            note: "note";
        }>;
        message: z.ZodString;
        path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        rule: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        consequence: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        evidence: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        reproduction: z.ZodCatch<z.ZodOptional<z.ZodNullable<z.ZodObject<{
            property: z.ZodNullable<z.ZodString>;
            input: z.ZodString;
            inputClass: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            expected: z.ZodNullable<z.ZodString>;
            actual: z.ZodNullable<z.ZodString>;
            command: z.ZodNullable<z.ZodArray<z.ZodString>>;
            executed: z.ZodBoolean;
            run: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>>>>;
    }, z.core.$strip>>;
    previous: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        status: z.ZodEnum<{
            closed: "closed";
            open: "open";
            withdrawn: "withdrawn";
        }>;
        basis: z.ZodString;
    }, z.core.$strict>>>;
}, z.core.$strip>;
/** Идентичность находки: предмет, класс и текст. Новый текст — новая находка. */
export declare const findingId: (subject: string, finding: {
    rule?: string | null;
    message: string;
}) => string;
export declare const reviewFindingSchema: z.ZodObject<{
    id: z.ZodString;
    severity: z.ZodEnum<{
        blocking: "blocking";
        note: "note";
    }>;
    message: z.ZodString;
    rule: z.ZodOptional<z.ZodString>;
    path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    status: z.ZodEnum<{
        closed: "closed";
        open: "open";
        withdrawn: "withdrawn";
    }>;
    openedIn: z.ZodNumber;
    changedIn: z.ZodNumber;
    basis: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
/**
 * Раунд технического ревью плана (графа) или контракта. Раунды предмета
 * нумеруются подряд и не переписываются; переименование предмета не
 * начинает историю заново — предмет задаётся ID, а не заголовком.
 */
export declare const reviewRecordSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        contract: "contract";
        plan: "plan";
    }>;
    subject: z.ZodString;
    digest: z.ZodString;
    round: z.ZodNumber;
    at: z.ZodISODateTime;
    approved: z.ZodBoolean;
    summary: z.ZodString;
    authorRuntime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
        fixture: "fixture";
        external: "external";
    }>;
    reviewerRuntime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
        fixture: "fixture";
    }>;
    reviewerModel: z.ZodOptional<z.ZodString>;
    sameVendor: z.ZodBoolean;
    reviewerBinding: z.ZodOptional<z.ZodString>;
    contextDigest: z.ZodOptional<z.ZodString>;
    findings: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        severity: z.ZodEnum<{
            blocking: "blocking";
            note: "note";
        }>;
        message: z.ZodString;
        rule: z.ZodOptional<z.ZodString>;
        path: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        line: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        status: z.ZodEnum<{
            closed: "closed";
            open: "open";
            withdrawn: "withdrawn";
        }>;
        openedIn: z.ZodNumber;
        changedIn: z.ZodNumber;
        basis: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    artifact: z.ZodString;
}, z.core.$strict>;
export type ReviewRecord = z.infer<typeof reviewRecordSchema>;
/**
 * Согласованность ответа reviewer с историей предмета: approved без
 * блокирующих находок и без открытых блокирующих прежних, у каждой прежней
 * открытой находки названо состояние, ссылки только на известные находки.
 */
export declare function reviewIssues(result: ReviewResult, previousOpen: {
    id: string;
    severity: 'blocking' | 'note';
}[]): string[];
/** Дополнительных вызовов reviewer при ошибке протокола, когда политика их не задаёт. */
export declare const DEFAULT_REVIEW_PROTOCOL_RETRIES = 1;
/** Причины ошибки протокола ответа reviewer. */
export declare const protocolIssueReasons: readonly ["schema", "unknown", "duplicate", "not-open", "missing", "approved-with-blocking"];
export type ProtocolIssueReason = (typeof protocolIssueReasons)[number];
/** Причина ошибки протокола: путь поля ответа (`previous[0].id`), класс и пояснение. */
export declare const protocolIssueSchema: z.ZodObject<{
    path: z.ZodString;
    reason: z.ZodEnum<{
        schema: "schema";
        unknown: "unknown";
        missing: "missing";
        duplicate: "duplicate";
        "not-open": "not-open";
        "approved-with-blocking": "approved-with-blocking";
    }>;
    message: z.ZodString;
}, z.core.$strict>;
export type ProtocolIssue = z.infer<typeof protocolIssueSchema>;
/**
 * Сведения раунда ревью кода в evidence (аддитивное поле `reviewRound`).
 * Валидный раунд несёт применённые переходы; невалидный — только причины и
 * историю не меняет.
 */
export declare const reviewRoundSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    scope: z.ZodString;
    round: z.ZodNumber;
    call: z.ZodNumber;
    calls: z.ZodNumber;
    protocol: z.ZodEnum<{
        valid: "valid";
        invalid: "invalid";
        unsafe: "unsafe";
    }>;
    expected: z.ZodArray<z.ZodString>;
    issues: z.ZodOptional<z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        reason: z.ZodEnum<{
            schema: "schema";
            unknown: "unknown";
            missing: "missing";
            duplicate: "duplicate";
            "not-open": "not-open";
            "approved-with-blocking": "approved-with-blocking";
        }>;
        message: z.ZodString;
    }, z.core.$strict>>>;
    transitions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        from: z.ZodEnum<{
            closed: "closed";
            open: "open";
            withdrawn: "withdrawn";
        }>;
        to: z.ZodEnum<{
            closed: "closed";
            open: "open";
            withdrawn: "withdrawn";
        }>;
        basis: z.ZodString;
    }, z.core.$strict>>>;
    spec: z.ZodOptional<z.ZodString>;
    mode: z.ZodOptional<z.ZodEnum<{
        legacy: "legacy";
        strict: "strict";
    }>>;
}, z.core.$strict>;
export type ReviewRound = z.infer<typeof reviewRoundSchema>;
/** Область истории находок ревью кода: поручение в репозитории. */
export declare const codeReviewScope: (repositoryId: string, workId: string) => string;
interface FindingOrigin {
    runId: string;
    phase: 'candidate' | 'integration';
    sha: string;
    round: number;
}
/** ID находки, выданный controller при записи валидного раунда. */
export declare const codeFindingId: (scope: string, origin: FindingOrigin, index: number, finding: {
    severity: string;
    message: string;
}) => string;
/** Детерминированный ID находки записи alpha.5 (без ID) — из неизменяемого origin. */
export declare const legacyFindingId: (scope: string, evidence: {
    id: string;
    runId: string;
    phase: string;
    sha: string;
}, index: number, finding: {
    severity: string;
    message: string;
}) => string;
export interface FindingTransitionRecord {
    round: number;
    runId: string;
    phase: 'candidate' | 'integration';
    sha: string;
    from: FindingStatus;
    to: FindingStatus;
    basis: string;
}
/** Находка в истории ревью кода поручения. */
export interface CodeFinding {
    id: string;
    severity: string;
    message: string;
    path: string | null;
    line: number | null;
    status: FindingStatus;
    origin: FindingOrigin & {
        evidence: string;
        spec?: string;
        legacy?: true;
    };
    openedIn: number;
    changedIn: number;
    basis?: string;
    transitions: FindingTransitionRecord[];
}
export interface CodeReviewHistory {
    scope: string;
    /** Номер последнего состоявшегося раунда области (0 — раундов не было). */
    round: number;
    findings: CodeFinding[];
}
/** Минимум сведений попытки, из которых собирается история (структурно — `AttemptState`). */
export interface HistoryAttempt {
    id: string;
    status: string;
    failureKind?: string | undefined;
    evidence: {
        id: string;
        runId: string;
        kind: 'test' | 'review';
        phase: 'candidate' | 'integration';
        sha: string;
        passed: boolean;
        findings?: {
            severity: string;
            message: string;
            path?: string | null | undefined;
            line?: number | null | undefined;
            id?: string | undefined;
        }[] | undefined;
        reviewRound?: ReviewRound | undefined;
    }[];
}
/**
 * История находок области по evidence попыток поручения (в порядке записи).
 * Применяются только валидные раунды; невалидные вызовы историю не меняют.
 * Записи alpha.5 без `reviewRound`: находки отклонившего ревью открыты с
 * детерминированно восстановленным ID.
 */
export declare function codeReviewHistory(attempts: HistoryAttempt[], scope: string): CodeReviewHistory;
/** Начатые вызовы reviewer попытки по фазе: записи учёта вызовов (до invoke). */
export interface StartedReviewCalls {
    /** Число начатых вызовов (запись учёта создаётся до внешнего вызова). */
    count: number;
    /** Начало первого из них, epoch ms. */
    firstStartMs?: number;
    /** Время, уже израсходованное этими вызовами (завершёнными и прерванными), мс. */
    spentMs: number;
}
/**
 * Состояние логического ревью (область, фаза, SHA) по записанному состоянию:
 * сколько вызовов reviewer уже начато, когда начался первый и сколько времени
 * израсходовано. Начатый вызов — запись учёта вызова, сделанная до внешнего
 * invoke (`measuredInvoke`): прерванный вызов (controller убит до ответа)
 * засчитывается так же, как завершённый. Логическое ревью продолжается через
 * попытки, прерванные до вердикта (истёкшие, отказ окружения), и закрывается
 * валидным вердиктом или иным завершением попытки (в том числе остановкой
 * `review-protocol`). Записи без учёта вызовов (прежние версии) считаются по
 * невалидным evidence.
 */
export declare function logicalReview(attempts: (HistoryAttempt & {
    candidateSha?: string;
    integrationSha?: string;
})[], scope: string, phase: 'candidate' | 'integration', sha: string, started: (attemptId: string) => StartedReviewCalls): {
    firstStartMs?: number | undefined;
    used: number;
    spentMs: number;
    runs: string[];
};
/** Путь поля ответа в виде `previous[0].id`. */
export declare const issuePath: (path: readonly PropertyKey[]) => string;
export type CodeReviewVerdict = {
    valid: false;
    issues: ProtocolIssue[];
    result?: ReviewResult;
} | {
    valid: true;
    result: ReviewResult;
    round: number;
    transitions: {
        id: string;
        from: FindingStatus;
        to: FindingStatus;
        basis: string;
    }[];
    /** Находки ответа с выданными ID, по порядку ответа. */
    findings: (ReviewResult['findings'][number] & {
        id: string;
    })[];
};
/**
 * Проверка ответа reviewer целиком против истории области — до любой
 * записи. Каждая прежняя открытая находка названа ровно одним переходом;
 * закрытые/снятые — только явным повторным открытием; неизвестный, чужой и
 * повторный ID — ошибка; `approved` при blocking, оставшейся открытой, или при
 * новой blocking — ошибка. Невалидный ответ ничего не меняет.
 */
export declare function checkCodeReview(output: unknown, history: CodeReviewHistory, origin: Omit<FindingOrigin, 'round'>, 
/**
 * Адаптер без протокола переходов: ответ проверяется как в alpha.5 — без
 * прежних открытых находок (их состояние не требуется, ссылки на прежние
 * ID неизвестны). Схема и противоречивый approved — по-прежнему ошибки.
 */
options?: {
    legacy?: boolean;
}): CodeReviewVerdict;
export {};
