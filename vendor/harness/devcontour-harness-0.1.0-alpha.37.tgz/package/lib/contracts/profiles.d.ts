import { z } from 'zod';
/**
 * Профиль стека — переносимый файл, из которого собирается описание
 * репозитория в политике: gates, подготовка, окружение, lifecycle,
 * защищённые пути, роли и инструкции стека. Профиль только описывает:
 * разрешение читает манифесты и не исполняет ни одной команды проекта.
 *
 * Форма файла совпадает с профилями, которые уже закреплены у потребителей
 * (их digest — sha256 байтов файла), поэтому встроенные профили переносятся
 * побайтно.
 */
export declare const PROFILE_FILE_LIMIT = 131072;
export declare const PROFILE_FILES_LIMIT = 32;
export declare const PROFILE_DEPTH_LIMIT = 16;
/** Привязка runtime в профиле: кто пишет или проверяет у роли. */
export declare const profileBindingSchema: z.ZodObject<{
    runtime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
    }>;
    model: z.ZodOptional<z.ZodString>;
    effort: z.ZodOptional<z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
        xhigh: "xhigh";
    }>>;
    toolProfile: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
/** Роль, которую требует поверхность стека. `title` — подпись для людей, harness её не читает. */
export declare const profileRoleSchema: z.ZodObject<{
    runtime: z.ZodEnum<{
        codex: "codex";
        claude: "claude";
    }>;
    model: z.ZodOptional<z.ZodString>;
    effort: z.ZodOptional<z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
        xhigh: "xhigh";
    }>>;
    toolProfile: z.ZodOptional<z.ZodString>;
    writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
    reviewer: z.ZodOptional<z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
        model: z.ZodOptional<z.ZodString>;
        effort: z.ZodOptional<z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
            xhigh: "xhigh";
        }>>;
        toolProfile: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    title: z.ZodOptional<z.ZodString>;
    requiresContract: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
/**
 * Инструкции стека: файлы, которые хост закрепляет как контекст ролей
 * (`files` — вкладываются в запрос, `references` — только называются).
 * Harness их не читает и не копирует: закреплять их — дело ContextSource.
 */
export declare const profileContextPackSchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodString;
    repositoryId: z.ZodOptional<z.ZodString>;
    roles: z.ZodDefault<z.ZodArray<z.ZodString>>;
    files: z.ZodArray<z.ZodString>;
    references: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
/** Gate в профиле: та же форма, что в политике; отсутствие JUnit у test gate называется явно. */
export declare const profileGateSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        check: "check";
        test: "test";
    }>;
    command: z.ZodArray<z.ZodString>;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
    report: z.ZodOptional<z.ZodObject<{
        type: z.ZodLiteral<"junit">;
        path: z.ZodString;
    }, z.core.$strict>>;
    property: z.ZodOptional<z.ZodObject<{
        path: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
    cwd: z.ZodOptional<z.ZodString>;
    resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export declare const stackProfileSchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodString;
    extends: z.ZodDefault<z.ZodArray<z.ZodString>>;
    capabilities: z.ZodDefault<z.ZodArray<z.ZodString>>;
    gates: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            check: "check";
            test: "test";
        }>;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
        report: z.ZodOptional<z.ZodObject<{
            type: z.ZodLiteral<"junit">;
            path: z.ZodString;
        }, z.core.$strict>>;
        property: z.ZodOptional<z.ZodObject<{
            path: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
        cwd: z.ZodOptional<z.ZodString>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>>;
    prepare: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>>;
    environment: z.ZodOptional<z.ZodObject<{
        inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
        values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strict>>;
    lifecycle: z.ZodOptional<z.ZodObject<{
        setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        teardown: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    toolchain: z.ZodOptional<z.ZodObject<{
        tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
            npm: "npm";
            pnpm: "pnpm";
        }>>>;
    }, z.core.$strict>>;
    protectedPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
    generatedPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
    concurrency: z.ZodOptional<z.ZodNumber>;
    runTimeoutMs: z.ZodOptional<z.ZodNumber>;
    roles: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
        model: z.ZodOptional<z.ZodString>;
        effort: z.ZodOptional<z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
            xhigh: "xhigh";
        }>>;
        toolProfile: z.ZodOptional<z.ZodString>;
        writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
        reviewer: z.ZodOptional<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        title: z.ZodOptional<z.ZodString>;
        requiresContract: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>>;
    contextPacks: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        repositoryId: z.ZodOptional<z.ZodString>;
        roles: z.ZodDefault<z.ZodArray<z.ZodString>>;
        files: z.ZodArray<z.ZodString>;
        references: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type StackProfile = z.infer<typeof stackProfileSchema>;
export declare const profileSourceSchema: z.ZodObject<{
    repositoryId: z.ZodString;
    path: z.ZodString;
}, z.core.$strict>;
/** Закрепление профиля: digest — по байтам листа (один файл) или по замыканию слоёв. */
export declare const profilePinSchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodString;
    digest: z.ZodString;
    source: z.ZodOptional<z.ZodObject<{
        repositoryId: z.ZodString;
        path: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ProfilePin = z.infer<typeof profilePinSchema>;
/** Разрешённый профиль: слои сложены, gates упорядочены и проверены. */
export declare const resolvedProfileSchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodString;
    digest: z.ZodString;
    capabilities: z.ZodArray<z.ZodString>;
    gates: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"test">;
        report: z.ZodObject<{
            type: z.ZodLiteral<"junit">;
            path: z.ZodString;
        }, z.core.$strict>;
        artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
        property: z.ZodOptional<z.ZodObject<{
            path: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
        cwd: z.ZodOptional<z.ZodString>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"check">;
        report: z.ZodOptional<z.ZodObject<{
            type: z.ZodLiteral<"junit">;
            path: z.ZodString;
        }, z.core.$strict>>;
        artifacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
        property: z.ZodOptional<z.ZodObject<{
            path: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        dependsOn: z.ZodOptional<z.ZodArray<z.ZodString>>;
        cwd: z.ZodOptional<z.ZodString>;
        resources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>], "kind">>;
    prepare: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        command: z.ZodArray<z.ZodString>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
    environment: z.ZodOptional<z.ZodObject<{
        inherit: z.ZodDefault<z.ZodArray<z.ZodString>>;
        values: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        secrets: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strict>>;
    lifecycle: z.ZodOptional<z.ZodObject<{
        setup: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        ready: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>>;
        teardown: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            command: z.ZodArray<z.ZodString>;
            timeoutMs: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    toolchain: z.ZodOptional<z.ZodObject<{
        tools: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        packageManagers: z.ZodDefault<z.ZodRecord<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>, z.ZodEnum<{
            npm: "npm";
            pnpm: "pnpm";
        }>>>;
    }, z.core.$strict>>;
    protectedPaths: z.ZodArray<z.ZodString>;
    generatedPaths: z.ZodArray<z.ZodString>;
    concurrency: z.ZodOptional<z.ZodNumber>;
    runTimeoutMs: z.ZodOptional<z.ZodNumber>;
    roles: z.ZodRecord<z.ZodString, z.ZodObject<{
        runtime: z.ZodEnum<{
            codex: "codex";
            claude: "claude";
        }>;
        model: z.ZodOptional<z.ZodString>;
        effort: z.ZodOptional<z.ZodEnum<{
            low: "low";
            medium: "medium";
            high: "high";
            xhigh: "xhigh";
        }>>;
        toolProfile: z.ZodOptional<z.ZodString>;
        writePaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
        reviewer: z.ZodOptional<z.ZodObject<{
            runtime: z.ZodEnum<{
                codex: "codex";
                claude: "claude";
            }>;
            model: z.ZodOptional<z.ZodString>;
            effort: z.ZodOptional<z.ZodEnum<{
                low: "low";
                medium: "medium";
                high: "high";
                xhigh: "xhigh";
            }>>;
            toolProfile: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        title: z.ZodOptional<z.ZodString>;
        requiresContract: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    contextPacks: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        repositoryId: z.ZodOptional<z.ZodString>;
        roles: z.ZodDefault<z.ZodArray<z.ZodString>>;
        files: z.ZodArray<z.ZodString>;
        references: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    source: z.ZodOptional<z.ZodObject<{
        repositoryId: z.ZodString;
        path: z.ZodString;
    }, z.core.$strict>>;
    closure: z.ZodArray<z.ZodObject<{
        ref: z.ZodString;
        digest: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ResolvedProfile = z.infer<typeof resolvedProfileSchema>;
/** Профиль с текстом файла листа (`resolveProfile(..., { includeLeafContent: true })`). */
export type ResolvedProfileWithLeaf = ResolvedProfile & {
    leafContent: string;
};
