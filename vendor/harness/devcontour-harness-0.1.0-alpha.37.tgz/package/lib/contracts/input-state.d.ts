import type { InputRequest } from './input.ts';
/**
 * Где вопрос: ждёт ответа (`awaiting-answer`), ответ записан, но не применён
 * (`answered-not-applied`), применён и ждёт выдачи попытки или её первого
 * вызова (`applied-awaiting-claim`), передан исполнителю началом вызова
 * (`delivered`); перенесённый ответ заменённого вопроса устарел до выдачи
 * (`carry-stale`: перенести снова или снять). Закрытые запросы иначе
 * состояния не имеют.
 */
export declare const inputStates: readonly ["awaiting-answer", "answered-not-applied", "applied-awaiting-claim", "delivered", "carry-stale"];
export type InputState = (typeof inputStates)[number];
export type RequestLike = Pick<InputRequest, 'id' | 'kind' | 'lifecycle' | 'delivered' | 'version' | 'effectiveSeverity' | 'createdAt'> & Partial<Pick<InputRequest, 'stale' | 'target'>>;
export declare function inputStateOf(r: Pick<RequestLike, 'lifecycle' | 'delivered' | 'stale' | 'target'>): InputState | undefined;
