import { z } from 'zod';
/**
 * Вопрос исполнителя и продолжение после ответа (H02).
 *
 * Writer, не сумевший закончить без решения человека или ведущего, отдаёт
 * вместе с `completed: false` вопрос (`inputRequest`); более мелкие развилки
 * он решает сам и записывает допущением (`assumptions`). Где проходит
 * граница — задаёт `inputPolicy` политики: порог серьёзности, закреплённый в
 * попытке при выдаче, и критические пути. Самооценку модели controller
 * поднимает до потолка (10), когда вопрос касается критической области
 * (`affects`) или попытка изменила критический путь: модель этих минимумов
 * понизить не может.
 *
 * Канонический запрос (`InputRequest`) хранится в локальном пространстве
 * `input-requests` у владельца-репозитория. Вопрос и основание исходной
 * попытки неизменяемы; ответы только дополняются; применение называет
 * точный digest ответа и проверенное основание продолжения (`target`).
 */
/** Области, вопрос о которых всегда критичен: их меняет только согласование, а не исполнитель. */
export declare const criticalAreas: readonly ["contract", "acceptance", "product", "api", "migration"];
export declare const criticalAreaSchema: z.ZodEnum<{
    acceptance: "acceptance";
    contract: "contract";
    product: "product";
    api: "api";
    migration: "migration";
}>;
export type CriticalArea = (typeof criticalAreas)[number];
/** Пределы вопроса и ответа — как у вопросов подготовки DevContour. */
export declare const INPUT_LIMITS: {
    readonly question: 1500;
    readonly answer: 3000;
    readonly options: 6;
    readonly answers: 20;
    readonly assumptions: 20;
    readonly rationale: 2000;
};
/** Потолок серьёзности; порог 11 — полностью автономный режим (исполнитель не останавливается). */
export declare const INPUT_SEVERITY_MAX = 10;
export declare const INPUT_AUTONOMOUS = 11;
export declare const inputOptionSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodString;
    consequence: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export type InputOption = z.infer<typeof inputOptionSchema>;
/**
 * Вопрос исполнителя: текст, варианты (до шести), рекомендуемый вариант,
 * самооценка серьёзности по шкале запроса (1 — косметика, обратимо, локально;
 * 10 — меняет требования, договор, модель данных, безопасность или все
 * задачи), основание оценки и затронутые критические области.
 */
export declare const inputQuestionSchema: z.ZodObject<{
    question: z.ZodString;
    options: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        consequence: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    recommended: z.ZodNullable<z.ZodString>;
    severity: z.ZodNumber;
    rationale: z.ZodString;
    affects: z.ZodArray<z.ZodEnum<{
        acceptance: "acceptance";
        contract: "contract";
        product: "product";
        api: "api";
        migration: "migration";
    }>>;
}, z.core.$strict>;
export type InputQuestion = z.infer<typeof inputQuestionSchema>;
/** Развилка, которую исполнитель решил сам: вопрос, выбор, основание, самооценка, области. */
export declare const assumptionSchema: z.ZodObject<{
    question: z.ZodString;
    chosen: z.ZodString;
    rationale: z.ZodString;
    severity: z.ZodNumber;
    affects: z.ZodArray<z.ZodEnum<{
        acceptance: "acceptance";
        contract: "contract";
        product: "product";
        api: "api";
        migration: "migration";
    }>>;
}, z.core.$strict>;
export type Assumption = z.infer<typeof assumptionSchema>;
/** Почему серьёзность поднята до потолка: объявленная область или изменённый критический путь. */
export declare const inputFloors: readonly ["declared", "critical-path"];
export declare const inputFloorSchema: z.ZodEnum<{
    declared: "declared";
    "critical-path": "critical-path";
}>;
export type InputFloor = (typeof inputFloors)[number];
/** Допущение попытки с оценкой controller: действующая серьёзность и сработавшие минимумы. */
export declare const recordedAssumptionSchema: z.ZodObject<{
    question: z.ZodString;
    chosen: z.ZodString;
    rationale: z.ZodString;
    severity: z.ZodNumber;
    affects: z.ZodArray<z.ZodEnum<{
        acceptance: "acceptance";
        contract: "contract";
        product: "product";
        api: "api";
        migration: "migration";
    }>>;
    effectiveSeverity: z.ZodNumber;
    floors: z.ZodArray<z.ZodEnum<{
        declared: "declared";
        "critical-path": "critical-path";
    }>>;
}, z.core.$strict>;
export type RecordedAssumption = z.infer<typeof recordedAssumptionSchema>;
/**
 * Политика вопросов исполнителя. `threshold` 1–10: вопрос с действующей
 * серьёзностью не ниже порога останавливает попытку (`needs-input`), ниже —
 * исполнитель решает сам и записывает допущение. 11 — полностью автономный
 * режим: остановок нет, каждое решение — допущение; критические — ещё и
 * неблокирующий запрос ведущему (follow-up), утверждённое не меняется.
 * `criticalPaths` — пути (как `writeScope`: каталог или файл), изменение
 * которых делает вопрос и допущение попытки критическими.
 *
 * Политика закрепляется в попытке при выдаче: новое значение действует со
 * следующей попытки. В `executionDigest` она не входит — смена порога не
 * требует нового согласования графа и не меняет основания reuse.
 */
export declare const inputPolicySchema: z.ZodObject<{
    threshold: z.ZodDefault<z.ZodNumber>;
    criticalPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export type InputPolicy = z.infer<typeof inputPolicySchema>;
export declare const DEFAULT_INPUT_POLICY: InputPolicy;
/** Кто ответил или закрыл запрос: оператор, ведущий агент или хост от их имени. */
export declare const inputActorSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        operator: "operator";
        lead: "lead";
        host: "host";
    }>;
    id: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type InputActor = z.infer<typeof inputActorSchema>;
/**
 * Ответ — неизменяемая запись. `kind`: `clarification` — уточнение той же
 * работы (продолжение через `applyInput`), `requirement-change` — изменение
 * требований (обычная ревизия и `supersede`, не продолжение). `messageRef` —
 * непрозрачная ссылка хоста на сообщение обсуждения. `digest` —
 * `answerDigest(requestId, answer)`.
 */
export declare const inputAnswerSchema: z.ZodObject<{
    revision: z.ZodNumber;
    text: z.ZodString;
    optionId: z.ZodNullable<z.ZodString>;
    kind: z.ZodEnum<{
        clarification: "clarification";
        "requirement-change": "requirement-change";
    }>;
    actor: z.ZodObject<{
        kind: z.ZodEnum<{
            operator: "operator";
            lead: "lead";
            host: "host";
        }>;
        id: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    messageRef: z.ZodOptional<z.ZodString>;
    digest: z.ZodString;
    at: z.ZodISODateTime;
}, z.core.$strict>;
export type InputAnswer = z.infer<typeof inputAnswerSchema>;
/** Digest ответа: запрос, номер версии и содержание (без времени). */
export declare const answerDigest: (requestId: string, answer: Pick<InputAnswer, "revision" | "text" | "optionId" | "kind">) => string;
/**
 * Основание исходной попытки: откуда вопрос. Неизменяемо. `inputPolicy` —
 * закреплённая в попытке политика, по которой вопрос стал остановкой.
 */
export declare const inputOriginSchema: z.ZodObject<{
    source: z.ZodObject<{
        connector: z.ZodString;
        ref: z.ZodString;
        revision: z.ZodString;
    }, z.core.$strict>;
    graphId: z.ZodString;
    graphDigest: z.ZodString;
    orderDigest: z.ZodString;
    policyDigest: z.ZodString;
    contextDigest: z.ZodNullable<z.ZodString>;
    baseSha: z.ZodNullable<z.ZodString>;
    inputPolicy: z.ZodObject<{
        threshold: z.ZodDefault<z.ZodNumber>;
        criticalPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>;
    contentDigest: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type InputOrigin = z.infer<typeof inputOriginSchema>;
/**
 * Основание продолжения, которое активирует `applyInput`: тот же граф и
 * постановка, проверенный снимок контекста с ответом, раунд ревью плана и
 * актёр согласования. `digest` — `targetDigest(target)`.
 */
export declare const inputTargetSchema: z.ZodObject<{
    originDigest: z.ZodString;
    answerDigest: z.ZodString;
    graphDigest: z.ZodString;
    orderDigest: z.ZodString;
    contentDigest: z.ZodOptional<z.ZodString>;
    policyDigest: z.ZodString;
    contextDigest: z.ZodNullable<z.ZodString>;
    review: z.ZodNullable<z.ZodObject<{
        round: z.ZodNumber;
        approved: z.ZodBoolean;
        reviewerBinding: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    actor: z.ZodEnum<{
        operator: "operator";
        agent: "agent";
    }>;
    digest: z.ZodString;
}, z.core.$strict>;
export type InputTarget = z.infer<typeof inputTargetSchema>;
export declare const targetDigest: (target: Omit<InputTarget, "digest">) => string;
export declare const inputLifecycles: readonly ["pending", "answered", "applied", "cancelled", "superseded"];
export type InputLifecycle = (typeof inputLifecycles)[number];
/**
 * Состояние вопроса для проекций (`projections/input.ts` повторяет перечень
 * без zod; тест сверяет оба): ждёт ответа, ответ не применён, применён и ждёт
 * вызова, передан исполнителю.
 */
export declare const inputStateNames: readonly ["awaiting-answer", "answered-not-applied", "applied-awaiting-claim", "delivered", "carry-stale"];
/**
 * Канонический запрос. `kind`: `question` — остановка попытки (блокирует
 * claim, retry, repair и finish, пока `pending` или `answered`);
 * `follow-up` — неблокирующий запрос ведущему из автономного режима или
 * отклонённого вопроса ниже порога. `blocking` — блокирует ли запрос
 * работу. `draft` — черновик попытки (digest и файлы `AttemptState.partial`).
 * `version` — CAS записи.
 */
export declare const inputRequestSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        question: "question";
        "follow-up": "follow-up";
    }>;
    blocking: z.ZodBoolean;
    workId: z.ZodString;
    graphId: z.ZodString;
    runId: z.ZodString;
    attempt: z.ZodNumber;
    callId: z.ZodNullable<z.ZodString>;
    question: z.ZodObject<{
        question: z.ZodString;
        options: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            consequence: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
        recommended: z.ZodNullable<z.ZodString>;
        severity: z.ZodNumber;
        rationale: z.ZodString;
        affects: z.ZodArray<z.ZodEnum<{
            acceptance: "acceptance";
            contract: "contract";
            product: "product";
            api: "api";
            migration: "migration";
        }>>;
    }, z.core.$strict>;
    effectiveSeverity: z.ZodNumber;
    floors: z.ZodArray<z.ZodEnum<{
        declared: "declared";
        "critical-path": "critical-path";
    }>>;
    criticalHits: z.ZodArray<z.ZodString>;
    draft: z.ZodNullable<z.ZodObject<{
        digest: z.ZodString;
        files: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    createdAt: z.ZodISODateTime;
    originBasis: z.ZodObject<{
        source: z.ZodObject<{
            connector: z.ZodString;
            ref: z.ZodString;
            revision: z.ZodString;
        }, z.core.$strict>;
        graphId: z.ZodString;
        graphDigest: z.ZodString;
        orderDigest: z.ZodString;
        policyDigest: z.ZodString;
        contextDigest: z.ZodNullable<z.ZodString>;
        baseSha: z.ZodNullable<z.ZodString>;
        inputPolicy: z.ZodObject<{
            threshold: z.ZodDefault<z.ZodNumber>;
            criticalPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>;
        contentDigest: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    lifecycle: z.ZodEnum<{
        pending: "pending";
        answered: "answered";
        applied: "applied";
        cancelled: "cancelled";
        superseded: "superseded";
    }>;
    answers: z.ZodArray<z.ZodObject<{
        revision: z.ZodNumber;
        text: z.ZodString;
        optionId: z.ZodNullable<z.ZodString>;
        kind: z.ZodEnum<{
            clarification: "clarification";
            "requirement-change": "requirement-change";
        }>;
        actor: z.ZodObject<{
            kind: z.ZodEnum<{
                operator: "operator";
                lead: "lead";
                host: "host";
            }>;
            id: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        messageRef: z.ZodOptional<z.ZodString>;
        digest: z.ZodString;
        at: z.ZodISODateTime;
    }, z.core.$strict>>;
    target: z.ZodOptional<z.ZodObject<{
        originDigest: z.ZodString;
        answerDigest: z.ZodString;
        graphDigest: z.ZodString;
        orderDigest: z.ZodString;
        contentDigest: z.ZodOptional<z.ZodString>;
        policyDigest: z.ZodString;
        contextDigest: z.ZodNullable<z.ZodString>;
        review: z.ZodNullable<z.ZodObject<{
            round: z.ZodNumber;
            approved: z.ZodBoolean;
            reviewerBinding: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
        actor: z.ZodEnum<{
            operator: "operator";
            agent: "agent";
        }>;
        digest: z.ZodString;
    }, z.core.$strict>>;
    delivered: z.ZodOptional<z.ZodObject<{
        runId: z.ZodString;
        callId: z.ZodString;
        at: z.ZodISODateTime;
    }, z.core.$strict>>;
    closed: z.ZodOptional<z.ZodObject<{
        at: z.ZodISODateTime;
        by: z.ZodEnum<{
            operator: "operator";
            lead: "lead";
            host: "host";
            controller: "controller";
        }>;
        reason: z.ZodString;
        successor: z.ZodOptional<z.ZodString>;
        carry: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    stale: z.ZodOptional<z.ZodObject<{
        targetDigest: z.ZodString;
        reason: z.ZodEnum<{
            context: "context";
            graph: "graph";
            order: "order";
            policy: "policy";
        }>;
        at: z.ZodISODateTime;
    }, z.core.$strict>>;
    normalized: z.ZodOptional<z.ZodArray<z.ZodString>>;
    version: z.ZodNumber;
}, z.core.$strict>;
export type InputRequest = z.infer<typeof inputRequestSchema>;
/** Вопрос или допущение с оценкой controller. */
export interface RatedInput {
    question: InputQuestion;
    effectiveSeverity: number;
    floors: InputFloor[];
}
/**
 * Что ответ writer оставил движку вместе с исходом попытки: вопрос
 * (`question` — остановка `needs-input`, `declined` — вопрос ниже порога у
 * незавершённой попытки), допущения с оценкой, неблокирующие запросы ведущему
 * (автономный режим), изменённые критические пути и вызов, в ответе которого
 * всё это пришло. Только память процесса: сохраняется движком в
 * `input-requests` и `AttemptState.assumptions`.
 */
export interface InputOutcome {
    question?: RatedInput & {
        mode: 'request' | 'declined';
    };
    assumptions: RecordedAssumption[];
    followUps: RatedInput[];
    criticalHits: string[];
    callId: string | null;
    /** Ответ был вне схемы: что controller исправил, чтобы не потерять вопрос. */
    normalized?: string[];
}
/** Запрос держит работу: вопрос, ещё не применённый и не закрытый. */
export declare const blocksWork: (r: Pick<InputRequest, "blocking" | "lifecycle"> & Partial<Pick<InputRequest, "stale" | "target">>) => boolean;
/** Ответ запроса связан с основанием выдачи: применённый или перенесённый. */
export declare const linksAnswer: (r: Pick<InputRequest, "kind" | "lifecycle" | "target">) => boolean;
/** Последний ответ запроса. */
export declare const latestAnswer: (r: Pick<InputRequest, "answers">) => {
    revision: number;
    text: string;
    optionId: string | null;
    kind: "clarification" | "requirement-change";
    actor: {
        kind: "operator" | "lead" | "host";
        id?: string | undefined;
    };
    digest: string;
    at: string;
    messageRef?: string | undefined;
} | undefined;
/** ID запроса: детерминированный от попытки и порядкового номера внутри неё. */
export declare const inputRequestId: (runId: string, index: number) => string;
/** Вид источника контекста с ответом на запрос. */
export declare const INPUT_SOURCE_KIND = "input-answer";
/** ID источника контекста ответа на запрос `requestId`. */
export declare const inputSourceId: (requestId: string) => string;
/**
 * Manifest источника ответа: какой запрос, какой точно ответ (digest и
 * версия) и какие сообщения обсуждения хоста (ID, версия, digest) включены.
 */
export declare const inputManifestSchema: z.ZodObject<{
    requestId: z.ZodString;
    answerDigest: z.ZodString;
    revision: z.ZodNumber;
    messages: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
        digest: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type InputManifest = z.infer<typeof inputManifestSchema>;
