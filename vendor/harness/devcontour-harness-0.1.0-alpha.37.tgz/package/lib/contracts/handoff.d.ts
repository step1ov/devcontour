import { z } from 'zod';
/**
 * Пакет передачи контекста (`harness handoff`, `handoffPack`): состояние доски
 * для следующей сессии ведущего агента, собранное из хранилища, а не из
 * памяти агента. Факты — только из сохранённого состояния; свободный текст
 * агента — только `intentions`.
 *
 * Пакет ограничен по размеру, чтобы поместиться в контекст агента: списки
 * обрезаются по `HANDOFF_LIMITS` (число отброшенного — в `truncated`), каждая
 * строка из хранилища очищается от escape-последовательностей и управляющих
 * символов и усекается до предела своего поля с «…» (без разрыва суррогатной
 * пары), а сериализованный пакет не больше `HANDOFF_MAX_BYTES` байт UTF-8:
 * сверх него записи отбрасываются (`truncated.bySize`).
 *
 * Литералы `nextSteps` повторяют `src/projections/next.ts` (модуль без zod);
 * тест сверяет оба перечня поэлементно.
 */
export declare const HANDOFF_VERSION = 1;
export declare const HANDOFF_LIMITS: {
    /** Открытые поручения (не принятые и не отменённые). */
    readonly works: 50;
    /** Остановки и решения (`explain`), после свёртки одинаковых. */
    readonly stops: 30;
    /** Ссылки evidence одной остановки. */
    readonly evidence: 5;
    /** Поручения, перечисленные у свёрнутой остановки. */
    readonly stopWorks: 20;
    /** Последние провалы попыток, новые первыми. */
    readonly failures: 10;
    /** Незавершённые записи попыток. */
    readonly unfinished: 20;
    /** Блокировки одного поручения. */
    readonly blockers: 3;
    /** Строки бюджетов (общий и групп — первыми). */
    readonly budgets: 20;
    /** Задания графов с восстановлениями. */
    readonly repairs: 10;
    /** Намерения агента и знаков в каждом. */
    readonly intentions: 20;
    readonly intentionChars: 1000;
    /** Вопросы исполнителя (открытые запросы), вопросы первыми. */
    readonly inputs: 10;
    /** Знаков ответа в пакете (`answer.excerpt`). */
    readonly answerChars: 500;
    /** Предел строки факта из хранилища. */
    readonly text: 300;
    /** Предел идентификатора, имени стадии, владельца из хранилища. */
    readonly name: 200;
};
/** Предел сериализованного пакета (JSON, UTF-8). */
export declare const HANDOFF_MAX_BYTES: number;
/**
 * Наименьший предел, который хост может задать пакету (`maxBytes` у
 * `handoffPack`): ниже него не помещается даже обычный минимальный пакет.
 * Это не гарантия: записи, которые не отбрасываются (сводка, очередь, идущие
 * попытки, задания, следующий шаг), могут не уложиться и в больший предел.
 */
export declare const HANDOFF_MIN_BYTES: number;
export declare const handoffNextSteps: readonly ["accepted", "cancelled", "recovery-awaiting-lead", "recovery-analyzing", "recovery-applying", "recovery-retry-allowed", "recovery-retrying", "recovery-awaiting-user", "recovery-stopped", "corpus-adoption", "held", "plan-review", "attempt-running", "retry-within-budget", "attempts-exhausted", "awaiting-claim"];
/** Команда harness, которая выполняет следующий шаг, когда он — запуск команды. */
export declare const handoffCommands: readonly ["harness run", "harness resume"];
export declare const handoffPackSchema: z.ZodObject<{
    handoffVersion: z.ZodLiteral<1>;
    at: z.ZodISODateTime;
    graphId: z.ZodOptional<z.ZodString>;
    limits: z.ZodObject<{
        maxAttempts: z.ZodNumber;
        repairBudget: z.ZodNumber;
    }, z.core.$strict>;
    summary: z.ZodObject<{
        works: z.ZodNumber;
        open: z.ZodNumber;
        done: z.ZodNumber;
        cancelled: z.ZodNumber;
        byStatus: z.ZodArray<z.ZodObject<{
            status: z.ZodEnum<{
                cancelled: "cancelled";
                draft: "draft";
                ready: "ready";
                failed: "failed";
                running: "running";
                verifying: "verifying";
                reviewing: "reviewing";
                integrating: "integrating";
                done: "done";
            }>;
            count: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    queue: z.ZodObject<{
        paused: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodEnum<{
            operator: "operator";
            runtime: "runtime";
            shutdown: "shutdown";
            "base-check": "base-check";
            reconfigure: "reconfigure";
        }>>;
        detail: z.ZodOptional<z.ZodString>;
        since: z.ZodOptional<z.ZodISODateTime>;
        operation: z.ZodOptional<z.ZodString>;
        failures: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "context-exhausted": "context-exhausted";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
            "needs-input": "needs-input";
        }>>>;
        liftedByRun: z.ZodOptional<z.ZodLiteral<true>>;
        code: z.ZodOptional<z.ZodEnum<{
            INVALID_INPUT: "INVALID_INPUT";
            UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
            UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
            GRAPH_CYCLE: "GRAPH_CYCLE";
            GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
            GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
            GATE_UNKNOWN: "GATE_UNKNOWN";
            GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
            REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
            REVIEWER_MISSING: "REVIEWER_MISSING";
            RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
            APPROVAL_STALE: "APPROVAL_STALE";
            APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
            LEASE_STALE: "LEASE_STALE";
            CONTROLLER_BUSY: "CONTROLLER_BUSY";
            PAUSED: "PAUSED";
            NOT_READY: "NOT_READY";
            SCOPE_VIOLATION: "SCOPE_VIOLATION";
            GATE_FAILED: "GATE_FAILED";
            REVIEW_REJECTED: "REVIEW_REJECTED";
            BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
            BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
            ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
            CONTEXT_EXHAUSTED: "CONTEXT_EXHAUSTED";
            INPUT_REQUIRED: "INPUT_REQUIRED";
            REVISION_CONFLICT: "REVISION_CONFLICT";
            CANCELLED: "CANCELLED";
            NOT_FOUND: "NOT_FOUND";
            PATH_CONFLICT: "PATH_CONFLICT";
            STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
            RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
            REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
            SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
            GIT_FAILED: "GIT_FAILED";
            STORAGE_FAILED: "STORAGE_FAILED";
            DELIVERY_FAILED: "DELIVERY_FAILED";
            INTERNAL: "INTERNAL";
        }>>;
        actor: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            lead: "lead";
            controller: "controller";
            user: "user";
        }>>>;
        action: z.ZodOptional<z.ZodEnum<{
            none: "none";
            wait: "wait";
            retry: "retry";
            "review-plan": "review-plan";
            "diagnose-failure": "diagnose-failure";
            "reset-attempts": "reset-attempts";
            "raise-budget": "raise-budget";
            "replan-dependents": "replan-dependents";
            "recovery-decision": "recovery-decision";
            "user-decision": "user-decision";
            "resume-queue": "resume-queue";
            "fix-environment": "fix-environment";
            "fix-access": "fix-access";
            "answer-input": "answer-input";
            "apply-input": "apply-input";
        }>>;
    }, z.core.$strict>;
    controller: z.ZodOptional<z.ZodObject<{
        owner: z.ZodString;
        until: z.ZodISODateTime;
        live: z.ZodBoolean;
    }, z.core.$strict>>;
    active: z.ZodArray<z.ZodObject<{
        workId: z.ZodString;
        title: z.ZodString;
        runId: z.ZodString;
        attempt: z.ZodNumber;
        phase: z.ZodEnum<{
            cancelled: "cancelled";
            draft: "draft";
            ready: "ready";
            failed: "failed";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        runtime: z.ZodString;
        elapsedMs: z.ZodNumber;
        stage: z.ZodOptional<z.ZodObject<{
            name: z.ZodString;
            elapsedMs: z.ZodNumber;
        }, z.core.$strict>>;
        sinceHeartbeatMs: z.ZodOptional<z.ZodNumber>;
        leaseUntil: z.ZodISODateTime;
        stale: z.ZodBoolean;
        gates: z.ZodObject<{
            phase: z.ZodEnum<{
                candidate: "candidate";
                integration: "integration";
            }>;
            required: z.ZodNumber;
            passed: z.ZodNumber;
            failed: z.ZodNumber;
            remaining: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    unfinished: z.ZodArray<z.ZodObject<{
        runId: z.ZodString;
        workId: z.ZodString;
        attempt: z.ZodNumber;
        phase: z.ZodEnum<{
            cancelled: "cancelled";
            draft: "draft";
            ready: "ready";
            failed: "failed";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        startedAt: z.ZodISODateTime;
        stale: z.ZodBoolean;
        current: z.ZodBoolean;
        interrupted: z.ZodOptional<z.ZodLiteral<"shutdown">>;
    }, z.core.$strict>>;
    works: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        graphId: z.ZodString;
        title: z.ZodString;
        status: z.ZodEnum<{
            cancelled: "cancelled";
            draft: "draft";
            ready: "ready";
            failed: "failed";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        attempt: z.ZodNumber;
        failureKind: z.ZodOptional<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "context-exhausted": "context-exhausted";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
            "needs-input": "needs-input";
        }>>;
        failure: z.ZodOptional<z.ZodString>;
        hold: z.ZodOptional<z.ZodObject<{
            operation: z.ZodString;
            reason: z.ZodString;
        }, z.core.$strict>>;
        recovery: z.ZodOptional<z.ZodObject<{
            status: z.ZodString;
            property: z.ZodString;
            reason: z.ZodOptional<z.ZodString>;
            proposal: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        blockers: z.ZodArray<z.ZodObject<{
            code: z.ZodEnum<{
                INVALID_INPUT: "INVALID_INPUT";
                UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
                UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
                GRAPH_CYCLE: "GRAPH_CYCLE";
                GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
                GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
                GATE_UNKNOWN: "GATE_UNKNOWN";
                GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
                REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
                REVIEWER_MISSING: "REVIEWER_MISSING";
                RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
                APPROVAL_STALE: "APPROVAL_STALE";
                APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
                LEASE_STALE: "LEASE_STALE";
                CONTROLLER_BUSY: "CONTROLLER_BUSY";
                PAUSED: "PAUSED";
                NOT_READY: "NOT_READY";
                SCOPE_VIOLATION: "SCOPE_VIOLATION";
                GATE_FAILED: "GATE_FAILED";
                REVIEW_REJECTED: "REVIEW_REJECTED";
                BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
                BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
                ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
                CONTEXT_EXHAUSTED: "CONTEXT_EXHAUSTED";
                INPUT_REQUIRED: "INPUT_REQUIRED";
                REVISION_CONFLICT: "REVISION_CONFLICT";
                CANCELLED: "CANCELLED";
                NOT_FOUND: "NOT_FOUND";
                PATH_CONFLICT: "PATH_CONFLICT";
                STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
                RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
                REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
                SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
                GIT_FAILED: "GIT_FAILED";
                STORAGE_FAILED: "STORAGE_FAILED";
                DELIVERY_FAILED: "DELIVERY_FAILED";
                INTERNAL: "INTERNAL";
            }>;
            message: z.ZodString;
        }, z.core.$strict>>;
        blockersTruncated: z.ZodOptional<z.ZodNumber>;
        next: z.ZodObject<{
            actor: z.ZodNullable<z.ZodEnum<{
                lead: "lead";
                controller: "controller";
                user: "user";
            }>>;
            action: z.ZodEnum<{
                none: "none";
                wait: "wait";
                retry: "retry";
                "review-plan": "review-plan";
                "diagnose-failure": "diagnose-failure";
                "reset-attempts": "reset-attempts";
                "raise-budget": "raise-budget";
                "replan-dependents": "replan-dependents";
                "recovery-decision": "recovery-decision";
                "user-decision": "user-decision";
                "resume-queue": "resume-queue";
                "fix-environment": "fix-environment";
                "fix-access": "fix-access";
                "answer-input": "answer-input";
                "apply-input": "apply-input";
            }>;
            step: z.ZodOptional<z.ZodEnum<{
                cancelled: "cancelled";
                accepted: "accepted";
                "recovery-awaiting-lead": "recovery-awaiting-lead";
                "recovery-analyzing": "recovery-analyzing";
                "recovery-applying": "recovery-applying";
                "recovery-retry-allowed": "recovery-retry-allowed";
                "recovery-retrying": "recovery-retrying";
                "recovery-awaiting-user": "recovery-awaiting-user";
                "recovery-stopped": "recovery-stopped";
                "corpus-adoption": "corpus-adoption";
                held: "held";
                "plan-review": "plan-review";
                "attempt-running": "attempt-running";
                "retry-within-budget": "retry-within-budget";
                "attempts-exhausted": "attempts-exhausted";
                "awaiting-claim": "awaiting-claim";
            }>>;
            property: z.ZodOptional<z.ZodString>;
            detail: z.ZodOptional<z.ZodString>;
            command: z.ZodOptional<z.ZodEnum<{
                "harness run": "harness run";
                "harness resume": "harness resume";
            }>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    stops: z.ZodArray<z.ZodObject<{
        code: z.ZodEnum<{
            INVALID_INPUT: "INVALID_INPUT";
            UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
            UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
            GRAPH_CYCLE: "GRAPH_CYCLE";
            GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
            GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
            GATE_UNKNOWN: "GATE_UNKNOWN";
            GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
            REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
            REVIEWER_MISSING: "REVIEWER_MISSING";
            RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
            APPROVAL_STALE: "APPROVAL_STALE";
            APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
            LEASE_STALE: "LEASE_STALE";
            CONTROLLER_BUSY: "CONTROLLER_BUSY";
            PAUSED: "PAUSED";
            NOT_READY: "NOT_READY";
            SCOPE_VIOLATION: "SCOPE_VIOLATION";
            GATE_FAILED: "GATE_FAILED";
            REVIEW_REJECTED: "REVIEW_REJECTED";
            BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
            BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
            ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
            CONTEXT_EXHAUSTED: "CONTEXT_EXHAUSTED";
            INPUT_REQUIRED: "INPUT_REQUIRED";
            REVISION_CONFLICT: "REVISION_CONFLICT";
            CANCELLED: "CANCELLED";
            NOT_FOUND: "NOT_FOUND";
            PATH_CONFLICT: "PATH_CONFLICT";
            STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
            RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
            REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
            SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
            GIT_FAILED: "GIT_FAILED";
            STORAGE_FAILED: "STORAGE_FAILED";
            DELIVERY_FAILED: "DELIVERY_FAILED";
            INTERNAL: "INTERNAL";
        }>;
        cause: z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "context-exhausted": "context-exhausted";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
            "needs-input": "needs-input";
            "runtime-missing": "runtime-missing";
            "controller-busy": "controller-busy";
            "operator-pause": "operator-pause";
            "approval-required": "approval-required";
            "not-ready": "not-ready";
        }>;
        phase: z.ZodEnum<{
            gates: "gates";
            review: "review";
            preflight: "preflight";
            integration: "integration";
            delivery: "delivery";
            claim: "claim";
            implementation: "implementation";
        }>;
        actor: z.ZodNullable<z.ZodEnum<{
            lead: "lead";
            controller: "controller";
            user: "user";
        }>>;
        action: z.ZodEnum<{
            none: "none";
            wait: "wait";
            retry: "retry";
            "review-plan": "review-plan";
            "diagnose-failure": "diagnose-failure";
            "reset-attempts": "reset-attempts";
            "raise-budget": "raise-budget";
            "replan-dependents": "replan-dependents";
            "recovery-decision": "recovery-decision";
            "user-decision": "user-decision";
            "resume-queue": "resume-queue";
            "fix-environment": "fix-environment";
            "fix-access": "fix-access";
            "answer-input": "answer-input";
            "apply-input": "apply-input";
        }>;
        retryPlanned: z.ZodBoolean;
        message: z.ZodString;
        evidence: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                attempt: "attempt";
                evidence: "evidence";
                event: "event";
                doctor: "doctor";
            }>;
            id: z.ZodString;
            sha: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        workId: z.ZodOptional<z.ZodString>;
        runId: z.ZodOptional<z.ZodString>;
        queue: z.ZodOptional<z.ZodLiteral<true>>;
        works: z.ZodOptional<z.ZodArray<z.ZodString>>;
        worksCount: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    failures: z.ZodArray<z.ZodObject<{
        runId: z.ZodString;
        workId: z.ZodString;
        workStatus: z.ZodOptional<z.ZodEnum<{
            cancelled: "cancelled";
            draft: "draft";
            ready: "ready";
            failed: "failed";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>>;
        attempt: z.ZodNumber;
        status: z.ZodEnum<{
            failed: "failed";
            expired: "expired";
        }>;
        phase: z.ZodEnum<{
            cancelled: "cancelled";
            draft: "draft";
            ready: "ready";
            failed: "failed";
            running: "running";
            verifying: "verifying";
            reviewing: "reviewing";
            integrating: "integrating";
            done: "done";
        }>;
        finishedAt: z.ZodOptional<z.ZodISODateTime>;
        failureKind: z.ZodOptional<z.ZodEnum<{
            gate: "gate";
            unknown: "unknown";
            review: "review";
            cancelled: "cancelled";
            environment: "environment";
            timeout: "timeout";
            "provider-auth": "provider-auth";
            stalled: "stalled";
            "context-exhausted": "context-exhausted";
            "stale-base": "stale-base";
            "empty-result": "empty-result";
            unfinished: "unfinished";
            "scope-violation": "scope-violation";
            "review-protocol": "review-protocol";
            merge: "merge";
            budget: "budget";
            "needs-lead": "needs-lead";
            "needs-input": "needs-input";
        }>>;
        code: z.ZodEnum<{
            INVALID_INPUT: "INVALID_INPUT";
            UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
            UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
            GRAPH_CYCLE: "GRAPH_CYCLE";
            GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
            GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
            GATE_UNKNOWN: "GATE_UNKNOWN";
            GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
            REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
            REVIEWER_MISSING: "REVIEWER_MISSING";
            RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
            APPROVAL_STALE: "APPROVAL_STALE";
            APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
            LEASE_STALE: "LEASE_STALE";
            CONTROLLER_BUSY: "CONTROLLER_BUSY";
            PAUSED: "PAUSED";
            NOT_READY: "NOT_READY";
            SCOPE_VIOLATION: "SCOPE_VIOLATION";
            GATE_FAILED: "GATE_FAILED";
            REVIEW_REJECTED: "REVIEW_REJECTED";
            BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
            BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
            ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
            CONTEXT_EXHAUSTED: "CONTEXT_EXHAUSTED";
            INPUT_REQUIRED: "INPUT_REQUIRED";
            REVISION_CONFLICT: "REVISION_CONFLICT";
            CANCELLED: "CANCELLED";
            NOT_FOUND: "NOT_FOUND";
            PATH_CONFLICT: "PATH_CONFLICT";
            STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
            RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
            REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
            SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
            GIT_FAILED: "GIT_FAILED";
            STORAGE_FAILED: "STORAGE_FAILED";
            DELIVERY_FAILED: "DELIVERY_FAILED";
            INTERNAL: "INTERNAL";
        }>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    budgets: z.ZodOptional<z.ZodObject<{
        onUnknown: z.ZodEnum<{
            continue: "continue";
            stop: "stop";
        }>;
        entries: z.ZodArray<z.ZodObject<{
            scope: z.ZodEnum<{
                work: "work";
                group: "group";
                total: "total";
            }>;
            id: z.ZodOptional<z.ZodString>;
            state: z.ZodEnum<{
                exceeded: "exceeded";
                undetermined: "undetermined";
                within: "within";
            }>;
            limitUsd: z.ZodOptional<z.ZodNumber>;
            limitMs: z.ZodOptional<z.ZodNumber>;
            reportedUsd: z.ZodNumber;
            estimatedUsd: z.ZodNumber;
            complete: z.ZodBoolean;
            unknownCalls: z.ZodNumber;
            unfinishedCalls: z.ZodNumber;
            abandonedCalls: z.ZodNumber;
            uncoveredRuns: z.ZodNumber;
            durationMs: z.ZodNumber;
            remainingUsd: z.ZodNullable<z.ZodNumber>;
            remainingMs: z.ZodNullable<z.ZodNumber>;
            reason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    repairs: z.ZodArray<z.ZodObject<{
        graphId: z.ZodString;
        status: z.ZodString;
        used: z.ZodNumber;
        budget: z.ZodNumber;
    }, z.core.$strict>>;
    inputs: z.ZodOptional<z.ZodArray<z.ZodObject<{
        requestId: z.ZodString;
        workId: z.ZodString;
        kind: z.ZodEnum<{
            question: "question";
            "follow-up": "follow-up";
        }>;
        state: z.ZodEnum<{
            "awaiting-answer": "awaiting-answer";
            "answered-not-applied": "answered-not-applied";
            "applied-awaiting-claim": "applied-awaiting-claim";
            "carry-stale": "carry-stale";
        }>;
        severity: z.ZodNumber;
        question: z.ZodString;
        options: z.ZodArray<z.ZodString>;
        answer: z.ZodOptional<z.ZodObject<{
            revision: z.ZodNumber;
            digest: z.ZodString;
            excerpt: z.ZodString;
        }, z.core.$strict>>;
        origin: z.ZodObject<{
            graphDigest: z.ZodString;
            orderDigest: z.ZodString;
            contextDigest: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        targetDigest: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    next: z.ZodObject<{
        actor: z.ZodNullable<z.ZodEnum<{
            lead: "lead";
            controller: "controller";
            user: "user";
        }>>;
        action: z.ZodEnum<{
            none: "none";
            wait: "wait";
            retry: "retry";
            "review-plan": "review-plan";
            "diagnose-failure": "diagnose-failure";
            "reset-attempts": "reset-attempts";
            "raise-budget": "raise-budget";
            "replan-dependents": "replan-dependents";
            "recovery-decision": "recovery-decision";
            "user-decision": "user-decision";
            "resume-queue": "resume-queue";
            "fix-environment": "fix-environment";
            "fix-access": "fix-access";
            "answer-input": "answer-input";
            "apply-input": "apply-input";
        }>;
        step: z.ZodOptional<z.ZodEnum<{
            cancelled: "cancelled";
            accepted: "accepted";
            "recovery-awaiting-lead": "recovery-awaiting-lead";
            "recovery-analyzing": "recovery-analyzing";
            "recovery-applying": "recovery-applying";
            "recovery-retry-allowed": "recovery-retry-allowed";
            "recovery-retrying": "recovery-retrying";
            "recovery-awaiting-user": "recovery-awaiting-user";
            "recovery-stopped": "recovery-stopped";
            "corpus-adoption": "corpus-adoption";
            held: "held";
            "plan-review": "plan-review";
            "attempt-running": "attempt-running";
            "retry-within-budget": "retry-within-budget";
            "attempts-exhausted": "attempts-exhausted";
            "awaiting-claim": "awaiting-claim";
        }>>;
        property: z.ZodOptional<z.ZodString>;
        detail: z.ZodOptional<z.ZodString>;
        command: z.ZodOptional<z.ZodEnum<{
            "harness run": "harness run";
            "harness resume": "harness resume";
        }>>;
        workId: z.ZodOptional<z.ZodString>;
        code: z.ZodOptional<z.ZodEnum<{
            INVALID_INPUT: "INVALID_INPUT";
            UNSUPPORTED_COMMAND: "UNSUPPORTED_COMMAND";
            UNSUPPORTED_VERSION: "UNSUPPORTED_VERSION";
            GRAPH_CYCLE: "GRAPH_CYCLE";
            GRAPH_UNKNOWN_DEPENDENCY: "GRAPH_UNKNOWN_DEPENDENCY";
            GRAPH_DUPLICATE_ID: "GRAPH_DUPLICATE_ID";
            GATE_UNKNOWN: "GATE_UNKNOWN";
            GATE_GROUP_CYCLE: "GATE_GROUP_CYCLE";
            REVIEWER_SAME_VENDOR: "REVIEWER_SAME_VENDOR";
            REVIEWER_MISSING: "REVIEWER_MISSING";
            RESPONSE_TOO_LARGE: "RESPONSE_TOO_LARGE";
            APPROVAL_STALE: "APPROVAL_STALE";
            APPROVAL_REQUIRED: "APPROVAL_REQUIRED";
            LEASE_STALE: "LEASE_STALE";
            CONTROLLER_BUSY: "CONTROLLER_BUSY";
            PAUSED: "PAUSED";
            NOT_READY: "NOT_READY";
            SCOPE_VIOLATION: "SCOPE_VIOLATION";
            GATE_FAILED: "GATE_FAILED";
            REVIEW_REJECTED: "REVIEW_REJECTED";
            BUDGET_EXHAUSTED: "BUDGET_EXHAUSTED";
            BUDGET_UNKNOWN: "BUDGET_UNKNOWN";
            ATTEMPTS_EXHAUSTED: "ATTEMPTS_EXHAUSTED";
            CONTEXT_EXHAUSTED: "CONTEXT_EXHAUSTED";
            INPUT_REQUIRED: "INPUT_REQUIRED";
            REVISION_CONFLICT: "REVISION_CONFLICT";
            CANCELLED: "CANCELLED";
            NOT_FOUND: "NOT_FOUND";
            PATH_CONFLICT: "PATH_CONFLICT";
            STATE_VERSION_UNSUPPORTED: "STATE_VERSION_UNSUPPORTED";
            RUNTIME_UNAVAILABLE: "RUNTIME_UNAVAILABLE";
            REVIEW_PROTOCOL_INVALID: "REVIEW_PROTOCOL_INVALID";
            SANDBOX_UNAVAILABLE: "SANDBOX_UNAVAILABLE";
            GIT_FAILED: "GIT_FAILED";
            STORAGE_FAILED: "STORAGE_FAILED";
            DELIVERY_FAILED: "DELIVERY_FAILED";
            INTERNAL: "INTERNAL";
        }>>;
    }, z.core.$strict>;
    intentions: z.ZodArray<z.ZodString>;
    truncated: z.ZodObject<{
        works: z.ZodNumber;
        stops: z.ZodNumber;
        failures: z.ZodNumber;
        unfinished: z.ZodNumber;
        budgets: z.ZodNumber;
        budgetsWithin: z.ZodNumber;
        budgetsShared: z.ZodDefault<z.ZodNumber>;
        repairs: z.ZodNumber;
        inputs: z.ZodDefault<z.ZodNumber>;
        intentions: z.ZodNumber;
        intentionsDropped: z.ZodNumber;
        bySize: z.ZodBoolean;
    }, z.core.$strict>;
}, z.core.$strict>;
export type HandoffPack = z.infer<typeof handoffPackSchema>;
