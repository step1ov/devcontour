import { Worker } from 'node:worker_threads';
/**
 * SHA-256 и права файлов дерева в потоках: сверка копии seed читает десятки
 * тысяч мелких файлов, и асинхронное чтение по одному упирается в переходы
 * через пул libuv из четырёх потоков, а хэш — в один главный поток. Здесь
 * каждый поток сам открывает, читает и хэширует свою порцию синхронно.
 *
 * Байты и права берутся с одного дескриптора: файл открыт без перехода по
 * ссылке и без ожидания устройства, а `fstat` того же дескриптора решает,
 * обычный ли это файл. Подмена между обходом и чтением — отказ, а не чтение
 * чужого файла.
 */
export interface FileDigest {
    rel: string;
    sha256: string;
    /** Права вместе с setuid, setgid и sticky (`0o7777`). */
    mode: number;
    size: number;
}
/** Файл оказался не обычным: ссылка, каталог, устройство. */
export declare class NotRegularFile extends Error {
    readonly rel: string;
    constructor(rel: string);
}
/** Запуск потока; тест подменяет его, чтобы проверить отказ запуска. */
export declare const digestWorker: {
    create: () => Worker;
};
/**
 * Отпечатки файлов `rels` под `root`. Первый отказ или отмена останавливает раздачу
 * и все потоки; результат возвращается, только когда ни один поток не работает.
 */
export declare function fileDigests(root: string, rels: string[], signal?: AbortSignal): Promise<FileDigest[]>;
