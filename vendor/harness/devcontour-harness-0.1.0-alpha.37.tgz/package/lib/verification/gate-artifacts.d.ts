import { gateArtifactLimits, type GateArtifactFiles } from '../contracts/index.ts';
import type { Redactor } from '../environment/redaction.ts';
type Limits = {
    -readonly [K in keyof typeof gateArtifactLimits]: number;
};
/**
 * Сохранить artifacts gate в `dest` и описать результат для evidence.
 *
 * Пути — относительно корня дерева `root`; каталог обходится в порядке имён
 * в пределах `scan` записей. Ссылки не разыменовываются ни в объявленном
 * пути, ни в его компонентах, ни внутри каталога: такой путь записывается как
 * `symlink`. Копируются только обычные файлы с одной жёсткой ссылкой и с
 * разрешёнными расширениями в пределах `gateArtifactLimits`; файл,
 * разрешающийся перед чтением вне дерева, не
 * копируется. Всё прочее и всякий отказ чтения или записи записываются в
 * `skipped` с причиной. Функция не бросает: исход gate от сохранения не
 * зависит, а отказ сохранения остаётся в evidence.
 *
 * `dest` принадлежит harness: прежние копии того же gate удаляются, чтобы
 * они не выдали себя за результат этого запуска. Каталог, совпадающий с
 * деревом, содержащий его или лежащий внутри него, отклоняется до удаления.
 */
export declare function keepGateArtifacts(options: {
    root: string;
    paths: readonly string[];
    dest: string;
    redact: Redactor;
    signal?: AbortSignal;
    /** Только для тестов: меньшие пределы. */
    limits?: Partial<Limits>;
    /** Только для тестов: вызывается перед посещением каждого пути. */
    beforeVisit?: (rel: string) => Promise<void> | void;
}): Promise<GateArtifactFiles>;
export {};
