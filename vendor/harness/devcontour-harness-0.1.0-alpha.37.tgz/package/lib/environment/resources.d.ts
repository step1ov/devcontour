import { type ExecutionPolicy } from '../contracts/index.ts';
type Resource = ExecutionPolicy['resources'][number];
export declare const resourceKey: (r: Resource) => string;
/**
 * База блокировок ресурсов машины. Общая с DevContour (`~/.devcontour-local/
 * resources.sqlite`): устройство или порт исключительны для всех контуров
 * одной машины, а не для одного каталога состояния.
 */
export declare const defaultResourceDatabase: () => string;
type LeaseRow = {
    key: string;
    resource: string;
    owner: string;
    token: string;
    pid: number;
    expires: number;
};
export declare class ResourcePool {
    private db;
    constructor(path: string);
    list(): LeaseRow[];
    tryAcquire(resources: Resource[], owner: string, token: string, ttl: number): boolean;
    heartbeat(token: string, count: number, ttl: number): void;
    release(token: string): void;
    clearAbandoned(key: string, token: string): void;
    /**
     * Digest манифеста seed зависимостей (`verification/dependency-store.ts`).
     * Лежит здесь, а не рядом с seed: подмена seed вместе с его манифестом не
     * совпадёт с записью, а песочнице база на запись закрыта. От кода с правами
     * хоста (`prepare`, `lifecycle`) закрепление не защищает.
     */
    seedPin(root: string, key: string): string | undefined;
    setSeedPin(root: string, key: string, digest: string | undefined): void;
    private seedPins;
    close(): void;
}
export declare function withResources<T>(config: Pick<ExecutionPolicy, 'resources' | 'leaseMs'> & {
    resourceDatabase: string;
}, ids: string[], owner: string, signal: AbortSignal, work: (signal: AbortSignal, resources: Resource[]) => Promise<T>): Promise<T>;
export {};
