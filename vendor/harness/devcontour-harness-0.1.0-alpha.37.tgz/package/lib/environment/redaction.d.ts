export type Redactor = ((text: string) => string) & {
    secrets?: readonly string[];
};
export declare function redactor(values: readonly string[]): Redactor;
export declare function composeRedactors(...values: Redactor[]): Redactor;
export declare function outputRedactor(redact?: Redactor): (text: string, final?: boolean) => string;
/**
 * Замаскировать все строки во вложенной структуре перед сохранением.
 *
 * Доказательство собирается из многих полей: итог, команда, команда повтора,
 * разобранный отчёт, находки ревью, наблюдённые команды. Маскировать каждое
 * поле в месте его сборки — значит однажды пропустить одно; сохраняемая
 * запись проходит через эту функцию целиком.
 */
export declare function redactDeep<T>(value: T, redact?: (text: string) => string): T;
/**
 * Безопасная форма ошибки: маскируются сообщение, стек, причина и все
 * собственные поля (у ошибки процесса — `path`, `spawnargs`, `cmd`, `stderr`
 * и др.), класс и код сохраняются. Исходный объект не возвращается: его
 * сырые поля несли бы известные значения дальше.
 */
export declare function redactError(error: unknown, redact: (text: string) => string): unknown;
/** Значения секретов: `secrets`-карты политики (на любом уровне) из окружения controller. */
export declare function policySecrets(policy: unknown, env?: NodeJS.ProcessEnv): string[];
