import { AsyncLocalStorage } from 'node:async_hooks';
import type { Activity } from '../contracts/index.ts';
/** Исполняющаяся команда владельца: процесс, что это и хвост её вывода. */
export interface TrackedCommand {
    readonly pid: number | undefined;
    readonly activity: Activity;
    readonly startedAt: number;
    outputBytes: number;
    /** Хвост вывода после маски: в снимок зависания он идёт как есть. */
    tail: string;
    /** Маска команды: ею закрываются строки команд процессов в снимке. */
    readonly redact?: (text: string) => string;
}
/**
 * Движение работы одного владельца (попытки). Команды попытки регистрируются
 * здесь сами (`command` находит владельца через `activityScope`), так что
 * вызовам агента, gates и шагам среды не нужно передавать его явно. Движение —
 * начало и конец команды, её вывод и то, что владелец отмечает сам (`moved`:
 * граница стадии, заметный расход процессора).
 */
export declare class ActivityScope {
    readonly clock: () => number;
    readonly running: Set<TrackedCommand>;
    lastMovementAt: number;
    constructor(clock?: () => number);
    moved(at?: number): void;
    begin(pid: number | undefined, activity: Activity, redact?: (text: string) => string): TrackedCommand;
    output(tracked: TrackedCommand, text: string): void;
    end(tracked: TrackedCommand): void;
    /** Последняя начатая из исполняющихся команд: её называет живость. */
    current(): TrackedCommand | undefined;
}
/** Владелец команд текущего асинхронного контекста; нет — команды не отслеживаются. */
export declare const activityScope: AsyncLocalStorage<ActivityScope>;
