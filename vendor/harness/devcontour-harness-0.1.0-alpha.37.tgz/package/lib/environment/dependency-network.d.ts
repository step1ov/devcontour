/** Причина отказа среды, которую несёт сообщение: стабильный токен в начале. */
export declare const DEPENDENCY_NETWORK = "dependency-network";
/**
 * Argv — установка зависимостей известным менеджером пакетов: `npm
 * install|i|ci|clean-install`, `pnpm install|i|fetch`, `yarn [install]`, в том
 * числе через `corepack` (и `corepack pnpm@9`), по абсолютному пути и с `.cmd`.
 * До подкоманды допускаются только известные опции; `--`, неизвестная опция
 * без `=` (её значение не отличить от подкоманды), скрипты (`npm run …`),
 * `npx`, `exec`, shell — не установка.
 */
export declare function isDependencyInstall(argv: readonly string[]): boolean;
/**
 * Строка отчёта менеджера о сетевом отказе — или `undefined`, когда вывод не
 * доказывает его (условия 1, 4, 5 правила; входы дерева — `untrustedInputs`).
 */
export declare function registryFailureLine(argv: readonly string[], code: number | null | undefined, output: string): string | undefined;
/**
 * Почему входам установки в дереве `root` верить нельзя (условия 2 и 3
 * правила), или `undefined`, если они совпадают с базой `base` и база не
 * исполняет кода при установке. Сверяются все файлы входов по обе стороны —
 * в базе и в дереве (обход файловой системы, включая игнорируемые git), все
 * `.gitignore` и все символические ссылки дерева. Любая ошибка чтения —
 * недоверие.
 */
export declare function untrustedInputs(root: string, base: string): Promise<string | undefined>;
/** Где и чем исполнялась упавшая установка. */
export interface InstallFailure {
    argv: readonly string[];
    code: number | null | undefined;
    output: string;
    /** Корень проверяемого дерева. */
    root: string;
    /** SHA базы, с которой сверяются входы; нет базы — нет и классификации. */
    base?: string;
}
/**
 * Строка-подпись сетевого отказа установки, если выполнены все условия
 * правила, иначе `undefined`: отказ остаётся прежнего класса.
 */
export declare function dependencyNetworkFailure(failure: InstallFailure): Promise<string | undefined>;
/** Сообщение отказа: токен причины первым, чтобы `explain` показал его и после обрезки. */
export declare const dependencyNetworkMessage: (signature: string, detail: string) => string;
