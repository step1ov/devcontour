import { type Usage } from '../contracts/index.ts';
export declare const unknownUsage: () => Usage;
/** Только телеметрия runtime, никогда — структурированный ответ модели или её слова о стоимости. */
export declare function parseUsage(runtime: 'codex' | 'claude', stdout: string, completed: boolean): Usage;
/** Версия CLI runtime (`<executable> --version`); `null` — неизвестна. */
export declare function runtimeVersion(executable: string, env?: NodeJS.ProcessEnv): Promise<string | null>;
/** Модель, которую runtime выбрал на самом деле: событие system у claude, ключи modelUsage у codex. */
export declare function reportedModel(stdout: string): string | null;
/** Строка потока длиннее — не разбирается и делает телеметрию неполной. */
export declare const LINE_LIMIT = 8000000;
/**
 * Телеметрия, собранная по ходу потока runtime, а не из хвоста вывода. Хвост
 * stdout и журнал вызова ограничены, и у долгого вызова итоговое событие
 * `result` (стоимость и счётчики claude) или ранние `turn.completed` codex
 * оказывались за пределом: стоимость, сообщённая провайдером, терялась или
 * учитывалась неполной. Здесь каждая строка разбирается сразу; хранятся
 * только поля телеметрии — последнее событие `result`, события
 * `turn.completed` и первая сообщённая модель, — а не текст вывода.
 * У claude также — `terminal_reason` и `num_turns` последнего `result` (по
 * ним адаптер узнаёт нехватку окна контекста) и число автоматических и ручных сжатий
 * контекста (`system`/`compact_boundary`): успешное сжатие не отказ.
 */
export declare function usageStream(runtime: 'codex' | 'claude'): {
    /**
     * Очередной фрагмент stdout runtime (без маски: берутся только числа).
     * Вызывается из обработчика вывода процесса и не бросает: сбой разбора —
     * неполная телеметрия, а не падение controller.
     */
    push(text: string): void;
    /** Телеметрия всего потока; `completed` — вызов завершился штатно. */
    usage(completed: boolean): Usage;
    model: () => string | null;
    /** `terminal_reason` последнего `result` claude; нет — runtime не сообщил. */
    terminalReason: () => string | undefined;
    /** `num_turns` последнего `result` claude; нет — runtime не сообщил. */
    numTurns: () => number | undefined;
    /** Сколько раз runtime сжал контекст за вызов (`compact_boundary`). */
    compactions: () => number;
};
