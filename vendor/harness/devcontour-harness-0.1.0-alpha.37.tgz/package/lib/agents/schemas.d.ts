export declare const implementationOutputSchema: {
    type: string;
    additionalProperties: boolean;
    properties: {
        completed: {
            type: string;
        };
        summary: {
            type: string;
        };
        discoveries: {
            type: string;
            maxItems: number;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    kind: {
                        type: string;
                        enum: string[];
                    };
                    title: {
                        type: string;
                    };
                    path: {
                        type: string;
                    };
                    line: {
                        type: string;
                        minimum: number;
                    };
                    observation: {
                        type: string;
                    };
                    consequence: {
                        type: string;
                    };
                    reproduction: {
                        type: string;
                    };
                };
                required: string[];
            };
        };
        inputRequest: {
            type: string[];
            additionalProperties: boolean;
            properties: {
                question: {
                    type: string;
                };
                options: {
                    type: string;
                    maxItems: 6;
                    items: {
                        type: string;
                        additionalProperties: boolean;
                        properties: {
                            id: {
                                type: string;
                            };
                            label: {
                                type: string;
                            };
                            consequence: {
                                type: string[];
                            };
                        };
                        required: string[];
                    };
                };
                recommended: {
                    type: string[];
                };
                severity: {
                    type: string;
                    minimum: number;
                    maximum: number;
                };
                rationale: {
                    type: string;
                };
                affects: {
                    type: string;
                    maxItems: 5;
                    items: {
                        type: string;
                        enum: ("acceptance" | "contract" | "product" | "api" | "migration")[];
                    };
                };
            };
            required: string[];
        };
        assumptions: {
            type: string;
            maxItems: 20;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    question: {
                        type: string;
                    };
                    chosen: {
                        type: string;
                    };
                    rationale: {
                        type: string;
                    };
                    severity: {
                        type: string;
                        minimum: number;
                        maximum: number;
                    };
                    affects: {
                        type: string;
                        maxItems: 5;
                        items: {
                            type: string;
                            enum: ("acceptance" | "contract" | "product" | "api" | "migration")[];
                        };
                    };
                };
                required: string[];
            };
        };
    };
    required: string[];
};
export declare const reviewOutputSchema: {
    type: string;
    additionalProperties: boolean;
    properties: {
        execution: {
            type: string;
            additionalProperties: boolean;
            properties: {
                commands: {
                    type: string;
                    maxItems: number;
                    items: {
                        type: string;
                        additionalProperties: boolean;
                        properties: {
                            command: {
                                type: string;
                            };
                            exitCode: {
                                type: string;
                            };
                            summary: {
                                type: string;
                            };
                        };
                        required: string[];
                    };
                };
                noCommandsReason: {
                    type: string[];
                };
            };
            required: string[];
        };
        approved: {
            type: string;
        };
        summary: {
            type: string;
        };
        discoveries: {
            type: string;
            maxItems: number;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    kind: {
                        type: string;
                        enum: string[];
                    };
                    title: {
                        type: string;
                    };
                    path: {
                        type: string;
                    };
                    line: {
                        type: string;
                        minimum: number;
                    };
                    observation: {
                        type: string;
                    };
                    consequence: {
                        type: string;
                    };
                    reproduction: {
                        type: string;
                    };
                };
                required: string[];
            };
        };
        findings: {
            type: string;
            maxItems: number;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    severity: {
                        type: string;
                        enum: string[];
                    };
                    message: {
                        type: string;
                    };
                    path: {
                        type: string[];
                    };
                    line: {
                        type: string[];
                        minimum: number;
                    };
                    rule: {
                        type: string[];
                    };
                    consequence: {
                        type: string[];
                    };
                    evidence: {
                        type: string[];
                    };
                    reproduction: {
                        anyOf: ({
                            type: string;
                            additionalProperties?: undefined;
                            properties?: undefined;
                            required?: undefined;
                        } | {
                            type: string;
                            additionalProperties: boolean;
                            properties: {
                                property: {
                                    type: string[];
                                };
                                input: {
                                    type: string;
                                };
                                inputClass: {
                                    type: string[];
                                };
                                expected: {
                                    type: string[];
                                };
                                actual: {
                                    type: string[];
                                };
                                command: {
                                    type: string[];
                                    items: {
                                        type: string;
                                    };
                                };
                                executed: {
                                    type: string;
                                };
                                run: {
                                    type: string[];
                                };
                            };
                            required: string[];
                        })[];
                    };
                };
                required: string[];
            };
        };
        previous: {
            type: string;
            maxItems: number;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    id: {
                        type: string;
                        pattern: string;
                    };
                    status: {
                        type: string;
                        enum: ("closed" | "open" | "withdrawn")[];
                    };
                    basis: {
                        type: string;
                        pattern: string;
                    };
                };
                required: string[];
            };
        };
    };
    required: string[];
};
/**
 * Ответ reviewer попытки без изменений: тот же протокол и обязательное
 * `alreadySatisfied` (`null` — подтверждения нет). Обычное ревью этого поля
 * не получает: его вид ответа не меняется.
 */
export declare const alreadySatisfiedReviewOutputSchema: {
    properties: {
        alreadySatisfied: {
            anyOf: ({
                type: string;
                additionalProperties?: undefined;
                properties?: undefined;
                required?: undefined;
            } | {
                type: string;
                additionalProperties: boolean;
                properties: {
                    gates: {
                        type: string;
                        minItems: number;
                        maxItems: number;
                        items: {
                            type: string;
                        };
                    };
                    evidence: {
                        type: string;
                    };
                };
                required: string[];
            })[];
        };
        execution: {
            type: string;
            additionalProperties: boolean;
            properties: {
                commands: {
                    type: string;
                    maxItems: number;
                    items: {
                        type: string;
                        additionalProperties: boolean;
                        properties: {
                            command: {
                                type: string;
                            };
                            exitCode: {
                                type: string;
                            };
                            summary: {
                                type: string;
                            };
                        };
                        required: string[];
                    };
                };
                noCommandsReason: {
                    type: string[];
                };
            };
            required: string[];
        };
        approved: {
            type: string;
        };
        summary: {
            type: string;
        };
        discoveries: {
            type: string;
            maxItems: number;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    kind: {
                        type: string;
                        enum: string[];
                    };
                    title: {
                        type: string;
                    };
                    path: {
                        type: string;
                    };
                    line: {
                        type: string;
                        minimum: number;
                    };
                    observation: {
                        type: string;
                    };
                    consequence: {
                        type: string;
                    };
                    reproduction: {
                        type: string;
                    };
                };
                required: string[];
            };
        };
        findings: {
            type: string;
            maxItems: number;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    severity: {
                        type: string;
                        enum: string[];
                    };
                    message: {
                        type: string;
                    };
                    path: {
                        type: string[];
                    };
                    line: {
                        type: string[];
                        minimum: number;
                    };
                    rule: {
                        type: string[];
                    };
                    consequence: {
                        type: string[];
                    };
                    evidence: {
                        type: string[];
                    };
                    reproduction: {
                        anyOf: ({
                            type: string;
                            additionalProperties?: undefined;
                            properties?: undefined;
                            required?: undefined;
                        } | {
                            type: string;
                            additionalProperties: boolean;
                            properties: {
                                property: {
                                    type: string[];
                                };
                                input: {
                                    type: string;
                                };
                                inputClass: {
                                    type: string[];
                                };
                                expected: {
                                    type: string[];
                                };
                                actual: {
                                    type: string[];
                                };
                                command: {
                                    type: string[];
                                    items: {
                                        type: string;
                                    };
                                };
                                executed: {
                                    type: string;
                                };
                                run: {
                                    type: string[];
                                };
                            };
                            required: string[];
                        })[];
                    };
                };
                required: string[];
            };
        };
        previous: {
            type: string;
            maxItems: number;
            items: {
                type: string;
                additionalProperties: boolean;
                properties: {
                    id: {
                        type: string;
                        pattern: string;
                    };
                    status: {
                        type: string;
                        enum: ("closed" | "open" | "withdrawn")[];
                    };
                    basis: {
                        type: string;
                        pattern: string;
                    };
                };
                required: string[];
            };
        };
    };
    required: string[];
    type: string;
    additionalProperties: boolean;
};
