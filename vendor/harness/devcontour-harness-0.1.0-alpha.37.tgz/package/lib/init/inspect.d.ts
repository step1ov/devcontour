import { type ProjectFacts } from '../contracts/index.ts';
import { type ToolProbe } from '../toolchains/probe.ts';
/** Маркеры репозитория DevContour: второй controller и state не создаются. */
export declare const devcontourMarkers: string[];
export type GitFacts = {
    problem: 'path-missing' | 'not-directory' | 'not-git-repository';
    path: string;
} | {
    path: string;
    /** realpath верхнего уровня Git. */
    root: string;
    worktree: 'main' | 'linked';
    baseSha: string | null;
    branch: string | null;
};
/** Корень Git каталога `path`, вид worktree и HEAD — только чтением. */
export declare function gitFacts(path: string, env: NodeJS.ProcessEnv): Promise<GitFacts>;
export interface InspectProjectOptions {
    repository: string;
    env?: NodeJS.ProcessEnv;
    /** Проба `--version`; по умолчанию — процесс во временном каталоге. */
    probe?: ToolProbe;
    /** Runtime, наличие которых проверить; по умолчанию оба. */
    runtimes?: ('claude' | 'codex')[];
}
/**
 * Факты готовности репозитория к первому запуску без записи: Git-корень и
 * base SHA, lockfiles и менеджер пакетов, подходящие встроенные профили с
 * digest, scripts проверок, версии инструментов и наличие CLI runtime.
 * Ничего не создаёт и не исполняет из манифестов; модели не вызываются,
 * авторизация runtime остаётся неизвестной. Генерация `.harness` и target ref
 * — дело `init`; DevContour применяет к фактам собственные правила размещения.
 */
export declare function inspectProject(options: InspectProjectOptions): Promise<ProjectFacts>;
