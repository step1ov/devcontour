import type { ExecutionPolicy, ExecutionView, WorkflowJob } from '../contracts/index.ts';
import type { Engine } from '../engine/engine.ts';
import type { StopInput } from '../projections/stop.ts';
/**
 * Что читают диагнозы по сохранённому состоянию (`stopInputsOf`) и пакет
 * передачи контекста: движок над хранилищем, политика исполнения и очередь
 * заданий графов — список заданий и решение, продолжит ли задание работу.
 * `Harness` удовлетворяет ему структурно (`workflows` — его `WorkflowQueue`);
 * хост со своим движком передаёт свой адаптер заданий.
 */
export interface StopSource {
    readonly engine: Engine;
    readonly policy: ExecutionPolicy;
    readonly workflows: {
        /** Задания очереди; диагнозы и пакет читают задания `kind: 'graph'`. */
        list(): readonly WorkflowJob[];
        /** Продолжит ли очередь задание сама (как `WorkflowQueue.continues`). */
        continues(job: WorkflowJob, view: ExecutionView, options?: {
            reconfigureApplies?: boolean;
        }): boolean;
    };
}
export interface StopInputOptions {
    maxAttempts: number;
    repairBudget: number;
    /** Одна работа; неизвестная — `NOT_FOUND`. */
    workId?: string;
    /**
     * Набор работ (не вместе с `workId`): входы каждой — те же, что у вызова с
     * её `workId`, за одно чтение. Неизвестная — `NOT_FOUND`.
     */
    workIds?: readonly string[];
}
/**
 * Control таким, каким его увидит следующий run этого процесса: run снимает
 * паузу «не запускали» (без причины) и штатную остановку, а применимый запрос
 * политики применяет до выдачи стадии (с ним снимается и его пауза). Общий
 * для `explain` и `status --detail`. `lifted` — пауза есть, но её снимет run.
 * Документ не меняется: `control` — прежний объект или его копия.
 */
export declare function nextRunControl(h: {
    readonly engine: Engine;
}, v: ExecutionView): {
    control: {
        paused: boolean;
        pauseReason?: "operator" | "runtime" | "shutdown" | "base-check" | "reconfigure" | undefined;
        pausedAt?: string | undefined;
        pauseOperation?: string | undefined;
        pauseFailures?: ("gate" | "unknown" | "review" | "cancelled" | "environment" | "timeout" | "provider-auth" | "stalled" | "context-exhausted" | "stale-base" | "empty-result" | "unfinished" | "scope-violation" | "review-protocol" | "merge" | "budget" | "needs-lead" | "needs-input")[] | undefined;
        waits?: {
            kind: "base-check" | "context-lock";
            detail: string;
            at: string;
            operation?: string | undefined;
        }[] | undefined;
        appliedPolicy?: {
            digest: string;
            at: string;
            by: string;
            generation?: number | undefined;
        } | undefined;
        reconfigure?: {
            operation: string;
            digest: string;
            requestedAt: string;
            appliedAt?: string | undefined;
            appliedBy?: string | undefined;
            error?: string | undefined;
        } | undefined;
    };
    lifted: boolean;
};
/**
 * Входы explainStop из сохранённого состояния; ничего не пишет.
 *
 * Класс отказа — сохранённый `failureKind` (его поставил классификатор в
 * точке отказа); текст ошибки здесь не разбирается. Счётчики восстановления
 * подставляются так, как их видит `repairDecision` (h1-spec K4): без
 * отпечатка повторять нечего, без задания графа движок сам не чинит.
 * Первым идёт вход действующей роли controller, затем поручения (кроме
 * принятых) в порядке состояния.
 *
 * Выбор: `workId` — одна работа, `workIds` — набор (входы каждой — те же,
 * что у вызова с её `workId`, в порядке состояния), без них — доска. Всё, что
 * общее для работ (прогноз групп, обратные зависимости, запросы, записи
 * вызовов), читается один раз за вызов, поэтому диагноз набора и доски
 * линеен по числу работ и их связей.
 */
export declare function stopInputsOf(h: StopSource, options: StopInputOptions): StopInput[];
