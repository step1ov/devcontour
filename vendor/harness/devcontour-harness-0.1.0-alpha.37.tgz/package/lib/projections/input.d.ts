import { type InputState, type RequestLike } from '../contracts/input-state.ts';
export { inputStates, inputStateOf, type InputState } from '../contracts/input-state.ts';
/** Сводка вопроса поручения для статуса: только ID, состояние, версия и серьёзность — без текста. */
export interface WorkInputView {
    requestId: string;
    state: InputState;
    version: number;
    severity: number;
}
/**
 * Последний незакрытый вопрос поручения (`kind: question`) — тот, о котором
 * говорит статус; неблокирующие запросы считаются отдельно (`followUps`).
 */
export declare function workInputOf(requests: readonly RequestLike[]): {
    input?: WorkInputView;
    followUps: number;
};
