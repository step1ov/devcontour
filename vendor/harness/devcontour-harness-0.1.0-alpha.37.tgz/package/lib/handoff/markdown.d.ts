import { type HandoffPack } from '../contracts/handoff.ts';
/**
 * Текст пакета передачи для новой сессии ведущего агента. Те же данные, что
 * JSON-ответ; раздел «Намерения» — единственный, который пишет агент.
 */
export declare function handoffMarkdown(pack: HandoffPack): string;
