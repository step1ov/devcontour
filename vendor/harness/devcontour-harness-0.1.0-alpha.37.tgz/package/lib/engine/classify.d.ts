import { BlockedError, type EnvironmentCause, type FailureKind } from '../contracts/index.ts';
export { BlockedError };
/**
 * Отказ провайдера, а не работы: он повторится на любой следующей выдаче.
 * Список узкий намеренно — временные ошибки сети сюда не входят.
 */
export declare const providerRefusal: (message: string) => boolean;
export declare function classifyFailure(error: unknown, message: string): FailureKind;
/**
 * Причина отказа окружения (`attempt.diagnosed`): названная в точке
 * обнаружения (`TaskFailure.diagnosis`), иначе — по тем же признакам, что
 * класс отказа. Отказ не окружения — `none`; движок приводит причину к
 * классу сам, поэтому здесь достаточно лучшей догадки.
 */
export declare function environmentCauseOf(error: unknown, message: string, kind: FailureKind): EnvironmentCause;
/**
 * Отказ с дописанной причиной (например, неудавшейся очисткой): класс,
 * свойства и причина окружения `TaskFailure` сохраняются; прочий отказ —
 * `Error` с исходным в `cause`.
 */
export declare function withSuffix(failure: Error, suffix: string): Error;
