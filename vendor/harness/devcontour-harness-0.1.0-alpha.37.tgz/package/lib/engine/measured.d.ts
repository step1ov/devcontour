import { type RuntimeAdapter, type RuntimeRequest, type RuntimeResponse } from '../contracts/index.ts';
import '../environment/live-calls.ts';
import type { CallMeta } from './budget.ts';
import type { Engine } from './engine.ts';
/**
 * Вызов runtime под учётом. До вызова, в одной транзакции с регистрацией
 * идущего вызова, проверяются бюджеты: превышенный или неопределённый не даёт
 * начать вызов, и записи тогда нет. Тарифы закрепляются на старте вызова:
 * правка цен во время или после вызова оценку не меняет. Тариф выбирается
 * только по модели, о которой сообщил runtime: запрошенная модель не
 * подтверждает, что работала именно она. Время идущего вызова сохраняется по
 * ходу: другой процесс не увидит его ниже этого замера при откате часов.
 * Ошибочные вызовы остаются в учёте со своей стоимостью.
 */
export declare function measuredInvoke(engine: Engine, adapter: RuntimeAdapter, request: RuntimeRequest, signal: AbortSignal, meta: CallMeta, 
/**
 * Вызов начался: бюджет пропустил его и запись учёта создана — до
 * обращения к runtime. Отказ обработчика вызов не отменяет.
 */
onStart?: (callId: string) => void): Promise<RuntimeResponse>;
