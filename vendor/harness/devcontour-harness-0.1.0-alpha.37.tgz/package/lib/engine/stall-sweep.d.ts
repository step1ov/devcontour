import type { Activity, LivenessState, RunEventPayload, StallSweepPolicy } from '../contracts/index.ts';
import { ActivityScope } from '../environment/activity.ts';
/**
 * Доля процессорного времени от прошедшего, с которой расход дерева считается
 * движением. Простаивающий event loop или ожидание сети расходуют десятые доли
 * процента; работающая проверка без вывода — десятки. Расход считается по
 * каждому процессу отдельно (сумма положительных приростов): завершившийся
 * потомок уносит своё время из суммы дерева, и сравнение сумм ложно видело бы
 * простой у сборки из коротких процессов. Накопленный прирост сравнивается с
 * временем от последнего движения: грубое разрешение ps (секунды на Linux) не
 * даёт ни ложного движения, ни ложного простоя.
 */
export declare const CPU_ACTIVE_SHARE = 0.01;
export interface ProcessRow {
    pid: number;
    parentPid: number;
    /** Процессорное время процесса; нет — ps его не сообщил. */
    cpuMs?: number;
    command: string;
}
/** Время `ps -o time`: `[[dd-]hh:]mm:ss[.cc]` (Linux — целые секунды, macOS — сотые). */
export declare function parseCpuTime(text: string): number | undefined;
/** Строки `ps -axww -o pid=,ppid=,time=,command=`. */
export declare function parseProcessTable(stdout: string): ProcessRow[];
/**
 * Таблица процессов, общая для одновременных обходов (попытки controller,
 * совместная проверка, gates на SHA): снимок моложе `maxAgeMs` берётся
 * готовым, а не новым вызовом ps.
 */
export declare function sharedSample(maxAgeMs: number): Promise<ProcessRow[] | null>;
/** Таблица процессов одним вызовом ps; отказ или Windows — `null`, а не исключение. */
export declare function sampleProcesses(timeoutMs?: number): Promise<ProcessRow[] | null>;
/** Процесс и все его потомки по таблице. */
export declare function treeOf(rows: readonly ProcessRow[], root: number): ProcessRow[];
export declare function livenessOf(idleMs: number, policy: StallSweepPolicy): LivenessState;
export interface SweepSubject {
    id: string;
    scope: ActivityScope;
}
export interface StallSnapshot {
    processes: ProcessRow[];
    processesUnavailable?: boolean;
    /** Хвост вывода последней начатой команды (замаскированный). */
    tail: string;
}
export interface LivenessChange {
    subject: SweepSubject;
    previous: LivenessState;
    state: LivenessState;
    /** Время обхода и последнего движения, epoch ms. */
    at: number;
    lastMovementAt: number;
    idleMs: number;
    activity?: Activity;
    /**
     * ps не дал данных о процессах исполняющихся команд: оценка только по
     * выводу и стадиям, поэтому выше `quiet` она не поднимается.
     */
    cpuUnavailable?: boolean;
    /** Только у `stalled`. */
    snapshot?: StallSnapshot;
    /**
     * Номер эпизода зависания субъекта (с 1): растёт при каждом новом входе в
     * `stalled`, повтор незаписанного перехода сохраняет номер — по нему снимок
     * пишется один раз на эпизод.
     */
    episode: number;
}
/**
 * Исход записи перехода у получателя: `recorded` — записан; `retry` —
 * временный отказ, следующий обход повторит переход; `dropped` — больше не
 * оценивать (владение утрачено, попытка остановлена).
 */
export type ChangeOutcome = 'recorded' | 'retry' | 'dropped';
/** Незаписанных повторов одного перехода, после которых субъект больше не оценивается. */
export declare const MAX_CHANGE_RETRIES = 5;
/** Строка команды без маски не сохраняется. */
export declare const UNMASKED_COMMAND = "(\u0441\u0442\u0440\u043E\u043A\u0430 \u043A\u043E\u043C\u0430\u043D\u0434\u044B \u0441\u043A\u0440\u044B\u0442\u0430: \u043D\u0435\u0442 \u043C\u0430\u0441\u043A\u0438)";
/**
 * Периодический обход исполняющегося. Один ps на обход для всех попыток;
 * переходы отдаются `changed` синхронно. Попытка без исполняющихся команд
 * (ждёт hook, ресурс, интеграцию) оценивается от последнего движения с
 * большим порогом (`stalledMs`) и не выше `quiet`: её команды не зависли,
 * а снимать нечего. При `action: stop` попытка после `stalled` больше не
 * оценивается: её остановка сама выглядела бы движением.
 */
export declare class StallSweep {
    private readonly options;
    private readonly memo;
    private timer?;
    private running?;
    /** Конец прошлого обхода: перерыв считается от него, не от начала. */
    private lastTick?;
    private gaps;
    constructor(options: {
        policy: StallSweepPolicy;
        subjects: () => Iterable<SweepSubject>;
        changed: (change: LivenessChange) => ChangeOutcome | void;
        clock?: () => number;
        sample?: () => Promise<ProcessRow[] | null>;
    });
    start(): void;
    stop(): void;
    /** Один обход; параллельный вызов ждёт идущий, а не запускает второй. */
    tick(): Promise<void>;
    private sweep;
    private decide;
    /**
     * Движение по процессору: сумма положительных приростов каждого процесса
     * (новый — от нуля). Завершившийся потомок не уменьшает счёт. Смена
     * состава дерева сама по себе движением не считается: цикл ожидания
     * (`until nc -z db 5432; do sleep 1; done`) порождает процессы без конца,
     * не продвигаясь.
     */
    private cpuMovement;
}
/** Остановка обходом зависших: причина прерывания и текст отказа. */
export declare class StalledError extends Error {
    name: string;
}
/** Текст остановки по переходу в `stalled`. */
export declare function stallMessage(change: LivenessChange, policy: StallSweepPolicy, artifact?: string): string;
/**
 * Обход зависших для операции вне попытки (совместная проверка, gates на
 * SHA): своя область движения, один субъект. Переходы получает `onChange`
 * (запись — у вызывающего); при `action: stop` на `stalled` вызывается
 * `abort` с `StalledError`, и операция завершается отказом с её текстом.
 */
export declare function superviseStalls<T>(policy: StallSweepPolicy, abort: (reason: StalledError) => void, fn: () => Promise<T>, 
/** Каждый переход — в обоих режимах; сбой получателя не мешает остановке. */
onChange?: (change: LivenessChange) => void): Promise<T>;
/**
 * Нагрузка события перехода (`attempt.liveness`, `joint.liveness`) из
 * перехода обхода: снимок урезан до пределов события, `action` — только у
 * `stalled`, `artifact` — только записанный файл снимка.
 */
export declare function livenessPayload(change: LivenessChange, action: StallSweepPolicy['action'], artifact?: string): RunEventPayload<'attempt.liveness'>;
