import { type AttemptState, type WorkState } from '../contracts/index.ts';
/**
 * Рабочие деревья закончившихся попыток. Обычно попытка убирает их сама; после
 * падения процесса, отказа удаления или под прежними версиями они остаются и
 * занимают диск. Удаление необратимо, поэтому правило одно: в сомнении дерево
 * остаётся, а отказ назван. Убирается только то, что восстановимо: вершина
 * достижима из ref, неподтверждённые правки доказанно лежат в патче. Игнорируемые
 * файлы патч не сохраняет — они перечисляются в отчёте.
 */
export type WorktreeRefusal = 'active' | 'recoverable' | 'cleanup-pending' | 'cleanup-unreadable' | 'unknown-attempt' | 'untrusted' | 'embedded-repository' | 'scan-limit' | 'scan-failed' | 'read-only-path' | 'undecodable-path' | 'worktree-locked' | 'clean-filter' | 'tree-changed' | 'ignore-rules-changed' | 'hidden-changes' | 'staged-ignored' | 'staged-differs' | 'unreachable-head' | 'patch-unusable' | 'removal-incomplete' | 'not-registered';
export interface WorktreeCleanupEntry {
    path: string;
    repositoryId: string;
    attemptId?: string;
    /**
     * remove — будет удалено (dry run); removed — удалено; refused — дерево не
     * тронуто. failed — отказ шага: при `removalStarted` git мог удалить часть
     * файлов и регистрацию, истинное состояние — в `registered` и `treePresent`,
     * а `patch` указывает на сохранённые правки.
     */
    action: 'remove' | 'removed' | 'refused' | 'failed';
    reason?: WorktreeRefusal;
    error?: string;
    head?: string;
    sizeKb?: number;
    /** Файлов с неподтверждёнными правками. */
    uncommitted?: number;
    /** Игнорируемое в дереве: в патч не входит и исчезает вместе с деревом. */
    ignored?: {
        count: number;
        paths: string[];
    };
    /** Патч этих правок (не для dry run): `git apply --index` поверх `head`. */
    patch?: string;
    /** Запись об удалении: при `removal-incomplete` её снимают вручную. */
    record?: string;
    removalStarted?: boolean;
    /** Отсутствует, только если git не смог ответить. */
    registered?: boolean;
    treePresent?: boolean;
}
/** Почему попытку нельзя лишить дерева: идёт, или её работа ещё может продолжиться. */
export declare function attemptRefusal(attempt: AttemptState, work: WorkState | undefined, latest: boolean, running: boolean): WorktreeRefusal | undefined;
/** Незавершённая очистка: дерево — вход `cleanup --run`, его нельзя убирать мимо teardown. */
export declare function cleanupUnfinished(artifacts: string, receipts: string[]): Promise<boolean>;
/** Зарегистрированные рабочие деревья репозитория: настоящий путь → заперто ли. */
export declare function registered(repoPath: string): Promise<Map<string, {
    locked: boolean;
}>>;
/** Вершина самого дерева: список деревьев снят раньше, а работа в дереве могла идти. */
export declare const treeHead: (dir: string) => Promise<string | undefined>;
export interface TreeScan {
    embedded?: string;
    readOnly?: string;
    undecodable?: string;
    limited: boolean;
    /** Пути `.gitignore` относительно дерева. */
    ignoreFiles: string[];
}
/**
 * Настоящее дерево вместе с игнорируемым: вложенный репозиторий (`.git` файлом
 * или каталогом, либо голый) git-командам внешнего не виден, если каталог
 * игнорируется. В `node_modules` тоже смотрим: зависимость из git-источника или
 * правка на месте бывает единственной копией работы. Обход ограничен: дошедший
 * до предела обход не доказал ничего. Символические ссылки не проходятся.
 */
export declare function scanTree(root: string, limit: number): Promise<TreeScan>;
/** Что мешает удалить дерево, и что в нём лежит. Ничего не пишет. */
export declare function inspectTree(dir: string, repoPath: string, head: string | undefined, limit: number): Promise<{
    refusal?: WorktreeRefusal;
    uncommitted?: number;
    ignored?: WorktreeCleanupEntry['ignored'];
    /** Статус, по которому принято решение: перед удалением он сверяется. */
    status?: string;
}>;
/**
 * Дерево то же, что при проверках: та же вершина, тот же статус, те же правки.
 * Узкое окно до удаления остаётся: запись после этой сверки не будет замечена.
 */
export declare function treeUnchanged(dir: string, head: string, status: string, edits: string | undefined): Promise<boolean>;
/**
 * Неподтверждённые правки дерева — патчем к закреплённой вершине `head`, той же,
 * что в записи об удалении. Индекс попытки не
 * меняется: всё идёт через временные индексы. Формат закреплён против настроек
 * пользователя, а патч проверен до удаления: наложенный на HEAD, он обязан дать
 * то же дерево, что и правки. Иначе отказ, и дерево остаётся.
 */
export declare function savePatch(dir: string, artifacts: string, name: string, head: string): Promise<{
    refusal: "embedded-repository";
    edits?: undefined;
    patch?: undefined;
} | {
    refusal: "patch-unusable";
    edits?: undefined;
    patch?: undefined;
} | {
    edits: string;
    patch: string;
    refusal?: undefined;
}>;
/** Дерево на диске — именно зарегистрированное дерево этого репозитория. */
export declare function trusted(dir: string, repoPath: string): boolean;
export declare function sizeKb(dir: string): Promise<number>;
/** Убрать дерево с пределом для больших деревьев: `command` ждёт по умолчанию 120 с. */
export declare function removeTree(repoPath: string, path: string, timeoutMs: number): Promise<void>;
export declare const recordFile: (artifacts: string, path: string) => string;
export interface RemovalRecord extends WorktreeCleanupEntry {
    status: 'removing' | 'removed' | 'incomplete';
    at: string;
    previous?: RemovalRecord;
}
/** Запись об удалении этого дерева; нечитаемая запись — как незавершённое удаление. */
export declare function readRemoval(artifacts: string, path: string): Promise<RemovalRecord | undefined>;
/**
 * Запись рядом с артефактами попытки: с какой вершины убрано и где патч. Пишется
 * и до удаления: прерванное удаление не теряет указатель на патч и видно
 * следующему запуску. Замена атомарна.
 */
export declare function recordRemoval(artifacts: string, entry: WorktreeCleanupEntry, status: RemovalRecord['status'], previous?: RemovalRecord): Promise<void>;
/**
 * Один запуск очистки на каталог состояния: два запуска делили бы патчи и записи.
 * Замок сверяет PID, поэтому каталог состояния должен принадлежать одному
 * пространству PID: контейнер со своим пространством увидел бы чужой замок умершим.
 */
export declare function lockCleanup(file: string): Promise<() => Promise<void>>;
/** Что осталось после отказа удаления; `registered` — только если git ответил. */
export declare function treeState(repoPath: string, path: string): Promise<{
    treePresent: boolean;
    registered?: boolean | undefined;
}>;
export declare const isWithin: (path: string, root: string) => boolean;
