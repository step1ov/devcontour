import type { AttemptState, BudgetScopes, CallRecord, ExecutionPolicy, ExecutionView } from '../contracts/index.ts';
import { usageTotals } from './usage.ts';
/**
 * Бюджеты расходов и времени вызовов моделей.
 *
 * Расход считается по сохранённым записям вызовов, а не по счётчикам попыток:
 * `retry --reset`, возврат попытки после отказа окружения, переход этапа
 * очереди и перезапуск процесса его не уменьшают. Ошибочные, идущие и
 * прерванные вызовы входят в расход. Неизвестная стоимость делает денежный
 * бюджет неопределённым; что тогда делать, задаёт `budgets.onUnknown`.
 *
 * Учёт локален: записи вызовов не переносятся между клонами, поэтому бюджет
 * считает вызовы этой установки.
 */
export type BudgetScope = {
    kind: 'work' | 'group' | 'total';
    id?: string;
};
/** Правила и области бюджетов: политика и группы хоста. */
export interface BudgetContext {
    policy: ExecutionPolicy;
    scopes: BudgetScopes;
}
/**
 * Прежняя запись вызова о группе: вида предмета нет, но при вызове закреплена
 * группа без поручения и без попытки. Вызов о поручении закреплял его
 * `workId`, поэтому совпадение ID предмета с поручением такую запись не
 * делает расходом одного поручения — она остаётся расходом группы.
 */
export declare function legacyGroupCall(r: {
    runId?: string;
    subjectKind?: CallRecord['subjectKind'];
    groupId?: string;
    workId?: string;
}): boolean;
/**
 * Записи вызовов области. Поручению принадлежат его попытки, вызовы о нём и
 * вызовы о его группе целиком (ревью плана): правила долевой атрибуции нет,
 * и вызов о группе не должен считаться нулевым для поручения. Группе — вызовы,
 * закреплённые за ней при вызове: перенос поручения в другую группу расход не
 * переносит.
 */
export declare function scopeRecords(c: BudgetContext, view: ExecutionView, records: CallRecord[], scope: BudgetScope, groupsOf?: () => Set<string>): {
    id: string;
    stage: string;
    runtime: string;
    model: string | null;
    runtimeVersion: string | null;
    startedAt: string;
    outcome: "error" | "active" | "abandoned" | "returned";
    promptBytes: number;
    promptDigest: string;
    usage: {
        inputTokens: number | null;
        outputTokens: number | null;
        cacheReadTokens: number | null;
        cacheWriteTokens: number | null;
        reportedUsd: number | null;
        complete: boolean;
        source: "fixture" | "unavailable" | "codex-turn-events" | "claude-result";
    };
    costUsd: number | null;
    costSource: "unknown" | "provider-reported" | "tariff-estimate";
    repositoryId?: string | undefined;
    runId?: string | undefined;
    subjectId?: string | undefined;
    subjectKind?: "work" | "group" | "other" | undefined;
    finishedAt?: string | undefined;
    process?: {
        id: string;
        pid: number;
        startedAt?: number | undefined;
    } | undefined;
    abandonedAt?: string | undefined;
    durationMs?: number | undefined;
    elapsedMs?: number | undefined;
    startedHr?: string | undefined;
    durationUnknown?: true | undefined;
    bootId?: string | undefined;
    workId?: string | undefined;
    groupId?: string | undefined;
    workIds?: string[] | undefined;
    price?: {
        runtime: "codex" | "claude";
        model: string;
        effectiveAt: string;
        input: number;
        output: number;
        cacheRead: number;
        cacheWrite: number;
    } | undefined;
    diagnostics?: {
        startedAt: string;
        finishedAt: string;
        lastOutputAt: string | null;
        exitCode: number | null;
        signal: string | null;
        timedOut: boolean;
        aborted: boolean;
        stdoutTail: string;
        stderrTail: string;
        processTree?: {
            available: boolean;
            processes: {
                pid: number;
                parentPid: number;
                groupPid: number;
                name: string;
            }[];
            reason?: string | undefined;
        } | undefined;
    } | undefined;
}[];
/**
 * Собственные вызовы поручения: его попытки и вызовы о нём. Вызовы о группе
 * (ревью и проверка плана), которые `scopeRecords` целиком засчитывает каждому
 * её поручению, сюда не входят: это один расход группы, а не каждого.
 */
export declare function ownWorkRecords(view: ExecutionView, records: CallRecord[], workId: string): {
    id: string;
    stage: string;
    runtime: string;
    model: string | null;
    runtimeVersion: string | null;
    startedAt: string;
    outcome: "error" | "active" | "abandoned" | "returned";
    promptBytes: number;
    promptDigest: string;
    usage: {
        inputTokens: number | null;
        outputTokens: number | null;
        cacheReadTokens: number | null;
        cacheWriteTokens: number | null;
        reportedUsd: number | null;
        complete: boolean;
        source: "fixture" | "unavailable" | "codex-turn-events" | "claude-result";
    };
    costUsd: number | null;
    costSource: "unknown" | "provider-reported" | "tariff-estimate";
    repositoryId?: string | undefined;
    runId?: string | undefined;
    subjectId?: string | undefined;
    subjectKind?: "work" | "group" | "other" | undefined;
    finishedAt?: string | undefined;
    process?: {
        id: string;
        pid: number;
        startedAt?: number | undefined;
    } | undefined;
    abandonedAt?: string | undefined;
    durationMs?: number | undefined;
    elapsedMs?: number | undefined;
    startedHr?: string | undefined;
    durationUnknown?: true | undefined;
    bootId?: string | undefined;
    workId?: string | undefined;
    groupId?: string | undefined;
    workIds?: string[] | undefined;
    price?: {
        runtime: "codex" | "claude";
        model: string;
        effectiveAt: string;
        input: number;
        output: number;
        cacheRead: number;
        cacheWrite: number;
    } | undefined;
    diagnostics?: {
        startedAt: string;
        finishedAt: string;
        lastOutputAt: string | null;
        exitCode: number | null;
        signal: string | null;
        timedOut: boolean;
        aborted: boolean;
        stdoutTail: string;
        stderrTail: string;
        processTree?: {
            available: boolean;
            processes: {
                pid: number;
                parentPid: number;
                groupPid: number;
                name: string;
            }[];
            reason?: string | undefined;
        } | undefined;
    } | undefined;
}[];
export type BudgetStatus = {
    scope: BudgetScope;
    limit: {
        usd?: number;
        timeMs?: number;
    };
    spent: ReturnType<typeof usageTotals> & {
        uncoveredRuns: number;
        liveCalls: number;
    };
    state: 'within' | 'exceeded' | 'undetermined';
    reason?: string;
};
export declare function budgetStatus(c: BudgetContext, view: ExecutionView, scope: BudgetScope, records?: CallRecord[], at?: number, shared?: {
    uncovered: () => AttemptState[];
    groupsOf?: () => Set<string>;
}): BudgetStatus | undefined;
/** Бюджеты, относящиеся к поручению: его собственный, его групп и общий. */
export declare function workBudgets(c: BudgetContext, view: ExecutionView, workId: string, records?: {
    id: string;
    stage: string;
    runtime: string;
    model: string | null;
    runtimeVersion: string | null;
    startedAt: string;
    outcome: "error" | "active" | "abandoned" | "returned";
    promptBytes: number;
    promptDigest: string;
    usage: {
        inputTokens: number | null;
        outputTokens: number | null;
        cacheReadTokens: number | null;
        cacheWriteTokens: number | null;
        reportedUsd: number | null;
        complete: boolean;
        source: "fixture" | "unavailable" | "codex-turn-events" | "claude-result";
    };
    costUsd: number | null;
    costSource: "unknown" | "provider-reported" | "tariff-estimate";
    repositoryId?: string | undefined;
    runId?: string | undefined;
    subjectId?: string | undefined;
    subjectKind?: "work" | "group" | "other" | undefined;
    finishedAt?: string | undefined;
    process?: {
        id: string;
        pid: number;
        startedAt?: number | undefined;
    } | undefined;
    abandonedAt?: string | undefined;
    durationMs?: number | undefined;
    elapsedMs?: number | undefined;
    startedHr?: string | undefined;
    durationUnknown?: true | undefined;
    bootId?: string | undefined;
    workId?: string | undefined;
    groupId?: string | undefined;
    workIds?: string[] | undefined;
    price?: {
        runtime: "codex" | "claude";
        model: string;
        effectiveAt: string;
        input: number;
        output: number;
        cacheRead: number;
        cacheWrite: number;
    } | undefined;
    diagnostics?: {
        startedAt: string;
        finishedAt: string;
        lastOutputAt: string | null;
        exitCode: number | null;
        signal: string | null;
        timedOut: boolean;
        aborted: boolean;
        stdoutTail: string;
        stderrTail: string;
        processTree?: {
            available: boolean;
            processes: {
                pid: number;
                parentPid: number;
                groupPid: number;
                name: string;
            }[];
            reason?: string | undefined;
        } | undefined;
    } | undefined;
}[], at?: number): BudgetStatus[];
/**
 * `workBudgets` для многих поручений одного вида: общий бюджет считается раз,
 * бюджет группы — раз на группу, попытки без записанных вызовов читаются
 * одним проходом, группы поручения спрашиваются у хоста, только когда они
 * нужны (предел группы или запись без поручения). Ответ по поручению — тот
 * же, что у `workBudgets` с теми же `records` и `at`. Действует в пределах
 * этого вида (одного чтения).
 */
export declare function workBudgetsOf(c: BudgetContext, view: ExecutionView, records?: {
    id: string;
    stage: string;
    runtime: string;
    model: string | null;
    runtimeVersion: string | null;
    startedAt: string;
    outcome: "error" | "active" | "abandoned" | "returned";
    promptBytes: number;
    promptDigest: string;
    usage: {
        inputTokens: number | null;
        outputTokens: number | null;
        cacheReadTokens: number | null;
        cacheWriteTokens: number | null;
        reportedUsd: number | null;
        complete: boolean;
        source: "fixture" | "unavailable" | "codex-turn-events" | "claude-result";
    };
    costUsd: number | null;
    costSource: "unknown" | "provider-reported" | "tariff-estimate";
    repositoryId?: string | undefined;
    runId?: string | undefined;
    subjectId?: string | undefined;
    subjectKind?: "work" | "group" | "other" | undefined;
    finishedAt?: string | undefined;
    process?: {
        id: string;
        pid: number;
        startedAt?: number | undefined;
    } | undefined;
    abandonedAt?: string | undefined;
    durationMs?: number | undefined;
    elapsedMs?: number | undefined;
    startedHr?: string | undefined;
    durationUnknown?: true | undefined;
    bootId?: string | undefined;
    workId?: string | undefined;
    groupId?: string | undefined;
    workIds?: string[] | undefined;
    price?: {
        runtime: "codex" | "claude";
        model: string;
        effectiveAt: string;
        input: number;
        output: number;
        cacheRead: number;
        cacheWrite: number;
    } | undefined;
    diagnostics?: {
        startedAt: string;
        finishedAt: string;
        lastOutputAt: string | null;
        exitCode: number | null;
        signal: string | null;
        timedOut: boolean;
        aborted: boolean;
        stdoutTail: string;
        stderrTail: string;
        processTree?: {
            available: boolean;
            processes: {
                pid: number;
                parentPid: number;
                groupPid: number;
                name: string;
            }[];
            reason?: string | undefined;
        } | undefined;
    } | undefined;
}[], at?: number): (workId: string) => BudgetStatus[];
/** Сведения о вызове: попытка, предмет (поручение, группа, документ), стадия. */
export interface CallMeta {
    repositoryId?: string;
    runId?: string;
    subjectId?: string;
    /** Вид предмета: явный вид важнее совпадения ID с поручением. */
    subjectKind?: CallRecord['subjectKind'];
    stage: string;
    /**
     * Состав группы из входа вызова (ревью плана до регистрации графа): группа и
     * её поручения закрепляются за расходом на момент вызова, а не по составу,
     * который хранилище узнает позже.
     */
    group?: {
        id: string;
        workIds: string[];
    };
}
/**
 * Бюджеты вызова модели: по его попытке или поручению — бюджеты поручения; о
 * группе — бюджеты группы и каждого её открытого поручения, за которыми вызов
 * будет учтён; о прочем (контракт) — общий.
 */
export declare function callBudgets(c: BudgetContext, view: ExecutionView, meta: Pick<CallMeta, 'runId' | 'subjectId' | 'subjectKind' | 'group'>, records?: {
    id: string;
    stage: string;
    runtime: string;
    model: string | null;
    runtimeVersion: string | null;
    startedAt: string;
    outcome: "error" | "active" | "abandoned" | "returned";
    promptBytes: number;
    promptDigest: string;
    usage: {
        inputTokens: number | null;
        outputTokens: number | null;
        cacheReadTokens: number | null;
        cacheWriteTokens: number | null;
        reportedUsd: number | null;
        complete: boolean;
        source: "fixture" | "unavailable" | "codex-turn-events" | "claude-result";
    };
    costUsd: number | null;
    costSource: "unknown" | "provider-reported" | "tariff-estimate";
    repositoryId?: string | undefined;
    runId?: string | undefined;
    subjectId?: string | undefined;
    subjectKind?: "work" | "group" | "other" | undefined;
    finishedAt?: string | undefined;
    process?: {
        id: string;
        pid: number;
        startedAt?: number | undefined;
    } | undefined;
    abandonedAt?: string | undefined;
    durationMs?: number | undefined;
    elapsedMs?: number | undefined;
    startedHr?: string | undefined;
    durationUnknown?: true | undefined;
    bootId?: string | undefined;
    workId?: string | undefined;
    groupId?: string | undefined;
    workIds?: string[] | undefined;
    price?: {
        runtime: "codex" | "claude";
        model: string;
        effectiveAt: string;
        input: number;
        output: number;
        cacheRead: number;
        cacheWrite: number;
    } | undefined;
    diagnostics?: {
        startedAt: string;
        finishedAt: string;
        lastOutputAt: string | null;
        exitCode: number | null;
        signal: string | null;
        timedOut: boolean;
        aborted: boolean;
        stdoutTail: string;
        stderrTail: string;
        processTree?: {
            available: boolean;
            processes: {
                pid: number;
                parentPid: number;
                groupPid: number;
                name: string;
            }[];
            reason?: string | undefined;
        } | undefined;
    } | undefined;
}[], at?: number): BudgetStatus[];
/**
 * Поручение и группа вызова на момент вызова: за ними остаётся его расход.
 * У вызова о группе — её открытые поручения.
 */
export declare function callAttribution(c: BudgetContext, view: ExecutionView, meta: Pick<CallMeta, 'runId' | 'subjectId' | 'subjectKind' | 'group'>, all?: boolean): Pick<CallRecord, 'workId' | 'groupId' | 'workIds'>;
/** Бюджет, который запрещает тратить: превышен или не определён при `onUnknown: stop`. */
export declare function blockingBudget(c: BudgetContext, statuses: BudgetStatus[]): BudgetStatus | undefined;
/** Запрещает ли тратить бюджет в этом состоянии: превышен или не определён при `onUnknown: stop`. */
export declare function budgetBlocks(state: BudgetStatus['state'], onUnknown: 'stop' | 'continue' | undefined): boolean;
/** Отказ до траты: превышенный или неопределённый бюджет не даёт начать вызов. */
export declare function assertBudget(c: BudgetContext, statuses: BudgetStatus[]): void;
/** Компактный вид бюджета для статуса и потребителей. */
export declare function budgetView(b: BudgetStatus): {
    reason?: string | undefined;
    scope: BudgetScope;
    state: "exceeded" | "undetermined" | "within";
    limit: {
        usd?: number;
        timeMs?: number;
    };
    reportedUsd: number;
    estimatedUsd: number;
    unknownCalls: number;
    unfinishedCalls: number;
    abandonedCalls: number;
    errorCalls: number;
    uncoveredRuns: number;
    durationMs: number;
    remainingUsd: number | null;
    remainingMs: number | null;
};
/** Бюджеты установки: общий, группы с незавершённой работой, незавершённые поручения. */
export declare function budgetOverview(c: BudgetContext, view: ExecutionView, records?: CallRecord[]): {
    onUnknown: "continue" | "stop";
    budgets: {
        reason?: string | undefined;
        scope: BudgetScope;
        state: "exceeded" | "undetermined" | "within";
        limit: {
            usd?: number;
            timeMs?: number;
        };
        reportedUsd: number;
        estimatedUsd: number;
        unknownCalls: number;
        unfinishedCalls: number;
        abandonedCalls: number;
        errorCalls: number;
        uncoveredRuns: number;
        durationMs: number;
        remainingUsd: number | null;
        remainingMs: number | null;
    }[];
} | undefined;
