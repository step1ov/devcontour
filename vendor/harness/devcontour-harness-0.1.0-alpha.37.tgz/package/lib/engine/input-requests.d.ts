import { type ContextSnapshot, type ContextSourceEntry, type ExecutionView, type InputAnswer, type InputManifest, type InputRequest, type WorkState } from '../contracts/index.ts';
/**
 * Чтение запросов исполнителя (`input-requests`). Запрос хранится у
 * владельца — репозитория поручения; поиск по поручению идёт у его
 * владельца, без владельца — по всем.
 */
export declare function requestsOf(view: ExecutionView, work?: Pick<WorkState, 'id' | 'order'>): InputRequest[];
/**
 * `requestsOf` для многих поручений одного вида: записи пространства
 * читаются один раз, ответ по поручению — тот же, что у `requestsOf`
 * (владелец — репозиторий поручения, без него — все; тот же порядок).
 */
export declare function requestsIndex(view: ExecutionView): (work: Pick<WorkState, 'id' | 'order'>) => InputRequest[];
/**
 * Вопрос, держащий поручение: блокирующий запрос в `pending` или
 * `answered`. Это канонический блокер claim, retry (в том числе со сбросом),
 * repair и finish: `WorkState.hold` для него не занимается, и снятие чужого
 * удержания ожидания ответа не обходит.
 */
export declare function blockingRequest(view: ExecutionView, work: Pick<WorkState, 'id' | 'order'>): InputRequest | undefined;
/** Запрос по ID у любого владельца. */
export declare function requestById(view: ExecutionView, id: string): {
    owner: string;
    request: InputRequest;
} | undefined;
/** Сообщение обсуждения хоста, включённое в источник ответа: ID, версия и digest. */
export type InputMessageRef = InputManifest['messages'][number];
/**
 * Источник контекста с ответом на вопрос исполнителя (`input-answer`):
 * файл `input/<id>.md` — вопрос, варианты и ответ, их получат writer и оба
 * reviewer; справка `input/<id>.manifest.json` — точные запрос, digest и
 * версия ответа и включённые сообщения хоста. Версия источника — версия
 * ответа (`r<N>`), не ревизия Git. Источник неизменяем: новое сообщение или
 * ответ — новый источник и новый снимок.
 */
export declare function inputContextSource(request: InputRequest, answer: InputAnswer, messages?: InputMessageRef[]): ContextSourceEntry;
/** Снимок `base` с источником ответа (прежний источник того же запроса заменяется). */
export declare function withInput(base: ContextSnapshot | undefined, entry: ContextSourceEntry): ContextSnapshot;
/** Manifest источника ответа; источник другого вида или без manifest — `undefined`. */
export declare function inputManifestOf(source: ContextSourceEntry): InputManifest | undefined;
/**
 * Ответ заменённого запроса (`superseded`), перенесённый в контекст
 * преемника: продолжением исходной работы он не является — это сведения для
 * новой редакции. Запрос закрыт, блокировки нет; снимок называет ровно один
 * из записанных ответов.
 */
export declare const carried: (request: InputRequest, manifest: InputManifest, mayCarry: (request: InputRequest) => boolean) => boolean;
/**
 * Источники ответов снимка, которые ещё не применены `applyInput`: запрос не
 * найден, не применён или применён с другим ответом. Такой снимок не
 * становится действующим согласованием обходным путём (approve, run).
 */
export declare function unappliedInputs(view: ExecutionView, snapshot: ContextSnapshot | undefined, 
/**
 * Можно ли перенести ответ заменённого запроса сейчас — правило движка
 * (`(r) => engine.carryAllowed(view, r)`; то же делает
 * `Engine.unappliedInputs`). Обязателен: отметка `closed.carry` — лишь
 * сведение о моменте замены, решать по ней нельзя.
 */
mayCarry: (request: InputRequest) => boolean): {
    source: string;
    requestId?: string;
    reason: string;
}[];
