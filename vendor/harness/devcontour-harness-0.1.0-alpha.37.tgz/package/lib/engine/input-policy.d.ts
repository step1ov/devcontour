import { type Assumption, type ImplementationResult, type InputFloor, type InputPolicy, type InputQuestion, type RatedInput, type RecordedAssumption } from '../contracts/index.ts';
/**
 * Решение controller по ответу writer и закреплённой в попытке политике
 * вопросов (`AttemptState.inputPolicy`). Чистая функция: тот же ответ, та же
 * политика и те же изменённые пути дают тот же исход.
 *
 * Действующая серьёзность — самооценка модели, поднятая до потолка (10)
 * минимумами, которые модель понизить не может: вопрос или допущение
 * называет критическую область (`declared`) или попытка изменила
 * критический путь политики (`critical-path`).
 */
/** Оценка вопроса или допущения controller. */
export interface InputRating {
    effectiveSeverity: number;
    floors: InputFloor[];
}
/** Вопрос, которым кончилась попытка, с оценкой. */
export type RatedQuestion = RatedInput;
export type InputDecision = 
/** Остановка `needs-input`: вопрос writer или допущение не ниже порога. */
{
    kind: 'stop';
    question: RatedQuestion;
    fromAssumption: boolean;
}
/** Вопрос ниже порога: нарушение запроса, попытка — `unfinished`, вопрос записан отклонённым. */
 | {
    kind: 'declined';
    question: RatedQuestion;
}
/** `completed: false` без вопроса. */
 | {
    kind: 'unfinished';
}
/** `completed: true`, допущения ниже порога (или автономный режим). */
 | {
    kind: 'continue';
};
export interface InputEvaluation {
    decision: InputDecision;
    /** Допущения попытки с оценкой (все, включая превращённое в вопрос). */
    assumptions: RecordedAssumption[];
    /** Автономный режим: неблокирующие запросы ведущему по критическим развилкам. */
    followUps: RatedQuestion[];
    /** Изменённые критические пути (не больше 20). */
    criticalHits: string[];
}
/** Порог выше потолка серьёзности — автономный режим: остановок нет. */
export declare const autonomous: (policy: InputPolicy) => boolean;
/** Останавливает ли действующая серьёзность попытку при этой политике. */
export declare const stops: (policy: InputPolicy, effectiveSeverity: number) => boolean;
/** Допущение как вопрос: выбранный исполнителем вариант — единственный и рекомендуемый. */
export declare function assumptionQuestion(a: Assumption): InputQuestion;
export declare function evaluateInput(output: Pick<ImplementationResult, 'completed' | 'inputRequest' | 'assumptions'>, policy: InputPolicy, changedPaths: readonly string[]): InputEvaluation;
/** Раздел запроса writer: порог, шкала, критические области и пути, как задать вопрос. */
export declare function inputPolicyText(policy: InputPolicy): string;
/**
 * Ответ writer вне схемы, в котором есть вопрос: привести вопрос и
 * допущения к схеме (усечь текст до пределов, исправить ID вариантов, взять
 * первые шесть вариантов, ограничить серьёзность; неразборчивая серьёзность —
 * потолок), чтобы вопрос не потерялся, а исправленное было видно в запросе.
 * Схема договора остаётся строгой: результат проходит её целиком. Ответа без
 * вопроса функция не исправляет — `undefined`, отказ остаётся отказом.
 */
export declare function normalizeImplementation(raw: unknown): {
    output: ImplementationResult;
    issues: string[];
} | undefined;
