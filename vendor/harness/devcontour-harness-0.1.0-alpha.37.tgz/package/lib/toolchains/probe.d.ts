/**
 * Проба версии — единственный процесс, который запускает диагностика
 * toolchain: `<tool> --version` (у go — `go version`, у собранного без метки
 * версии Go-бинарника — `go version -m <файл>`, который только читает файл).
 * Каталог пробы — нейтральный временный: менеджер пакетов не должен увидеть
 * `packageManager` проекта и переключиться на другую версию.
 */
export interface ToolProbe {
    (argv: string[], options: {
        timeoutMs: number;
        env: NodeJS.ProcessEnv;
    }): Promise<{
        code: number;
        stdout: string;
        stderr: string;
        timedOut: boolean;
    }>;
}
export declare const PROBE_TIMEOUT_MS = 10000;
export declare const defaultProbe: ToolProbe;
/** Исполняемый файл из PATH (как его нашёл бы spawn) или undefined. */
export declare function resolveExecutable(name: string, path: string | undefined): string | undefined;
/** Версия из вывода пробы: первое `1.2.3`/`1.2` (в том числе `go1.24.5`, `v24.3.0`). */
export declare function versionOf(output: string): string | undefined;
/** Версия модуля в build info Go-бинарника (`go version -m`). */
export declare function moduleVersionOf(output: string): string | undefined;
/** Требование версии: `1.12.3` — названные компоненты совпадают, `>=1.24` — не ниже. */
export declare function satisfies(version: string, required: string): boolean;
/**
 * Версии менеджера, на которых хранилище зависимостей проверено настоящим
 * прогоном. Граница сверху — не осторожность: с pnpm 10.27.0 `pnpm fetch` кладёт
 * в store символическую ссылку `<store>/v10/projects/<hash>`, а seed с ссылками
 * отклоняется; с 11.0.0 pnpm ещё и не читает `npm_config_store_dir`. Вне диапазона
 * хранилище не вмешивается в окружение.
 */
export declare const dependencyStoreVersions: {
    readonly pnpm: {
        readonly from: "9.15.0";
        readonly below: "10.27.0";
    };
};
export declare function dependencyStoreSupports(manager: keyof typeof dependencyStoreVersions, version: string): boolean;
/** Версия менеджера из поля `packageManager`: `pnpm@10.12.3+sha512…` → `10.12.3`. */
export declare function declaredManagerVersion(field: unknown, manager: string): string | undefined;
