/** Файл больше предела: дальше предела он не читался. */
export declare class OversizedFile extends Error {
    readonly limit: number;
    constructor(limit: number);
}
/**
 * Текст файла, который пишет чужой процесс, не больше `limit` байт. Память
 * ограничена и тогда, когда файл растёт после проверки размера: читается
 * не больше `limit + 1` байта. Symlink не разыменовывается, FIFO без писателя
 * не держит `open` (O_NONBLOCK) и отклоняется как не обычный файл.
 */
export declare function readBounded(path: string, limit: number): Promise<string>;
