import { z } from 'zod';
import type { ProviderId, TaskColumn } from './transport.ts';
/**
 * Конфигурация коннектора внешнего хранилища задач.
 *
 * Provider выбирается явно (`relay-v1-http` | `relay-v2-cli`) и никогда не
 * угадывается по имени binary. `projectId` — ожидаемая идентичность проекта:
 * несовпадение с тем, что сообщил backend, блокирует любые мутации. Настройки
 * provider (`relay`) проверяет адаптер; ядро требует только минимально нужные
 * поля, чтобы ошибка была видна до подключения.
 */
export declare const providerIds: ["relay-v1-http", "relay-v2-cli"];
export declare const taskColumns: ["inbox", "ready", "in-progress", "review", "done", "cancelled"];
/** Сопоставление критерия задачи с доказательством принятого результата. */
export declare const criterionMappingSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodOptional<z.ZodString>;
    gate: z.ZodString;
    testId: z.ZodOptional<z.ZodString>;
    evidence: z.ZodDefault<z.ZodEnum<{
        gate: "gate";
        test: "test";
    }>>;
}, z.core.$strict>;
export type CriterionMapping = z.infer<typeof criterionMappingSchema>;
export declare const taskMappingSchema: z.ZodObject<{
    ref: z.ZodString;
    role: z.ZodDefault<z.ZodString>;
    repositoryId: z.ZodOptional<z.ZodString>;
    writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
    gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
    criteria: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        gate: z.ZodString;
        testId: z.ZodOptional<z.ZodString>;
        evidence: z.ZodDefault<z.ZodEnum<{
            gate: "gate";
            test: "test";
        }>>;
    }, z.core.$strict>>>;
    requiredDocuments: z.ZodDefault<z.ZodArray<z.ZodString>>;
    context: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export type TaskMapping = z.infer<typeof taskMappingSchema>;
/**
 * Базовая линия: зависимости, закрытые до внедрения harness, принимает человек.
 * Только явные ключи задач и один полный SHA: без шаблонов, дат и общего
 * переключателя. Это решение оператора, а не доказательство результата.
 */
export declare const baselineSchema: z.ZodObject<{
    sha: z.ZodString;
    tasks: z.ZodArray<z.ZodString>;
    reason: z.ZodString;
}, z.core.$strict>;
export type Baseline = z.infer<typeof baselineSchema>;
export declare const connectorConfigSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    provider: z.ZodLiteral<"relay-v1-http">;
    relay: z.ZodIntersection<z.ZodRecord<z.ZodString, z.ZodUnknown>, z.ZodObject<{
        endpoint: z.ZodString;
    }, z.core.$loose>>;
    version: z.ZodLiteral<1>;
    projectId: z.ZodString;
    actor: z.ZodString;
    stateDir: z.ZodOptional<z.ZodString>;
    contextDir: z.ZodOptional<z.ZodString>;
    repository: z.ZodObject<{
        id: z.ZodString;
        path: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    tasks: z.ZodArray<z.ZodObject<{
        ref: z.ZodString;
        role: z.ZodDefault<z.ZodString>;
        repositoryId: z.ZodOptional<z.ZodString>;
        writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
        gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        criteria: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            gate: z.ZodString;
            testId: z.ZodOptional<z.ZodString>;
            evidence: z.ZodDefault<z.ZodEnum<{
                gate: "gate";
                test: "test";
            }>>;
        }, z.core.$strict>>>;
        requiredDocuments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        context: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    baseline: z.ZodOptional<z.ZodObject<{
        sha: z.ZodString;
        tasks: z.ZodArray<z.ZodString>;
        reason: z.ZodString;
    }, z.core.$strict>>;
    completion: z.ZodDefault<z.ZodObject<{
        mode: z.ZodDefault<z.ZodEnum<{
            complete: "complete";
            "review-only": "review-only";
        }>>;
        column: z.ZodOptional<z.ZodEnum<{
            ready: "ready";
            review: "review";
            cancelled: "cancelled";
            done: "done";
            "in-progress": "in-progress";
            inbox: "inbox";
        }>>;
        historicalComment: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    eligibility: z.ZodDefault<z.ZodObject<{
        columns: z.ZodDefault<z.ZodArray<z.ZodEnum<{
            ready: "ready";
            review: "review";
            cancelled: "cancelled";
            done: "done";
            "in-progress": "in-progress";
            inbox: "inbox";
        }>>>;
    }, z.core.$strict>>;
    limits: z.ZodDefault<z.ZodObject<{
        documents: z.ZodDefault<z.ZodNumber>;
        documentBytes: z.ZodDefault<z.ZodNumber>;
        totalBytes: z.ZodDefault<z.ZodNumber>;
        taskBytes: z.ZodDefault<z.ZodNumber>;
        rereads: z.ZodDefault<z.ZodNumber>;
        leaseMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
    history: z.ZodDefault<z.ZodObject<{
        enabled: z.ZodDefault<z.ZodBoolean>;
        client: z.ZodDefault<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    provider: z.ZodLiteral<"relay-v2-cli">;
    relay: z.ZodIntersection<z.ZodRecord<z.ZodString, z.ZodUnknown>, z.ZodObject<{
        binary: z.ZodString;
        config: z.ZodString;
        project: z.ZodOptional<z.ZodString>;
        env: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$loose>>;
    version: z.ZodLiteral<1>;
    projectId: z.ZodString;
    actor: z.ZodString;
    stateDir: z.ZodOptional<z.ZodString>;
    contextDir: z.ZodOptional<z.ZodString>;
    repository: z.ZodObject<{
        id: z.ZodString;
        path: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    tasks: z.ZodArray<z.ZodObject<{
        ref: z.ZodString;
        role: z.ZodDefault<z.ZodString>;
        repositoryId: z.ZodOptional<z.ZodString>;
        writeScope: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<".">, z.ZodString]>>;
        gates: z.ZodOptional<z.ZodArray<z.ZodString>>;
        criteria: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            gate: z.ZodString;
            testId: z.ZodOptional<z.ZodString>;
            evidence: z.ZodDefault<z.ZodEnum<{
                gate: "gate";
                test: "test";
            }>>;
        }, z.core.$strict>>>;
        requiredDocuments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        context: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    baseline: z.ZodOptional<z.ZodObject<{
        sha: z.ZodString;
        tasks: z.ZodArray<z.ZodString>;
        reason: z.ZodString;
    }, z.core.$strict>>;
    completion: z.ZodDefault<z.ZodObject<{
        mode: z.ZodDefault<z.ZodEnum<{
            complete: "complete";
            "review-only": "review-only";
        }>>;
        column: z.ZodOptional<z.ZodEnum<{
            ready: "ready";
            review: "review";
            cancelled: "cancelled";
            done: "done";
            "in-progress": "in-progress";
            inbox: "inbox";
        }>>;
        historicalComment: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    eligibility: z.ZodDefault<z.ZodObject<{
        columns: z.ZodDefault<z.ZodArray<z.ZodEnum<{
            ready: "ready";
            review: "review";
            cancelled: "cancelled";
            done: "done";
            "in-progress": "in-progress";
            inbox: "inbox";
        }>>>;
    }, z.core.$strict>>;
    limits: z.ZodDefault<z.ZodObject<{
        documents: z.ZodDefault<z.ZodNumber>;
        documentBytes: z.ZodDefault<z.ZodNumber>;
        totalBytes: z.ZodDefault<z.ZodNumber>;
        taskBytes: z.ZodDefault<z.ZodNumber>;
        rereads: z.ZodDefault<z.ZodNumber>;
        leaseMs: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
    history: z.ZodDefault<z.ZodObject<{
        enabled: z.ZodDefault<z.ZodBoolean>;
        client: z.ZodDefault<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>], "provider">;
export type ConnectorConfig = z.infer<typeof connectorConfigSchema>;
export type ConnectorConfigInput = z.input<typeof connectorConfigSchema>;
/** Загруженная конфигурация и каталог, от которого разрешаются её относительные пути. */
export interface LoadedConfig {
    config: ConnectorConfig;
    baseDir: string;
    file?: string;
}
export declare function parseConfig(value: unknown, baseDir: string, file?: string): LoadedConfig;
export declare function loadConfig(path: string): LoadedConfig;
export declare const resolveFrom: (baseDir: string, path: string) => string;
/** ID коннектора (WorkSource/ResultSink и доверенный издатель receipts): provider + проект. */
export declare const connectorIdOf: (provider: ProviderId, projectId: string) => string;
/** Стабильная идентичность задачи: backend, проект и постоянный ID задачи. */
export declare const taskIdentity: (provider: ProviderId, projectId: string, taskId: string) => string;
export declare function parseIdentity(identity: string): {
    provider: ProviderId;
    projectId: string;
    taskId: string;
} | undefined;
/** ID поручения по идентичности задачи: одинаковые номера разных проектов/backend не совпадают. */
export declare const orderIdOf: (provider: ProviderId, projectId: string, taskId: string) => string;
export declare const contextIdOf: (orderId: string) => string;
/** ID графа по набору задач конфигурации. */
export declare const graphIdOf: (provider: ProviderId, projectId: string, taskIds: string[]) => string;
/** Digest сопоставления задачи: входит в semantic digest — смена mapping требует нового согласования. */
export declare const mappingDigest: (config: ConnectorConfig, mapping: TaskMapping) => string;
/**
 * Запись базовой линии для зависимости; её digest — receipt предпосылки. Вся
 * `baseline` внутри: любая её правка отзывает выданные предпосылки.
 */
export declare const baselineRecord: (config: ConnectorConfig, key: string, orderId: string, repositoryId: string) => {
    kind: string;
    issuer: string;
    key: string;
    orderId: string;
    repositoryId: string;
    baseline: {
        sha: string;
        tasks: string[];
        reason: string;
    } | undefined;
};
/** Колонка завершения по правилам конфигурации. */
export declare const completionColumn: (config: ConnectorConfig) => TaskColumn;
/** Файл хранилища коннектора внутри каталога состояния. */
export declare const storeFileOf: (stateDir: string, provider: ProviderId, projectId: string) => string;
