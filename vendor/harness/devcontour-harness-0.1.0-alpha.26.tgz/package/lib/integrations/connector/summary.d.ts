import type { RunResult } from '../../contracts/index.ts';
import { type Redactor } from '../../environment/redaction.ts';
/**
 * Краткий итог для внешнего хранилища задач. В нём: исход, проверяемые SHA,
 * сводка gates, сопоставление критериев, источник снимка и receipt. Не
 * попадают: полный runtime log, вызовы инструментов, локальные пути (они не
 * являются ссылками, доступными с другого компьютера), lease/fencing токены
 * и секреты (маскируются `redact`).
 */
export interface CriterionOutcome {
    criterionId: string;
    title: string;
    gate?: string;
    testId?: string;
    /** `closed` — закрыт этой доставкой; `already` — уже был отмечен; остальные — блокеры. */
    outcome: 'closed' | 'already' | 'unproven' | 'manual';
    reason?: string;
}
export declare const stripPaths: (text: string) => string;
export declare function summaryText(input: {
    marker: string;
    result: RunResult;
    task: {
        key: string;
        identity: string;
    };
    snapshot: {
        revision: string;
        casRevision: number;
    };
    criteria: CriterionOutcome[];
    completion: string;
    historical?: boolean;
    /** Зависимости задачи, принятые человеком по базовой линии (не доказаны). */
    baseline?: {
        tasks: string[];
        sha: string;
        reason: string;
    };
    redact?: Redactor;
}): {
    title: string;
    body: string;
};
